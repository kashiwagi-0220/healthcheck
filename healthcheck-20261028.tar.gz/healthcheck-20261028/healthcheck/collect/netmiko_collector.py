"""
healthcheck.collect.netmiko_collector — netmiko による実収集エンジン(実機用)

CliCollector 抽象の実装。1機器に netmiko(Paramiko ベース)で接続し、CliJob.commands
を順次実行して CollectResult を返す。netmiko は重い依存のため、Genie/TextFSM と同じく
import は実行時(遅延)に行う。未導入なら pip ヒント付きの ImportError を投げる
(未導入という設定ミスを、個別機器の失敗として握りつぶさず明示するため)。

接続・コマンドの失敗は例外を投げず、CollectResult / CommandResult に success=False +
error として記録する(ファサードが完了順にまとめ、一過性の失敗だけ再試行できるように)。
踏み台(バスチョン)経由でしか到達できない機器向けに、ssh_config_file は netmiko
(Paramiko)の範囲で調整できるよう、そのまま ConnectHandler に渡す口を用意する。

接続開始・接続成功/失敗・コマンドごとの実行開始・完了/失敗・切断を標準の `logging`
(`logging.getLogger(__name__)`)で記録する(コマンド単位の実行状況を後から確認できる
ようにするため)。ログの出力先(標準出力・ファイル等)はこのモジュールでは決めず、
アプリ全体のエントリポイント(GUIの場合は gui/backend/app/logging_config.py)が
`logging` の設定で決める。

- ssh_config_file: OpenSSH 形式の設定ファイル(paramiko.SSHConfig でパースされる)。
  例えば
    Host 192.168.*.*
        ProxyJump bastion.example.com
  (Host はグロブパターンでマッチする。CIDR表記は使えない)と書いたファイルのパスを
  渡すと、そのファイルの Host 単位の設定(ProxyJump 等)が接続に反映される。
  config/proxy.conf に実例あり。

netmiko 語彙への変換(_VENDOR_TYPE_TO_NETMIKO / netmiko_type_for):
  Device は vendor + type(command_catalog のディレクトリ名+ファイル名に対応)を持ち、
  利用者が自由に決められる分類名であって netmiko 独自の語彙とは限らない。netmiko の
  ConnectHandler(device_type=...)には netmiko 独自の語彙(例 "cisco_ios")を渡す必要が
  あるため、ここで変換する(cisco/apic は netmiko 側にも同名の実在ドライバ
  (CiscoApicSSH)があり偶然一致するが、これは意図せぬ一致であり、両者が別概念である
  ことに変わりはない)。対応表は vendor → type → netmiko 語彙 の2階層辞書として持つ。
  Genie・TextFSM(ntc-templates)もそれぞれ独自の語彙を必要とするが、変換表は各パーサが
  自分専用に持つ(healthcheck.parse.genie_parser の _VENDOR_TYPE_TO_GENIE、
  healthcheck.parse.textfsm_parser の _VENDOR_TYPE_TO_TEXTFSM)。parse層がcollect層に
  依存しないよう、この3つの対応表はあえて共有しない。
  対応表は vendor/type と netmiko 語彙が同じ場合(例 "cisco"→"ios"→"cisco_ios")も含め、
  CLI で使う組み合わせは全て明示的に書く(_VENDOR_TYPE_TO_NETMIKO に無い組み合わせは
  「netmiko 語彙が未登録」として netmiko_type_for() がエラーにする。暗黙にそのまま
  使う既定は持たない。command_catalog に既定を持たせない方針と同じ考え方)。
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

from healthcheck.models import CliJob, CommandResult, CollectResult
from healthcheck.collect.base import CliCollector, CredentialProvider

logger = logging.getLogger(__name__)

# カタログ vendor -> type -> netmiko の device_type 語彙。CLI で使う組み合わせは
# 同じ語彙になる場合も含め全て明示的に書く(暗黙の既定は持たない)。
_VENDOR_TYPE_TO_NETMIKO: dict[str, dict[str, str]] = {
    "cisco": {
        "ios": "cisco_ios",
        "nxos": "cisco_nxos",
        "iosxe": "cisco_xe",  # netmiko側の実在ドライバ名は "cisco_xe"(iosxeではない)
        "apic": "cisco_apic",  # netmiko 側の実在ドライバ名(CiscoApicSSH)と偶然同じ。将来 CLI/SSH 収集を追加する場合用
        "asa": "cisco_asa",
    },
    "f5": {
        "bigip": "f5_tmsh",    # netmiko 側の実在ドライバ名(F5TmshSSH)。将来 CLI/SSH 収集を追加する場合用
    },
    "paloalto": {
        "panos": "paloalto_panos",  # netmiko 側の実在ドライバ名(PaloAltoPanosSSH)と偶然同じ
    },
}


# netmiko のドライバが「送ったコマンドの表示し返しの確認」(cmd_verify)を無効にしている
# 機種のうち、このアプリでは有効に戻すもの(netmiko の device_type 語彙)。
#
# この確認が無効だと、出力が途切れ途切れに届いたとき(踏み台経由で多数の機器を並列に
# 取得し、受信が遅れたときなど)に netmiko のプロンプト判定がずれる。遅れて届いた古い
# プロンプトで前のコマンドが出力の途中で打ち切られ、その続きの行を次のコマンドの
# プロンプトと取り違えて、read_timeout まで待ち続けてしまう。確認が有効なら、
# 表示し返しより前に残った古いプロンプトを netmiko が取り除くため、ずれが起きない。
#
# - cisco_asa: ドライバは端末幅を広げない場合(allow_auto_change=False。True は機器の
#   設定 "terminal width" を書き換えるため使わない)に、長いコマンドの折り返しで照合に
#   失敗するのを避けて無効にしている。このアプリの ASA のコマンドは短く、既定の端末幅
#   (80桁)にプロンプトを足しても折り返さないため、有効に戻してよい。ASA のコマンド
#   セット・カタログには、プロンプトと合わせて端末幅に収まる長さのコマンドだけを使う
#   (超えると表示し返しの確認に 10 秒待って失敗する)。
#
# 無効にする理由が別の機種は加えない(例: Nokia SR OS の従来の CLI はスペースで
# コマンドが自動補完され、表示し返しが長さに関係なく一致しないため、有効にすると
# 全コマンドが失敗する)。機種を増やすときは、そのドライバが無効にしている理由を確認して
# 判断する。
_CMD_VERIFY_REENABLED: frozenset[str] = frozenset({"cisco_asa"})


def netmiko_type_for(vendor: str, type: str) -> str:
    """カタログの vendor + type から netmiko の device_type 語彙を返す。

    _VENDOR_TYPE_TO_NETMIKO に無ければ ValueError(暗黙にそのまま使う既定は持たない。
    CLI で収集する組み合わせは必ず明示的に登録する)。NetmikoCollector がこの関数を
    呼んで netmiko 語彙を解決する。
    """
    netmiko_type = _VENDOR_TYPE_TO_NETMIKO.get(vendor, {}).get(type)
    if netmiko_type is None:
        raise ValueError(
            f"vendor='{vendor}' type='{type}' の netmiko 語彙が _VENDOR_TYPE_TO_NETMIKO に"
            "登録されていません(healthcheck/collect/netmiko_collector.py)。"
            "CLI で収集する組み合わせは明示的に登録してください。"
        )
    return netmiko_type


class NetmikoCollector(CliCollector):
    """netmiko で1機器に接続し、コマンド群を順次実行するエンジン。"""

    def __init__(
        self,
        read_timeout: float = 10.0,
        conn_timeout: float = 10.0,
        ssh_config_file: str | None = None,
    ):
        self.read_timeout = read_timeout   # コマンド出力待ち(send_command の read_timeout)
        self.conn_timeout = conn_timeout   # TCP 接続確立のタイムアウト
        self.ssh_config_file = ssh_config_file

    def collect_device(self, job: CliJob, credentials: CredentialProvider) -> CollectResult:
        try:
            from netmiko import ConnectHandler
            from netmiko.exceptions import NetmikoAuthenticationException, NetmikoTimeoutException
        except ImportError as e:
            raise ImportError(
                "netmiko が未導入です。'pip install netmiko' が必要です。"
            ) from e

        device = job.device
        creds = credentials.resolve(device)
        started_at = datetime.now(timezone.utc)

        conn_params: dict[str, Any] = {
            "device_type": netmiko_type_for(device.vendor, device.type),
            "host": device.ip or device.host,     # ip があれば優先(DNS 非解決環境向け)
            "port": device.port,
            "username": creds.username,
            "password": creds.password,
            "conn_timeout": self.conn_timeout,
            # ConnectHandler の timeout は delay_factor_compat 専用(netmiko 4系以降は
            # 実質不使用)なのでここには渡さない。コマンド出力待ちは send_command 側の
            # read_timeout で制御する(下記)。
        }
        if creds.secret:
            conn_params["secret"] = creds.secret
        if self.ssh_config_file:
            conn_params["ssh_config_file"] = self.ssh_config_file

        logger.info("%s: 接続開始 (%s:%s)", device.host, conn_params["host"], device.port)
        try:
            conn = ConnectHandler(**conn_params)
        except NetmikoAuthenticationException as e:
            logger.warning("%s: 接続失敗(認証) - %s", device.host, e)
            return CollectResult(
                device=device, success=False, error=f"authentication failed: {e}",
                started_at=started_at, finished_at=datetime.now(timezone.utc),
            )
        except NetmikoTimeoutException as e:
            logger.warning("%s: 接続失敗(タイムアウト) - %s", device.host, e)
            return CollectResult(
                device=device, success=False, error=f"connection timeout: {e}",
                started_at=started_at, finished_at=datetime.now(timezone.utc),
            )
        except Exception as e:
            logger.warning("%s: 接続失敗 - %r", device.host, e)
            return CollectResult(
                device=device, success=False, error=repr(e),
                started_at=started_at, finished_at=datetime.now(timezone.utc),
            )
        logger.info("%s: 接続成功", device.host)
        if conn_params["device_type"] in _CMD_VERIFY_REENABLED:
            # None は「ドライバとしての指定なし」で、send_command の既定(確認あり)に戻る。
            conn.global_cmd_verify = None

        outputs: dict[str, CommandResult] = {}
        all_ok = True
        try:
            if creds.secret:
                conn.enable()
            for cmd in job.commands:
                cmd_started = datetime.now(timezone.utc)
                logger.info("%s: コマンド実行開始 - %s", device.host, cmd)
                try:
                    raw = conn.send_command(cmd, read_timeout=self.read_timeout)
                    outputs[cmd] = CommandResult(
                        command=cmd, success=True, raw=raw,
                        started_at=cmd_started, finished_at=datetime.now(timezone.utc),
                    )
                    logger.info("%s: コマンド完了 - %s", device.host, cmd)
                except Exception as e:
                    all_ok = False
                    outputs[cmd] = CommandResult(
                        command=cmd, success=False, error=repr(e),
                        started_at=cmd_started, finished_at=datetime.now(timezone.utc),
                    )
                    logger.warning("%s: コマンド失敗 - %s: %r", device.host, cmd, e)
        finally:
            conn.disconnect()
            logger.info("%s: 切断", device.host)

        return CollectResult(
            device=device, success=all_ok, outputs=outputs,
            started_at=started_at, finished_at=datetime.now(timezone.utc),
        )
