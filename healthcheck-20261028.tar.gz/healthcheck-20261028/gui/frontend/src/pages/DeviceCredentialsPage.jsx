import { useEffect, useState } from "react";
import { getCredentials, setDefaultCredential, setHostCredential, deleteHostCredential } from "../api/client";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { TextFilter } from "@/components/TableFilters";
import HighlightMatch from "@/components/HighlightMatch";
import { EMPTY_TEXT_QUERY, compileTextQuery } from "@/lib/textQuery";

const DEFAULT_LABEL = "デフォルト";

// 作成・編集共通のフォーム(CommandSetsPage の CommandSetForm を参考にした形)。
// host は「デフォルト」行の編集時・既存ホスト行の編集時は変更不可(表示のみ)。
// 新規追加時のみ入力でき、予約語「デフォルト」は使えない(default 行と衝突するため)。
function CredentialForm({ host, initial, onCancel, onSubmit, submitLabel, showHostInput }) {
  const [hostInput, setHostInput] = useState(host ?? "");
  const [username, setUsername] = useState(initial?.username ?? "");
  const [password, setPassword] = useState(initial?.password ?? "");
  const [secret, setSecret] = useState(initial?.secret ?? "");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  const handleSubmit = () => {
    if (showHostInput) {
      if (!hostInput.trim()) {
        setError("ホスト名を入力してください。");
        return;
      }
      if (hostInput.trim() === DEFAULT_LABEL) {
        setError(`'${DEFAULT_LABEL}' は予約されています。別のホスト名を使用してください。`);
        return;
      }
    }
    if (!username.trim() || !password) {
      setError("ユーザ名 / パスワード を入力してください。");
      return;
    }
    setSaving(true);
    setError(null);
    const payload = { username: username.trim(), password, secret: secret || null };
    onSubmit(showHostInput ? hostInput.trim() : host, payload)
      .catch((e) => setError(e.message))
      .finally(() => setSaving(false));
  };

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-4 gap-3">
        <div className="space-y-1">
          <Label className="text-sm font-semibold">ホスト名</Label>
          {showHostInput ? (
            <Input className="h-8" placeholder="例: RT-05" value={hostInput} onChange={(e) => setHostInput(e.target.value)} />
          ) : (
            <Input className="h-8" value={host} disabled />
          )}
        </div>
        <div className="space-y-1">
          <Label className="text-sm font-semibold">ユーザ名</Label>
          <Input className="h-8" value={username} onChange={(e) => setUsername(e.target.value)} />
        </div>
        <div className="space-y-1">
          <Label className="text-sm font-semibold">パスワード</Label>
          <Input className="h-8" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
        </div>
        <div className="space-y-1">
          <Label className="text-sm font-semibold">enableパスワード(任意)</Label>
          <Input className="h-8" type="password" value={secret} onChange={(e) => setSecret(e.target.value)} />
        </div>
      </div>

      {error && <p className="text-sm text-destructive">{error}</p>}
      <div className="flex items-center gap-2">
        <Button size="sm" onClick={handleSubmit} disabled={saving}>
          {saving ? "保存中..." : submitLabel}
        </Button>
        <Button size="sm" variant="outline" onClick={onCancel} disabled={saving}>
          キャンセル
        </Button>
      </div>
    </div>
  );
}

export default function DeviceCredentialsPage() {
  const [credentials, setCredentials] = useState(null);
  const [error, setError] = useState(null);
  const [creating, setCreating] = useState(false);
  const [editingKey, setEditingKey] = useState(null); // "default" またはホスト名
  const [hostFilter, setHostFilter] = useState(EMPTY_TEXT_QUERY);

  const reload = () => getCredentials().then(setCredentials).catch((e) => setError(e.message));
  useEffect(() => {
    reload();
  }, []);

  const handleSaveDefault = (_host, payload) =>
    setDefaultCredential(payload).then(() => { setEditingKey(null); return reload(); });
  const handleCreateHost = (host, payload) =>
    setHostCredential(host, payload).then(() => { setCreating(false); return reload(); });
  const handleUpdateHost = (host) => (_host, payload) =>
    setHostCredential(host, payload).then(() => { setEditingKey(null); return reload(); });
  const handleDeleteHost = (host) => {
    if (!window.confirm(`'${host}' の認証情報の上書きを削除しますか?`)) return;
    deleteHostCredential(host).then(reload).catch((e) => setError(e.message));
  };

  if (!credentials) {
    return error ? <p className="text-sm text-destructive">{error}</p> : null;
  }

  const hostEntries = Object.entries(credentials.hosts);
  const hostMatcher = compileTextQuery(hostFilter);
  const filteredHostEntries = hostEntries.filter(([host]) => hostMatcher.test(host));

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          {filteredHostEntries.length + 1} / {hostEntries.length + 1} 件(デフォルトを含む)
        </p>
        <Button size="sm" onClick={() => { setEditingKey(null); setCreating((v) => !v); }}>
          <Plus /> 追加
        </Button>
      </div>
      {error && <p className="text-sm text-destructive">{error}</p>}

      <Table containerClassName="max-h-[78vh] overflow-y-auto rounded-md border bg-card">
          <TableHeader className="sticky top-0 z-10 bg-muted">
            <TableRow>
              <TableHead>ホスト名</TableHead>
              <TableHead>ユーザ名</TableHead>
              <TableHead>パスワード</TableHead>
              <TableHead>enableパスワード</TableHead>
              <TableHead>操作</TableHead>
            </TableRow>
            <TableRow className="hover:bg-transparent">
              <TableHead className="py-1.5">
                <TextFilter value={hostFilter} onChange={setHostFilter} placeholder="絞り込み" />
              </TableHead>
              <TableHead className="py-1.5" />
              <TableHead className="py-1.5" />
              <TableHead className="py-1.5" />
              <TableHead className="py-1.5" />
            </TableRow>
          </TableHeader>
          <TableBody>
            <TableRow className="hover:bg-accent">
              <TableCell className="font-medium">{DEFAULT_LABEL}</TableCell>
              <TableCell>{credentials.default.username}</TableCell>
              <TableCell className="text-muted-foreground">{credentials.default.password ? "*****" : "-"}</TableCell>
              <TableCell className="text-muted-foreground">{credentials.default.secret ? "*****" : "-"}</TableCell>
              <TableCell>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => { setCreating(false); setEditingKey("default"); }}
                >
                  <Pencil />
                </Button>
              </TableCell>
            </TableRow>

            {filteredHostEntries.map(([host, entry]) => (
              <TableRow key={host} className="hover:bg-accent">
                <TableCell className="font-medium">
                  <HighlightMatch text={host} matcher={hostMatcher} />
                </TableCell>
                <TableCell>{entry.username}</TableCell>
                <TableCell className="text-muted-foreground">{entry.password ? "*****" : "-"}</TableCell>
                <TableCell className="text-muted-foreground">{entry.secret ? "*****" : "-"}</TableCell>
                <TableCell>
                  <div className="flex gap-1">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => { setCreating(false); setEditingKey(host); }}
                    >
                      <Pencil />
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => handleDeleteHost(host)}>
                      <Trash2 />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
      </Table>

      <Dialog
        open={creating || editingKey !== null}
        onClose={() => { setCreating(false); setEditingKey(null); }}
        title={
          creating
            ? "認証情報を追加"
            : editingKey === "default"
              ? "デフォルト認証情報を編集"
              : `認証情報を編集: ${editingKey}`
        }
        className="max-w-3xl"
      >
        {creating && (
          <CredentialForm
            showHostInput
            submitLabel="追加"
            onCancel={() => setCreating(false)}
            onSubmit={handleCreateHost}
          />
        )}
        {editingKey === "default" && (
          <CredentialForm
            host={DEFAULT_LABEL}
            initial={credentials.default}
            submitLabel="保存"
            onCancel={() => setEditingKey(null)}
            onSubmit={handleSaveDefault}
          />
        )}
        {editingKey !== null && editingKey !== "default" && (
          <CredentialForm
            host={editingKey}
            initial={credentials.hosts[editingKey]}
            submitLabel="保存"
            onCancel={() => setEditingKey(null)}
            onSubmit={handleUpdateHost(editingKey)}
          />
        )}
      </Dialog>
    </div>
  );
}
