import { useEffect, useMemo, useState } from "react";
import {
  getCommandCatalog,
  createCommandCatalogEntry,
  updateCommandCatalogEntry,
  deleteCommandCatalogEntry,
  commandCatalogFilesUrl,
  uploadCommandCatalogFiles,
} from "../api/client";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { deviceVendorColor, deviceTypeColor } from "@/lib/deviceTypeColor";
import { TextFilter, SelectFilter } from "@/components/TableFilters";
import HighlightMatch from "@/components/HighlightMatch";
import { EMPTY_TEXT_QUERY, compileTextQuery } from "@/lib/textQuery";
import FileTransferButtons from "@/components/FileTransferButtons";
import Pagination from "@/components/Pagination";
import { usePageRange, usePageSlice } from "@/hooks/usePagination";

// REST 由来のコマンドは収集時に必ず parser: json を使う(コア側の不変条件。
// healthcheck/command/command_catalog.py 参照)ため、parser の値だけで CLI/REST を判別できる。
function typeOf(parser) {
  return parser === "json" ? "REST" : "CLI";
}

// 「比較キー」列の表示・絞り込みで共有する判定。compare_keys は TextFSM の
// list→dict化用途に加え、ネストした list(dict の値としての list。例 APIC の
// imdata)にも使える(healthcheck/common/diff.py 参照)が、genie はパース結果が
// 常にトップレベル dict
// (healthcheck.common.diff の docstring 参照)のため compare_keys が意味を持たない。
// genie のみ "-" とし、それ以外(textfsm/json)は設定有無で判定する。
function keyStatusOf(spec) {
  if (spec.parser === "genie") return "-";
  return spec.compare_keys ? "設定済み" : "未設定";
}

// catalog は GET /command-catalog のレスポンスそのまま(vendor -> type -> {command: spec}
// の3階層。コア側の CommandCatalog.by_vendor_type と同じ階層構造)。
function flatten(catalog) {
  const rows = [];
  for (const [vendor, types] of Object.entries(catalog)) {
    for (const [type, commands] of Object.entries(types)) {
      for (const [command, spec] of Object.entries(commands)) {
        rows.push({ vendor, type, command, spec });
      }
    }
  }
  // ベンダー > タイプ > コマンド名 の昇順。
  rows.sort((a, b) => a.vendor.localeCompare(b.vendor) || a.type.localeCompare(b.type) || a.command.localeCompare(b.command));
  return rows;
}

const EMPTY_FILTERS = { vendor: "", type: "", command: EMPTY_TEXT_QUERY, type_: "", parser: "", keyStatus: "" };

// 作成・編集共通のフォーム。vendor/type/command は作成時のみ入力できる(編集時は
// 変更不可。キーそのものの変更はここでは扱わない。CommandSetForm 等と同じ考え方)。
// 新規作成時のベンダー・タイプは、既存カタログに実在するもの(catalog)から選ぶ
// プルダウンにする(CommandSetForm と同じ考え方。表記ゆれを防ぐため)。
function CommandCatalogEntryForm({ vendor, type, command, initial, catalog, onCancel, onSubmit, submitLabel }) {
  const isNew = !vendor;
  const [vendorInput, setVendorInput] = useState(vendor ?? "");
  const [typeInput, setTypeInput] = useState(type ?? "");
  const [commandInput, setCommandInput] = useState(command ?? "");
  // 種別(CLI/REST)を明示的に選ばせる(parser の値だけから連想させない。REST は
  // 常に parser: json 固定なので、種別=REST を選んだ時点で parser は自動的に
  // "json" にする)。
  const [entryType, setEntryType] = useState(initial ? typeOf(initial.parser) : "CLI");
  const [parser, setParser] = useState(initial?.parser ?? "genie");
  const [noise, setNoise] = useState((initial?.noise ?? []).join("\n"));
  const [compareKeys, setCompareKeys] = useState((initial?.compare_keys ?? []).join("\n"));
  const [path, setPath] = useState(initial?.path ?? "");
  const [description, setDescription] = useState(initial?.description ?? "");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  const isRest = entryType === "REST";
  const vendorOptions = useMemo(() => Object.keys(catalog ?? {}).sort(), [catalog]);
  const typeOptions = useMemo(
    () => Object.keys(catalog?.[vendorInput] ?? {}).sort(),
    [catalog, vendorInput]
  );

  const handleVendorChange = (value) => {
    setVendorInput(value);
    // vendor が変わったら type をリセットする(別ベンダーの type を引き継がない)。
    setTypeInput("");
  };

  const handleEntryTypeChange = (value) => {
    setEntryType(value);
    if (value === "REST") {
      setParser("json");
    } else if (parser === "json") {
      setParser("genie");
    }
  };

  const handleSubmit = () => {
    if (isNew && (!vendorInput || !typeInput || !commandInput.trim())) {
      setError("ベンダー・タイプ・コマンドを入力してください。");
      return;
    }
    if (isRest && !path.trim()) {
      setError("種別がRESTの場合は path を指定してください。");
      return;
    }
    setSaving(true);
    setError(null);
    const payload = {
      parser,
      noise: noise.split("\n").map((s) => s.trim()).filter(Boolean),
      // genie はパース結果が常にトップレベル dict のため compare_keys が意味を
      // 持たない(keyStatusOf と同じ判定)。入力欄を無効化しているだけでなく、
      // 過去に設定された値が残っていても保存時に確実に null にする。
      compare_keys:
        parser !== "genie" && compareKeys.trim()
          ? compareKeys.split("\n").map((s) => s.trim()).filter(Boolean)
          : null,
      method: "get",
      path: isRest ? path.trim() : null,
      description: description.trim() || null,
    };
    if (isNew) {
      payload.vendor = vendorInput;
      payload.type = typeInput;
      payload.command = commandInput.trim();
    }
    onSubmit(payload)
      .catch((e) => setError(e.message))
      .finally(() => setSaving(false));
  };

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-4 gap-3">
        <div className="space-y-1">
          <Label className="text-sm font-semibold">ベンダー</Label>
          {isNew ? (
            <Select className="h-8" value={vendorInput} onChange={(e) => handleVendorChange(e.target.value)}>
              <option value="" disabled>
                選択してください
              </option>
              {vendorOptions.map((v) => (
                <option key={v} value={v}>
                  {v}
                </option>
              ))}
            </Select>
          ) : (
            <Input className="h-8" value={vendor} disabled />
          )}
        </div>
        <div className="space-y-1">
          <Label className="text-sm font-semibold">タイプ</Label>
          {isNew ? (
            <Select
              className="h-8"
              value={typeInput}
              onChange={(e) => setTypeInput(e.target.value)}
              disabled={!vendorInput}
            >
              <option value="" disabled>
                {vendorInput ? "選択してください" : "先にベンダーを選択"}
              </option>
              {typeOptions.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </Select>
          ) : (
            <Input className="h-8" value={type} disabled />
          )}
        </div>
        <div className="col-span-2 space-y-1">
          <Label className="text-sm font-semibold">コマンド</Label>
          {isNew ? (
            <Input
              className="h-8"
              placeholder='例: show version / fault_summary'
              value={commandInput}
              onChange={(e) => setCommandInput(e.target.value)}
            />
          ) : (
            <Input className="h-8" value={command} disabled />
          )}
        </div>
      </div>

      <div className="space-y-1">
        <Label className="text-sm font-semibold">説明(任意)</Label>
        <Input className="h-8" value={description} onChange={(e) => setDescription(e.target.value)} />
      </div>

      <div className="grid grid-cols-3 gap-3">
        <div className="space-y-1">
          <Label className="text-sm font-semibold">種別</Label>
          <Select className="h-8" value={entryType} onChange={(e) => handleEntryTypeChange(e.target.value)}>
            <option value="CLI">CLI</option>
            <option value="REST">REST</option>
          </Select>
        </div>
        {isRest ? (
          <div className="col-span-2 space-y-1">
            <Label className="text-sm font-semibold">APIパス</Label>
            <Input
              className="h-8"
              placeholder="/api/node/class/faultSummary.json"
              value={path}
              onChange={(e) => setPath(e.target.value)}
            />
          </div>
        ) : (
          <div className="space-y-1">
            <Label className="text-sm font-semibold">パーサ</Label>
            <Select className="h-8" value={parser} onChange={(e) => setParser(e.target.value)}>
              <option value="genie">genie</option>
              <option value="textfsm">textfsm</option>
            </Select>
          </div>
        )}
      </div>

      {/* ノイズと比較キーは、どちらも1行1件のキーパスで横幅が要るため縦に並べる。 */}
      <div className="space-y-3">
        <div className="space-y-1">
          <Label className="text-sm font-semibold">ノイズ(比較時に無視するキーパス。1行1件)</Label>
          <Textarea className="h-24 font-mono text-xs" value={noise} onChange={(e) => setNoise(e.target.value)} />
        </div>
        <div className="space-y-1">
          <Label className="text-sm font-semibold">比較キー(list→dict化用。1行1件・任意)</Label>
          <Textarea
            className="h-24 font-mono text-xs"
            value={compareKeys}
            onChange={(e) => setCompareKeys(e.target.value)}
            disabled={parser === "genie"}
            placeholder={parser === "genie" ? "genie では使用しません" : undefined}
          />
        </div>
      </div>

      {error && <p className="text-sm text-destructive">{error}</p>}
      <div className="flex items-center gap-2">
        <Button size="sm" onClick={handleSubmit} disabled={saving}>
          {saving ? "保存中..." : submitLabel}
        </Button>
        <Button size="sm" variant="outline" onClick={onCancel} disabled={saving}>
          キャンセル
        </Button>
      </div>
    </div>
  );
}

// CommandCatalogEntryForm と同じレイアウトの、編集不可(表示専用)版。表から
// ノイズ・キー列を削除した代わりに、コマンドをクリックするとここで内容
// (ノイズ・比較キーも含む)を確認できるようにする。
function CommandCatalogEntryView({ vendor, type, command, spec }) {
  const isRest = typeOf(spec.parser) === "REST";
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-4 gap-3">
        <div className="space-y-1">
          <Label className="text-sm font-semibold">ベンダー</Label>
          <div>
            <Badge className={deviceVendorColor(vendor)}>{vendor}</Badge>
          </div>
        </div>
        <div className="space-y-1">
          <Label className="text-sm font-semibold">タイプ</Label>
          <div>
            <Badge className={deviceTypeColor(type)}>{type}</Badge>
          </div>
        </div>
        <div className="col-span-2 space-y-1">
          <Label className="text-sm font-semibold">コマンド</Label>
          <p className="text-sm font-medium">{command}</p>
        </div>
      </div>

      <div className="space-y-1">
        <Label className="text-sm font-semibold">説明</Label>
        <p className="text-sm">{spec.description || "-"}</p>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <div className="space-y-1">
          <Label className="text-sm font-semibold">種別</Label>
          <div>
            <Badge variant={isRest ? "default" : "success"}>{typeOf(spec.parser)}</Badge>
          </div>
        </div>
        {isRest ? (
          <div className="col-span-2 space-y-1">
            <Label className="text-sm font-semibold">APIパス</Label>
            <p className="font-mono text-sm">{spec.path || "-"}</p>
          </div>
        ) : (
          <div className="space-y-1">
            <Label className="text-sm font-semibold">パーサ</Label>
            <div>
              <Badge variant="secondary">{spec.parser}</Badge>
            </div>
          </div>
        )}
      </div>

      {/* ノイズと比較キーは、どちらも1行1件のキーパスで横幅が要るため縦に並べる。 */}
      <div className="space-y-3">
        <div className="space-y-1">
          <Label className="text-sm font-semibold">ノイズ(比較時に無視するキーパス)</Label>
          <div className="min-h-24 space-y-0.5 rounded-md border bg-muted/30 p-2 font-mono text-xs">
            {spec.noise.length > 0 ? (
              spec.noise.map((n) => <p key={n}>{n}</p>)
            ) : (
              <p className="text-muted-foreground">(なし)</p>
            )}
          </div>
        </div>
        <div className="space-y-1">
          <Label className="text-sm font-semibold">比較キー(list→dict化用)</Label>
          <div className="min-h-24 space-y-0.5 rounded-md border bg-muted/30 p-2 font-mono text-xs">
            {spec.compare_keys && spec.compare_keys.length > 0 ? (
              spec.compare_keys.map((k) => <p key={k}>{k}</p>)
            ) : (
              <p className="text-muted-foreground">(なし)</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// 件数が多くなりうるため(Genieパーサーが対応するコマンドを幅広く登録しているため)、
// クライアント側でページングする(一覧APIはページング無しで全件返すが、DOMへは
// 100件ずつしか描画しない。一覧のブラウザ描画が重くなるのを防ぐため)。

export default function CommandCatalogPage() {
  const [catalog, setCatalog] = useState(null);
  const [error, setError] = useState(null);
  const [filters, setFilters] = useState(EMPTY_FILTERS);
  const [page, setPage] = useState(0);
  const [creating, setCreating] = useState(false);
  const [editingKey, setEditingKey] = useState(null);
  const [viewingKey, setViewingKey] = useState(null);

  const reload = () => getCommandCatalog().then(setCatalog).catch((e) => setError(e.message));
  useEffect(() => {
    reload();
  }, []);

  const setFilter = (key) => (value) => {
    setPage(0);
    setFilters((prev) => ({ ...prev, [key]: value }));
  };

  const rows = useMemo(() => (catalog ? flatten(catalog) : []), [catalog]);
  const editingRow = useMemo(
    () => rows.find((r) => `${r.vendor}:${r.type}:${r.command}` === editingKey) ?? null,
    [rows, editingKey]
  );
  const viewingRow = useMemo(
    () => rows.find((r) => `${r.vendor}:${r.type}:${r.command}` === viewingKey) ?? null,
    [rows, viewingKey]
  );
  const vendors = useMemo(() => Array.from(new Set(rows.map((r) => r.vendor))).sort(), [rows]);
  const types = useMemo(() => Array.from(new Set(rows.map((r) => r.type))).sort(), [rows]);
  const parsers = useMemo(() => Array.from(new Set(rows.map((r) => r.spec.parser))).sort(), [rows]);

  const commandMatcher = useMemo(() => compileTextQuery(filters.command), [filters.command]);
  const filtered = useMemo(() => {
    return rows.filter((r) => {
      if (filters.vendor && r.vendor !== filters.vendor) return false;
      if (filters.type && r.type !== filters.type) return false;
      if (!commandMatcher.test(r.command)) return false;
      if (filters.type_ && typeOf(r.spec.parser) !== filters.type_) return false;
      if (filters.parser && r.spec.parser !== filters.parser) return false;
      if (filters.keyStatus && keyStatusOf(r.spec) !== filters.keyStatus) return false;
      return true;
    });
  }, [rows, filters, commandMatcher]);

  const { pageCount, rangeStart, rangeEnd } = usePageRange(filtered.length, page);
  const pageRows = usePageSlice(filtered, page);

  const handleCreate = (payload) =>
    createCommandCatalogEntry(payload).then(() => { setCreating(false); return reload(); });
  const handleUpdate = (vendor, type, command) => (payload) =>
    updateCommandCatalogEntry(vendor, type, command, payload).then(() => { setEditingKey(null); return reload(); });
  const handleDelete = (vendor, type, command) => {
    if (!window.confirm(`'${command}' (${vendor}/${type}) を削除しますか?`)) return;
    deleteCommandCatalogEntry(vendor, type, command).then(reload).catch((e) => setError(e.message));
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          {rangeStart}-{rangeEnd} / {filtered.length} 件(全 {rows.length} 件)
        </p>
        <div className="flex items-center gap-2">
          <Pagination page={page} pageCount={pageCount} onPageChange={setPage} />
          <FileTransferButtons
            downloadUrl={commandCatalogFilesUrl}
            downloadLabel="YAMLダウンロード"
            uploadLabel="YAMLアップロード"
            accept=".zip,.yaml,.yml"
            onUpload={uploadCommandCatalogFiles}
            onUploaded={() => reload()}
            onError={setError}
          />
          <Button size="sm" onClick={() => { setEditingKey(null); setCreating((v) => !v); }}>
            <Plus /> 新規作成
          </Button>
        </div>
      </div>
      {error && <p className="text-sm text-destructive">{error}</p>}

      {/* table-fixed: 列幅を % で指定し、ウィンドウ幅が狭くなったら表全体が
          比例して縮むようにする(auto レイアウト + 固定px幅のヒントだと、
          ウィンドウを縮めても表の実寸は縮まず、代わりに表がはみ出して横
          スクロールになってしまうため)。 */}
      <Table className="table-fixed" containerClassName="max-h-[78vh] overflow-y-auto rounded-md border bg-card">
          <TableHeader className="sticky top-0 z-10 bg-muted">
            <TableRow>
              <TableHead className="w-[8%]">ベンダー</TableHead>
              <TableHead className="w-[8%]">タイプ</TableHead>
              <TableHead className="w-[34%]">コマンド</TableHead>
              <TableHead className="w-[8%]">種別</TableHead>
              <TableHead className="w-[8%]">パーサ</TableHead>
              <TableHead className="w-[12%]">比較キー</TableHead>
              <TableHead className="w-[8%]">ノイズ</TableHead>
              <TableHead className="w-[14%]">操作</TableHead>
            </TableRow>
            <TableRow className="hover:bg-transparent">
              <TableHead className="py-1.5">
                <SelectFilter value={filters.vendor} onChange={setFilter("vendor")} options={vendors} />
              </TableHead>
              <TableHead className="py-1.5">
                <SelectFilter value={filters.type} onChange={setFilter("type")} options={types} />
              </TableHead>
              <TableHead className="py-1.5">
                <TextFilter value={filters.command} onChange={setFilter("command")} placeholder="絞り込み" />
              </TableHead>
              <TableHead className="py-1.5">
                <SelectFilter value={filters.type_} onChange={setFilter("type_")} options={["CLI", "REST"]} />
              </TableHead>
              <TableHead className="py-1.5">
                <SelectFilter value={filters.parser} onChange={setFilter("parser")} options={parsers} />
              </TableHead>
              <TableHead className="py-1.5">
                <SelectFilter
                  value={filters.keyStatus}
                  onChange={setFilter("keyStatus")}
                  options={["-", "設定済み", "未設定"]}
                />
              </TableHead>
              <TableHead className="py-1.5" />
              <TableHead className="py-1.5" />
            </TableRow>
          </TableHeader>
          <TableBody>
            {pageRows.map(({ vendor, type, command, spec }) => {
              const key = `${vendor}:${type}:${command}`;
              return (
                <TableRow
                  key={key}
                  className="cursor-pointer hover:bg-accent"
                  onClick={() => setViewingKey(key)}
                >
                  <TableCell>
                    <Badge className={deviceVendorColor(vendor)}>{vendor}</Badge>
                  </TableCell>
                  <TableCell>
                    <Badge className={deviceTypeColor(type)}>{type}</Badge>
                  </TableCell>
                  <TableCell className="font-medium" title={spec.description || undefined}>
                    <HighlightMatch text={command} matcher={commandMatcher} />
                  </TableCell>
                  <TableCell>
                    <Badge variant={typeOf(spec.parser) === "REST" ? "default" : "success"}>
                      {typeOf(spec.parser)}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge variant="secondary">{spec.parser}</Badge>
                  </TableCell>
                  <TableCell className="text-muted-foreground">
                    {keyStatusOf(spec)}
                  </TableCell>
                  <TableCell className="text-muted-foreground">{spec.noise.length}件</TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={(e) => { e.stopPropagation(); setCreating(false); setEditingKey(key); }}
                      >
                        <Pencil />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={(e) => { e.stopPropagation(); handleDelete(vendor, type, command); }}
                      >
                        <Trash2 />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              );
            })}
            {filtered.length === 0 && (
              <TableRow>
                <TableCell colSpan={8} className="text-center text-sm text-muted-foreground">
                  該当するコマンドがありません
                </TableCell>
              </TableRow>
            )}
          </TableBody>
      </Table>

      <Dialog
        open={creating || editingKey !== null}
        onClose={() => { setCreating(false); setEditingKey(null); }}
        title={creating ? "コマンドカタログを新規作成" : `コマンドカタログを編集: ${editingKey}`}
        className="max-w-8xl"
      >
        {creating && (
          <CommandCatalogEntryForm
            catalog={catalog}
            submitLabel="作成"
            onCancel={() => setCreating(false)}
            onSubmit={handleCreate}
          />
        )}
        {editingKey !== null && editingRow && (
          <CommandCatalogEntryForm
            vendor={editingRow.vendor}
            type={editingRow.type}
            command={editingRow.command}
            initial={editingRow.spec}
            submitLabel="保存"
            onCancel={() => setEditingKey(null)}
            onSubmit={handleUpdate(editingRow.vendor, editingRow.type, editingRow.command)}
          />
        )}
      </Dialog>

      <Dialog
        open={viewingKey !== null}
        onClose={() => setViewingKey(null)}
        title={`コマンドカタログ: ${viewingKey}`}
        className="max-w-8xl"
      >
        {viewingRow && (
          <CommandCatalogEntryView
            vendor={viewingRow.vendor}
            type={viewingRow.type}
            command={viewingRow.command}
            spec={viewingRow.spec}
          />
        )}
      </Dialog>
    </div>
  );
}
