import { useEffect } from "react";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";

// 依存ライブラリを増やさない簡易モーダル。オーバーレイクリック・Escで閉じる。
// 開いている間は背面のスクロールを止める。
//
// 枠全体の高さは「画面の高さ − 外側の余白(上 1vh・下 1rem)」までに抑え、題名の帯は
// 固定、中身(contentClassName)はその枠の中で縮んでスクロールする。中身だけに高さの
// 上限を付ける作りだと、題名の帯と余白の分だけ枠が画面からはみ出し、ポップアップ
// 全体がわずかにスクロールしてしまうため(画面が縦に長いほど起きやすい)。
function Dialog({ open, onClose, title, children, className, contentClassName }) {
  useEffect(() => {
    if (!open) return;
    const onKeyDown = (e) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKeyDown);
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKeyDown);
      document.body.style.overflow = prevOverflow;
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-black/50 p-4 pt-[1vh]"
      onClick={onClose}
    >
      <div
        className={cn(
          "flex max-h-[calc(99vh-1.5rem)] w-full max-w-2xl flex-col rounded-lg border bg-card shadow-lg",
          className
        )}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex shrink-0 items-center justify-between border-b px-4 py-3">
          <h2 className="text-sm font-semibold">{title}</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
            <X className="size-4" />
          </button>
        </div>
        <div className={cn("max-h-[75vh] min-h-0 overflow-y-auto p-4", contentClassName)}>{children}</div>
      </div>
    </div>
  );
}

// 結果表示(正常性確認の結果・スナップショットの詳細)のポップアップは raw や
// 差分で横にも長くなるため、幅を画面いっぱいに近いところまで広げる。
export const RESULT_DIALOG_WIDTH = "max-w-9xl";

// 中身が多いときに、ポップアップ全体ではなく中の一部(表・raw・差分など)だけを
// スクロールさせるための中身の指定。中身を縦並び(flex)にし、中身自体の高さの上限は
// 外して枠の上限に任せる。中の部品は、大きさを保ちたい部分(ボタン・見出し・タブ)に
// shrink-0 を、スクロールさせたい部分に min-h-0 と overflow-auto を付ける(min-h-0 は
// 縮むことを許すために、そこまでの途中の階層すべてに必要)。
export const DIALOG_CONTENT_FLEX = "flex max-h-none flex-col";

// 枠を画面の高さいっぱいに固定する。絞り込みで中身の量が変わっても枠の大きさが
// 変わらないようにしたいポップアップで使い、中身には DIALOG_CONTENT_FLEX と flex-1 を
// 合わせて指定する。値は上の枠の上限(max-h)と同じにする。
export const DIALOG_FULL_HEIGHT = "h-[calc(99vh-1.5rem)]";

export { Dialog };
