// 絞り込みに一致した部分を黄色で強調する。matcher は lib/textQuery.js の
// compileTextQuery() の戻り値(各ページが絞り込みに使うものをそのまま渡す)。
//
// 部分一致では、例えば "ise" で絞ると "enterprise-sw01" のような、探している機器とは
// 関係のない名前も残る(名前の途中に "ise" を含むため)。正規表現でも、どこが一致した
// のかは表を見ただけでは分からない。一致した箇所を示して、絞り込みが効いていないように
// 見えたり、意図しない一致に気づかなかったりするのを防ぐ。
export default function HighlightMatch({ text, matcher }) {
  const value = text ?? "";
  const ranges = matcher?.active ? matcher.ranges(value) : [];
  if (ranges.length === 0) return value;

  const parts = [];
  let from = 0;
  for (const [start, end] of ranges) {
    if (start > from) parts.push(value.slice(from, start));
    parts.push(
      <mark key={start} className="rounded-sm bg-yellow-200 px-0.5 text-inherit">
        {value.slice(start, end)}
      </mark>
    );
    from = end;
  }
  parts.push(value.slice(from));
  return <>{parts}</>;
}
