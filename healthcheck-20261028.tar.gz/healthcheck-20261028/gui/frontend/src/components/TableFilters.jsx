import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { compileTextQuery } from "@/lib/textQuery";

// 表のヘッダー行(列タイトルの下)に置く列フィルタ。機器一覧・コマンドカタログ・
// コマンドセット・スナップショット一覧・認証情報・機器選択のどの表でも見た目と
// 操作を揃えるため、入力欄の形だけをここに持つ。絞り込みの条件保持と実際の
// フィルタ処理は各ページ側が行う。

// 文字の絞り込み。value は { text, regex }(lib/textQuery.js)。右端の ".*" で、この欄
// だけ部分一致と正規表現を切り替える。正規表現として正しくない間は赤枠にし、理由を
// ツールチップで示す(その間、ページ側はこの欄の絞り込みを掛けない)。
export function TextFilter({ value, onChange, placeholder }) {
  const { error } = compileTextQuery(value);
  return (
    <div className="relative">
      <Input
        className={cn("h-7 pr-8 text-xs", error && "border-destructive focus-visible:ring-destructive")}
        placeholder={value.regex ? "正規表現" : placeholder}
        title={error ?? undefined}
        value={value.text}
        onChange={(e) => onChange({ ...value, text: e.target.value })}
      />
      <button
        type="button"
        aria-pressed={value.regex}
        title={value.regex ? "正規表現で絞り込み中(クリックで部分一致に戻す)" : "正規表現で絞り込む"}
        onClick={() => onChange({ ...value, regex: !value.regex })}
        className={cn(
          "absolute top-1/2 right-1 -translate-y-1/2 rounded px-1 font-mono text-[10px] leading-4",
          value.regex ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted"
        )}
      >
        .*
      </button>
    </div>
  );
}

export function SelectFilter({ value, onChange, options }) {
  return (
    <Select className="h-7 text-xs" value={value} onChange={(e) => onChange(e.target.value)}>
      <option value="">すべて</option>
      {options.map((opt) => (
        <option key={opt} value={opt}>
          {opt}
        </option>
      ))}
    </Select>
  );
}
