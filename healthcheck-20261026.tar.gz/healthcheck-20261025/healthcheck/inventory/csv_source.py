"""
healthcheck.inventory.csv_source — CSV インベントリアダプタ

CSV のヘッダ行を列名とし、各行を1機器にする。列: host, vendor, type, ip, port, id と、
任意の追加列(meta に入る。例 site, role)。必須は host と vendor・type。

行→Device の変換(row_to_device)はここに置く。インベントリアダプタが CsvInventory
だけのため、別ファイルへは分けない(2つ目の利用者が現れた時点で共通化を検討する)。
"""

from __future__ import annotations

import csv
from pathlib import Path

from healthcheck.models import Device
from healthcheck.inventory.base import InventorySource, filter_devices

# Device の既知フィールド(これ以外の列は meta に入れる)
_KNOWN = {"host", "vendor", "type", "ip", "port", "id"}


def row_to_device(row: dict) -> Device:
    """CSV の1行(辞書)から Device を作る。未知のキーは meta へ。"""
    # 空文字・空白を除いた辞書にする(CSV の空セル対策)
    clean = {k.strip(): (v.strip() if isinstance(v, str) else v)
             for k, v in row.items() if k and str(k).strip() != ""}

    host = clean.get("host")
    vendor = clean.get("vendor")
    type_ = clean.get("type")
    if not host:
        raise ValueError(f"inventory 行に host がありません: {row}")
    if not vendor:
        raise ValueError(f"inventory 行に vendor がありません(host={host})")
    if not type_:
        raise ValueError(f"inventory 行に type がありません(host={host})")

    meta = {k: v for k, v in clean.items() if k not in _KNOWN and v not in (None, "")}

    port = clean.get("port")
    return Device(
        host=host,
        vendor=vendor,
        type=type_,
        ip=clean.get("ip") or None,
        port=int(port) if port not in (None, "") else 22,
        id=clean.get("id") or None,
        meta=meta,
    )


class CsvInventory(InventorySource):
    def __init__(self, path: str | Path):
        self.path = Path(path)

    def get_devices(self, filter: dict | None = None) -> list[Device]:
        devices: list[Device] = []
        with self.path.open(newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                # 完全な空行はスキップ
                if not any((v or "").strip() for v in row.values()):
                    continue
                devices.append(row_to_device(row))
        return filter_devices(devices, filter)
