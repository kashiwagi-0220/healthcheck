"""
healthcheck.inventory — インベントリ層

対象機器の一覧を「どこから取るか」を抽象化する。
  base        … InventorySource(抽象IF)+ filter_devices(共通フィルタ処理)
  csv_source  … CsvInventory(CSV アダプタ。現時点で使う唯一の実装)

YAML アダプタは現時点で使う予定が無いため実装しない(必要になったら
InventorySource を満たす実装を1ファイル追加するだけでよい。他層は無変更)。
将来 NetBox 等のアダプタも同様に追加できる。
"""

from healthcheck.inventory.base import InventorySource
from healthcheck.inventory.csv_source import CsvInventory

__all__ = ["InventorySource", "CsvInventory"]
