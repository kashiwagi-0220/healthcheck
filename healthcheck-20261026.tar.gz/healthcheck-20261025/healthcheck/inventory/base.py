"""
healthcheck.inventory.base — インベントリ層の抽象IF

対象機器の一覧を「どこから取るか」を抽象化する。現状は CSV アダプタ(CsvInventory)
のみ。将来 YAML/NetBox 等のアダプタを追加・差し替えても上位(ツール)は無変更で済む。

機器の関連付けキーは host(ホスト名)。インベントリソースで変わりうる id では
なく、ソースをまたいで安定する host を使う(models.Device 参照)。

責務分離: フィルタ解決(式→機器リスト)は照会に使う。比較などの実行本体は、
GUI が照会で解決した確定 device(host)リストを受け取る。
"""

from __future__ import annotations

from abc import ABC, abstractmethod

from healthcheck.models import Device


class InventorySource(ABC):
    """対象機器の一覧を返すインベントリソース。"""

    @abstractmethod
    def get_devices(self, filter: dict | None = None) -> list[Device]:
        """機器一覧を返す。filter で絞り込む(None なら全件)。

        filter は「属性名 → 値(または値のリスト)」で、AND で評価する。
        対象は Device の属性(host/device_type/ip 等)と meta のキー。
        例: {"device_type": "cisco_ios"} / {"site": ["hq", "dc1"]}
        """


def filter_devices(devices: list[Device], filter: dict | None) -> list[Device]:
    """Device リストを filter で絞り込む共通ヘルパ(各アダプタが再利用)。

    - キーはまず Device の属性を見て、無ければ meta を見る。
    - 値がリストなら「いずれかに一致(in)」、スカラなら「等しい」。
    """
    if not filter:
        return list(devices)

    def match(dev: Device) -> bool:
        for key, want in filter.items():
            got = getattr(dev, key, None)
            if got is None:
                got = dev.meta.get(key)
            if isinstance(want, (list, tuple, set)):
                if got not in want:
                    return False
            else:
                if got != want:
                    return False
        return True

    return [d for d in devices if match(d)]
