"""
healthcheck.collect.file_credential_provider — ファイルによる認証情報解決

CredentialProvider(抽象)の実装。config/credentials.yaml を読む。

既定は全機器共通の1アカウント(default)だが、一部のホストだけ別アカウントを
使いたい場合のために host 単位の上書き(hosts)も持てる。ファイルの形:

  default:
    username: ...
    password: ...
    secret: ...(任意)
  hosts:
    <host>:
      username: ...
      password: ...
      secret: ...(任意)

hosts.<host> に一致する host があればそれを使い、無ければ default を使う。
CommandCatalog 等と同じ理由(YAML は既定値を完全に置き換える。部分上書きはしない)
で、hosts.<host> を書いた場合は username/password をその中で完結させる(default の
一部だけを引き継ぐ、という部分マージはしない。secret だけは各エントリ内で任意
(未指定なら None)。今その host がどの認証情報を使っているのか、1つのブロックを
見るだけで分かる状態を優先する)。

現時点は平文で保存する。将来 SOPS+age
等で暗号化する構想があるため、「ファイルの中身(YAML文字列)を取得する」処理を
_read_raw() に分離してある。暗号化する際は _read_raw() を復号処理(例 `sops -d
<path>` の実行結果を返す)に差し替えるだけで済み、resolve() 側(YAMLパース・
Credentials 組み立て)は変更不要な設計にしている。
"""

from __future__ import annotations

from pathlib import Path

import yaml

from healthcheck.models import Device
from healthcheck.collect.base import Credentials, CredentialProvider


class FileCredentialProvider(CredentialProvider):
    """ファイルから認証情報を解決する。既定は全機器共通の1アカウント(default)、
    host 単位の上書き(hosts.<host>)があればそちらを優先する。"""

    def __init__(self, path: str | Path):
        self.path = Path(path)

    def _read_raw(self) -> str:
        """ファイルの中身(YAML文字列)を返す。将来 SOPS 等で暗号化する場合は、
        このメソッドだけを復号処理に差し替えればよい(他は変更不要)。"""
        if not self.path.exists():
            raise RuntimeError(f"認証情報ファイルが見つかりません: {self.path}")
        return self.path.read_text(encoding="utf-8")

    def resolve(self, device: Device) -> Credentials:
        data = yaml.safe_load(self._read_raw()) or {}
        entry = (data.get("hosts") or {}).get(device.host) or data.get("default")
        if not entry:
            raise RuntimeError(f"{self.path}: default が指定されていません。")
        username = entry.get("username")
        password = entry.get("password")
        if not username or not password:
            raise RuntimeError(
                f"{self.path}: {device.host} に使う認証情報の username / password が"
                "指定されていません。"
            )
        return Credentials(
            username=username,
            password=password,
            secret=entry.get("secret") or None,
        )
