"""
healthcheck.collect.bigip_rest_collector — F5 BIG-IP REST API による収集エンジン

RestCollector 抽象の実装。参照: F5 CloudDocs「Authentication with the F5 REST API」
(https://clouddocs.f5.com/api/icontrol-soap/Authentication_with_the_F5_REST_API.html)
に記載のトークン認証手順をそのまま踏む。

  1) POST /mgmt/shared/authn/login に
     {"username", "password", "loginProviderName": "tmos"} を送り、
     応答の token.token(入れ子オブジェクトの中の文字列)を得る
     (例: {"token": {"token": "VUT2YR667OICEHAEKWBGWOJ3HF", "timeout": 1200, ...}, ...})。
  2) job.queries(RestQuery)ごとに GET {RestQuery.path} を、ヘッダー
     "X-F5-Auth-Token" にトークンを載せて実行する。
  3) DELETE /mgmt/shared/authz/tokens/{token} でトークンを破棄する(finally。
     失敗は無視)。参照ページ自体にはログアウト手順の明記が無いため、BIG-IPの
     トークン管理API(トークンリソースをDELETEして無効化する一般的な方式)に倣う。

APICRestCollector(healthcheck/collect/apic_rest_collector.py)と同じ設計パターン。
netmiko の「接続→コマンド群→切断」と同じライフサイクルを1機器1接続(1セッション)
単位で踏む。requests は遅延 import(netmiko/Genie と import 方針を揃える)。

method の安全性検証(get のみ許可)は RestPolicy が collect 前に行う前提で、
ここでは再検証しない(take_snapshot が両方を満たすことを検証する設計)。

実機の BIG-IP がこの環境に無いため、モックでの検証止まり(APICRestCollector は
実機 sandboxapicdc.cisco.com での検証済み。BIG-IP は実機確認できたら更新する)。
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone

from healthcheck.models import RestJob, CommandResult, CollectResult, Device
from healthcheck.collect.base import RestCollector, CredentialProvider

logger = logging.getLogger(__name__)


class BigIpRestCollector(RestCollector):
    """F5 BIG-IP の REST API に接続し、RestQuery 群を順次実行するエンジン。"""

    def __init__(self, timeout: float = 10.0, verify: bool | str = False, login_provider_name: str = "tmos"):
        self.timeout = timeout
        # BIG-IP もラボ環境等で自己署名証明書を使うことが多いため、APICRestCollector と
        # 同じく既定では証明書検証を行わない(呼び出し側で明示的に verify=True 等を渡せる)。
        self.verify = verify
        self.login_provider_name = login_provider_name

    def collect_device(self, job: RestJob, credentials: CredentialProvider) -> CollectResult:
        try:
            import requests
        except ImportError as e:
            raise ImportError(
                "requests が未導入です。'pip install requests' が必要です。"
            ) from e

        device = job.device
        creds = credentials.resolve(device)
        base_url = f"https://{device.ip or device.host}"
        started_at = datetime.now(timezone.utc)

        session = requests.Session()
        session.verify = self.verify
        if not self.verify:
            import urllib3
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        logger.info("%s: ログイン開始 (%s)", device.host, base_url)
        try:
            token = self._login(session, base_url, creds.username, creds.password)
        except Exception as e:
            logger.warning("%s: ログイン失敗 - %r", device.host, e)
            return CollectResult(
                device=device, success=False, error=f"login failed: {e!r}",
                started_at=started_at, finished_at=datetime.now(timezone.utc),
            )
        logger.info("%s: ログイン成功", device.host)

        outputs: dict[str, CommandResult] = {}
        all_ok = True
        try:
            for query in job.queries:
                q_started = datetime.now(timezone.utc)
                logger.info("%s: 問い合わせ開始 - %s", device.host, query.key)
                try:
                    if not query.path:
                        raise ValueError("RestQuery.path が未設定です(BigIpRestCollector は path 必須)")
                    resp = session.get(
                        base_url + query.path,
                        headers={"X-F5-Auth-Token": token},
                        timeout=self.timeout,
                    )
                    resp.raise_for_status()
                    outputs[query.key] = CommandResult(
                        command=query.key, success=True, raw=resp.text,
                        started_at=q_started, finished_at=datetime.now(timezone.utc),
                    )
                    logger.info("%s: 問い合わせ完了 - %s", device.host, query.key)
                except Exception as e:
                    all_ok = False
                    outputs[query.key] = CommandResult(
                        command=query.key, success=False, error=repr(e),
                        started_at=q_started, finished_at=datetime.now(timezone.utc),
                    )
                    logger.warning("%s: 問い合わせ失敗 - %s: %r", device.host, query.key, e)
        finally:
            self._logout(session, base_url, token, device)

        return CollectResult(
            device=device, success=all_ok, outputs=outputs,
            started_at=started_at, finished_at=datetime.now(timezone.utc),
        )

    def _login(self, session, base_url: str, username: str, password: str) -> str:
        """/mgmt/shared/authn/login してトークン文字列を返す。応答は
        {"token": {"token": "<値>", "timeout": ..., ...}, ...} という入れ子構造。"""
        resp = session.post(
            base_url + "/mgmt/shared/authn/login",
            json={
                "username": username,
                "password": password,
                "loginProviderName": self.login_provider_name,
            },
            timeout=self.timeout,
        )
        resp.raise_for_status()
        return resp.json()["token"]["token"]

    def _logout(self, session, base_url: str, token: str, device: Device) -> None:
        """トークンを破棄する。収集結果には影響させないため失敗は無視する。"""
        try:
            session.delete(
                base_url + f"/mgmt/shared/authz/tokens/{token}",
                headers={"X-F5-Auth-Token": token},
                timeout=self.timeout,
            )
            logger.info("%s: ログアウト", device.host)
        except Exception as e:
            # トークン削除の失敗は収集結果に影響しない(取得は既に終わっている)ため
            # 握りつぶすが、トークンが残り続ける兆候なので記録はする。
            logger.warning("%s: トークン削除失敗 - %r", device.host, e)
