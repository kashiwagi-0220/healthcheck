"""
healthcheck.collect.panos_rest_collector — PAN-OS REST API による収集エンジン

RestCollector 抽象の実装。参照: PAN-OS & Panorama API リファレンス
「Get Started with the PAN-OS REST API」
(https://docs.paloaltonetworks.com/pan-os/11-1/pan-os-panorama-api/
get-started-with-the-pan-os-rest-api)。

  1) POST /api/?type=keygen に {"user": ..., "password": ...} を **POSTボディ**で送り
     (GETのURLクエリにパスワードを載せる方式もPAN-OS側は許容するが、平文パスワードが
     URL・アクセスログに残るリスクがあるため使わない)、応答XML
     <response status="success"><result><key>...</key></result></response>
     から key を得る。認証エンドポイント自体は昔からある XML API
     (/api/?type=keygen)のものだが、REST API(/restapi/v.../...)もこの API キーを
     共有して使う(ドキュメントに明記)。
  2) job.queries(RestQuery)ごとに GET {RestQuery.path} を、ヘッダー
     "X-PAN-KEY" に API キーを載せて実行する(ドキュメント記載の認証方式。
     APIC の cookie 方式・BIG-IP のヘッダー方式とはヘッダー名が異なるだけで
     同じ「トークンを添えて叩く」パターン)。
  3) 明示的なログアウト/失効エンドポイントは無い(PAN-OS の API キーは CLI/Web GUI
     から無効化する運用が一般的で、APIC の aaaLogout・BIG-IP のトークン DELETE に
     相当する後片付け手順がドキュメントに存在しない)。そのため
     APICRestCollector/BigIpRestCollector と異なり finally でのログアウト処理は無い。

netmiko の「接続→コマンド群→切断」と同じライフサイクルを踏襲するが、上記の通り
「切断」に相当する処理が無い点が他の2つの RestCollector 実装と異なる。requests は
netmiko/Genie と import 方針を揃えるため遅延 import にする。

method の安全性検証(get のみ許可)は RestPolicy が collect 前に行う前提で、
ここでは再検証しない(take_snapshot が両方を満たすことを検証する設計)。

REST API のパスにはバージョン番号を含む(例 "/restapi/v11.1/Policies/
SecurityRules?...")。PAN-OS のバージョンによって対応する REST API バージョンが
異なるため、実機導入時はファイアウォールの実バージョンに合わせて
command_catalog 側のパスを調整すること(このプロジェクトの command_catalog は
v11.1 系のドキュメントを基準に作成している)。
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone

from healthcheck.models import RestJob, CommandResult, CollectResult
from healthcheck.collect.base import RestCollector, CredentialProvider

logger = logging.getLogger(__name__)


class PanosRestCollector(RestCollector):
    """PAN-OS(Palo Alto Networks ファイアウォール)の REST API に接続し、
    RestQuery 群を順次実行するエンジン。"""

    def __init__(self, timeout: float = 10.0, verify: bool | str = False):
        self.timeout = timeout
        # ラボ環境等で自己署名証明書を使うことが多いため、既定では証明書検証を
        # 行わない(APICRestCollector/BigIpRestCollector と同じ方針)。
        self.verify = verify

    def collect_device(self, job: RestJob, credentials: CredentialProvider) -> CollectResult:
        try:
            import requests
        except ImportError as e:
            raise ImportError(
                "requests が未導入です。'pip install requests' が必要です。"
            ) from e

        device = job.device
        creds = credentials.resolve(device)
        base_url = f"https://{device.ip or device.host}"
        started_at = datetime.now(timezone.utc)

        session = requests.Session()
        session.verify = self.verify
        if not self.verify:
            import urllib3
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        logger.info("%s: APIキー取得開始 (%s)", device.host, base_url)
        try:
            api_key = self._get_api_key(session, base_url, creds.username, creds.password)
        except Exception as e:
            logger.warning("%s: APIキー取得失敗 - %r", device.host, e)
            return CollectResult(
                device=device, success=False, error=f"api key取得に失敗しました: {e!r}",
                started_at=started_at, finished_at=datetime.now(timezone.utc),
            )
        logger.info("%s: APIキー取得成功", device.host)

        outputs: dict[str, CommandResult] = {}
        all_ok = True
        for query in job.queries:
            q_started = datetime.now(timezone.utc)
            logger.info("%s: 問い合わせ開始 - %s", device.host, query.key)
            try:
                if not query.path:
                    raise ValueError("RestQuery.path が未設定です(PanosRestCollector は path 必須)")
                resp = session.get(
                    base_url + query.path,
                    headers={"X-PAN-KEY": api_key},
                    timeout=self.timeout,
                )
                resp.raise_for_status()
                outputs[query.key] = CommandResult(
                    command=query.key, success=True, raw=resp.text,
                    started_at=q_started, finished_at=datetime.now(timezone.utc),
                )
                logger.info("%s: 問い合わせ完了 - %s", device.host, query.key)
            except Exception as e:
                all_ok = False
                outputs[query.key] = CommandResult(
                    command=query.key, success=False, error=repr(e),
                    started_at=q_started, finished_at=datetime.now(timezone.utc),
                )
                logger.warning("%s: 問い合わせ失敗 - %s: %r", device.host, query.key, e)

        return CollectResult(
            device=device, success=all_ok, outputs=outputs,
            started_at=started_at, finished_at=datetime.now(timezone.utc),
        )

    def _get_api_key(self, session, base_url: str, username: str, password: str) -> str:
        """POST /api/?type=keygen で API キーを取得する(XML応答)。"""
        from xml.etree import ElementTree

        resp = session.post(
            base_url + "/api/",
            data={"type": "keygen", "user": username, "password": password},
            timeout=self.timeout,
        )
        resp.raise_for_status()
        root = ElementTree.fromstring(resp.text)
        if root.get("status") != "success":
            raise ValueError(f"keygen failed: {resp.text}")
        key = root.findtext("./result/key")
        if not key:
            raise ValueError(f"応答に key が見つかりません: {resp.text}")
        return key
