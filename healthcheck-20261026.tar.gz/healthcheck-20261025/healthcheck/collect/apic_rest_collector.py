"""
healthcheck.collect.apic_rest_collector — Cisco APIC REST API による収集エンジン

RestCollector 抽象の実装。参照: Cisco APIC RESTful API User Guide
「Using Tools for API Development and Testing」に記載の手順をそのまま踏む。

  1) POST /api/aaaLogin.json に {"aaaUser": {"attributes": {"name", "pwd"}}} を送り、
     応答の imdata[0].aaaLogin.attributes.token を得る。
  2) job.queries(RestQuery)ごとに GET {RestQuery.path} を、cookie "APIC-Cookie"
     にトークンを載せて実行する(ガイド記載の認証方式)。
  3) POST /api/aaaLogout.json でセッションを破棄する(finally。失敗は無視)。

netmiko の「接続→コマンド群→切断」と同じライフサイクルを1機器1接続(1セッション)
単位で踏む。requests は重い依存では無いが、netmiko/Genie と import 方針を揃えるため
遅延 import にする。

APIC は path(REST API パス。例 "/api/class/faultSummary.json")だけで問い合わせ先が
決まるため、RestQuery は key + method + path のみを持つ(models.py 参照)。

method の安全性検証(get のみ許可)は RestPolicy が collect 前に行う前提で、
ここでは再検証しない(take_snapshot が両方を満たすことを検証する設計)。
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone

from healthcheck.models import RestJob, CommandResult, CollectResult, Device
from healthcheck.collect.base import RestCollector, CredentialProvider

logger = logging.getLogger(__name__)


class APICRestCollector(RestCollector):
    """Cisco APIC の REST API に接続し、RestQuery 群を順次実行するエンジン。"""

    def __init__(self, timeout: float = 10.0, verify: bool | str = False):
        self.timeout = timeout
        # APIC はラボ環境等で自己署名証明書を使うことが多いため、既定では証明書検証を
        # 行わない。正式なCA署名証明書の環境で検証したい場合は呼び出し側で明示的に
        # verify=True や CA バンドルパスを渡す。
        self.verify = verify

    def collect_device(self, job: RestJob, credentials: CredentialProvider) -> CollectResult:
        try:
            import requests
        except ImportError as e:
            raise ImportError(
                "requests が未導入です。'pip install requests' が必要です。"
            ) from e

        device = job.device
        creds = credentials.resolve(device)
        base_url = f"https://{device.ip or device.host}"
        started_at = datetime.now(timezone.utc)

        session = requests.Session()
        session.verify = self.verify
        if not self.verify:
            # verify=False が既定になったため、毎回 InsecureRequestWarning が出て
            # ログが埋もれるのを避ける(検証を無効にしていること自体は self.verify で
            # 呼び出し側が把握できるため、警告としての意味が薄い)。
            import urllib3
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        logger.info("%s: ログイン開始 (%s)", device.host, base_url)
        try:
            token = self._login(session, base_url, creds.username, creds.password)
        except Exception as e:
            logger.warning("%s: ログイン失敗 - %r", device.host, e)
            return CollectResult(
                device=device, success=False, error=f"login failed: {e!r}",
                started_at=started_at, finished_at=datetime.now(timezone.utc),
            )
        logger.info("%s: ログイン成功", device.host)

        outputs: dict[str, CommandResult] = {}
        all_ok = True
        try:
            for query in job.queries:
                q_started = datetime.now(timezone.utc)
                logger.info("%s: 問い合わせ開始 - %s", device.host, query.key)
                try:
                    if not query.path:
                        raise ValueError("RestQuery.path が未設定です(APICRestCollector は path 必須)")
                    resp = session.get(
                        base_url + query.path,
                        cookies={"APIC-Cookie": token},
                        timeout=self.timeout,
                    )
                    resp.raise_for_status()
                    outputs[query.key] = CommandResult(
                        command=query.key, success=True, raw=resp.text,
                        started_at=q_started, finished_at=datetime.now(timezone.utc),
                    )
                    logger.info("%s: 問い合わせ完了 - %s", device.host, query.key)
                except Exception as e:
                    all_ok = False
                    outputs[query.key] = CommandResult(
                        command=query.key, success=False, error=repr(e),
                        started_at=q_started, finished_at=datetime.now(timezone.utc),
                    )
                    logger.warning("%s: 問い合わせ失敗 - %s: %r", device.host, query.key, e)
        finally:
            self._logout(session, base_url, token, device)

        return CollectResult(
            device=device, success=all_ok, outputs=outputs,
            started_at=started_at, finished_at=datetime.now(timezone.utc),
        )

    def _login(self, session, base_url: str, username: str, password: str) -> str:
        """aaaLogin してトークン(APIC-Cookie に載せる値)を返す。"""
        resp = session.post(
            base_url + "/api/aaaLogin.json",
            json={"aaaUser": {"attributes": {"name": username, "pwd": password}}},
            timeout=self.timeout,
        )
        resp.raise_for_status()
        return resp.json()["imdata"][0]["aaaLogin"]["attributes"]["token"]

    def _logout(self, session, base_url: str, token: str, device: Device) -> None:
        """aaaLogout でセッションを破棄する。収集結果には影響させないため失敗は無視する。"""
        try:
            session.post(
                base_url + "/api/aaaLogout.json",
                cookies={"APIC-Cookie": token},
                timeout=self.timeout,
            )
            logger.info("%s: ログアウト", device.host)
        except Exception as e:
            # ログアウトの失敗は収集結果に影響しない(取得は既に終わっている)ため
            # 握りつぶすが、セッションが残り続ける兆候なので記録はする。
            logger.warning("%s: ログアウト失敗 - %r", device.host, e)
