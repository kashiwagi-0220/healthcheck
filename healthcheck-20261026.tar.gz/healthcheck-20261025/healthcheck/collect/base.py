"""
healthcheck.collect.base — 収集エンジン・認証情報解決の抽象IF

CliCollector(CLI)/RestCollector(REST)は、どちらも「1機器・1ジョブを実行して
CollectResult を返す」単位。ジョブの型が本質的に違う(CliJob.commands は文字列の
コマンド列、RestJob.queries は構造化された RestQuery 列)ため、1つの抽象にまとめず
2つの独立した抽象にする。機器間の並列・完了順ストリーミングは take_snapshot が、
リトライは collect.collect_one が担い、各 Collector は1機器の収集に集中する
(単一責任)。

接続ライブラリ(netmiko / 将来 scrapli 等。REST側は requests 等)はこの抽象の裏に隠す。
engine 選択で差し替えられ、どの実装も同じ CollectResult を返すので後段は収集手段を
意識しない。

Credentials/CredentialProvider もここに置く。CLI・REST の両実装から使う共有の抽象で、
どちらか一方の名前は冠さない。CredentialProvider.resolve() が Credentials を返す密結合の
ため、分離すると base.py と実装ファイルが互いに import し合う循環になる。Credentials は
機微情報のため models.py(層をまたぐ共有契約)には持たせない(Device は認証情報を
持たない設計)。
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass

from healthcheck.models import CliJob, RestJob, CollectResult, Device


@dataclass
class Credentials:
    username: str
    password: str
    secret: str | None = None      # enable / 特権パスワード(必要な機種のみ)


class CredentialProvider(ABC):
    """機器の認証情報を解決する。"""

    @abstractmethod
    def resolve(self, device: Device) -> Credentials:
        """その機器に使う認証情報を返す。"""


class CliCollector(ABC):
    """1機器に CLI でコマンド群を実行するエンジン。"""

    @abstractmethod
    def collect_device(self, job: CliJob, credentials: CredentialProvider) -> CollectResult:
        """1機器のジョブ(コマンド群)を順次実行し、CollectResult を返す。

        機器内のコマンドは順次実行(1接続を使い回す想定)。失敗しても例外を
        投げず、CollectResult.success=False + error に理由を入れて返すのが基本
        (ファサードが完了順にまとめられるように)。
        """


class RestCollector(ABC):
    """1機器に REST API で問い合わせを実行するエンジン。"""

    @abstractmethod
    def collect_device(self, job: RestJob, credentials: CredentialProvider) -> CollectResult:
        """1機器のジョブ(RestQuery 群)を実行し、CollectResult を返す。

        CliCollector.collect_device と同じ契約(例外を投げず success=False で返す)。
        outputs のキーは RestQuery.key、raw は応答を JSON 文字列化したもの(CommandResult.raw
        の型を CLI 側と揃えるため)。パースは parse 層の JsonParser が json.loads で行う。
        """
