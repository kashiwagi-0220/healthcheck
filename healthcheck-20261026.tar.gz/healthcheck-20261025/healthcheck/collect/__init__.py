"""
healthcheck.collect — 収集層ファサード

収集の基本単位と、その材料(collector・認証情報)を解決する関数を提供する。
機器単位の収集→パース→保存のパイプラインは healthcheck.common.snapshot
(take_snapshot)が組み立て、ここはその部品を渡す側に徹する。

- collect_one(collector, job, credentials, ...)
    1ジョブ(=1機器分の CLI コマンド列、または REST 問い合わせ列)をリトライ込みで
    収集する。一過性の失敗(接続タイムアウト等)のみ指数バックオフ + ジッタで
    再試行し、認証失敗・コマンドエラーは決定的失敗として再試行しない。
- get_cli_collector(engine) / get_rest_collector(engine)
    engine 名から collector 実装を解決する。CLI は netmiko 一択のため既定値を
    持つが、REST は機種ごとに認証の作法が違うため engine 名が必須。
- rest_engine_for(device)
    機器の vendor/type から REST engine 名を引く。REST は機器ごとに実装を
    選ぶ必要があるため、その対応表をここに置く。
- default_credentials()
    config/credentials.yaml を読む FileCredentialProvider。CLI・REST 共通で、
    現時点では平文保存(file_credential_provider.py 参照)。

並列化の方針: 機器間は並列(take_snapshot の max_concurrency)、機器内のコマンドは
順次(各 Collector 内)。
"""

from __future__ import annotations

import random
import time
from pathlib import Path
from typing import Union

from healthcheck.models import CliJob, RestJob, CollectResult, Device
from healthcheck.collect.base import CliCollector, RestCollector, CredentialProvider
from healthcheck.collect.file_credential_provider import FileCredentialProvider

_CREDENTIALS_FILE = Path(__file__).resolve().parent.parent.parent / "config" / "credentials.yaml"


def default_credentials() -> CredentialProvider:
    return FileCredentialProvider(_CREDENTIALS_FILE)


def get_cli_collector(engine: str) -> CliCollector:
    """engine名(例 "netmiko")から CliCollector 実装を解決する。"""
    if engine == "netmiko":
        from healthcheck.collect.netmiko_collector import NetmikoCollector  # 遅延 import
        return NetmikoCollector()
    raise ValueError(f"unknown engine: {engine}")


def get_rest_collector(engine: str) -> RestCollector:
    """engine名(例 "apic")から RestCollector 実装を解決する。"""
    if engine == "apic":
        from healthcheck.collect.apic_rest_collector import APICRestCollector  # 遅延 import
        return APICRestCollector()
    if engine == "bigip":
        from healthcheck.collect.bigip_rest_collector import BigIpRestCollector  # 遅延 import
        return BigIpRestCollector()
    if engine == "panos":
        from healthcheck.collect.panos_rest_collector import PanosRestCollector  # 遅延 import
        return PanosRestCollector()
    raise ValueError(f"unknown engine: {engine}")


# REST で取得する機種と、その問い合わせに使う engine の対応。REST は機種ごとに
# 認証・エンドポイントの作法が全く違う(APIC は aaaLogin→APIC-Cookie、BIG-IP は
# token 認証、PAN-OS は API キー)ため、CLI(netmiko 一択)と違って機器ごとに
# 実装を選ぶ必要がある。機種を増やすときは get_rest_collector とここの2箇所に足す。
_REST_ENGINE_BY_DEVICE: dict[tuple[str, str], str] = {
    ("cisco", "apic"): "apic",
    ("f5", "bigip"): "bigip",
    ("paloalto", "panos"): "panos",
}


def rest_engine_for(device: Device) -> str | None:
    """機器の vendor/type に対応する REST engine 名(対応が無ければ None)。"""
    return _REST_ENGINE_BY_DEVICE.get((device.vendor, device.type))


def collect_one(
    collector: Union[CliCollector, RestCollector],
    job: Union[CliJob, RestJob],
    credentials: CredentialProvider,
    retries: int = 1,
    retry_base_delay: float = 0.5,
) -> CollectResult:
    """1ジョブ(1機器分)をリトライ込みで収集する。take_snapshot が機器ごとの
    パイプラインの中で呼ぶ、収集の基本単位。

    一過性の失敗のみ再試行する。Collector は例外を投げずに success=False を返す
    設計だが、接続層で例外が漏れた場合に備えてここでも捕捉する。ただし ImportError
    (エンジン未導入等の設定不備)は個別機器の失敗として握りつぶさずそのまま投げる
    (parse 層の ImportError 方針と揃え、大きく・すぐ気づけるようにする)。"""
    attempt = 0
    while True:
        try:
            result = collector.collect_device(job, credentials)
        except ImportError:
            raise
        except Exception as e:                     # 予期しない例外は結果化
            result = CollectResult(device=job.device, success=False, error=repr(e))

        if result.success or attempt >= retries or not _is_transient(result):
            return result
        # 指数バックオフ + ジッタ(AAA へのサンダリングハード回避)
        time.sleep(retry_base_delay * (2 ** attempt) + random.uniform(0, retry_base_delay))
        attempt += 1


def _is_transient(result: CollectResult) -> bool:
    """再試行すべき一過性の失敗か(接続タイムアウト等)。認証失敗などは再試行しない。"""
    err = (result.error or "").lower()
    if not err:
        return False
    transient = ("timeout", "timed out", "connection", "unreachable", "reset")
    permanent = ("auth", "authentication", "permission", "denied", "unknown command")
    if any(p in err for p in permanent):
        return False
    return any(t in err for t in transient)


__all__ = [
    "collect_one",
    "get_cli_collector", "get_rest_collector", "rest_engine_for", "default_credentials",
]
