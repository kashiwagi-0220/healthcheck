"""
healthcheck.models — 中核データ契約(共通の型)

各層(インベントリ / 収集 / パース / 保管 / ツール)は、この型だけを介して
やり取りする。層は互いの実装を知らず、この型を「契約」として共有する。
これが疎結合の要であり、アダプタ(CSV↔NetBox 等)の差し替えを可能にする。

型はおおまかに3つのフェーズに対応する:
  1) 収集フェーズ : Device, CliJob, CommandResult, CollectResult, RestQuery, RestJob
  2) 保管フェーズ : DataRef, Snapshot(意味づけなし)
  3) 分析フェーズ : Status, CommandComparison, DeviceComparison, HealthCheckResult
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Literal

# vendor/type の想定値(型ヒントのみ。from __future__ import annotations により実行時
# 評価されないため、実行時の値チェックはしない。command_catalog/ 配下のディレクトリ・
# ファイルが実際の正とするソースであり、この一覧はそれに追従するドキュメント目的)。
Vendor = Literal["cisco", "f5", "paloalto"]
DeviceModel = Literal["apic", "ios", "iosxe", "iosxr", "nxos", "asa", "bigip", "panos"]


# =============================================================================
# 1) 収集フェーズ
# =============================================================================

@dataclass
class Device:
    """インベントリ層が返す機器。収集・パース・分岐の判断材料になる。

    認証情報はここに持たせない(credential provider が別途解決する)。
    属性名は netmiko の接続パラメータに合わせ、収集層で変換せずそのまま渡せるようにする。

    - host … ホスト名。**機器の関連付け(保管)のキー**。インベントリソースが CSV→NetBox に
      変わっても、host が一致すれば過去の snapshot と結びつく(id はソースで変わりうるため
      キーにしない)。netmiko の host にもそのまま渡せる。
    - ip   … 接続先IP。DNS 名前解決しない環境などで使う。host と併せて両方持つ。
    - vendor / type … この機器の種別を vendor(ベンダー。例 "cisco")と type(機種/OS。例 "ios")
      に分けて持つ。ベンダー単位の表示・絞り込みをしやすくするため、結合済みの
      カタログキー文字列(例 "cisco_ios")は Device 側では一切持たない。結合文字列を
      キーとして使う箇所は vendor/type を受け取った側でその場で結合する
      (command_catalog のディレクトリ構成
      `config/command/command_catalog/<vendor>/<type>.yaml` と対応する)。
    - id   … インベントリソース内の参照ID(NetBox の PK 等)。任意。ソースで変わりうるので
      機器の関連付けには使わない(host を使う)。
    """
    host: str                                  # ホスト名。関連付け(保管)のキー
    vendor: str                                # ベンダー。例 "cisco"(Vendor 参照)
    type: str                                  # 機種/OS。例 "ios"(DeviceModel 参照)
    ip: str | None = None                      # 接続先IP(任意)
    port: int = 22                             # netmiko port
    id: str | None = None                      # ソース内参照ID(任意。関連付けには使わない)
    meta: dict = field(default_factory=dict)   # NetBox等由来の属性(例 {"site": "hq", "role": "core"})


@dataclass
class CliJob:
    """1機器に対する「何を取得するか」の実行単位(CLI収集)。

    機器ごとに異なるコマンドを持てるのがポイント。ジョブを組むのはツールの
    責務(単一機能)、これを並列に実行するのは収集層の責務。RestJob(REST収集)と対になる。
    """
    device: Device
    commands: list[str]


@dataclass
class CommandResult:
    """コマンド1つの結果(パース前の生出力)。"""
    command: str
    success: bool
    raw: str | None = None                     # 生出力。失敗時は None
    error: str | None = None
    started_at: datetime | None = None
    finished_at: datetime | None = None


@dataclass
class CollectResult:
    """1機器分の収集結果。機器内の複数コマンド結果をまとめて保持する。

    機器内コマンドは順次実行のため、完了の単位も機器。outputs でコマンド
    個別にもアクセスでき、「個別に返す / まとめて返す」の両対応になる。
    """
    device: Device
    success: bool                              # 機器レベル:接続成功かつ全コマンド成功
    outputs: dict[str, CommandResult] = field(default_factory=dict)
    error: str | None = None                   # 機器レベルの失敗(接続不可/認証失敗 等)
    started_at: datetime | None = None
    finished_at: datetime | None = None

    @property
    def duration(self) -> float | None:
        if self.started_at and self.finished_at:
            return (self.finished_at - self.started_at).total_seconds()
        return None

    def __getitem__(self, command: str) -> CommandResult:
        """res["show ip route"] でコマンド個別の結果を取得する糖衣。"""
        return self.outputs[command]


# ---- REST収集(APIC / F5)。入力型が本質的に違うため CLI とは別の型にする ----

@dataclass
class RestQuery:
    """REST取得の指定。CLIの「コマンド文字列」に相当する(CliJob.commands の1要素と対)。

    method + path だけで問い合わせ先が一意に決まる素朴な REST API(APIC の
    /api/class/... 、BIG-IP の /mgmt/tm/... 等)を素の requests で叩く前提の形。
    Ansible モジュール(aci_rest の module パラメータや bigip_device_info の
    gather_subset 等)を経由する場合に必要なフィールドは、実際にそのモジュール
    経由の実装(2つ目の利用者)が現れた時点で追加する。
    """
    key: str                                   # 結果を引くためのキー(例 "routes")
    method: str = "get"
    path: str | None = None                    # 例 APIC の /api/... パス


@dataclass
class RestJob:
    device: Device
    queries: list[RestQuery]


# =============================================================================
# 2) 保管フェーズ
# =============================================================================

@dataclass
class DataRef:
    """保管層内のデータへの参照(ポインタ)。

    実データ本体は保管層にあり、ここは場所だけを持つ。分析時は必要なものだけを
    storage.load_* で遅延ロードする。
    backend は将来ファイルシステム以外(オブジェクトストレージ等)へ差し替える際の
    切替口として残す。現状は "filesystem" のみで、raw/parsed は保管ルートからの相対パス。
    """
    backend: str = "filesystem"                # 現状 "filesystem" のみ(将来の切替口)
    raw: str | None = None                     # 生出力の場所(相対パス)
    parsed: str | None = None                  # パース済みの場所(相対パス)
    meta: dict = field(default_factory=dict)


@dataclass
class Snapshot:
    """ある機器・ある時点の取得結果を指す軽量オブジェクト。

    実データは持たず、コマンドごとの DataRef(ポインタ)だけを保持する。
    比較時に必要な command の parsed だけを遅延ロードできる。

    このツール(CLI)にとって snapshot は「取得結果の1時点」でしかなく、
    意味づけ属性(checkpoint か / どの作業(work)か / label は何か)は持たない。
    それらの意味づけは GUI 側が snapshot_id を使って管理する(責務分離)。
    """
    id: str
    host: str                                  # 機器の関連付けキー(Device.host と対応)
    taken_at: datetime | None = None
    refs: dict[str, DataRef] = field(default_factory=dict)   # コマンド → 参照
    success: bool = True                       # 収集失敗のスナップショットも記録する
    error: str | None = None


# =============================================================================
# 3) 分析フェーズ(正常性確認ツールの出力型)
# =============================================================================
#
# 正常性確認ツール専用に絞った型。汎用の「封筒＋自由ペイロード」ではなく、
# 比較結果を型として明示的に持つ(GUI・実行履歴が中身を型から把握できる)。
# 将来ツールが増えたら、そのとき汎用化を再検討する(単体ツールに徹する方針)。

# 判定語彙(正常性確認で実際に使う4値)。
#   ok      … 差分なし
#   ng      … 差分あり
#   skipped … 比較対象外(パース不可 / 片側にしかない / 比較キー無し等)
#   error   … 取得失敗など、比較以前の失敗
Status = Literal["ok", "ng", "skipped", "error"]


@dataclass
class CommandComparison:
    """1コマンドの比較結果。"""
    command: str
    status: Status                             # ok / ng / skipped
    reason: str | None = None                  # skipped/error の理由
    all_diffs: list[dict] = field(default_factory=list)        # ノイズ除外前の全差分
    effective_diffs: list[dict] = field(default_factory=list)  # 除外後の差分(判定根拠)


@dataclass
class DeviceComparison:
    """機器1台に対する正常性確認の結果。

    正常性確認では中身は必ず「コマンドごとの比較結果」なので、自由 dict ではなく
    比較結果(commands)を型として直接持つ。CommandComparison(コマンド粒度)と対になる
    機器粒度の比較結果。
    """
    device: Device
    status: Status                             # 機器の総合判定
    message: str                               # 人間可読の1行要約
    commands: list[CommandComparison] = field(default_factory=list)


@dataclass
class HealthCheckResult:
    """正常性確認の出力の器。

    findings に機器ごとの結果、summary に全体集計(ok/ng/... の件数)、
    params に実行パラメータ(比較した2時点など)を持つ。呼び出し側(GUI)が
    レスポンスとしてその場で受け取るだけで、実行履歴としては保管しない。
    id を採番する仕組みも持たないため、id/params は常に None/空 のまま。
    単体ツールのため「どのツールの結果か」は型名自体が表しており、tool のような
    フィールドは持たない。
    """
    id: str | None = None
    findings: list[DeviceComparison] = field(default_factory=list)
    summary: dict[str, int] = field(default_factory=dict)
    params: dict = field(default_factory=dict)
    generated_at: datetime | None = None

    def add(self, finding: DeviceComparison) -> None:
        """DeviceComparison を追加し、summary のカウントを自動更新する。"""
        self.findings.append(finding)
        self.summary[finding.status] = self.summary.get(finding.status, 0) + 1
