"""
healthcheck.common.compare — 比較本体(パース済みデータの突き合わせ)

方針:
  両出力を dict に正規化 → ノイズ除外 → 共通再帰 diff。
  全差分(ノイズ除外前)と除外後差分の両方を出し、判定は除外後で行う。
  比較はパース済みのみ。パース不可(parsed=None)の command は skipped。
  一方にしかない command はスキップして報告する(共通部分だけ比較)。

正規化のキー列・ノイズ除外パスは CommandCatalog(command 層。device_type + command
ごとの定義)から引く。旧 NoiseFilter/CompareKeys は CommandCatalog に統合された。

このモジュールは「1機器・2時点」の比較(compare_device)を提供し、結果を
models.DeviceComparison(機器1台の結果)として返す。機器横断はツール側で機器ごとに回して
HealthCheckResult に集約する(compare 自体は機器を意識しない)。
"""

from __future__ import annotations

import copy
from typing import Any

from healthcheck.models import Device, DeviceComparison, CommandComparison, Status
from healthcheck.common.diff import normalize, diff
from healthcheck.command.command_catalog import CommandCatalog

# パース済みデータの入れ物: command -> parsed(dict/list) または None(パース不可)
ParsedByCommand = dict[str, Any]


def compare_device(
    device: Device,
    before: ParsedByCommand,
    after: ParsedByCommand,
    *,
    command_catalog: CommandCatalog | None = None,
) -> DeviceComparison:
    """1機器の2時点(before/after)をコマンドごとに比較し、DeviceComparison を返す。

    before/after は {command: parsed}。parsed は Genie の dict か TextFSM の list、
    パース不可なら None。両方に存在する command だけを比較し、片方だけ・パース不可は
    skipped として記録する。command_catalog に定義の無い command は、比較キー列・
    ノイズ除外パスとも「無し」として扱う(検証は take_snapshot 側の責務)。
    """
    command_catalog = command_catalog or CommandCatalog()

    commands: list[CommandComparison] = []
    # 両時点の command の和集合を、順序を保ちつつ取る
    all_commands = list(dict.fromkeys(list(before.keys()) + list(after.keys())))

    for cmd in all_commands:
        # --- 一方にしかない command はスキップ ---
        if cmd not in before or cmd not in after:
            side = "after" if cmd not in before else "before"
            commands.append(CommandComparison(
                command=cmd, status="skipped",
                reason=f"{side} にのみ存在するためスキップ"))
            continue

        b_parsed, a_parsed = before[cmd], after[cmd]

        # --- パース不可(どちらかが None)はスキップ ---
        if b_parsed is None or a_parsed is None:
            commands.append(CommandComparison(
                command=cmd, status="skipped",
                reason="パース不可のため比較対象外(パース済みのみ比較)"))
            continue

        spec = command_catalog.spec_for(device.vendor, device.type, cmd)

        # --- 正規化(TextFSM の list はキー列で dict 化) ---
        key_fields = spec.compare_keys if spec else None
        b_norm = normalize(b_parsed, key_fields)
        a_norm = normalize(a_parsed, key_fields)

        # --- 全差分(ノイズ除外前) ---
        all_changes = diff(b_norm, a_norm)

        # --- 除外後差分(ノイズを除いてから diff) ---
        noise_paths = spec.noise if spec else []
        b_clean = _apply_noise(b_norm, noise_paths) if isinstance(b_norm, dict) else b_norm
        a_clean = _apply_noise(a_norm, noise_paths) if isinstance(a_norm, dict) else a_norm
        eff_changes = diff(b_clean, a_clean)

        commands.append(CommandComparison(
            command=cmd,
            status="ok" if not eff_changes else "ng",
            all_diffs=[c.to_dict() for c in all_changes],
            effective_diffs=[c.to_dict() for c in eff_changes],
        ))

    status = _aggregate([c.status for c in commands])
    return DeviceComparison(
        device=device,
        status=status,
        message=_message(status, commands),
        commands=commands,
    )


def _apply_noise(parsed: dict, noise_paths: list[str]) -> dict:
    """parsed のコピーから、ノイズキーパスに該当する箇所を除去して返す。

    キーパスの表記: "a.b.c"(ネスト) / "*"(任意の1階層。例 "interfaces.*.last_change")。
    """
    result = copy.deepcopy(parsed)
    for path in noise_paths:
        _remove_path(result, path.split("."))
    return result


def _remove_path(node, parts: list[str]) -> None:
    """node から parts(キーパス)に該当する箇所を再帰的に削除する。"""
    if not parts or node is None:
        return
    key, rest = parts[0], parts[1:]

    if isinstance(node, list):
        for item in node:
            _remove_path(item, parts)
        return

    if not isinstance(node, dict):
        return

    if key == "*":
        # 任意の1階層: 全ての子に対して残りのパスを適用
        if rest:
            for v in node.values():
                _remove_path(v, rest)
        else:
            node.clear()
        return

    if not rest:
        node.pop(key, None)                 # 末端: そのキーを削除
    elif key in node:
        _remove_path(node[key], rest)       # 途中: さらに潜る


def _aggregate(statuses: list[str]) -> Status:
    """コマンド結果を機器の総合判定に畳む。"""
    if "ng" in statuses:
        return "ng"
    if any(s == "ok" for s in statuses):
        return "ok"
    return "skipped"      # ok が1つもなく ng もない = 全て skipped(or 空)


def _message(status: Status, commands: list[CommandComparison]) -> str:
    """人間可読の1行要約。"""
    if status == "ok":
        return "差分なし"
    if status == "ng":
        n = sum(1 for c in commands if c.status == "ng")
        return f"{n} コマンドで差分あり"
    return "比較対象なし(全てスキップ)"
