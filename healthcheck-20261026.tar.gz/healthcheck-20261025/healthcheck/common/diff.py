"""
healthcheck.common.diff — パース済みデータの正規化と再帰 diff(自作・依存ゼロ)

比較の心臓部。方針:
  両出力を dict に正規化 → ノイズ除外 → 共通再帰 diff。
このモジュールは「正規化(list→dict)」と「再帰 dict diff」を提供する。
dict はそのまま、list(トップレベル・dict にネストしたもの問わず。パーサ種別は
問わない)はキー列(compare_keys)で dict 化する。記法は normalize() のdocstring参照。

diff の結果は「キーパス + 種別 + 値」のフラットなリスト(自前表現)。
DeepDiff の独特な出力に依存せず、CommandComparison.all_diffs/effective_diffs に
そのまま載せられる形にする。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

# 差分の種別
ChangeType = Literal["changed", "added", "removed"]


@dataclass
class Change:
    """1件の差分。path はキーパス(例 ['vrf','default','routes','10.0.0.0/24'])。"""
    path: list[str]
    type: ChangeType
    before: Any = None      # changed / removed のとき
    after: Any = None       # changed / added のとき

    def path_str(self) -> str:
        return ".".join(self.path)

    def to_dict(self) -> dict:
        # path は文字列結合せず配列のまま返す。IPアドレス等キー自体に "." を含む
        # 値があるため、".".join() した文字列を呼び出し側で再分割すると境界が
        # あいまいになる。表示用に連結したい場合は受け取った側で ".".join() する。
        d = {"path": self.path, "type": self.type}
        if self.type in ("changed", "removed"):
            d["before"] = self.before
        if self.type in ("changed", "added"):
            d["after"] = self.after
        return d


# ---- 正規化: list(トップレベル・ネスト問わず)を、キー列で dict 化 ----
#
# key_fields の記法(並び順の変化に強い比較を、パーサ種別に関わらず一貫させるための形):
#   各要素は "a.b[].c.d[].e" のようなドット区切りパスを1本の文字列で書く。
#   "名前[]" は「このキーの値は list で、その要素1つずつに対して以降のパスを適用する」
#   ことを示す区切り。先頭が "[]" 単独(例 "[].name")なら「パース結果そのもの(または
#   直前の list 要素)が list」を表す(TextFSM のトップレベル list はこの形)。
#   "[]" の後ろに何も続かない(例 "logs[]")なら、要素の値そのものをキーにする
#   (スカラの list。Genie の `show logging logfile` の `logs` 等)。
#   "*" は「その階層にキーが1つしか無い dict」にのみ一致する任意の1階層
#   (compare.py の noise パスと同じ書き方。クラス名がコマンドごとに変わる
#   APIC の imdata 要素 `{"fabricNode": {"attributes": {"dn": ...}}}` を
#   "imdata[].*.attributes.dn" の1本で(クラス名を書かずに)拾える)。
#   1本のパスに "[]" を複数回書けば、ネストした list(list→dict→list)の、
#   どのlistをキーにするかを区別できる(例 BIG-IP の
#   "items[].membersReference.items[].fullPath" は外側 items の中の
#   membersReference.items という内側の list だけをキー化する。外側 items 自体を
#   キー化したい場合は別の要素として "items[].fullPath" を併記する)。
#
# 複数の key_fields 要素が同じ list を指していれば、それらを AND 連結した複合キーに
# する(従来通り)。どの list にも一致しない key_fields 要素は無視される。

def normalize(parsed: Any, key_fields: list[str] | str | None = None) -> Any:
    """パース結果を比較しやすい dict に正規化する。

    - dict(Genie 等) … キーを再帰的に文字列へ統一して返す(Genie はキーに int を
        返すことがある(例 next_hop_list の "1"/1)。一度 storage 層で JSON に
        保存して読み直すと、JSON はキーに文字列しか許さないため int キーが
        文字列キーに変わる。その結果、「ディスク保存済みの snapshot」と
        「取得直後(未保存)の snapshot」を比較すると、同じキーが int/str の
        別物として扱われ diff() で見かけ上の removed+added が出てしまう。
        比較しやすい形に揃えるという normalize() 本来の役割としてここで吸収する)。
    - list(トップレベル・dict にネストしたもの問わず) … 必ず {キー: レコード} の
        dict に変換する(パーサ種別・ネスト位置によらず一貫させるため、常に変換
        する)。一致する key_fields が無ければ index を文字列キーにした dict に
        フォールバックする
        ({"0": ..., "1": ...}。並び順の変化に弱いので、可能な限り key_fields を
        与える)。key_fields の記法は上記コメント参照。
    - それ以外(スカラ)… そのまま返す。
    """
    return _normalize(parsed, _parse_key_fields(key_fields))


def _split_path(path: str) -> list[str]:
    """ドット区切りのパス文字列をトークン列に分解する。"名前[]" は "名前" と
    "[]"(そのキーの値が list であることを示す区切り)の2トークンに、"[]" 単独
    (直前に名前が無い。パース結果自身や list 要素自身が list の場合)は "[]" の
    1トークンになる。"""
    tokens: list[str] = []
    for part in path.split("."):
        if part.endswith("[]"):
            name = part[:-2]
            if name:
                tokens.append(name)
            tokens.append("[]")
        else:
            tokens.append(part)
    return tokens


def _parse_key_fields(key_fields: list[str] | str | None) -> list[list[str]]:
    if key_fields is None:
        return []
    if isinstance(key_fields, str):
        key_fields = [key_fields]
    return [_split_path(kf) for kf in key_fields]


def _normalize(value: Any, key_paths: list[list[str]]) -> Any:
    if isinstance(value, dict):
        result = {}
        for k, v in value.items():
            # 子へ降りる時、先頭トークンがこのキー名(または、このdictのキーが
            # 1つだけの時に限り "*")に一致する key_paths だけを残し、先頭
            # トークンを消費してから渡す(一致しないものは以降この枝では使われない)。
            sub_paths = []
            for p in key_paths:
                if not p:
                    continue
                head, rest = p[0], p[1:]
                if head == k or (head == "*" and len(value) == 1):
                    sub_paths.append(rest)
            result[str(k)] = _normalize(v, sub_paths)
        return result
    if isinstance(value, list):
        # 先頭が "[]" の key_paths だけが、この list に対する指定
        at_list = [p[1:] for p in key_paths if p and p[0] == "[]"]
        # さらに2つに分ける: この list の要素キーとして使うもの(残りに "[]" が
        # 無い)と、要素の先にある(もっと深い)list を指す途中経過のもの
        # (残りに "[]" がまだ残っている)
        key_specs = [p for p in at_list if "[]" not in p]
        deeper = [p for p in at_list if "[]" in p]
        converted = _list_to_dict(value, key_specs)
        return {k: _normalize(v, deeper) for k, v in converted.items()}
    return value


def _extract_field(row: Any, tokens: list[str]) -> Any:
    """row(list の1要素)から、1つの key_fields 要素のうち list より後ろの
    トークン列を辿って値を取り出す。取り出せなければ None。"*" はその階層に
    キーが1つしか無い dict にのみ一致する任意の1階層。"""
    value = row
    for tok in tokens:
        if not isinstance(value, dict):
            return None
        if tok == "*":
            if len(value) != 1:
                return None
            value = next(iter(value.values()))
        else:
            if tok not in value:
                return None
            value = value[tok]
    return value


def _list_to_dict(rows: list, key_specs: list[list[str]]) -> dict:
    """key_specs: 各要素が1つの複合キー項目(トークン列)。空トークン列
    (元の記法で "[]" の後ろに何も続かない)は要素の値そのものをキーにする
    (スカラの list 用)。"""
    result: dict[str, Any] = {}
    for i, row in enumerate(rows):
        key = None
        if key_specs:
            parts = []
            ok = True
            for tokens in key_specs:
                v = row if not tokens else _extract_field(row, tokens)
                if v in (None, ""):
                    ok = False
                    break
                parts.append(str(v))
            if ok:
                key = "|".join(parts)          # 複合キーは | で連結
        if key is None:
            key = str(i)                       # フォールバック: index
        # 同一キー衝突時は index を添えて一意化(取りこぼさない)
        if key in result:
            key = f"{key}#{i}"
        result[key] = row
    return result


# ---- 再帰 dict diff ----

def diff(before: Any, after: Any, *, _path: list[str] | None = None) -> list[Change]:
    """before/after を再帰的に比較し、差分(Change)のリストを返す。

    - 両方 dict … キーごとに再帰。片方だけのキーは added / removed。
    - それ以外  … 値が異なれば changed(葉として扱う)。
    list は呼び出し前に normalize で dict 化しておく前提だが、
    生の list が来た場合は「値そのもの」として等価比較する(安全側)。
    """
    path = _path or []
    changes: list[Change] = []

    if isinstance(before, dict) and isinstance(after, dict):
        for key in before.keys() | after.keys():
            sub = path + [str(key)]
            if key not in after:
                changes.append(Change(path=sub, type="removed", before=before[key]))
            elif key not in before:
                changes.append(Change(path=sub, type="added", after=after[key]))
            else:
                changes.extend(diff(before[key], after[key], _path=sub))
        return changes

    # 葉(スカラ or 正規化しなかった list など): 値の等価比較
    if before != after:
        changes.append(Change(path=path, type="changed", before=before, after=after))
    return changes
