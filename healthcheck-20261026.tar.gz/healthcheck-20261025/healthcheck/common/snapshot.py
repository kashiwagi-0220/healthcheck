"""
healthcheck.common.snapshot — 取得(snapshot を作る)共通操作(take_snapshot)

コマンド層(CommandSet/CliPolicy/RestPolicy/CommandCatalog)→収集層(collect)→
パース層(parse)→保管層(DataStore)を束ね、機器ごとの Snapshot を返す。

機器ごとに独立した「収集→パース→保存」のパイプラインを、take_snapshot 自身が持つ
ThreadPoolExecutor(max_concurrency)で並列実行し、完了した機器から順に yield する
(返す順序は「機器リストの入力順」ではなく「完了順」)。機器単位で完結させることで、
(a) 全機器分の生データを同時にメモリへ保持しない、(b) 一番遅い機器を待たずに
パース・保存が進む、という2点を満たす。

CLI・REST は完全に別系統(別ジョブ型・別 Collector)なので、1機器がその両方を使う
場合(APIC 等)は同じワーカー内で CLI→REST の順に逐次実行する(単体ツールとして
シンプルさを優先し、機器内でさらに並列化はしない。機器間の並列性(max_concurrency)は
維持する)。収集そのものは collect.collect_one()(1ジョブをリトライ込みで収集する
基本単位)を呼び、collector・credentials の解決も collect 層の
get_cli_collector / rest_engine_for+get_rest_collector / default_credentials を使う。
REST は機種ごとに接続の作法が違うため、機器の vendor/type から実装を解決して
機器ごとに使い分ける(_resolve_rest_collectors)。

収集前に、CLI・REST それぞれ独立した2つの検証を行う(どちらも満たす必要がある):
  - CliPolicy / RestPolicy … 安全性の関門
  - CommandCatalog … 認可(その取得項目の取り扱い方=パーサ等が定義されているか)
この検証はネットワークI/Oを伴わないため全機器分をまとめて先に行う
(1台でも設定ミスがあれば、収集を始める前に全体を止める)。

entry.rest は key(文字列)のリスト(entry.cli と同じ形)で、RestQuery 自体
(method/path)は持たない。CommandCatalog.spec_for(vendor, type, key) から
method/path を引いて RestQuery を組み立ててから RestJob を作る
(command_catalog.py 参照)。
"""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from typing import Iterator

import healthcheck.collect as collect
from healthcheck.collect.base import CliCollector, RestCollector, CredentialProvider
from healthcheck.command.command_set import CommandSet
from healthcheck.command.command_catalog import CommandCatalog
from healthcheck.command.cli_policy import CliPolicy
from healthcheck.command.rest_policy import RestPolicy
from healthcheck.models import CliJob, RestJob, RestQuery, CollectResult, Device, Snapshot
from healthcheck.parse import parse, default_engines
from healthcheck.parse.base import ParserEngine
from healthcheck.storage.base import DataStore


def _snapshot_id(taken_at: datetime) -> str:
    """時系列でソート可能な ID(マイクロ秒精度)。storage 層の list_snapshots が
    snapshot_id を時刻順とみなしてソートする前提に合わせる。"""
    return taken_at.astimezone(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")


def _merge_results(device: Device, cli: CollectResult | None, rest: CollectResult | None) -> CollectResult:
    """同じ機器の CLI 結果と REST 結果を1つの CollectResult に統合する。
    outputs は合算(CliJob.commands と RestJob.queries でキーが重ならない前提)。"""
    parts = [r for r in (cli, rest) if r is not None]
    outputs = {}
    for r in parts:
        outputs.update(r.outputs)
    started = [r.started_at for r in parts if r.started_at]
    finished = [r.finished_at for r in parts if r.finished_at]
    return CollectResult(
        device=device,
        success=all(r.success for r in parts) if parts else True,
        outputs=outputs,
        error=next((r.error for r in parts if r.error), None),
        started_at=min(started) if started else None,
        finished_at=max(finished) if finished else None,
    )


def _process_device(
    device: Device,
    cli_job: CliJob | None,
    rest_job: RestJob | None,
    *,
    cli_collector: CliCollector | None,
    rest_collector: RestCollector | None,
    credentials: CredentialProvider,
    retries: int,
    command_catalog: CommandCatalog,
    parse_engines: dict[str, ParserEngine],
    data_store: DataStore,
    save: bool,
) -> Snapshot:
    """1機器分の「収集→パース→保存」を行い、Snapshot を返す(take_snapshot の
    並列ワーカー本体)。CLI・REST 両方使う機器は同じワーカー内で逐次実行する。"""
    cli_result = collect.collect_one(cli_collector, cli_job, credentials, retries) if cli_job else None
    rest_result = collect.collect_one(rest_collector, rest_job, credentials, retries) if rest_job else None

    result = _merge_results(device, cli_result, rest_result)
    taken_at = result.started_at or datetime.now(timezone.utc)
    refs = {}
    for cmd, cmd_result in result.outputs.items():
        if not cmd_result.success or cmd_result.raw is None:
            continue    # 収集失敗はデータが無いので refs に入れない
        parsed = parse(
            device, cmd, cmd_result.raw,
            command_catalog=command_catalog, parse_engines=parse_engines,
        )
        ref = data_store.save_command(
            device.host, cmd, cmd_result.raw, parsed,
            taken_at=cmd_result.started_at or taken_at,
        )
        refs[cmd] = ref

    snapshot = Snapshot(
        id=_snapshot_id(taken_at),
        host=device.host,
        taken_at=taken_at,
        refs=refs,
        success=result.success,
        error=result.error,
    )
    if save:
        data_store.save_snapshot(snapshot)
    return snapshot


def _resolve_rest_collectors(
    device_jobs: list[tuple[Device, CliJob | None, RestJob | None]],
    override: RestCollector | None,
) -> dict[str, RestCollector]:
    """REST ジョブを持つ機器ごとに RestCollector を割り当てる(host -> collector)。

    機種(vendor/type)ごとに認証・エンドポイントの作法が違うため、CLI と違って
    1つの実装を全機器で共有できない。同じ engine の機器は同じインスタンスを
    使い回す(collector は機器ごとの状態を持たないため)。override を渡した場合は
    検証せずそれを全機器に使う。
    """
    by_host: dict[str, RestCollector] = {}
    by_engine: dict[str, RestCollector] = {}
    for device, _cli_job, rest_job in device_jobs:
        if rest_job is None:
            continue
        if override is not None:
            by_host[device.host] = override
            continue
        engine = collect.rest_engine_for(device)
        if engine is None:
            raise ValueError(
                f"{device.host}: REST で取得する機器ですが、vendor={device.vendor} / "
                f"type={device.type} に対応する REST engine がありません"
                "(healthcheck/collect/__init__.py の対応表を確認してください)。"
            )
        if engine not in by_engine:
            by_engine[engine] = collect.get_rest_collector(engine)
        by_host[device.host] = by_engine[engine]
    return by_host


def take_snapshot(
    devices: list[Device],
    *,
    data_store: DataStore,
    command_set: CommandSet | None = None,
    cli_policy: CliPolicy | None = None,
    rest_policy: RestPolicy | None = None,
    command_catalog: CommandCatalog | None = None,
    parse_engines: dict[str, ParserEngine] | None = None,
    cli_engine: str = "netmiko",
    cli_collector: CliCollector | None = None,
    rest_collector: RestCollector | None = None,
    credentials: CredentialProvider | None = None,
    max_concurrency: int = 10,
    retries: int = 1,
    save: bool = True,
) -> Iterator[Snapshot]:
    """機器群から取得内容(CLI+REST)を収集・パースし、機器ごとの Snapshot を返す。

    機器ごとに独立した「収集→パース→保存」のパイプラインを並列実行し、完了した
    機器から順に yield する(機器リストの入力順ではなく完了順になる)。

    save=False にすると保管しない(取得結果を見るだけ・テスト用)。
    REST の collector は機器の vendor/type から機種ごとに解決する
    (collect.rest_engine_for)。対応表に無い機種が REST で取得しようとした場合は、
    収集を始める前に例外を投げる。rest_collector を渡した場合はその1つを全機器に
    使う(テストでの差し替え用)。
    """
    command_set = command_set or CommandSet()
    cli_policy = cli_policy or CliPolicy()
    rest_policy = rest_policy or RestPolicy()
    command_catalog = command_catalog or CommandCatalog()
    parse_engines = parse_engines if parse_engines is not None else default_engines()

    # 検証(ネットワークI/Oを伴わないため、従来通り全機器分を先にまとめて行う。
    # 1台でも設定ミスがあれば、収集を始める前に全体を止める)。
    device_jobs: list[tuple[Device, CliJob | None, RestJob | None]] = []
    has_cli = False
    for device in devices:
        entry = command_set.for_device(device)

        denied_commands = cli_policy.find_denied(entry.cli)
        if denied_commands:
            raise ValueError(f"{device.host}: 許可されないコマンドが含まれています: {denied_commands}")

        # entry.rest は key(文字列)のリストで、実行内容(method/path)は
        # CommandCatalog 側の CommandSpec が持つ。カタログ照合(uncataloged チェック)
        # より先に RestQuery を組み立てることはできない(spec が無ければ method/path も
        # 無いため)。
        uncataloged = [
            c for c in entry.cli
            if command_catalog.spec_for(device.vendor, device.type, c) is None
        ] + [
            key for key in entry.rest
            if command_catalog.spec_for(device.vendor, device.type, key) is None
        ]
        if uncataloged:
            raise ValueError(
                f"{device.host}: config/command/command_catalog/ に定義の無い取得項目です"
                f"(vendor={device.vendor}, type={device.type}): {uncataloged}"
            )

        rest_queries = []
        for key in entry.rest:
            spec = command_catalog.spec_for(device.vendor, device.type, key)
            rest_queries.append(RestQuery(key=key, method=spec.method, path=spec.path))
        denied_queries = rest_policy.find_denied(rest_queries)
        if denied_queries:
            raise ValueError(
                f"{device.host}: 許可されないREST問い合わせが含まれています: "
                f"{[q.key for q in denied_queries]}"
            )

        cli_job = CliJob(device=device, commands=entry.cli) if entry.cli else None
        rest_job = RestJob(device=device, queries=rest_queries) if rest_queries else None
        if cli_job is None and rest_job is None:
            continue    # commands・rest_queries とも空だった機器(取得対象なし)
        has_cli = has_cli or cli_job is not None
        device_jobs.append((device, cli_job, rest_job))

    if not device_jobs:
        return

    resolved_cli_collector = cli_collector or (collect.get_cli_collector(cli_engine) if has_cli else None)
    rest_collector_by_host = _resolve_rest_collectors(device_jobs, rest_collector)
    resolved_credentials = credentials or collect.default_credentials()

    with ThreadPoolExecutor(max_workers=max_concurrency) as pool:
        futures = {
            pool.submit(
                _process_device, device, cli_job, rest_job,
                cli_collector=resolved_cli_collector,
                rest_collector=rest_collector_by_host.get(device.host),
                credentials=resolved_credentials, retries=retries,
                command_catalog=command_catalog, parse_engines=parse_engines,
                data_store=data_store, save=save,
            ): device
            for device, cli_job, rest_job in device_jobs
        }
        for fut in as_completed(futures):          # 完了した機器から順に返す(ストリーミング)
            yield fut.result()


__all__ = ["take_snapshot"]
