"""
healthcheck.common — 比較部品・取得の共通操作

GUIバックエンド等が組み合わせる共通関数の置き場:
  diff     … 正規化(list→dict)・自作再帰 diff                    normalize / diff
  compare  … 1機器・2時点の比較                                    compare_device
  snapshot … collect→parse→storage の一気通貫(取得操作)          take_snapshot

このファイルでの再エクスポートはしない。diff はサブモジュール名と関数名が同じで、
re-export すると `import healthcheck.common.diff as x` のような書き方をしたとき
x が「モジュール」ではなく「関数」を指してしまう(属性が上書きされる)ため。
呼び出し側は各サブモジュールから直接 import する(snapshot.take_snapshot は
この衝突が無いが、diff と扱いを揃えるため同様に直接 import する)。
"""
