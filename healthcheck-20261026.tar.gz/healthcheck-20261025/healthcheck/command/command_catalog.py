"""
healthcheck.command.command_catalog — vendor + type ごとのコマンド定義カタログ

「認可されたコマンド(＝安全でパース可能なコマンド)」を vendor + type(機種)ごとに
定義する。コマンドごとに、使うパーサ(genie/textfsm/json)・比較時に無視するノイズ
キーパス・比較キー列(compare_keys)をまとめて1箇所(CommandSpec)で持つ。

REST 由来の結果(RestQuery.key をキーとするもの)もここに同じ形で定義する。REST 応答は
収集時点で JSON 文字列化して CommandResult.raw に格納する設計のため、parser には
"json"(json.loads するだけの JsonParser)を指定する。「コマンド」という語はここでは
「1つの取得単位」の意味で使っており、CLI コマンド文字列か REST の key かは問わない。

CLI は「コマンド文字列そのもの」が実行内容を兼ねるため command_set 側は文字列の
リストだけで済むが、REST の key は識別子でしかなく実行内容(method/path)が別途
要る。この method/path も CommandSpec に持たせ、command_set 側は cli と同じく
key(文字列)のリストだけを持つ。method/path は REST 由来のコマンドにのみ意味を
持つ(CLI 由来では未使用のまま)。

安全性(許可プレフィックスチェック)は別(CliPolicy)。ここでの「認可」は「実行対象として
定義されているか(パース方法まで決まっているか)」を意味し、CliPolicy の
安全性チェックとは独立に働く(take_snapshot はその両方を満たすことを検証する)。

設定は `config/command/command_catalog/<vendor>/<type>.yaml`(1ファイル=1機種、
ディレクトリ名=ベンダー・ファイル名=タイプ)を from_directory() で読む。各ファイルは
{cli: {command: spec}, rest: {key: spec}} の形(片方だけでもよい)。in-memory の
表現も vendor → type → {command: spec} の3階層辞書(by_vendor_type)で持ち、
ディレクトリ構成(vendor/type.yaml)とそのまま対応させる。

CLI と REST を同じ機種ファイル内にまとめているのは、APIC のように同じ機種を
CLI・REST 両方で取り扱う場合に「この機種は結局どう取り扱われるのか」を1ファイルだけ
見れば分かるようにするため(CommandSet の command_set/ と同じ考え方)。ファイル内では
cli/rest の区別を持たないフラットな {command: spec} として保持する(CommandSpec 自体に
CLI/REST の違いは現れず、parser が "json" かどうかで判別できるため)。

vendor/type 間の共通化・フォールバックは持たない。同じ内容でも vendor/type ごとに
明示的に書く(コピペしてでも決定的に記載する)。理由は、編集時に「この機種 + command は
結局どの定義が効くのか」を確かめるために別の場所(共通ブロックの有無)まで見に行く
必要をなくすため。多少冗長になっても、1つの機種ブロックだけ見れば全てがわかる状態を
優先する。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

from healthcheck.command._yaml import load_yaml_fields

Parser = Literal["genie", "textfsm", "json"]


@dataclass
class CommandSpec:
    """1コマンド(vendor + type 込み)の取り扱い方。"""
    parser: Parser
    noise: list[str] = field(default_factory=list)           # 比較時に無視するキーパス
    compare_keys: list[str] | None = None                    # TextFSM の list→dict 化キー
    method: str = "get"                                      # REST由来のみ使用。安全のため既定は get
    path: str | None = None                                  # REST由来のみ使用。REST API パス
    description: str | None = None                           # 人間向けの任意の説明文(CommandSetEntry.description と同じ考え方)


@dataclass
class CommandCatalog:
    by_vendor_type: dict[str, dict[str, dict[str, CommandSpec]]] = field(default_factory=dict)
    # vendor -> type -> {command/key: spec}

    def spec_for(self, vendor: str, type: str, command: str) -> CommandSpec | None:
        """vendor + type + command の取り扱い方を返す(未定義なら None)。
        vendor + type ごとに明示的に定義されたものだけを見る(共通既定へのフォールバック
        はしない)。"""
        return self.by_vendor_type.get(vendor, {}).get(type, {}).get(command)

    @classmethod
    def from_directory(cls, dir_path: str | Path) -> CommandCatalog:
        """`<dir_path>/<vendor>/<type>.yaml`(1ファイル=1機種。ディレクトリ名=
        ベンダー・ファイル名=タイプ)から生成する。各ファイルは
        {cli: {command: spec}, rest: {key: spec}} の形(片方だけでもよい)。cli・rest
        の中身は同じ機種の1つの {command/key: spec} にまとめる(CommandSpec の扱いに
        CLI/REST の違いは現れないため)。

        ベンダーディレクトリに入れ忘れて dir_path 直下に置かれた *.yaml は
        黙って無視せず ValueError にする(glob パターンに一致しないだけで
        気づきにくいミスのため)。"""
        dir_path = Path(dir_path)
        stray = sorted(p.name for p in dir_path.glob("*.yaml"))
        if stray:
            raise ValueError(
                f"{dir_path} 直下に *.yaml があります(ベンダーディレクトリへの配置漏れ): "
                f"{stray}。config/command/command_catalog/<vendor>/<type>.yaml の形にしてください。"
            )

        by_vendor_type: dict[str, dict[str, dict[str, CommandSpec]]] = {}
        for file_path in sorted(dir_path.glob("*/*.yaml")):
            vendor = file_path.parent.name
            type_ = file_path.stem
            raw = load_yaml_fields(file_path)
            commands: dict[str, CommandSpec] = {}
            for command, spec in raw.get("cli", {}).items():
                commands[command] = CommandSpec(**spec)
            for key, spec in raw.get("rest", {}).items():
                commands[key] = CommandSpec(**spec)
            by_vendor_type.setdefault(vendor, {})[type_] = commands
        return cls(by_vendor_type=by_vendor_type)


__all__ = ["CommandCatalog", "CommandSpec"]
