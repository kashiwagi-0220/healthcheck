"""
healthcheck.command.cli_policy — CLIポリシー(実行可能コマンドの管理)

「設定変更を伴わない確認系コマンドのみ」を許可プレフィックス方式で通す安全の関門。
収集前に全コマンドを検証し、許可外は弾く。パース可否はここでは判定しない
(パース不可は比較時にスキップ。パース対応の追従コストを避ける)。

判定はシンプルに「許可プレフィックス(show/display/... の確認系)で始まるか」だけを見る
(禁止語チェックは持たない。安全性より単純さを優先した判断)。許可プレフィックスは
このファイルに直接書く(YAML 等の外部設定にはしない。安全装置の変更は必ずコード
レビューを通すため)。
"""

from __future__ import annotations

from dataclasses import dataclass

# 確認系(読み取り専用)コマンドの許可プレフィックス。ベンダー横断で一般的なもの。
# 変更する場合はこのファイルを直接編集する(コードレビューを経由させる)。
ALLOWED_PREFIXES: tuple[str, ...] = (
    "show", "display",          # Cisco / Huawei 等
    "get", "list",               # 一部 CLI / REST 風
    "ping", "traceroute",        # 到達性確認(状態を変えない)
)


@dataclass
class CliPolicy:
    allowed_prefixes: tuple[str, ...] = ALLOWED_PREFIXES

    def is_allowed(self, command: str) -> bool:
        """1コマンドが許可プレフィックスで始まるか。"""
        c = " ".join(command.strip().lower().split())   # 前後空白・連続空白を正規化
        if not c:
            return False
        return any(c == p or c.startswith(p + " ") for p in self.allowed_prefixes)

    def find_denied(self, commands: list[str]) -> list[str]:
        """コマンド群を検証し、拒否されたものの一覧を返す(空なら全て許可)。"""
        return [cmd for cmd in commands if not self.is_allowed(cmd)]

    def filter_allowed(self, commands: list[str]) -> list[str]:
        """許可されるコマンドだけを残して返す。"""
        return [cmd for cmd in commands if self.is_allowed(cmd)]
