"""
healthcheck.command — コマンド層

機器へ投げる内容(CLI/REST)に関する管理を1箇所に集約する:
  cli_policy       … CLI の実行可能コマンド管理(許可プレフィックス方式)      CliPolicy
  rest_policy      … REST の実行可能問い合わせ管理(method=get のみ許可)     RestPolicy
  command_set      … コマンドセットカタログ(cli+rest) + host→コマンドセット名の
                      解決(抽象IF CommandSetResolver もここに持つ)。
                      for_device()                      CommandSet / CommandSetEntry
                      / CommandSetResolver
  csv_resolver     … CommandSetResolver の実装(CSV。Excel編集向け)。将来 NetBox 等の
                      デバイスメタデータで動的に決める実装を追加する場合も、
                      この並びに1ファイル足すだけでよい      CsvCommandSetResolver
  command_catalog  … device_type ごとのコマンド定義(パーサ・ノイズ・比較キー)。
                      CLI・REST 共通                        CommandCatalog / CommandSpec

CliPolicy/RestPolicy(安全性の関門)と CommandCatalog(認可済み=パース方法まで
決まっているコマンドの定義)は独立している。take_snapshot は両方を満たすことを検証する。
"""

from healthcheck.command.cli_policy import CliPolicy
from healthcheck.command.rest_policy import RestPolicy
from healthcheck.command.command_set import CommandSet, CommandSetEntry, CommandSetResolver, validate_command_set_for
from healthcheck.command.csv_resolver import CsvCommandSetResolver
from healthcheck.command.command_catalog import CommandCatalog, CommandSpec

__all__ = [
    "CliPolicy", "RestPolicy",
    "CommandSet", "CommandSetEntry", "CommandSetResolver", "validate_command_set_for",
    "CsvCommandSetResolver",
    "CommandCatalog", "CommandSpec",
]
