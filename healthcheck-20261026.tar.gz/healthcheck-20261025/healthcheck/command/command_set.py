"""
healthcheck.command.command_set — 機器別の取得内容(CLI+REST)の管理

正常性確認で各機器から取得する内容を「コマンドセット」として定義・管理する。
コマンドセットは CLI コマンド群(cli)と REST 問い合わせ群(rest)の両方を持て、
同じ機器が両方から取得する構成にも対応する。人間向けの任意の説明文(description)
も持てる。

cli・rest はどちらも文字列のリスト(cli はコマンド文字列そのもの、rest は
CommandCatalog に定義された REST の key)。CLI は「コマンド文字列そのもの」が
実行内容を兼ねるため文字列だけで済むが、REST は key が識別子でしかなく実行内容
(method/path)は CommandCatalog 側の CommandSpec が持つ。実行内容を command_catalog
側へ寄せることで、「1つの機種ブロックだけ見れば全てがわかる」という設計方針を
CLI・REST で揃えている。

コマンドセットは必ず1つの機種(vendor + type)に属する(複数の機種のコマンドを
1つのコマンドセットに混在させない)。コマンドセット名は vendor_type と一致させる
運用が典型的だが、システムとして vendor/type に縛られない(同じ機種で用途違いの
コマンドセットを複数持てる。例: cisco_ios_full / cisco_ios_minimal)。この
「複数持てる」を成立させるにはコマンドセット名から vendor/type を機械的に
導出できないため、CommandSetEntry.vendor / CommandSetEntry.type として明示的に
持たせ、for_device() で機器本来の vendor/type と一致するか(タプル比較)を検証する。

構成:
  command_sets … コマンドセット名 → CommandSetEntry(vendor + type + cli + rest)の
                 カタログ。コード内蔵の既定は持たず、必ず
                 CommandSet.from_directory("config/command/command_set") で、
                 1コマンドセット=1ファイル(ファイル名=コマンドセット名)の
                 ディレクトリから読み込む(サンプル値が実運用のコマンドセットと
                 誤認されるのを避けるため、かつ GUI からの作成/削除/インポートを
                 ファイル単位の単純な操作にできるようにするため)。
  resolver     … host からコマンドセット名を決める CommandSetResolver
                 (CSV/YAML/将来 NetBox 等)

for_device(device) は resolver でコマンドセット名を決め、command_sets から引く。
command_sets が空 / resolver 未設定 / host が対応表に無い / コマンドセット名が未知 /
vendor・type が機器本来のものと不一致、のいずれも黙って空(CommandSetEntry())には
せず例外を投げる(コマンドセットは事前に決まっているべきという前提のため)。

各コマンド・REST問い合わせが実際に安全か・パース可能かは、ここでは判定しない
(CliPolicy/RestPolicy と CommandCatalog の責務。take_snapshot が検証する)。
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path

from healthcheck.models import Device
from healthcheck.command._yaml import load_yaml_fields


class CommandSetResolver(ABC):
    """機器が使うコマンドセット名を解決する(host→コマンドセット名)。

    現状は CSV で事前に用意した host→コマンドセット名の対応表を引くだけの実装
    (CsvCommandSetResolver。command/csv_resolver.py)だが、将来 NetBox 等の
    インベントリソースが持つデバイスメタデータ(Device.meta の site/role 等)を
    使って動的に決定する実装に差し替えられるよう、抽象を挟む(他層の
    InventorySource / Collector / ParserEngine と同じ発想)。

    決定できない(host が対応表に無い等)場合は None を返さず例外を投げる。
    「コマンドセットが事前に決まっていない機器がある」のは設定漏れであり、空の
    コマンド群で黙って進めるより、収集前に気づけたほうが安全なため(CliPolicy の
    安全性の関門と同じ考え方)。
    """

    @abstractmethod
    def resolve(self, device: Device) -> str:
        """この機器のコマンドセット名を返す。決定できなければ例外を投げる。"""


def require_command_set(host: str, table: dict[str, str], source: str) -> str:
    """host→コマンドセット名の対応表(dict)を引く共通処理。CommandSetResolver の
    実装(CsvCommandSetResolver 等)が共有する。

    見つからなければ ValueError(どのファイルの何が足りないか分かるメッセージ)。
    """
    if host not in table:
        raise ValueError(
            f"{host}: コマンドセットが未指定です({source})。"
            "host→コマンドセット名の対応表に追加してください。"
        )
    return table[host]


@dataclass
class CommandSetEntry:
    """1つのコマンドセットの中身。CLI(cli)と REST(rest)の両方を持てる。
    rest は RestQuery ではなく CommandCatalog に定義された key の文字列(cli と
    同じ形)。実行内容(method/path)は CommandCatalog 側が持つ(command_catalog.py
    参照)。vendor/type はこのコマンドセットが対象とする機種(両方必須。1コマンドセット
    =1機種)。description は人間向けの任意の説明文(未設定時は None)。"""
    vendor: str
    type: str
    cli: list[str] = field(default_factory=list)
    rest: list[str] = field(default_factory=list)
    description: str | None = None


def validate_command_set_for(
    command_sets: dict[str, CommandSetEntry], command_set_name: str, vendor: str, type_: str,
) -> CommandSetEntry:
    """command_set_name が command_sets に実在し、かつ vendor/type が一致することを
    検証し、一致する CommandSetEntry を返す。どちらかを満たさなければ ValueError
    (メッセージは呼び出し側がそのまま使える汎用的な文面。host 等の文脈を前置き
    したい場合は呼び出し側で付け加える)。

    CommandSet.for_device()(実行時の検証)と GUI の機器保存時検証
    (gui/backend/app/api/devices.py の _validate_command_set)が共有する。
    """
    if command_set_name not in command_sets:
        raise ValueError(
            f"未知のコマンドセットです({command_set_name})。"
            "config/command/command_set/ に定義してください。"
        )
    entry = command_sets[command_set_name]
    if (entry.vendor, entry.type) != (vendor, type_):
        raise ValueError(
            f"コマンドセット '{command_set_name}' は vendor='{entry.vendor}' "
            f"type='{entry.type}' 向けですが、指定された vendor='{vendor}' "
            f"type='{type_}' と一致しません。"
        )
    return entry


@dataclass
class CommandSet:
    command_sets: dict[str, CommandSetEntry] = field(default_factory=dict)
    resolver: CommandSetResolver | None = None

    def for_device(self, device: Device) -> CommandSetEntry:
        """その機器が取得すべき内容(CLI+REST)を返す。決定できなければ例外を投げる。"""
        if self.resolver is None:
            raise ValueError(
                "CommandSetResolver が未設定です。CommandSet(resolver=...) で "
                "host→コマンドセット名の解決方法(CsvCommandSetResolver 等)を指定してください。"
            )
        command_set_name = self.resolver.resolve(device)
        try:
            return validate_command_set_for(self.command_sets, command_set_name, device.vendor, device.type)
        except ValueError as e:
            raise ValueError(f"{device.host}: {e}") from e

    @classmethod
    def from_directory(cls, dir_path: str | Path, *, resolver: CommandSetResolver | None = None) -> CommandSet:
        """ディレクトリ配下の *.yaml(1ファイル=1コマンドセット、ファイル名=コマンドセット名)
        から生成する。各ファイルは {vendor: str, type: str, description?: str, cli: [...],
        rest: [...]} の形(vendor・type は必須、description は任意。cli・rest は
        どちらも文字列のリスト)。resolver は別途渡す(host→コマンドセット名の
        解決方法は設定データではなく実装の選択のため)。"""
        dir_path = Path(dir_path)
        command_sets = {}
        for file_path in sorted(dir_path.glob("*.yaml")):
            entry = load_yaml_fields(file_path)
            vendor = entry.get("vendor")
            type_ = entry.get("type")
            if not vendor:
                raise ValueError(f"{file_path}: vendor が指定されていません。")
            if not type_:
                raise ValueError(f"{file_path}: type が指定されていません。")
            command_sets[file_path.stem] = CommandSetEntry(
                vendor=vendor,
                type=type_,
                cli=list(entry.get("cli", [])),
                rest=list(entry.get("rest", [])),
                description=entry.get("description"),
            )
        return cls(command_sets=command_sets, resolver=resolver)
