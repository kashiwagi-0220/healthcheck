"""
healthcheck.command.csv_resolver — CSV による host→コマンドセット名の解決

CommandSetResolver(command_set.py)の実装。host, command_set の2列があるCSVを読む
(host/command_set 以外の列があっても無視するだけなので、inventory 層の CsvInventory
が読む devices.csv(host, vendor, type, ip, command_set 等)と同じファイルを共有して
構わない。1行=1機器を保ち、Excel でそのまま編集できる形にする。

例(必要な2列だけ抜粋):
  host,command_set
  RT-01,cisco_ios
  SW-01,cisco_nxos_full
"""

from __future__ import annotations

import csv
from pathlib import Path

from healthcheck.models import Device
from healthcheck.command.command_set import CommandSetResolver, require_command_set


class CsvCommandSetResolver(CommandSetResolver):
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self._table: dict[str, str] | None = None    # 遅延読み込み・キャッシュ

    def _load(self) -> dict[str, str]:
        if self._table is None:
            table: dict[str, str] = {}
            with self.path.open(newline="", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    host = (row.get("host") or "").strip()
                    command_set = (row.get("command_set") or "").strip()
                    if host and command_set:
                        table[host] = command_set
            self._table = table
        return self._table

    def resolve(self, device: Device) -> str:
        return require_command_set(device.host, self._load(), str(self.path))
