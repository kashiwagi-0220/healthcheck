"""
healthcheck.command.rest_policy — RESTポリシー(実行可能な問い合わせの管理)

CliPolicy(CLI版)と対になる、REST版の安全の関門。CliPolicy は自由文字列の
コマンドをプレフィックスで判定するが、RestQuery は既に構造化されている(自由文字列を
組み立てない)ため、判定は単純に「method が読み取り専用(既定 "get")か」だけを見る。

RestQuery.method は既定で "get" だが、型としては文字列で縛っていない(設定ファイルの
値がそのまま入りうる)ため、収集前にここで機械的に検証する(CliPolicy と同じ
「設定ミスは黙って進めず弾く」という考え方)。
"""

from __future__ import annotations

from dataclasses import dataclass

from healthcheck.models import RestQuery

# 許可する method。読み取り専用のみ(状態を変える post/put/delete 等は含めない)。
ALLOWED_METHODS: tuple[str, ...] = ("get",)


@dataclass
class RestPolicy:
    allowed_methods: tuple[str, ...] = ALLOWED_METHODS

    def is_allowed(self, query: RestQuery) -> bool:
        """1つの RestQuery が読み取り専用の method か。"""
        return query.method.strip().lower() in self.allowed_methods

    def find_denied(self, queries: list[RestQuery]) -> list[RestQuery]:
        """RestQuery 群を検証し、拒否されたものの一覧を返す(空なら全て許可)。"""
        return [q for q in queries if not self.is_allowed(q)]

    def filter_allowed(self, queries: list[RestQuery]) -> list[RestQuery]:
        """許可される RestQuery だけを残して返す。"""
        return [q for q in queries if self.is_allowed(q)]
