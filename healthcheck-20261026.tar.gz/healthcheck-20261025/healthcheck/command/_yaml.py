"""
healthcheck.command._yaml — command層の設定(YAML)読み込み共通ヘルパー

command層のうち、設定をディレクトリ配下の YAML ファイル(1ファイル=1エントリ)
から読み込む from_directory() を持つクラス(CommandSet/CommandCatalog)向けの
読み込み共通ヘルパー。両クラスとも、1ファイルの内容が {cli: {...}, rest: {...}}
というトップレベル dict になる形で使う。CliPolicy は対象外(許可プレフィックスは
安全装置のためコード直書きで、YAML化しない方針。command/cli_policy.py 参照)。

YAML は各クラスの既定値を完全に置き換える(コード内蔵 dict とのマージはしない)。
一部キーだけ書けば残りは既定値を引き継ぐ、という部分上書きは行わない方が
「今その設定がどこから来ているか」を追いやすく、保守しやすいため。
"""

from __future__ import annotations

from pathlib import Path

import yaml


def load_yaml_fields(path: str | Path) -> dict:
    """YAMLファイルを読み、トップレベルの dict を返す。

    ファイルが無ければ空 dict を返す(呼び出し側の dataclass フィールド既定値が
    そのまま使われる = YAML 未導入時は従来通りコード内蔵の既定で動く)。
    """
    path = Path(path)
    if not path.exists():
        return {}
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    return data or {}
