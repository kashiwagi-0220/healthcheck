"""
healthcheck.storage.data_memory — DataStore のメモリ実装(ディスク非使用)

FilesystemStore と同じ DataStore を満たすが、実体をすべてプロセス内の dict に
持ち、ディスクには一切書き込まない(GUI の「スナップショット取得」で保存せずに
表示だけしたい場合に使う)。take_snapshot() は DataStore という抽象IFにしか
依存しないため、この実装を渡すだけで「収集はするが何も永続化しない」動作になる。

インスタンスはその場限り(1回の取得分)として使う想定。プロセスや GC でインスタンスが
破棄されれば中身も消える。別インスタンス・別プロセスから同じデータを引くことは
できない(DataRef.backend="memory" の参照は、それを作った同じインスタンスでしか
load_raw/load_parsed できない)。
"""

from __future__ import annotations

from datetime import datetime, timezone

from healthcheck.models import DataRef, Snapshot
from healthcheck.storage.base import DataStore


class InMemoryDataStore(DataStore):
    def __init__(self):
        self._raw: dict[str, str] = {}
        self._parsed: dict[str, dict | None] = {}
        self._snapshots: dict[tuple[str, str], Snapshot] = {}
        self._counter = 0

    # ---- show コマンド結果(毎回保存・過去保持) ----

    def save_command(self, host, command, raw, parsed=None, taken_at=None) -> DataRef:
        self._counter += 1
        key = f"{host}:{command}:{self._counter}"
        self._raw[key] = raw
        if parsed is not None:
            self._parsed[key] = parsed
        return DataRef(backend="memory", raw=key, parsed=key if parsed is not None else None)

    # ---- snapshot(ポインタ集合) ----

    def save_snapshot(self, snapshot: Snapshot) -> None:
        self._snapshots[(snapshot.host, snapshot.id)] = snapshot

    def get_snapshot(self, host, snapshot_id) -> Snapshot | None:
        return self._snapshots.get((host, snapshot_id))

    def list_snapshots(self, host=None, since=None) -> list[Snapshot]:
        result = [
            snap for (h, _), snap in self._snapshots.items()
            if (host is None or h == host) and (since is None or not snap.taken_at or snap.taken_at >= since)
        ]
        result.sort(key=lambda s: s.taken_at or datetime.min.replace(tzinfo=timezone.utc))
        return result

    # ---- 実体ロード ----

    def load_raw(self, ref: DataRef) -> str:
        if ref.backend != "memory" or not ref.raw:
            raise ValueError(f"unsupported or empty ref for memory store: {ref}")
        return self._raw[ref.raw]

    def load_parsed(self, ref: DataRef) -> dict | None:
        if ref.backend != "memory" or not ref.parsed:
            return None
        return self._parsed.get(ref.parsed)


__all__ = ["InMemoryDataStore"]
