"""
healthcheck.storage — 保管層

DataStore(抽象IF。base.py)… show コマンド結果(毎回保存)と snapshot(ポインタ集合)。

  base            … DataStore(抽象IF)
  data_filesystem … FilesystemStore(ディスクへ保存する実装)
  data_memory     … InMemoryDataStore(メモリのみの実装。ディスクに一切書かずに
                    取得結果を見るだけ・比較するだけの用途向け)

将来ファイルシステム以外(MinIO/PostgreSQL 等)に差し替える場合も、この抽象を
満たす実装を追加するだけでよい(他層は無変更)。take_snapshot() 等の上位層は
DataStore という抽象IFにしか依存しないため、渡す実装を切り替えるだけで済む。
"""

from healthcheck.storage.base import DataStore
from healthcheck.storage.data_filesystem import FilesystemStore
from healthcheck.storage.data_memory import InMemoryDataStore

__all__ = ["DataStore", "FilesystemStore", "InMemoryDataStore"]
