"""
healthcheck.storage.base — 保管層の抽象IF

保管するのは show コマンド結果(毎回保存)と snapshot(ポインタ集合)。
共通関数(take_snapshot 等)はこの抽象だけに依存する。現状の実装はファイルシステムのみだが、
将来オブジェクトストレージ等へ差し替えても上位は無変更で済むよう抽象を残す。

機器の識別は host(ホスト名)で行う。インベントリソース(CSV/YAML/NetBox)で変わりうる
id ではなく、ソースをまたいで安定する host をキーにする(models.Device 参照)。
snapshot は意味づけ(checkpoint/work/label)を持たない。それらは GUI 側の管理。

保管するのは取得データ(raw/parsed)だけで、比較の実行結果(HealthCheckResult)は
保管しない。結果は呼び出し側がその場で受け取るレスポンスで完結する。
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime

from healthcheck.models import DataRef, Snapshot


class DataStore(ABC):
    """show コマンド結果(毎回保存)と snapshot(ポインタ)の保管。"""

    # ---- show コマンド結果(毎回保存・過去保持) ----

    @abstractmethod
    def save_command(
        self,
        host: str,
        command: str,
        raw: str,
        parsed: dict | None = None,
        taken_at: datetime | None = None,
    ) -> DataRef:
        """1コマンドの結果を新しい時点として保存し、その参照(DataRef)を返す。"""

    # ---- snapshot(ポインタ集合) ----

    @abstractmethod
    def save_snapshot(self, snapshot: Snapshot) -> None:
        """snapshot(manifest)を保存する。"""

    @abstractmethod
    def get_snapshot(self, host: str, snapshot_id: str) -> Snapshot | None:
        """snapshot_id で snapshot を取得する。無ければ None。"""

    @abstractmethod
    def list_snapshots(
        self,
        host: str | None = None,
        since: datetime | None = None,
    ) -> list[Snapshot]:
        """条件に合う snapshot 一覧(メタのみ)を返す。時系列順。

        意味づけ(checkpoint/work)では絞らない。区別は GUI が管理する。
        """

    # ---- 実体ロード(DataRef が指す実データを遅延取得) ----

    @abstractmethod
    def load_raw(self, ref: DataRef) -> str:
        """参照から生出力を取得する。"""

    @abstractmethod
    def load_parsed(self, ref: DataRef) -> dict | None:
        """参照からパース済みデータを取得する。パース結果が無ければ None。"""
