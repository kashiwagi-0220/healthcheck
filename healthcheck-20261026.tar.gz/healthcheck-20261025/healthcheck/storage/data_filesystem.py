"""
healthcheck.storage.data_filesystem — DataStore のファイルシステム実装

ディスク構造(機器の識別は host):

  <root>/devices/<host>/
    ├── <command_slug>/<timestamp>/     # show 結果(毎回保存・過去保持)
    │   ├── raw.txt
    │   ├── parsed.json                 # パースできた場合のみ
    │   └── meta.json                   # コマンド原文 / 取得時刻
    └── snapshot/<snapshot_id>/
        └── manifest.json               # Snapshot(ポインタ集合。意味づけなし)

DataRef.raw / parsed は「保管ルートからの相対パス」を持つ。load 時に root と
結合して開くため、保管場所を移してもツール側の参照は壊れにくい。

timestamp はマイクロ秒精度(秒精度だと同一秒内の再取得で上書きされるため)。
"""

from __future__ import annotations

import json
import re
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path

from healthcheck.models import DataRef, Snapshot
from healthcheck.storage.base import DataStore


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _ts(dt: datetime) -> str:
    """時刻を並べ替え可能なコンパクト表記に(マイクロ秒精度。例 20260809T101530123456Z)。"""
    return dt.astimezone(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")


def _slug(command: str) -> str:
    """コマンド文字列をディレクトリ名に使える形へ。原文は meta.json が保持する。"""
    s = command.strip().lower()
    s = re.sub(r"[^\w]+", "_", s)      # 英数字以外を _ に
    return re.sub(r"_+", "_", s).strip("_")


class FilesystemStore(DataStore):
    def __init__(self, root: str | Path):
        self.root = Path(root)

    # ---- パス組み立て(内部) ----

    def _device_dir(self, host: str) -> Path:
        return self.root / "devices" / host

    # ---- show コマンド結果(毎回保存) ----

    def save_command(self, host, command, raw, parsed=None, taken_at=None) -> DataRef:
        taken_at = taken_at or _utcnow()
        ts = _ts(taken_at)
        cmd_dir = self._device_dir(host) / _slug(command) / ts
        cmd_dir.mkdir(parents=True, exist_ok=True)

        (cmd_dir / "raw.txt").write_text(raw, encoding="utf-8")
        if parsed is not None:
            (cmd_dir / "parsed.json").write_text(
                json.dumps(parsed, ensure_ascii=False, indent=2), encoding="utf-8"
            )
        (cmd_dir / "meta.json").write_text(
            json.dumps({"command": command, "taken_at": taken_at.isoformat()},
                       ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

        rel = cmd_dir.relative_to(self.root)
        return DataRef(
            backend="filesystem",
            raw=str(rel / "raw.txt"),
            parsed=str(rel / "parsed.json") if parsed is not None else None,
        )

    # ---- snapshot(ポインタ集合) ----

    def save_snapshot(self, snapshot: Snapshot) -> None:
        snap_dir = self._device_dir(snapshot.host) / "snapshot" / snapshot.id
        snap_dir.mkdir(parents=True, exist_ok=True)
        (snap_dir / "manifest.json").write_text(
            json.dumps(_snapshot_to_dict(snapshot), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def get_snapshot(self, host, snapshot_id) -> Snapshot | None:
        manifest = self._device_dir(host) / "snapshot" / snapshot_id / "manifest.json"
        if not manifest.exists():
            return None
        return _snapshot_from_dict(json.loads(manifest.read_text(encoding="utf-8")))

    def list_snapshots(self, host=None, since=None) -> list[Snapshot]:
        result: list[Snapshot] = []
        if host:
            hosts = [host]
        else:
            devices_root = self.root / "devices"
            hosts = [p.name for p in devices_root.iterdir()] if devices_root.exists() else []

        for h in hosts:
            snap_root = self._device_dir(h) / "snapshot"
            if not snap_root.exists():
                continue
            for snap_dir in sorted(snap_root.iterdir()):   # snapshot_id=timestamp なので時系列順
                manifest = snap_dir / "manifest.json"
                if not manifest.exists():
                    continue
                snap = _snapshot_from_dict(json.loads(manifest.read_text(encoding="utf-8")))
                if since and snap.taken_at and snap.taken_at < since:
                    continue
                result.append(snap)
        return result

    # ---- 実体ロード ----

    def load_raw(self, ref: DataRef) -> str:
        if ref.backend != "filesystem" or not ref.raw:
            raise ValueError(f"unsupported or empty ref for filesystem: {ref}")
        return (self.root / ref.raw).read_text(encoding="utf-8")

    def load_parsed(self, ref: DataRef) -> dict | None:
        # パースできなかった command は parsed を持たない(比較時にスキップ扱い)
        if ref.backend != "filesystem" or not ref.parsed:
            return None
        return json.loads((self.root / ref.parsed).read_text(encoding="utf-8"))


# ---- Snapshot <-> dict(manifest.json のシリアライズ) ----

def _snapshot_to_dict(snap: Snapshot) -> dict:
    return {
        "id": snap.id,
        "host": snap.host,
        "taken_at": snap.taken_at.isoformat() if snap.taken_at else None,
        "success": snap.success,
        "error": snap.error,
        "refs": {cmd: asdict(ref) for cmd, ref in snap.refs.items()},
    }


def _snapshot_from_dict(d: dict) -> Snapshot:
    return Snapshot(
        id=d["id"],
        host=d["host"],
        taken_at=datetime.fromisoformat(d["taken_at"]) if d.get("taken_at") else None,
        refs={cmd: DataRef(**ref) for cmd, ref in d.get("refs", {}).items()},
        success=d.get("success", True),
        error=d.get("error"),
    )
