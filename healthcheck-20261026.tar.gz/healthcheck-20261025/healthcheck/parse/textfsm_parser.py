"""
healthcheck.parse.textfsm_parser — TextFSM パースエンジン(Cisco以外・汎用)

ntc-templates のテンプレートで raw をパースする。import は実行時(遅延)。
パース不可(対応テンプレート無し・失敗)は None を返す。

ntc-templates は platform 名(netmiko device_type 語彙準拠)でテンプレートを引く。
Device の vendor + type(カタログキー。利用者が自由に決める分類名)をこの語彙に変換
する対応表 _VENDOR_TYPE_TO_TEXTFSM はこのエンジン専用で、他層(collect層の
netmiko_collector等)には依存しない(genie_parser.py の _VENDOR_TYPE_TO_GENIE と同じ
考え方)。対応表は vendor → type → platform名の2階層辞書として持つ。vendor+type と platform 名が
同じ場合(例 "cisco"→"ios"→"cisco_ios")も含め明示的に書く(暗黙にそのまま使う既定は
持たない)。未登録の組み合わせは None(このパーサでは対応不可としてスキップ。
cisco/apic・f5/bigip のような REST 専用の組み合わせや、genie_parser 同様まだ登録して
いない組み合わせはこれで該当)。現時点でこのプロジェクトの command_catalog は
cisco 側では TextFSM を実際には使っていない(全て genie/json)ため、この対応表は
将来使う場合の準備として cisco の ios/nxos/xe のみ登録している。

自作テンプレートの追加方法:
  ntc-templates 本体のテンプレート(.textfsm ファイル)と索引(index)は、
  パッケージのインストール先(例 .venv/lib/pythonX.Y/site-packages/ntc_templates/templates/)
  に入っている。index は "Template, Hostname, Platform, Command" の4列(CSV風)で、
  例えば show ip route の行はこう:
    cisco_ios_show_ip_route.textfsm, .*, cisco_ios, sh[[ow]] ip r[[oute]]
  (Hostname は基本 ".*"。Command は [[..]] で省略入力にも一致する正規表現。
   Platform は parse_output(platform=...) に渡した値
   =_VENDOR_TYPE_TO_TEXTFSM[device.vendor][device.type] と一致させる)

  追加する方法は主に2つ:
  1) NTC_TEMPLATES_DIR 環境変数でテンプレートディレクトリ自体を差し替える
     (ntc_templates.parse._get_template_dir() が最初に見る)。ただし parse_output は
     指定ディレクトリの index だけを見るため、同梱の939テンプレートも使いたければ
     そのディレクトリごとコピーして自作分を追記する必要がある(pip 再インストールで
     消えるインストール先を直接書き換えるのは避ける)。
  2) ntc_templates.parse.parse_output(..., template_dir=..., try_fallback=True) で
     呼び出しごとに独自ディレクトリを指定し、見つからなければ既定ディレクトリに
     フォールバックさせる(index は自作テンプレート分だけで足りる)。
     ただしこちらは template_dir/try_fallback を呼び出し側から渡せる必要があり、
     現在の TextFsmParser.parse() はこの2引数を渡していない(拡張が必要)。
"""

from __future__ import annotations

from typing import Any

from healthcheck.models import Device
from healthcheck.parse.base import ParserEngine

# vendor -> type -> ntc-templates platform 名。同じ語彙になる場合も含め全て明示的に書く
# (暗黙の既定は持たない)。cisco 側は TextFSM を実際に使うコマンドが今のところ無いため
# 準備のみ。paloalto/panos は実際に textfsm を使う(config/command/command_catalog/
# paloalto/panos.yaml 参照)。
_VENDOR_TYPE_TO_TEXTFSM = {
    "cisco": {
        "ios": "cisco_ios",
        "nxos": "cisco_nxos",
        "iosxe": "cisco_xe",
    },
    "paloalto": {
        "panos": "paloalto_panos",
    },
}


class TextFsmParser(ParserEngine):
    def parse(self, device: Device, command: str, raw: str) -> Any | None:
        platform = _VENDOR_TYPE_TO_TEXTFSM.get(device.vendor, {}).get(device.type)
        if not platform:
            return None                         # TextFSM 対象外の機種
        try:
            from ntc_templates.parse import parse_output   # 遅延 import
        except ImportError as e:
            raise ImportError(
                "ntc-templates が未導入です。'pip install ntc-templates' が必要です。"
            ) from e
        try:
            # 対応テンプレート無しは例外→None
            return parse_output(platform=platform, command=command, data=raw)
        except Exception:
            return None
