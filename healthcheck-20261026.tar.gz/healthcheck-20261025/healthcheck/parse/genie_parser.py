"""
healthcheck.parse.genie_parser — Genie パースエンジン(Cisco系)

Genie(pyATS)で raw をパースする。依存が重く環境によっては未導入のため、
import は parse 実行時に行う(遅延 import)。未導入なら ImportError を説明的に投げる。
パース不可(対応 parser 無し・パース失敗)は None を返す。

Device の vendor + type(カタログキー。command_catalog のディレクトリ名+ファイル名に
使う値で、利用者が自由に決める分類名)は Genie の os 名と語彙が違うため、ここで変換
する。この変換表はこのエンジンだけが使う独自の対応表で、他層(collect層の
netmiko_collector等)には依存しない(parse層がcollect層に依存しないよう、各パーサが
vendor/type から直接自分の語彙に変換する)。対応表は vendor → type → Genie os 名の
2階層辞書として持つ(結合済み文字列をキーにせず、vendor/type の2軸のまま階層化する)。
cisco/ios・xe・xr・nxos・asa のように vendor+type がそのまま Genie 側でも使う名前の
由来になっている機種は変換不要。
"""

from __future__ import annotations

from typing import Any

from healthcheck.models import Device
from healthcheck.parse.base import ParserEngine

# vendor -> type -> Genie os 名(変換が要る組み合わせだけ書く)
_VENDOR_TYPE_TO_GENIE = {
    "cisco": {
        "ios": "ios",
        "iosxe": "iosxe",
        "xr": "iosxr",
        "nxos": "nxos",
        "asa": "asa",
    },
}


class GenieParser(ParserEngine):
    def parse(self, device: Device, command: str, raw: str) -> Any | None:
        os_name = _VENDOR_TYPE_TO_GENIE.get(device.vendor, {}).get(device.type)
        if not os_name:
            return None                         # Genie 対象外の機種
        try:
            from genie.conf.base import Device as GenieDevice  # 遅延 import
            from genie.libs.parser.utils import get_parser
        except ImportError as e:
            raise ImportError(
                "Genie(pyATS)が未導入です。'pip install pyats[library]' が必要です。"
            ) from e

        try:
            gdev = GenieDevice(name=device.host, os=os_name)
            gdev.custom.setdefault("abstraction", {})["order"] = ["os"]
            return gdev.parse(command, output=raw)      # dict を返す
        except Exception:
            # 対応 parser 無し・パース失敗はスキップ扱い(None)
            return None
