"""
healthcheck.parse.base — パースエンジンの抽象IF

ParserEngine は「1コマンドの生出力を構造化データにする」単位。
CommandCatalog が選んだエンジン("genie"/"textfsm")をファサードが呼ぶ。

パースできない場合は None を返す(例外を投げない)。None は比較側で
skipped(パース不可)として扱われる = パース済みのみ比較の方針と整合。
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from healthcheck.models import Device


class ParserEngine(ABC):
    """生出力を構造化する1エンジン(genie / textfsm / json)。"""

    @abstractmethod
    def parse(self, device: Device, command: str, raw: str) -> Any | None:
        """raw を構造化して返す。パース不可なら None。

        戻り値は Genie なら dict、TextFSM なら list[dict]。比較層の normalize が
        どちらも dict に正規化するため、ここでは形を統一しない。
        """
