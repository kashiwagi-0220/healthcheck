"""
healthcheck.parse — パース層ファサード

parse(device, command, raw, command_catalog, parse_engines=...) が入口。
CommandCatalog(command 層。device_type + command ごとの定義)でエンジン
("genie"/"textfsm")を選び、そのエンジンだけで parse する。フォールバックはしない
(選んだ1つでダメなら None=スキップ)。catalog に定義が無いコマンドも None
(「認可されているか」の検証は take_snapshot 側の責務で、ここでは行わない)。

parse_engines は差し替え可能(テストでの injection 用)。既定は実パーサ(genie / textfsm / json)。
"""

from __future__ import annotations

from typing import Any

from healthcheck.models import Device
from healthcheck.command.command_catalog import CommandCatalog
from healthcheck.parse.base import ParserEngine


def default_engines() -> dict[str, ParserEngine]:
    """実パーサのエンジン表(遅延生成)。実 import はエンジンの parse 実行時。"""
    from healthcheck.parse.genie_parser import GenieParser
    from healthcheck.parse.textfsm_parser import TextFsmParser
    from healthcheck.parse.json_parser import JsonParser
    return {"genie": GenieParser(), "textfsm": TextFsmParser(), "json": JsonParser()}


def parse(
    device: Device,
    command: str,
    raw: str,
    *,
    command_catalog: CommandCatalog | None = None,
    parse_engines: dict[str, ParserEngine] | None = None,
) -> Any | None:
    """1コマンドの生出力を、カタログで選んだエンジンでパースして返す。

    パース不可(カタログに定義が無い/選んだエンジンが None を返す)なら None。
    比較側で skipped 扱い。
    """
    command_catalog = command_catalog or CommandCatalog()
    parse_engines = parse_engines if parse_engines is not None else default_engines()

    spec = command_catalog.spec_for(device.vendor, device.type, command)
    if spec is None:
        return None                             # カタログに定義が無いコマンド
    engine = parse_engines.get(spec.parser)
    if engine is None:
        return None                             # そのエンジンが用意されていない
    return engine.parse(device, command, raw)


__all__ = ["parse", "default_engines"]
