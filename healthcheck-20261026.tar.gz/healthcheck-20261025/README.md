# healthcheck

ネットワーク機器から情報を取得し、2つの時点を比較して差分の有無を判定する正常性確認ツールです。
作業の前後で同じコマンドを実行し、意図しない変化が起きていないかを確認する用途を想定しています。

- 作業前に「スナップショット」を取得しておき、作業後に「正常性確認」でその時点と比較します
- 比較はパース済みデータに対して行い、毎回変わる値(uptime・カウンタ等)は設定で除外できます
- 操作はすべて Web GUI から行います(CLI は提供していません)

設計の詳細は `DESIGN.md` を参照してください。

---

## 1. 前提条件

### サーバ

| 項目 | 要件 | 備考 |
|---|---|---|
| OS | Linux | RHEL 9 系で動作確認。他ディストリビューションでも動作しますが未検証です |
| Python | **3.9 以上** | 3.9 で動作確認済み |
| メモリ | 2 GB 以上を推奨 | 機器数・同時実行数に依存します |
| ディスク | **2 GB 以上**(依存ライブラリ) + データ領域 | Genie(pyats)が大きく、Python 環境だけで約 900 MB になります |

**Node.js は不要です。** 画面はビルド済みの状態で配布し、API と同じプロセスから配信します。
画面のソースを変更して作り直す場合のみ、手元の作業環境に Node.js 20.19 以上(または 22.12 以上)が必要です。


### ネットワーク

- 管理対象機器への到達性
  - CLI 収集: **SSH (TCP/22)**
  - REST 収集: **HTTPS (TCP/443)**
- 踏み台(bastion)経由でしか到達できない機器がある場合は、踏み台への SSH 到達性

### 管理対象機器

| ベンダー | 機種 | 収集方式 |
|---|---|---|
| Cisco | IOS / IOS-XE / NX-OS / ASA | CLI (SSH) |
| Cisco | APIC (ACI) | REST |
| F5 | BIG-IP | REST |
| Palo Alto | PAN-OS | REST |

機器側には**参照系コマンドの実行権限を持つアカウント**を用意してください。設定変更は行いませんが、
機種によっては `show` 系コマンドに enable (特権) が必要な場合があります。

---

## 2. 構築手順

以下では `/opt/healthcheck` に配置する例で説明します。別の場所でも構いません。

### 2.1 ファイルの配置

移行元で配布用アーカイブを作ります。

```bash
./make-dist.sh                 # healthcheck-<日付>.tar.gz ができる
```

動作に必要なものだけが入り(約 270 KB)、**`config/credentials.yaml`(平文の認証情報)・
`data/`・`.venv/`・`node_modules/` は含まれません**。認証情報が混入していないことは
スクリプトが毎回確認し、見つかった場合は中止します。

展開先のサーバで配置します。

```bash
sudo mkdir -p /opt/healthcheck
sudo chown "$USER:$USER" /opt/healthcheck
tar xzf healthcheck-<日付>.tar.gz --strip-components=1 -C /opt/healthcheck
cd /opt/healthcheck
```

展開するのは以下です。`data/`(取得済みデータ)と `config/credentials.yaml`(認証情報)は
**移行元から持ち込まないでください**。前者は環境ごとに作られ、後者は平文の認証情報を含みます。

```
healthcheck/      コア実装(収集・パース・比較・保管)
gui/backend/      Web API (FastAPI)
gui/frontend/     画面 (React)
config/           設定ファイル(後述)
requirements.txt
```

### 2.2 Python 環境

```bash
cd /opt/healthcheck
python3 -m venv .venv
.venv/bin/pip install --upgrade pip
.venv/bin/pip install -r requirements.txt
```

コアと GUI の依存はすべて `requirements.txt` にまとまっています。

> **オフライン環境の場合**
> インターネットに接続できる同じ OS・同じ Python バージョンの環境で
> `pip download -r requirements.txt -d packages/` を実行し、`packages/` を持ち込んで
> `pip install --no-index --find-links packages/ -r requirements.txt` でインストールします。
> Genie (pyats) は依存が多くサイズも大きい(展開後で約 900 MB)点に注意してください。


### 2.3 画面(通常は作業不要)

`gui/frontend/dist/` にビルド済みの画面が含まれています。**そのまま使う場合、この手順は不要です。**
API を提供する FastAPI が同じプロセスからこのディレクトリを配信します。

画面のソースを変更した場合のみ、Node.js のある環境で作り直してください。

```bash
cd gui/frontend
npm ci
npm run build          # gui/frontend/dist/ が更新される
```

API の呼び出し先は相対パスで解決するため、**展開先のホスト名や URL をビルド時に指定する必要はありません。**


### 2.4 設定ファイルの準備

すべて `config/` 配下です。GUI からも編集できますが、初回は直接用意するのが簡単です。

#### `config/devices.csv` — 管理対象機器

```csv
host,vendor,type,ip,command_set
RT-01,cisco,ios,192.168.0.201,cisco_ios
SW-01,cisco,iosxe,192.168.0.202,cisco_iosxe
```

- `host` が機器の識別子です(環境内で一意にしてください)
- `vendor` / `type` の組み合わせは、コマンドカタログの `config/command/command_catalog/<vendor>/<type>.yaml` と対応します
- `command_set` には後述のコマンドセット名を指定します

#### `config/credentials.yaml` — 認証情報

雛形をコピーして編集します。

```bash
cp config/credentials.yaml.example config/credentials.yaml
chmod 600 config/credentials.yaml
```

```yaml
default:
  username: network
  password: "********"
  secret: "********"      # enable パスワード。不要なら省略可
hosts:                     # 機器ごとに上書きしたい場合のみ
  FW-01:
    username: admin
    password: "********"
```

**このファイルは平文です。** 必ず権限を絞ってください。

```bash
chmod 600 config/credentials.yaml
```

`.gitignore` で除外済みですが、バックアップや転送時の扱いにも注意してください。

#### `config/proxy.conf` — 踏み台経由の設定(任意)

踏み台を使わない場合は空のままで構いません。

```
Host 192.168.*.*
    ProxyJump bastion.example.com
```

OpenSSH の設定形式で、`Host` はグロブパターン(`*` `?`)で一致します(CIDR は使えません)。
有効/無効の切り替えはなく、**パターンに一致しない機器には適用されません**。

#### `config/command/` — 取得するコマンドの定義

リポジトリに含まれる定義をそのまま使えます。

- `command_catalog/<vendor>/<type>.yaml` — 機種ごとに「どのコマンドを、どのパーサで解析し、比較時に何を無視するか」
- `command_set/<name>.yaml` — 機器に割り当てる、取得コマンドの組み合わせ

変更方法は画面の「利用ガイド」に詳しく書いてあります。

### 2.5 データディレクトリ

```bash
mkdir -p /opt/healthcheck/data
```

取得したスナップショットと実行ログがここに保存されます。**自動削除はされません。**
運用に応じて古いデータを整理してください(後述)。

---

## 3. 起動

画面と API は同じ1プロセス(uvicorn)が提供します。Web サーバを別に立てる必要はありません。

`/etc/systemd/system/healthcheck.service`:

```ini
[Unit]
Description=healthcheck
After=network.target

[Service]
Type=simple
User=healthcheck
WorkingDirectory=/opt/healthcheck
Environment=PYTHONPATH=/opt/healthcheck
ExecStart=/opt/healthcheck/.venv/bin/python -m uvicorn app.main:app \
  --host 0.0.0.0 --port 8000 --app-dir /opt/healthcheck/gui/backend
Restart=on-failure

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now healthcheck
sudo systemctl status healthcheck
```

ブラウザから `http://<サーバのホスト名またはIP>:8000/` で開けます。

- `PYTHONPATH` の指定は**必須**です。このプロジェクトは `pip install` される形式ではなく、
  リポジトリ直下を import パスに通して使います
- `--host 0.0.0.0` は他のマシンからアクセスするための指定です。アクセス制御は
  ファイアウォールか、後述のリバースプロキシで行ってください

```bash
sudo firewall-cmd --add-port=8000/tcp --permanent && sudo firewall-cmd --reload
```

### リバースプロキシを置く場合(任意)

HTTPS 化や Basic 認証をかけたい場合は、前段に nginx 等を置きます。この構成では
API のパスごとの振り分けは不要で、**すべてをそのまま中継するだけ**です。

```nginx
server {
    listen 443 ssl;
    server_name healthcheck.example.com;

    ssl_certificate     /etc/pki/tls/certs/healthcheck.crt;
    ssl_certificate_key /etc/pki/tls/private/healthcheck.key;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;

        # 取得の進捗は Server-Sent Events で流すため、バッファリングを必ず切る。
        # 有効なままだと進捗が実行完了までまとめて届き、画面が固まったように見える。
        proxy_buffering off;
        proxy_cache off;
        proxy_read_timeout 1h;   # 機器数が多いと収集に時間がかかる
    }
}
```

この場合、uvicorn 側は `--host 127.0.0.1` に戻し、外部へ直接公開しないでください。
SELinux が有効な環境では中継を許可します。

```bash
sudo setsebool -P httpd_can_network_connect on
```


## 4. 動作確認

```bash
# 画面が返るか(HTML)
curl -s -o /dev/null -w '%{http_code} %{content_type}\n' http://127.0.0.1:8000/

# API が応答するか(JSON)
curl -s http://127.0.0.1:8000/devices
```

ブラウザで開いたら、以下の順で確認するのが確実です。

1. **機器 → 機器一覧** に `devices.csv` の内容が表示される
2. **スナップショット → スナップショット取得** で 1 台だけ選んで「取得して表示」を実行する
3. 失敗する場合は **ログ** を開き、接続・認証のどちらで失敗しているか確認する

よくある失敗:

| 症状 | 確認点 |
|---|---|
| 接続タイムアウト | 機器への経路、踏み台設定 (`proxy.conf`)、機器側の ACL |
| 認証エラー | `credentials.yaml` のユーザー名・パスワード、機器側のアカウント |
| 「コマンドセットが見つかりません」 | `devices.csv` の `command_set` 列と `config/command/command_set/` のファイル名 |
| 画面が 404 になる | `gui/frontend/dist/` が存在するか。無い場合は API のみ起動している状態です |

---

## 5. 運用

### ログ

`data/healthcheck.log` に出力されます(5 MB ごとに 3 世代でローテーション)。
画面の「ログ」からも参照できます。記録されるのは次の2種類です。

- 機器への接続・コマンド実行の記録
- 設定の変更操作(機器の追加/編集/削除、CSV・YAML の取り込み、認証情報・プロキシ設定の変更など)

### データの増加

`data/devices/` に取得結果が蓄積し続けます。**自動削除はしません。**
保存期間を決めて、古いものを定期的に削除してください。

```bash
# 例: 90 日より古い取得データを削除する
find /opt/healthcheck/data/devices -type d -mtime +90 -exec rm -rf {} +
```

### バックアップ

| 対象 | 内容 | 優先度 |
|---|---|---|
| `config/` | 機器一覧・コマンド定義・認証情報 | **高**(再構築に必須) |
| `data/` | 取得済みスナップショット | 中(過去との比較が必要なら) |

コマンドカタログとコマンドセットは、画面から ZIP でダウンロードすることもできます。

### 更新

```bash
cd /opt/healthcheck
# コードを更新したあと
.venv/bin/pip install -r requirements.txt    # 依存が増えた場合のみ
sudo systemctl restart healthcheck
```

画面(`gui/frontend/dist/`)はビルド済みのものが配布物に含まれるため、
展開先でのビルドは不要です。

`config/` と `data/` は更新対象に含めないでください。

---

## 6. セキュリティ上の注意

このツールは**認証機構を持ちません。** 画面を開ける人は誰でも、機器情報・取得データ・
認証情報の登録内容を参照・変更できます。次のいずれかで保護してください。

- 社内ネットワークからのみ到達できる場所に置く
- nginx の Basic 認証や、リバースプロキシ側の認証と組み合わせる

あわせて以下に注意してください。

- **`config/credentials.yaml` は平文**です。権限は 600 とし、サーバへのログイン権限を絞ってください
- 社内に閉じたネットワークでない場合は `--host 127.0.0.1` に戻し、前段のリバースプロキシ経由で公開してください
- 実運用では HTTPS を推奨します(認証情報を画面から登録するため)
- 機器側のアカウントは、参照系のみ許可した専用アカウントを推奨します

---

## 7. 構成の概要

```
ブラウザ
   │  HTTP
   ▼
uvicorn (FastAPI) :8000          ← 1プロセスで画面と API の両方を提供
   │
   ├── /            → gui/frontend/dist (ビルド済みの画面)
   ├── /devices 等  → API
   │
   ├── SSH (netmiko) → 機器
   ├── HTTPS (REST)  → 機器
   │
   ├── config/  設定
   └── data/    取得データ・ログ
```

HTTPS や認証が必要な場合のみ、前段にリバースプロキシを置きます(「3. 起動」参照)。

| ディレクトリ | 役割 |
|---|---|
| `healthcheck/` | コア実装。収集・パース・比較・保管 |
| `gui/backend/` | Web API。コアの関数を組み合わせて画面に返す |
| `gui/frontend/` | 画面 |
| `config/` | 設定(機器一覧・認証情報・コマンド定義) |
| `data/` | 取得データとログ |
