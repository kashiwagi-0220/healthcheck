"""
gui.backend.app.sse — Server-Sent Events の1イベント整形

スナップショット取得・正常性確認はどちらも進捗を SSE で流すため、イベントの
組み立て方(1イベント = "data: {JSON}\\n\\n")をここで共有する。イベント種別は
各APIが決める({"type": "start"|"device_done"|"progress"|...})。
"""

from __future__ import annotations

import json


def sse_event(event_type: str, **data) -> str:
    """1イベント分のテキストを返す。datetime 等はそのまま str() に落とす。"""
    payload = json.dumps({"type": event_type, **data}, default=str)
    return f"data: {payload}\n\n"
