"""
gui.backend.app.yaml_archive — 設定YAMLディレクトリのZIP入出力

コマンドカタログ(config/command/command_catalog/)とコマンドセット
(config/command/command_set/)は複数ファイルで構成されるため、devices.csv のような
1ファイルのやり取りではなくディレクトリ単位(ZIP)でダウンロード/アップロードする。
単一の .yaml を直接アップロードすることもできる(他環境から1件だけ持ち込む場合)。

アップロードは「同名は上書き、それ以外の既存ファイルは残す」マージ方式。ZIPに無い
ファイルを消さないのは、復元のつもりが取り違えたZIPで全件消える事故を避けるため
(不要なファイルの削除は画面側の削除操作で行う)。

展開先はアーカイブ内のパスをそのまま使うため、次を満たさないメンバーは拒否する:
  - 絶対パス・`..` を含むパス(展開先ディレクトリの外へ書き出させない)
  - `.yaml`/`.yml` 以外の拡張子
  - 想定より深い階層(カタログは <vendor>/<type>.yaml、セットは <name>.yaml)
さらに、展開前に全メンバーを YAML としてパースできるか確認し、1件でも壊れていれば
何も書き込まずに中断する(一部だけ反映された中途半端な状態を作らないため)。
"""

from __future__ import annotations

import io
import zipfile
from pathlib import Path

import yaml

from app.config_files import atomic_write_text

_YAML_SUFFIXES = (".yaml", ".yml")


def build_zip(root: Path) -> bytes:
    """root 配下の YAML を、root からの相対パスでZIPに詰めて返す。"""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(root.rglob("*")):
            if path.is_file() and path.suffix in _YAML_SUFFIXES:
                zf.write(path, path.relative_to(root).as_posix())
    return buf.getvalue()


def _check_member_path(name: str, max_depth: int) -> Path:
    """ZIPメンバー名を検証し、root からの相対パスとして返す。"""
    if name.endswith("/"):
        raise ValueError(f"ディレクトリは含められません: {name}")
    rel = Path(name)
    if rel.is_absolute() or ".." in rel.parts:
        raise ValueError(f"使用できないパスです: {name}")
    if rel.suffix not in _YAML_SUFFIXES:
        raise ValueError(f"YAMLファイル(.yaml/.yml)以外は含められません: {name}")
    if len(rel.parts) > max_depth:
        raise ValueError(f"階層が深すぎます(最大{max_depth}階層): {name}")
    return rel


def save_upload(root: Path, filename: str, content: bytes, *, max_depth: int) -> list[str]:
    """アップロードされた ZIP または単一 YAML を root 配下へ保存する。

    max_depth は root からの許容階層数(コマンドカタログは <vendor>/<type>.yaml の2、
    コマンドセットは <name>.yaml の1)。保存したファイルの相対パス一覧を返す。
    """
    name = (filename or "").strip()
    if name.lower().endswith(".zip"):
        entries = _read_zip(content, max_depth)
    elif name.lower().endswith(_YAML_SUFFIXES):
        rel = _check_member_path(Path(name).name, max_depth=1)
        entries = [(rel, _parse_yaml(content, rel.as_posix()))]
    else:
        raise ValueError("ZIP(.zip)または YAML(.yaml/.yml)ファイルを指定してください。")

    if not entries:
        raise ValueError("保存できるYAMLファイルが含まれていません。")

    saved = []
    for rel, text in entries:
        atomic_write_text(root / rel, text)
        saved.append(rel.as_posix())
    return saved


def _read_zip(content: bytes, max_depth: int) -> list[tuple[Path, str]]:
    try:
        zf = zipfile.ZipFile(io.BytesIO(content))
    except zipfile.BadZipFile:
        raise ValueError("ZIPファイルとして読み込めません。")
    with zf:
        entries = []
        for info in zf.infolist():
            if info.is_dir():
                continue
            rel = _check_member_path(info.filename, max_depth)
            entries.append((rel, _parse_yaml(zf.read(info), info.filename)))
    return entries


def _parse_yaml(raw: bytes, label: str) -> str:
    """YAMLとして妥当なことだけ確認し、元のテキストをそのまま返す。

    中身の構造(コマンドカタログなら cli/rest 等)の検証はしない。これらのファイルは
    起動時・参照時に CommandCatalog/CommandSet 側が読んで検証するため、ここでは
    「そもそもYAMLとして読めるか」だけを見る。
    """
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        raise ValueError(f"UTF-8として読み込めません: {label}")
    try:
        yaml.safe_load(text)
    except yaml.YAMLError as e:
        raise ValueError(f"YAMLとして読み込めません({label}): {e}")
    return text
