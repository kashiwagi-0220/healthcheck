"""
gui.backend.app.config_files — 設定ファイル(config/ 配下)の同時編集の保護

機器一覧・コマンドセット・コマンドカタログ・認証情報・プロキシ設定は、いずれも
「ファイルを読み込み → 一部を変えて → 全体を書き戻す」形で保存する。複数の利用者が
同時に使うと、後から保存した人の内容で全体が上書きされ、先に保存した人の変更が
消えてしまう。これを次の3つで防ぐ。

- 版の確認: 設定の中身から計算した「版」を、読み込みの応答に ETag ヘッダで付ける。
  画面は保存のときに読み込んだ時の版を If-Match ヘッダで送り、サーバは保存の直前に
  今の版と比べる。違っていれば(読み込んだ後に誰かが変更していれば)412 で保存を
  断る。版の確認は設定の種類ごと(機器一覧なら devices.csv 全体)に行うため、
  別の機器を変更された場合も断る側に倒れる。
- 排他: 版の確認・読み込み・書き込みを1つのロックの中で行い、同時に届いた保存同士が
  互いの変更を上書きしないようにする。読み込みの応答もロックの中で作り、返す中身と
  版が食い違わないようにする。ロックはこのプロセスの中だけで効くため、uvicorn を
  1プロセスで動かすことが前提(README の起動方法どおり)。
- 一括書き込み: 一時ファイルに書いてから置き換える(os.replace)。書き込みの途中の
  ファイルを他の処理(取得の実行開始など)が読むことがなく、途中で失敗しても元の
  ファイルが残る。置き換え後も元のパーミッションを保つ(認証情報の 600 など)。
"""

from __future__ import annotations

import contextlib
import hashlib
import os
import tempfile
import threading
from collections.abc import Iterator
from pathlib import Path

from fastapi import HTTPException, Response

from app.config import (
    COMMAND_CATALOG_DIR,
    COMMAND_SET_DIR,
    CREDENTIALS_FILE,
    DEVICES_CSV,
    PROXY_CONF,
)

# 設定の書き込みは稀で短いので、種類を問わず1つのロックで直列にする。
_LOCK = threading.RLock()

_YAML_SUFFIXES = (".yaml", ".yml")


def atomic_write_text(path: Path, text: str, *, mode: int | None = None) -> None:
    """text を path へ一括で書き込む(一時ファイルに書いてから置き換える)。

    mode を省略した場合、既存のファイルがあればそのパーミッションを引き継ぎ、
    無ければ 0o644 にする。改行は変換しない(csv モジュールが付ける \\r\\n を保つため)。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    if mode is None:
        mode = path.stat().st_mode & 0o777 if path.exists() else 0o644
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
            f.write(text)
            f.flush()
            os.fsync(f.fileno())
        os.chmod(tmp, mode)
        os.replace(tmp, path)
    except BaseException:
        with contextlib.suppress(FileNotFoundError):
            os.unlink(tmp)
        raise


def _files_of(target: Path) -> list[Path]:
    """版の計算に含めるファイル。ディレクトリなら配下の YAML 全部(名前順)。"""
    if target.is_dir():
        return sorted(p for p in target.rglob("*") if p.is_file() and p.suffix in _YAML_SUFFIXES)
    return [target]


def _strip_etag(value: str) -> str:
    value = value.strip()
    if value.startswith("W/"):
        value = value[2:]
    return value.strip('"')


class ConfigResource:
    """版を持つ設定1種類(1ファイル、またはディレクトリ配下の YAML 一式)。"""

    def __init__(self, label: str, target: Path):
        self.label = label
        self.target = target

    def version(self) -> str:
        """中身から計算した版。ファイルの追加・削除・名前の変更でも変わるよう、
        ディレクトリの場合は相対パスも含めて計算する。"""
        h = hashlib.sha256()
        root = self.target if self.target.is_dir() else self.target.parent
        for path in _files_of(self.target):
            h.update(path.relative_to(root).as_posix().encode())
            h.update(b"\0")
            h.update(path.read_bytes() if path.exists() else b"")
            h.update(b"\0")
        return f'"{h.hexdigest()[:16]}"'

    @contextlib.contextmanager
    def reading(self, response: Response) -> Iterator[None]:
        """読み込みの応答を作る間ロックを持ち、最後に版を ETag として付ける。"""
        with _LOCK:
            yield
            response.headers["ETag"] = self.version()

    @contextlib.contextmanager
    def writing(self, if_match: str | None, response: Response) -> Iterator[None]:
        """版を確認してから書き込みを許し、書き込み後の新しい版を ETag として返す。
        中で例外(404 など)が起きた場合は ETag を付けない。"""
        with _LOCK:
            if if_match is None:
                raise HTTPException(
                    status_code=428,
                    detail=f"{self.label}の版の指定(If-Match)がありません。"
                           "画面を再読み込みしてから、もう一度保存してください。",
                )
            if _strip_etag(if_match) != _strip_etag(self.version()):
                raise HTTPException(
                    status_code=412,
                    detail=f"{self.label}は、この画面を読み込んだ後に他の利用者によって変更されています。"
                           "画面を再読み込みして最新の内容を確認してから、もう一度保存してください。",
                )
            yield
            response.headers["ETag"] = self.version()


DEVICES_CONFIG = ConfigResource("機器一覧", DEVICES_CSV)
COMMAND_SETS_CONFIG = ConfigResource("コマンドセット", COMMAND_SET_DIR)
COMMAND_CATALOG_CONFIG = ConfigResource("コマンドカタログ", COMMAND_CATALOG_DIR)
CREDENTIALS_CONFIG = ConfigResource("認証情報", CREDENTIALS_FILE)
PROXY_CONFIG = ConfigResource("プロキシ設定", PROXY_CONF)
