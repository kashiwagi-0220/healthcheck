"""
gui.backend.app.schemas — GUI固有のリクエスト/レスポンス型(pydantic)

healthcheck パッケージの dataclass(Device/Snapshot/HealthCheckResult 等)は
response としてそのまま使う(app/api/*.py 参照)。ここに置くのは、CLIコアには
存在しないGUI固有の入力形状(例: before/after の mode 判別)のみ。
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class HostTargetIn(BaseModel):
    """1機器分の比較対象。mode="now" なら今すぐ取得(save で保存有無)、
    mode="snapshot" なら snapshot_id を直接指定する(「最新」は GUI 側が現時点の
    最新 snapshot_id にあらかじめ解決してから渡す)。"""
    mode: Literal["now", "snapshot"]
    snapshot_id: str | None = None   # mode="snapshot" の時のみ
    save: bool = False               # mode="now" の時のみ意味を持つ


class HealthCheckRequest(BaseModel):
    """POST /healthcheck・POST /healthcheck/stream 共通。host ごとに独立した
    比較対象(今すぐ取得/個別スナップショット指定)を混在させられる。"""
    hosts: list[str]
    before: dict[str, HostTargetIn]
    after: dict[str, HostTargetIn]
    max_concurrency: int = 10
    retries: int = 1


class CommandSetIn(BaseModel):
    """コマンドセットの中身(名前を除く)。作成・更新どちらの本文にも使う。
    cli・rest はどちらも文字列のリスト(rest は CommandCatalog に定義された
    REST の key。実行内容の method/path はコマンドカタログ側が持つため、ここでは
    持たない)。vendor/type はこのコマンドセットが対象とする機種(両方必須)。"""
    vendor: str
    type: str
    description: str | None = None
    cli: list[str] = Field(default_factory=list)
    rest: list[str] = Field(default_factory=list)


class CommandSetCreateIn(CommandSetIn):
    name: str


class DeviceIn(BaseModel):
    """機器1件分の入力(host を除く)。新規作成・編集どちらの本文にも使う。
    command_set は任意(未指定なら空欄のまま)。"""
    vendor: str
    type: str
    ip: str | None = None
    command_set: str | None = None


class DeviceCreateIn(DeviceIn):
    host: str


class CredentialEntryIn(BaseModel):
    """認証情報1件分(config/credentials.yaml の default / hosts.<host> と同じ形)。
    secret(enable/特権パスワード)は任意で、未指定なら None。"""
    username: str
    password: str
    secret: str | None = None


class CommandCatalogEntryIn(BaseModel):
    """コマンドカタログ1件分(vendor/type/commandを除く。CommandSpecと同じ形)。
    作成・更新どちらの本文にも使う。method は RestPolicy が
    "get" しか許可しないため、API側でも "get" 以外は拒否する(command_catalog.py 参照)。"""
    parser: Literal["genie", "textfsm", "json"]
    noise: list[str] = Field(default_factory=list)
    compare_keys: list[str] | None = None
    method: str = "get"
    path: str | None = None
    description: str | None = None


class CommandCatalogEntryCreateIn(CommandCatalogEntryIn):
    vendor: str
    type: str
    command: str
