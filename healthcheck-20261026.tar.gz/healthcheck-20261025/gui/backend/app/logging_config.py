"""
gui.backend.app.logging_config — 実行ログの出力先設定

収集層(healthcheck/collect/*)がコマンド・問い合わせ単位で出す標準 logging の
ログを、標準出力とファイル(data/healthcheck.log。後から確認できるように
するため永続化する。無制限に肥大化しないようローテーションする)の両方へ
出す。ログの出力先を決めるのはアプリ全体のエントリポイント側の責務で、収集層の
コード自体は logging.getLogger(__name__) で出すだけに留める。

GET /logs(app/api/logs.py)がこのファイルを読み返す。
"""

from __future__ import annotations

import logging
import logging.handlers
import time

from app.config import DATA_ROOT

LOG_FILE = DATA_ROOT / "healthcheck.log"
_FORMAT = "%(asctime)s %(levelname)s %(name)s: %(message)s"


def log_timestamp() -> str:
    """ログ行の先頭(logging の asctime)と同じ形式の現在時刻を返す。

    実行中の画面が「この実行が始まってから後のログ」だけを GET /logs で取るときの
    起点に使う。ブラウザの時計を使うと、端末とサーバの時計のずれやタイムゾーンの
    違いで取りこぼすため、ログを書くのと同じサーバの時計で決める。形式が同じなので
    GET /logs 側は文字列の大小比較だけで切り出せる。"""
    now = time.time()
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(now)) + f",{int((now % 1) * 1000):03d}"


def setup_logging() -> None:
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    formatter = logging.Formatter(_FORMAT)

    file_handler = logging.handlers.RotatingFileHandler(
        LOG_FILE, maxBytes=5 * 1024 * 1024, backupCount=3, encoding="utf-8"
    )
    file_handler.setFormatter(formatter)

    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(formatter)

    root = logging.getLogger()
    root.setLevel(logging.INFO)
    root.addHandler(file_handler)
    root.addHandler(stream_handler)
