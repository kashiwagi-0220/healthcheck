"""
gui.backend.app.api.proxy — SSHプロキシ設定(config/proxy.conf)の照会・編集・
アップロード・ダウンロードAPI

config/proxy.conf は固定の1ファイル(app.config.PROXY_CONF)。有効/無効の専用
フラグは持たず、Host パターンに一致しないホストにはそもそも netmiko/paramiko が
ProxyJump を適用しない挙動にそのまま委ねる。

編集・取り込みは、読み込んだ後に他の利用者が変更していないかを版(If-Match)で
確かめてから書き込む(app/config_files.py)。
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, HTTPException, UploadFile, File, Header, Response
from fastapi.responses import FileResponse
from pydantic import BaseModel

from app.config import PROXY_CONF
from app.config_files import PROXY_CONFIG
from app.sources import save_proxy_conf, read_proxy_conf, write_proxy_conf_text

router = APIRouter()

logger = logging.getLogger(__name__)


class ProxyConfIn(BaseModel):
    text: str


@router.get("/proxy")
def get_proxy(response: Response) -> dict:
    with PROXY_CONFIG.reading(response):
        return {"text": read_proxy_conf()}


@router.put("/proxy")
def put_proxy(body: ProxyConfIn, response: Response, if_match: str | None = Header(default=None)) -> dict:
    with PROXY_CONFIG.writing(if_match, response):
        write_proxy_conf_text(body.text)
        logger.info("プロキシ設定を更新しました(%d文字)", len(body.text))
        return {"text": read_proxy_conf()}


@router.get("/proxy/conf")
def download_proxy_conf() -> FileResponse:
    if not PROXY_CONF.exists():
        raise HTTPException(status_code=404, detail=f"{PROXY_CONF} が見つかりません。")
    return FileResponse(PROXY_CONF, filename=PROXY_CONF.name, media_type="text/plain")


@router.post("/proxy/conf")
def upload_proxy_conf(
    response: Response, file: UploadFile = File(...), if_match: str | None = Header(default=None)
) -> dict:
    # 同期関数にしてスレッドプールで動かす(ロックを待つ間にイベントループを止めないため)。
    content = file.file.read()
    with PROXY_CONFIG.writing(if_match, response):
        try:
            save_proxy_conf(content)
        except ValueError as e:
            logger.warning("プロキシ設定の取り込みに失敗しました(%s): %s", file.filename, e)
            raise HTTPException(status_code=400, detail=str(e))
    logger.info("プロキシ設定を取り込みました: %s", file.filename)
    return {"saved": PROXY_CONF.name}
