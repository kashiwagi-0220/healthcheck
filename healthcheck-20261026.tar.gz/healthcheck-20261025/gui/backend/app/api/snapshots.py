"""
gui.backend.app.api.snapshots — snapshot一覧・取得API

既存の healthcheck.storage.FilesystemStore をそのまま呼ぶだけの薄いエンドポイント
(照会系。GUI が「どの snapshot と比較するか」を選択・解決するために使う)。
一覧(GET /snapshots)は until・ページング(limit/offset)付きで
`{"items": [...], "total": N}` を返す(コアの list_snapshots 自体は絞り込みを
持たず、GUI側で絞り込み・並び替え・切り出しを行う)。

一覧に加え、1つの snapshot 内の1コマンド分の実データ(raw / parsed)を取得する
エンドポイント、全コマンド分をまとめて取得するエンドポイント(GUI側での一括
ダウンロード用)を持つ(いずれも DataStore.load_raw / load_parsed をそのまま
呼ぶだけ)。

「スナップショット取得」(POST /snapshots/take)は healthcheck.common.take_snapshot
をそのまま呼ぶ実行系エンドポイント(healthchecks.py の execute_healthcheck と同じ
構成部品の組み立て方)。save の値に関わらず取得直後のレスポンスで結果をそのまま
表示・ダウンロードできる(SSEイベントに raw/parsed をそのまま埋め込むため)。
save=True なら FilesystemStore(ディスクへ保存)、save=False なら InMemoryDataStore
(ディスクへは一切書かない。リクエスト限りのメモリ上のみ)を data_store として渡す。
「保存しない」場合に本当に何もディスクへ残らないようにするため、manifest だけでなく
store 自体を切り替える(take_snapshot は DataStore という抽象IFにしか依存しないため、
渡す実装を変えるだけで済む)。

POST /snapshots/take は Server-Sent Events(text/event-stream)で進捗を流す。
take_snapshot() が完了した機器から順に yield する(healthcheck/common/snapshot.py
参照)ため、GUI側もリスト化して待たず、結果が届いた端からイベントとして流す。
イベント種別は
{"type": "start", "total": N, "log_since": ...}(開始。N は要求された host 数。実際に
取得対象となる機器数(コマンド未定義の機器はtake_snapshot側でスキップされる)と
一致しない場合があるが、進捗表示の目安としては十分。log_since はこの時点のサーバ
時刻で、画面がこの実行のログだけを GET /logs から取るための起点)/
{"type": "device_done", "done": M, "total": N, "host": ..., ...}(1機器完了)/
{"type": "error", "message": ...}(検証エラー等で中断)/
{"type": "complete"}(全機器完了)。コアには進捗通知の仕組みを持ち込まず、GUI側が
take_snapshot() の既存のyield(機器ごとの完了)をそのままSSEに変換するだけに
留めている。
"""

from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from healthcheck.storage import FilesystemStore, InMemoryDataStore
from healthcheck.models import Snapshot
from healthcheck.common.snapshot import take_snapshot

from app.config import DATA_ROOT
from app.logging_config import log_timestamp
from app.sources import build_collection_parts, resolve_devices
from app.sse import sse_event

router = APIRouter()


def _store() -> FilesystemStore:
    return FilesystemStore(DATA_ROOT)


def _parse_iso(value: str | None, name: str) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=f"{name} が不正なISO8601です: {e}")


@router.get("/snapshots")
def list_snapshots(
    host: str | None = Query(default=None, description="完全一致。省略時は全機器"),
    host_contains: str | None = Query(
        default=None, description="ホスト名の部分一致(大小文字区別なし。一覧画面の自由語検索用)"
    ),
    since: str | None = Query(
        default=None, description="ISO8601(例 2026-09-01T00:00:00+00:00)。指定時刻以降のみ"
    ),
    until: str | None = Query(
        default=None, description="ISO8601。指定時刻以前のみ"
    ),
    limit: int = Query(default=100, ge=1, le=1000, description="1ページの件数"),
    offset: int = Query(default=0, ge=0, description="先頭からのスキップ件数"),
):
    """snapshot 一覧(ページング付き)。コア(healthcheck.storage)の list_snapshots は
    host(完全一致)/since までしか絞り込めない(CLI側の用途では十分なため)。
    host_contains・until・ページングは GUI一覧画面が大量の snapshot で固まらない
    ようにするための表示都合の機能なので、コアには持ち込まずここ(GUIバックエンド)
    で行う(host 単位・時系列の全件を一度読んでから絞り込む。機器数・snapshot数が
    今の規模(実機ラボ相当)であれば十分)。host(完全一致)は他の呼び出し側
    (healthchecks.py の前提となる「特定ホストのsnapshotだけを引く」用途)がそのまま
    使えるよう挙動を変えていない。host_contains を使う場合は絞り込みのため全件を
    読む(host のような1機器分だけを読むディレクトリ限定はできない)。新しい順
    (taken_at 降順)に並べてから offset/limit で切り出す。"""
    since_dt = _parse_iso(since, "since")
    until_dt = _parse_iso(until, "until")

    snapshots = _store().list_snapshots(host=host, since=since_dt)
    if host_contains:
        needle = host_contains.strip().lower()
        snapshots = [s for s in snapshots if needle in s.host.lower()]
    if until_dt:
        snapshots = [s for s in snapshots if not s.taken_at or s.taken_at <= until_dt]
    snapshots.sort(key=lambda s: s.taken_at or datetime.min.replace(tzinfo=timezone.utc), reverse=True)

    total = len(snapshots)
    return {"items": snapshots[offset:offset + limit], "total": total}


@router.get("/snapshots/{host}/{snapshot_id}", response_model=Snapshot)
def get_snapshot(host: str, snapshot_id: str) -> Snapshot:
    snap = _store().get_snapshot(host, snapshot_id)
    if snap is None:
        raise HTTPException(status_code=404, detail="snapshot が見つかりません")
    return snap


@router.get("/snapshots/{host}/{snapshot_id}/commands/{command}")
def get_snapshot_command(host: str, snapshot_id: str, command: str):
    snap = _store().get_snapshot(host, snapshot_id)
    if snap is None:
        raise HTTPException(status_code=404, detail="snapshot が見つかりません")
    ref = snap.refs.get(command)
    if ref is None:
        raise HTTPException(status_code=404, detail=f"この snapshot に command がありません: {command}")
    store = _store()
    return {
        "command": command,
        "raw": store.load_raw(ref),
        "parsed": store.load_parsed(ref),
    }


@router.get("/snapshots/{host}/{snapshot_id}/full")
def get_snapshot_full(host: str, snapshot_id: str):
    """1つの snapshot の全コマンド分の raw/parsed をまとめて返す(一覧画面での
    詳細表示・一括ダウンロード用)。"""
    snap = _store().get_snapshot(host, snapshot_id)
    if snap is None:
        raise HTTPException(status_code=404, detail="snapshot が見つかりません")
    store = _store()
    return {
        "host": host,
        "id": snap.id,
        "taken_at": snap.taken_at,
        "success": snap.success,
        "error": snap.error,
        "commands": {
            cmd: {"raw": store.load_raw(ref), "parsed": store.load_parsed(ref)}
            for cmd, ref in snap.refs.items()
        },
    }


class TakeSnapshotIn(BaseModel):
    hosts: list[str]
    save: bool = True
    max_concurrency: int = 10
    retries: int = 1


def _take_snapshot_events(
    devices, *, command_set, command_catalog, cli_collector, save, max_concurrency, retries,
):
    # save=False の場合、ディスクには一切書き込まない InMemoryDataStore を使う。
    store = _store() if save else InMemoryDataStore()
    total = len(devices)
    yield sse_event("start", total=total, log_since=log_timestamp())

    done = 0
    try:
        for snap in take_snapshot(
            devices,
            data_store=store,
            command_set=command_set,
            command_catalog=command_catalog,
            cli_collector=cli_collector,
            max_concurrency=max_concurrency,
            retries=retries,
            save=save,
        ):
            done += 1
            yield sse_event(
                "device_done",
                done=done,
                total=total,
                host=snap.host,
                id=snap.id,
                taken_at=snap.taken_at,
                success=snap.success,
                error=snap.error,
                saved=save,
                commands={
                    cmd: {"raw": store.load_raw(ref), "parsed": store.load_parsed(ref)}
                    for cmd, ref in snap.refs.items()
                },
            )
    except ValueError as e:
        yield sse_event("error", message=str(e))
        return
    except ImportError as e:
        yield sse_event("error", message=f"収集エンジンの読み込みに失敗しました: {e}")
        return

    yield sse_event("complete")


@router.post("/snapshots/take")
def take_snapshot_now(req: TakeSnapshotIn) -> StreamingResponse:
    devices = resolve_devices(req.hosts)

    command_set, command_catalog, cli_collector = build_collection_parts()

    return StreamingResponse(
        _take_snapshot_events(
            devices, command_set=command_set, command_catalog=command_catalog,
            cli_collector=cli_collector, save=req.save,
            max_concurrency=req.max_concurrency, retries=req.retries,
        ),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache"},
    )
