"""
gui.backend.app.api.command_sets — コマンドセット照会・作成・更新・削除API

既存の healthcheck.command.CommandSet(config/command/command_set/*.yaml から
1ファイル=1コマンドセットで読み込み)を使う。読み込みは CommandSet.from_directory()
にそのまま委ねるが、作成/更新/削除(ファイルの書き込み・削除)はコアに持ち込まず、
ここ(GUIバックエンド)に閉じる方針(healthcheck/command/command_set.py のコメント
参照。コアは読み取り専用のまま、GUI からの編集はファイル単位の単純な操作として扱う)。

コマンドセット名はそのままファイル名(<name>.yaml)になるため、パス上安全な文字
(英数字・アンダースコア・ハイフン)のみ許可する(パストラバーサル対策)。

保存系(作成・更新・削除・取り込み)は、読み込んだ後に他の利用者が変更していないかを
版(If-Match)で確かめてから書き込む(app/config_files.py)。版はコマンドセット全体
(ディレクトリ配下の YAML 一式)で1つ。
"""

from __future__ import annotations

import logging
import re

import yaml
from fastapi import APIRouter, HTTPException, UploadFile, File, Header
from fastapi.responses import Response

from healthcheck.command import CommandSet, CommandSetEntry

from app.config import COMMAND_SET_DIR
from app.config_files import COMMAND_SETS_CONFIG, atomic_write_text
from app.sources import get_command_set_resolver
from app.schemas import CommandSetIn, CommandSetCreateIn
from app.yaml_archive import build_zip, save_upload

logger = logging.getLogger(__name__)

router = APIRouter()

_NAME_RE = re.compile(r"^[A-Za-z0-9_-]+$")


def _validate_name(name: str) -> None:
    if not _NAME_RE.match(name):
        raise HTTPException(
            status_code=400,
            detail="コマンドセット名には半角英数字・アンダースコア(_)・ハイフン(-)のみ使用できます。",
        )


def _validate_vendor_type(vendor: str, type: str) -> None:
    if not vendor.strip():
        raise HTTPException(status_code=400, detail="vendor を指定してください。")
    if not type.strip():
        raise HTTPException(status_code=400, detail="type を指定してください。")


def _file_path(name: str):
    return COMMAND_SET_DIR / f"{name}.yaml"


def _to_entry(body: CommandSetIn) -> CommandSetEntry:
    return CommandSetEntry(
        vendor=body.vendor,
        type=body.type,
        cli=list(body.cli),
        rest=list(body.rest),
        description=body.description or None,
    )


def _write(name: str, body: CommandSetIn) -> None:
    data: dict = {"vendor": body.vendor, "type": body.type}
    if body.description:
        data["description"] = body.description
    data["cli"] = list(body.cli)
    data["rest"] = list(body.rest)
    atomic_write_text(_file_path(name), yaml.safe_dump(data, allow_unicode=True, sort_keys=False))


@router.get("/command-sets", response_model=dict[str, CommandSetEntry])
def list_command_sets(response: Response) -> dict[str, CommandSetEntry]:
    with COMMAND_SETS_CONFIG.reading(response):
        command_set = CommandSet.from_directory(COMMAND_SET_DIR, resolver=get_command_set_resolver())
        return command_set.command_sets


@router.post("/command-sets", status_code=201, response_model=CommandSetEntry)
def create_command_set(
    body: CommandSetCreateIn, response: Response, if_match: str | None = Header(default=None)
) -> CommandSetEntry:
    _validate_name(body.name)
    _validate_vendor_type(body.vendor, body.type)
    with COMMAND_SETS_CONFIG.writing(if_match, response):
        if _file_path(body.name).exists():
            raise HTTPException(status_code=409, detail=f"コマンドセット '{body.name}' は既に存在します。")
        _write(body.name, body)
        logger.info("コマンドセットを作成しました: %s (vendor=%s type=%s cli=%d件 rest=%d件)",
                    body.name, body.vendor, body.type, len(body.cli), len(body.rest))
    return _to_entry(body)


@router.put("/command-sets/{name}", response_model=CommandSetEntry)
def update_command_set(
    name: str, body: CommandSetIn, response: Response, if_match: str | None = Header(default=None)
) -> CommandSetEntry:
    _validate_name(name)
    _validate_vendor_type(body.vendor, body.type)
    with COMMAND_SETS_CONFIG.writing(if_match, response):
        if not _file_path(name).exists():
            raise HTTPException(status_code=404, detail=f"コマンドセット '{name}' が見つかりません。")
        _write(name, body)
        logger.info("コマンドセットを更新しました: %s (vendor=%s type=%s cli=%d件 rest=%d件)",
                    name, body.vendor, body.type, len(body.cli), len(body.rest))
    return _to_entry(body)


@router.delete("/command-sets/{name}", status_code=204)
def delete_command_set(name: str, response: Response, if_match: str | None = Header(default=None)) -> None:
    _validate_name(name)
    path = _file_path(name)
    with COMMAND_SETS_CONFIG.writing(if_match, response):
        if not path.exists():
            raise HTTPException(status_code=404, detail=f"コマンドセット '{name}' が見つかりません。")
        path.unlink()
        logger.info("コマンドセットを削除しました: %s", name)


@router.get("/command-sets/files")
def download_command_sets() -> Response:
    """config/command/command_set/ 配下のYAMLをまとめてZIPで返す。"""
    data = build_zip(COMMAND_SET_DIR)
    return Response(
        content=data,
        media_type="application/zip",
        headers={"Content-Disposition": 'attachment; filename="command_set.zip"'},
    )


@router.post("/command-sets/files")
def upload_command_sets(
    response: Response, file: UploadFile = File(...), if_match: str | None = Header(default=None)
) -> dict:
    """ZIP(複数)または単一YAML(1コマンドセット)を取り込む。同名は上書きし、
    アップロードに含まれない既存のコマンドセットはそのまま残す。同期関数にして
    スレッドプールで動かす(ロックを待つ間にイベントループを止めないため)。"""
    content = file.file.read()
    with COMMAND_SETS_CONFIG.writing(if_match, response):
        try:
            saved = save_upload(COMMAND_SET_DIR, file.filename, content, max_depth=1)
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))
    logger.info("コマンドセットを取り込みました(%s): %s", file.filename, ", ".join(saved))
    return {"saved": saved}
