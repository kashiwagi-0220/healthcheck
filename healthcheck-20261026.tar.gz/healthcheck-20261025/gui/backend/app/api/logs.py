"""
gui.backend.app.api.logs — 実行ログ照会API

app.logging_config が data/healthcheck.log へ書いている、収集層(healthcheck/collect/*)の
コマンド・問い合わせ単位の実行ログを読み返す。ローテーション後の
過去分(.1/.2/...)は対象にしない(「直近の実行を後から確認する」という用途には
現在のファイルで十分なため)。

ログ画面は q(任意の文字列)と limit で使う。正常性確認・スナップショット取得の
実行中の画面は、開始イベントで受け取った log_since を since に、対象機器を hosts に
渡し、その実行に関係する行だけを定期的に取り直す。
"""

from __future__ import annotations

import re

from fastapi import APIRouter, Query

from app.logging_config import LOG_FILE

router = APIRouter()

# ログ行の先頭の時刻(app.logging_config の _FORMAT の asctime)。例外のスタック
# トレースのような続きの行はこれで始まらない。
_TIMESTAMP = re.compile(r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3} ")


@router.get("/logs")
def get_logs(
    q: str | None = Query(default=None, description="任意の文字列の部分一致(大小文字区別なし)で絞り込む(ホスト名・コマンド名・エラー文言等、行の中身全体が対象)"),
    limit: int = Query(default=500, ge=1, le=5000, description="末尾から何行返すか"),
    since: str | None = Query(
        default=None,
        description="この時刻以降の行だけ返す。ログ行の先頭と同じ形式(例 2026-10-25 12:34:56,789)。"
                    "開始イベントの log_since をそのまま渡す",
    ),
    hosts: list[str] | None = Query(default=None, description="指定した機器のログ行だけ返す(複数指定可)"),
) -> dict:
    if not LOG_FILE.exists():
        return {"lines": [], "total": 0}

    with LOG_FILE.open(encoding="utf-8", errors="replace") as f:
        lines = [line.rstrip("\n") for line in f]

    if since:
        # 時刻で始まらない続きの行は、どの時点のものか判断できないので含めない。
        lines = [line for line in lines if _TIMESTAMP.match(line) and line[:len(since)] >= since]
    if hosts:
        # 収集層のログは「<ロガー名>: <host>: <内容>」の形。": <host>: " で探すことで、
        # SW-1 を指定したときに SW-10 の行まで拾わないようにする。
        markers = [f": {host}: " for host in hosts]
        lines = [line for line in lines if any(m in line for m in markers)]
    if q:
        needle = q.strip().lower()
        lines = [line for line in lines if needle in line.lower()]

    return {"lines": lines[-limit:], "total": len(lines)}
