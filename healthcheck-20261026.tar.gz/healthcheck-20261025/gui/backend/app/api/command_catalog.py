"""
gui.backend.app.api.command_catalog — コマンドカタログ照会・作成・更新・削除API

既存の healthcheck.command.CommandCatalog(config/command/command_catalog/<vendor>/<type>.yaml
から1ファイル=1機種で読み込み)を使う。読み込みは CommandCatalog.from_directory()
にそのまま委ねるが、作成/更新/削除(ファイルの書き込み)はコアに持ち込まず、ここ
(GUIバックエンド)に閉じる方針(command_sets.py と同じ考え方)。

1エントリ = 1つの (vendor, type, command)。vendor/type/command は作成時のみ指定でき、
編集時は固定(command_sets.py の name・devices.py の host と同じく、キーそのものの
変更はここでは扱わない。変えたい場合は削除して作り直す)。

parser が "json" かどうかで、ファイル内の cli ブロックと rest ブロックのどちらに
書くかを機械的に決める(コア側の不変条件と同じ。command_catalog.py 参照)。
vendor/type はディレクトリ名・ファイル名になるため、パス上安全な文字(英数字・
アンダースコア・ハイフン)のみ許可する(パストラバーサル対策。command はファイル名に
ならない=辞書のキーでしかないため制限しない。空白を含む CLI コマンドもそのまま使える)。
method は RestPolicy が "get" しか許可しないため、ここでも "get" 以外は拒否する
(実行時に弾かれるだけの設定を作らせないため)。

保存系(作成・更新・削除・取り込み)は、読み込んだ後に他の利用者が変更していないかを
版(If-Match)で確かめてから書き込む(app/config_files.py)。版はコマンドカタログ全体
(ディレクトリ配下の YAML 一式)で1つ。
"""

from __future__ import annotations

import logging
import re
from pathlib import Path

import yaml
from fastapi import APIRouter, HTTPException, UploadFile, File, Header
from fastapi.responses import Response

from healthcheck.command import CommandCatalog, CommandSpec

from app.config import COMMAND_CATALOG_DIR
from app.config_files import COMMAND_CATALOG_CONFIG, atomic_write_text
from app.schemas import CommandCatalogEntryIn, CommandCatalogEntryCreateIn
from app.yaml_archive import build_zip, save_upload

logger = logging.getLogger(__name__)

router = APIRouter()

_NAME_RE = re.compile(r"^[A-Za-z0-9_-]+$")


def _validate_name(value: str, label: str) -> None:
    if not _NAME_RE.match(value):
        raise HTTPException(
            status_code=400,
            detail=f"{label} には半角英数字・アンダースコア(_)・ハイフン(-)のみ使用できます。",
        )


def _validate_method(method: str) -> None:
    if method.strip().lower() != "get":
        raise HTTPException(status_code=400, detail='method は "get" のみ使用できます(RestPolicy の制約)。')


def _file_path(vendor: str, type_: str) -> Path:
    return COMMAND_CATALOG_DIR / vendor / f"{type_}.yaml"


def _read_file(path: Path) -> dict:
    if not path.exists():
        return {"cli": {}, "rest": {}}
    data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    return {"cli": dict(data.get("cli") or {}), "rest": dict(data.get("rest") or {})}


def _write_file(path: Path, data: dict) -> None:
    atomic_write_text(path, yaml.safe_dump(data, allow_unicode=True, sort_keys=False))


def _spec_dict(spec: CommandSpec) -> dict:
    """description・noise・compare_keys は値が無くても常に明記する(未設定なのか
    書き忘れなのかを見た目で区別できるようにするため)。method・path は
    REST(parser: json)専用のフィールドで、CLIエントリに書いても構造的に無意味
    (command_catalog.py の不変条件。method は常に get)なので、RESTの時だけ書く。"""
    d: dict = {
        "parser": spec.parser,
        "noise": list(spec.noise),
        "compare_keys": list(spec.compare_keys) if spec.compare_keys else None,
        "description": spec.description,
    }
    if spec.parser == "json":
        d["method"] = spec.method
        d["path"] = spec.path
    return d


def _bucket_for(spec: CommandSpec) -> str:
    return "rest" if spec.parser == "json" else "cli"


def _to_spec(body: CommandCatalogEntryIn) -> CommandSpec:
    _validate_method(body.method)
    if body.parser == "json" and not (body.path or "").strip():
        raise HTTPException(status_code=400, detail='parser が "json"(REST)の場合は path を指定してください。')
    return CommandSpec(
        parser=body.parser,
        noise=list(body.noise),
        compare_keys=list(body.compare_keys) if body.compare_keys else None,
        method=body.method,
        path=body.path or None,
        description=(body.description or "").strip() or None,
    )


@router.get("/command-catalog", response_model=dict[str, dict[str, dict[str, CommandSpec]]])
def get_command_catalog(response: Response) -> dict[str, dict[str, dict[str, CommandSpec]]]:
    with COMMAND_CATALOG_CONFIG.reading(response):
        catalog = CommandCatalog.from_directory(COMMAND_CATALOG_DIR)
        return catalog.by_vendor_type


@router.post("/command-catalog", status_code=201, response_model=CommandSpec)
def create_command_catalog_entry(
    body: CommandCatalogEntryCreateIn, response: Response, if_match: str | None = Header(default=None)
) -> CommandSpec:
    _validate_name(body.vendor, "vendor")
    _validate_name(body.type, "type")
    if not body.command.strip():
        raise HTTPException(status_code=400, detail="コマンドを指定してください。")
    spec = _to_spec(body)

    path = _file_path(body.vendor, body.type)
    with COMMAND_CATALOG_CONFIG.writing(if_match, response):
        data = _read_file(path)
        if body.command in data["cli"] or body.command in data["rest"]:
            raise HTTPException(
                status_code=409,
                detail=f"'{body.command}' は既に存在します({body.vendor}/{body.type})。",
            )
        data[_bucket_for(spec)][body.command] = _spec_dict(spec)
        _write_file(path, data)
        logger.info("コマンドカタログに追加しました: %s/%s '%s' (parser=%s)",
                    body.vendor, body.type, body.command, spec.parser)
    return spec


@router.put("/command-catalog/{vendor}/{type}/{command}", response_model=CommandSpec)
def update_command_catalog_entry(
    vendor: str, type: str, command: str, body: CommandCatalogEntryIn,
    response: Response, if_match: str | None = Header(default=None),
) -> CommandSpec:
    _validate_name(vendor, "vendor")
    _validate_name(type, "type")
    spec = _to_spec(body)

    path = _file_path(vendor, type)
    with COMMAND_CATALOG_CONFIG.writing(if_match, response):
        data = _read_file(path)
        if command not in data["cli"] and command not in data["rest"]:
            raise HTTPException(status_code=404, detail=f"'{command}' が見つかりません({vendor}/{type})。")

        data["cli"].pop(command, None)
        data["rest"].pop(command, None)
        data[_bucket_for(spec)][command] = _spec_dict(spec)
        _write_file(path, data)
        logger.info("コマンドカタログを更新しました: %s/%s '%s' (parser=%s)",
                    vendor, type, command, spec.parser)
    return spec


@router.delete("/command-catalog/{vendor}/{type}/{command}", status_code=204)
def delete_command_catalog_entry(
    vendor: str, type: str, command: str, response: Response, if_match: str | None = Header(default=None)
) -> None:
    _validate_name(vendor, "vendor")
    _validate_name(type, "type")

    path = _file_path(vendor, type)
    with COMMAND_CATALOG_CONFIG.writing(if_match, response):
        data = _read_file(path)
        if command not in data["cli"] and command not in data["rest"]:
            raise HTTPException(status_code=404, detail=f"'{command}' が見つかりません({vendor}/{type})。")

        data["cli"].pop(command, None)
        data["rest"].pop(command, None)
        _write_file(path, data)
        logger.info("コマンドカタログから削除しました: %s/%s '%s'", vendor, type, command)


@router.get("/command-catalog/files")
def download_command_catalog() -> Response:
    """config/command/command_catalog/ 配下のYAMLを <vendor>/<type>.yaml の形のまま
    ZIPで返す。"""
    data = build_zip(COMMAND_CATALOG_DIR)
    return Response(
        content=data,
        media_type="application/zip",
        headers={"Content-Disposition": 'attachment; filename="command_catalog.zip"'},
    )


@router.post("/command-catalog/files")
def upload_command_catalog(
    response: Response, file: UploadFile = File(...), if_match: str | None = Header(default=None)
) -> dict:
    """ZIP(複数機種)または単一YAML(1機種)を取り込む。同名は上書きし、
    アップロードに含まれない既存の機種ファイルはそのまま残す。同期関数にして
    スレッドプールで動かす(ロックを待つ間にイベントループを止めないため)。"""
    content = file.file.read()
    with COMMAND_CATALOG_CONFIG.writing(if_match, response):
        try:
            saved = save_upload(COMMAND_CATALOG_DIR, file.filename, content, max_depth=2)
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))
    logger.info("コマンドカタログを取り込みました(%s): %s", file.filename, ", ".join(saved))
    return {"saved": saved}
