"""
gui.backend.app.api.healthchecks — 正常性確認 実行API

2時点の取得と比較のオーケストレーションは、このGUIバックエンドが
healthcheck.common.snapshot(take_snapshot)と healthcheck.common.compare
(compare_device)の公開関数を直接組み合わせて行う(コア側に「ツール層」は持たない)。
機器ごとの完了をそのまま進捗として外へ流せるよう、取得と比較を1リクエスト内で
完結させる。

POST /healthcheck と POST /healthcheck/stream は同じ組み立て(_run_healthcheck_events)
を共有する。前者はイベントを最後まで消費して結果だけ返す薄い版、後者はSSEで
そのまま流す版。host ごとに独立した比較対象(今すぐ取得/個別スナップショット指定)を
混在させられる(app.schemas.HealthCheckRequest 参照)。
「今すぐ取得・保存しない」ホストは take_snapshot 呼び出し1回の中でだけ有効な
InMemoryDataStore を使うが、取得(collect)と比較(compare)を同じリクエスト内で
完結させるため、スナップショット一覧からは辿れない一時データでも比較には問題なく
使える。

"complete" イベント(または /healthcheck の戻り値)は result(core の
HealthCheckResult。差分のみ)に加え、details({host: {"before"|"after":
{command: {"raw":..., "parsed":..., "normalized":...}}}})も持つ。
CommandComparison は差分(all_diffs/effective_diffs)しか持たないため、結果
ポップアップで before/after の実データ(raw/parsed)をそのまま見せたい場合は別途
この details を使う。normalized は healthcheck.common.diff.normalize(parsed,
compare_keys) の結果そのもの(compare_device が実際に比較へ使う形)で、list が
どうキー化されたか(compare_keys が実際に効いているか)をGUIから確認できるようにする
ための補足情報。

実行結果(HealthCheckResult)は実行履歴として保管しない(呼び出し側がレスポンスを
その場で受け取って使うだけ)。

cli_collector: config/proxy.conf が存在すれば、それを使う NetmikoCollector を
構築して渡す(有効/無効の切り替えは持たず、ファイルの Host パターンに一致しない
ホストにはそもそも ProxyJump が適用されない netmiko/paramiko 自体の挙動にそのまま
委ねる。app.sources 参照)。
"""

from __future__ import annotations

import json
from dataclasses import asdict
from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse

from healthcheck.storage import FilesystemStore, InMemoryDataStore
from healthcheck.common.snapshot import take_snapshot
from healthcheck.common.compare import compare_device
from healthcheck.common.diff import normalize
from healthcheck.models import HealthCheckResult, DeviceComparison

from app.config import DATA_ROOT
from app.logging_config import log_timestamp
from app.sources import build_collection_parts, resolve_devices
from app.sse import sse_event
from app.schemas import HealthCheckRequest

router = APIRouter()


def _parsed_or_error(entry, side: str):
    """entry は (snapshot, その snapshot を読んだ DataStore) または None。"""
    if entry is None:
        return None, f"{side} 側の snapshot が見つかりません"
    snap, store = entry
    if snap is None:
        return None, f"{side} 側の snapshot が見つかりません"
    if not snap.success:
        return None, f"{side} 側の取得に失敗しました: {snap.error}"
    return {cmd: store.load_parsed(ref) for cmd, ref in snap.refs.items()}, None


def _command_details(entry, device, command_catalog):
    """entry は (snapshot, DataStore) または None。{command: {raw, parsed, normalized}} を
    返す(結果ポップアップで before/after の実データをそのまま見せるための
    補足情報。core の CommandComparison は差分しか持たないため、result とは別に
    details として載せる)。

    normalized は compare_device が実際に比較へ使う正規化後の形
    (healthcheck.common.diff.normalize をそのまま呼ぶだけ)。compare_keys の設定が
    実際にどう効いているか(list がどうキー化されたか)を確認できるようにする。"""
    if entry is None:
        return {}
    snap, store = entry
    if snap is None or not snap.refs:
        return {}
    result = {}
    for cmd, ref in snap.refs.items():
        parsed = store.load_parsed(ref)
        spec = command_catalog.spec_for(device.vendor, device.type, cmd)
        key_fields = spec.compare_keys if spec else None
        result[cmd] = {
            "raw": store.load_raw(ref),
            "parsed": parsed,
            "normalized": normalize(parsed, key_fields) if parsed is not None else None,
        }
    return result


def _run_healthcheck_events(
    devices, *, before, after, fs_store, command_set, command_catalog,
    cli_collector, max_concurrency, retries,
):
    """機器群の2時点(before/after)を取得・比較し、進捗イベントを yield する。
    POST /healthcheck(最後の "complete" だけ使う)・POST /healthcheck/stream
    (そのままSSEに変換する)の両方がこれを共有する。"""
    total = len(devices)
    # log_since は画面がこの実行のログだけを GET /logs から取るための起点(サーバ時刻)。
    yield sse_event("start", total=total, log_since=log_timestamp())
    mem_store = InMemoryDataStore()

    def iter_side(targets):
        """(host, snapshot, 読み込みに使った DataStore) を完了順に yield する。
        mode="snapshot" のホストは即座に解決できるので先に返し、mode="now" の
        ホストは保存有無ごとにまとめて take_snapshot() へ渡す(その方が
        take_snapshot 側の並列度をそのまま活かせるため)。"""
        now_by_save = {True: [], False: []}
        for d in devices:
            t = targets.get(d.host)
            if t is not None and t.mode == "snapshot":
                snap = fs_store.get_snapshot(d.host, t.snapshot_id) if t.snapshot_id else None
                yield d.host, snap, fs_store
            else:
                now_by_save[bool(t.save) if t is not None else False].append(d)

        for save_flag, group in now_by_save.items():
            if not group:
                continue
            store = fs_store if save_flag else mem_store
            for snap in take_snapshot(
                group,
                data_store=store,
                command_set=command_set,
                command_catalog=command_catalog,
                cli_collector=cli_collector,
                max_concurrency=max_concurrency,
                retries=retries,
                save=save_flag,
            ):
                yield snap.host, snap, store

    before_entries: dict = {}
    after_entries: dict = {}
    try:
        for host, snap, store in iter_side(before):
            before_entries[host] = (snap, store)
            yield sse_event("progress", phase="before", host=host, done=len(before_entries), total=total)

        # after の取得開始を知らせる。progress は機器が1台終わるたびにしか届かない
        # ため、これが無いと最初の after の機器が終わるまで画面が before の表示のまま残る。
        yield sse_event("phase", phase="after", total=total)
        for host, snap, store in iter_side(after):
            after_entries[host] = (snap, store)
            yield sse_event("progress", phase="after", host=host, done=len(after_entries), total=total)
    except ValueError as e:
        yield sse_event("error", message=str(e))
        return
    except ImportError as e:
        yield sse_event("error", message=f"収集エンジンの読み込みに失敗しました: {e}")
        return

    yield sse_event("comparing", total=total)

    result = HealthCheckResult(generated_at=datetime.now(timezone.utc))
    details: dict = {}
    for device in devices:
        before_entry = before_entries.get(device.host)
        after_entry = after_entries.get(device.host)
        before_parsed, before_err = _parsed_or_error(before_entry, "before")
        after_parsed, after_err = _parsed_or_error(after_entry, "after")

        details[device.host] = {
            "before": _command_details(before_entry, device, command_catalog),
            "after": _command_details(after_entry, device, command_catalog),
        }

        if before_parsed is None or after_parsed is None:
            result.add(DeviceComparison(device=device, status="error", message=before_err or after_err))
        else:
            result.add(compare_device(device, before_parsed, after_parsed, command_catalog=command_catalog))

    yield sse_event("complete", result=asdict(result), details=details)


@router.post("/healthcheck")
def execute_healthcheck(req: HealthCheckRequest) -> dict:
    """ストリームせず、最後の結果(result・details)だけ返す薄い版
    (POST /healthcheck/stream と同じ組み立てを共有する)。"""
    devices = resolve_devices(req.hosts)
    command_set, command_catalog, cli_collector = build_collection_parts()

    final: dict | None = None
    for line in _run_healthcheck_events(
        devices,
        before=req.before,
        after=req.after,
        fs_store=FilesystemStore(DATA_ROOT),
        command_set=command_set,
        command_catalog=command_catalog,
        cli_collector=cli_collector,
        max_concurrency=req.max_concurrency,
        retries=req.retries,
    ):
        payload = json.loads(line[len("data: "):])
        if payload["type"] == "error":
            raise HTTPException(status_code=400, detail=payload["message"])
        if payload["type"] == "complete":
            final = {"result": payload["result"], "details": payload["details"]}
    return final


@router.post("/healthcheck/stream")
def execute_healthcheck_stream(req: HealthCheckRequest) -> StreamingResponse:
    devices = resolve_devices(req.hosts)
    command_set, command_catalog, cli_collector = build_collection_parts()

    return StreamingResponse(
        _run_healthcheck_events(
            devices,
            before=req.before,
            after=req.after,
            fs_store=FilesystemStore(DATA_ROOT),
            command_set=command_set,
            command_catalog=command_catalog,
            cli_collector=cli_collector,
            max_concurrency=req.max_concurrency,
            retries=req.retries,
        ),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache"},
    )
