"""
gui.backend.app.config — 設定ファイル・データ保存先のパス解決

リポジトリ直下の config/・data/ を __file__ 基準の絶対パスで解決する(カレント
ディレクトリに依存しない)。

DEVICES_CSV・CREDENTIALS_FILE・PROXY_CONF は config/ 直下に固定で置く(どれを使うかを
選ぶ設定は持たない。実運用で使うファイルは常に1つのため)。SSHプロキシについても
有効/無効の切替は持たず、PROXY_CONF を常に netmiko へ渡す(Host パターンに一致しない
ホストにはそもそも ProxyJump が適用されない netmiko/paramiko 自体の挙動に委ねる。
app.sources.get_cli_collector() 参照)。
"""

from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parent.parent.parent.parent
CONFIG_ROOT = _REPO_ROOT / "config"
DATA_ROOT = _REPO_ROOT / "data"

DEVICES_CSV = CONFIG_ROOT / "devices.csv"
CREDENTIALS_FILE = CONFIG_ROOT / "credentials.yaml"
PROXY_CONF = CONFIG_ROOT / "proxy.conf"
COMMAND_SET_DIR = CONFIG_ROOT / "command" / "command_set"
COMMAND_CATALOG_DIR = CONFIG_ROOT / "command" / "command_catalog"
