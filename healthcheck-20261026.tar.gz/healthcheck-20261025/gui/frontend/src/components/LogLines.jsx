import { parseLogLine, LOG_LEVEL_CLASS, logLineClass, loggerClass } from "@/lib/logLine";
import { cn } from "@/lib/utils";

// ログの行を色分けして並べる。compact は実行中の画面のログ欄向けで、日付・レベル・
// ロガー名を省いて時刻と本文だけにする(その実行の間に読むだけなので)。
export default function LogLines({ lines, compact = false }) {
  // 時刻で始まらない行は前の行の続きなので、前の行と同じ色で字下げして出す。
  let prevClass;
  return lines.map((line, i) => {
    const entry = parseLogLine(line);
    if (!entry) {
      return (
        <div key={i} className={cn("pl-6 break-all whitespace-pre-wrap", prevClass ?? "text-muted-foreground")}>
          {line}
        </div>
      );
    }
    prevClass = logLineClass(entry);
    return (
      <div key={i} className={cn("break-all whitespace-pre-wrap", prevClass)}>
        <span className="text-muted-foreground">{compact ? entry.time : `${entry.date} ${entry.time},${entry.ms}`}</span>{" "}
        {!compact && (
          <>
            <span className={cn("font-semibold", LOG_LEVEL_CLASS[entry.level])}>{entry.level.padEnd(7)}</span>{" "}
            <span className={loggerClass(entry.logger)}>{entry.logger}</span>{" "}
          </>
        )}
        {entry.host && (
          <>
            <span className="font-semibold">{entry.host}:</span>{" "}
          </>
        )}
        {entry.text}
      </div>
    );
  });
}
