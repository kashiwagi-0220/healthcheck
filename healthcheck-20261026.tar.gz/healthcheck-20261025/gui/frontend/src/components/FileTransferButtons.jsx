import { useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Download, Upload } from "lucide-react";

// 設定ファイルのダウンロード/アップロードのボタン組。機器一覧(CSV)・コマンド
// カタログ/コマンドセット(ZIP・YAML)で同じ形にするため共有する。
// アップロード中の状態と結果メッセージはここで持ち、成功したら onUploaded で
// 呼び出し側に再読み込みさせる。
//
// downloadUrl は <a href> でそのまま開く(ファイルの組み立てはサーバ側が行う)。
// accept はファイル選択ダイアログで出す拡張子。
export default function FileTransferButtons({
  downloadUrl,
  downloadLabel,
  uploadLabel,
  accept,
  onUpload,
  onUploaded,
  onError,
}) {
  const inputRef = useRef(null);
  const [uploading, setUploading] = useState(false);

  const handleChange = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    onError(null);
    onUpload(file)
      .then((res) => onUploaded(res, file))
      .catch((err) => onError(err.message))
      .finally(() => {
        setUploading(false);
        if (inputRef.current) inputRef.current.value = "";
      });
  };

  return (
    <>
      <a
        href={downloadUrl}
        className="inline-flex h-8 items-center justify-center gap-2 rounded-md border border-input bg-background px-3 text-xs font-medium transition-colors hover:bg-accent hover:text-accent-foreground"
      >
        <Download className="size-4" /> {downloadLabel}
      </a>
      <Button size="sm" variant="outline" onClick={() => inputRef.current?.click()} disabled={uploading}>
        <Upload /> {uploading ? "アップロード中..." : uploadLabel}
      </Button>
      <input ref={inputRef} type="file" accept={accept} onChange={handleChange} className="hidden" />
    </>
  );
}
