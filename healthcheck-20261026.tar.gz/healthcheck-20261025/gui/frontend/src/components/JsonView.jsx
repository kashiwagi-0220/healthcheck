// JSON を読みやすくインデントして表示するだけのコンポーネント(色分けはしない)。
export default function JsonView({ value, className }) {
  return <pre className={className}>{JSON.stringify(value, null, 2)}</pre>;
}
