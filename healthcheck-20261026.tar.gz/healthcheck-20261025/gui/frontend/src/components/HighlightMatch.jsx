// 絞り込み語に一致した部分を黄色で強調する。
//
// ホスト名の絞り込みは部分一致のため、例えば "ise" で絞ると "enterprise-sw01" の
// ような、探している機器とは関係のない名前も残る(名前の途中に "ise" を含むため)。
// どこが一致したのかを示して、絞り込みが効いていないように見えるのを防ぐ。
export default function HighlightMatch({ text, query }) {
  const needle = query.trim().toLowerCase();
  if (!needle) return text;

  const lower = text.toLowerCase();
  const parts = [];
  let from = 0;
  for (let at = lower.indexOf(needle); at !== -1; at = lower.indexOf(needle, from)) {
    if (at > from) parts.push(text.slice(from, at));
    parts.push(
      <mark key={at} className="rounded-sm bg-yellow-200 px-0.5 text-inherit">
        {text.slice(at, at + needle.length)}
      </mark>
    );
    from = at + needle.length;
  }
  if (from === 0) return text;
  parts.push(text.slice(from));
  return <>{parts}</>;
}
