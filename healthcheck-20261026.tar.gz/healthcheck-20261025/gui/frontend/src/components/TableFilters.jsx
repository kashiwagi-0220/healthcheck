import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";

// 表のヘッダー行(列タイトルの下)に置く列フィルタ。機器一覧・コマンドカタログ・
// コマンドセット・スナップショット一覧・認証情報・機器選択のどの表でも見た目と
// 操作を揃えるため、入力欄の形だけをここに持つ。絞り込みの条件保持と実際の
// フィルタ処理は各ページ側が行う。

export function TextFilter({ value, onChange, placeholder }) {
  return (
    <Input
      className="h-7 text-xs"
      placeholder={placeholder}
      value={value}
      onChange={(e) => onChange(e.target.value)}
    />
  );
}

export function SelectFilter({ value, onChange, options }) {
  return (
    <Select className="h-7 text-xs" value={value} onChange={(e) => onChange(e.target.value)}>
      <option value="">すべて</option>
      {options.map((opt) => (
        <option key={opt} value={opt}>
          {opt}
        </option>
      ))}
    </Select>
  );
}
