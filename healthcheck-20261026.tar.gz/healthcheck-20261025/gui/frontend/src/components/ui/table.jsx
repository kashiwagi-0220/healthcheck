import { cn } from "@/lib/utils";

// containerClassName: 縦スクロール(sticky ヘッダー)を使うページは、ここに
// max-h-*/overflow-y-auto を渡す。横スクロール用の overflow-x-auto と別々の div に
// 分けると、position: sticky の基準になる「直近のスクロール祖先」が内側の div
// (横方向にしかスクロールしないが、CSSの仕様上そちらも overflow:auto 相当になり
// スクロールコンテナとして認識される)になってしまい、外側の div をスクロールしても
// ヘッダーが一緒に流れてしまう。縦横どちらのスクロールも
// 同じ1つの div に持たせることでこれを避ける。
function Table({ className, containerClassName, ...props }) {
  return (
    <div className={cn("relative w-full overflow-x-auto", containerClassName)}>
      {/* border-separate: collapse だと隣接行のボーダーが競合解決の対象になり、
          組み合わせによっては描画されない/太さが揃わないことがあるため、
          行ごとに独立してボーダーを描く separate モードに固定する。 */}
      <table
        className={cn("w-full border-separate border-spacing-0 caption-bottom text-sm", className)}
        {...props}
      />
    </div>
  );
}

function TableHeader({ className, ...props }) {
  return <thead className={className} {...props} />;
}

// border-separate モードでは行(tr)自体のボーダーはブラウザが描画しない(セル=th/td
// にのみボーダーを持たせる必要がある)ため、最終行のボーダーもセル側(td)を対象に消す。
function TableBody({ className, ...props }) {
  return <tbody className={cn("[&_tr:last-child_td]:border-b-0", className)} {...props} />;
}

function TableRow({ className, ...props }) {
  return (
    <tr
      className={cn("transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted", className)}
      {...props}
    />
  );
}

function TableHead({ className, ...props }) {
  return (
    <th
      className={cn(
        "h-10 border-b border-muted-foreground px-3 text-left align-middle font-semibold text-foreground whitespace-nowrap",
        className
      )}
      {...props}
    />
  );
}

function TableCell({ className, ...props }) {
  return (
    <td className={cn("border-b border-muted-foreground p-3 align-middle", className)} {...props} />
  );
}

export { Table, TableHeader, TableBody, TableRow, TableHead, TableCell };
