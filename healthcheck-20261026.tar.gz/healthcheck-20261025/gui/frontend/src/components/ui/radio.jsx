import { cn } from "@/lib/utils";

function Radio({ className, ...props }) {
  return (
    <input
      type="radio"
      className={cn(
        "size-4 shrink-0 border border-input shadow-xs accent-primary outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50",
        className
      )}
      {...props}
    />
  );
}

export { Radio };
