import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";

// shadcn/ui の Select は Radix 製だが、依存を増やさないためネイティブ <select> を
// 同等の見た目にラップしたもの(挙動は素朴だが単体ツールのGUIとしては十分)。
// className(高さ・幅・文字サイズ等)は外側の relative div(矢印の配置基準)に適用し、
// 内側の select は常に h-full w-full で追従させる。className を select 側だけに
// 適用すると、w-* で幅を上書きしたときに矢印(right-2 top-1/2 で div 基準に置く)と
// select 本体の右端がずれるため。
function Select({ className, children, ...props }) {
  return (
    <div className={cn("relative h-9 w-full text-sm", className)}>
      <select
        className="flex h-full w-full appearance-none items-center rounded-md border border-input bg-card px-3 py-1 pr-8 shadow-xs outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50"
        {...props}
      >
        {children}
      </select>
      <ChevronDown className="pointer-events-none absolute right-2 top-1/2 size-4 -translate-y-1/2 opacity-50" />
    </div>
  );
}

export { Select };
