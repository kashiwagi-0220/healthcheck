import { useEffect } from "react";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";

// 依存ライブラリを増やさない簡易モーダル。オーバーレイクリック・Escで閉じる。
// 開いている間は背面のスクロールを止める。
function Dialog({ open, onClose, title, children, className, contentClassName }) {
  useEffect(() => {
    if (!open) return;
    const onKeyDown = (e) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKeyDown);
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKeyDown);
      document.body.style.overflow = prevOverflow;
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-black/50 p-4 pt-[1vh]"
      onClick={onClose}
    >
      <div
        className={cn("w-full max-w-2xl rounded-lg border bg-card shadow-lg", className)}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b px-4 py-3">
          <h2 className="text-sm font-semibold">{title}</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
            <X className="size-4" />
          </button>
        </div>
        <div className={cn("max-h-[75vh] overflow-y-auto p-4", contentClassName)}>{children}</div>
      </div>
    </div>
  );
}

// 結果表示(正常性確認の結果・スナップショットの詳細)のポップアップは raw や
// 差分で縦にも横にも長くなるため、画面いっぱいに近いところまで広げる。高さは
// vh の固定値ではなく「画面高 - ヘッダ - 余白」で求める。オーバーレイ側に
// スクロールが出ると中身と二重スクロールになるため、その手前で収まるようにする。
export const RESULT_DIALOG_WIDTH = "max-w-9xl";
export const RESULT_DIALOG_HEIGHT = "max-h-[calc(100vh-5rem)]";

// スナップショットの詳細ポップアップ内の raw / parsed ペインの高さ。タブを切り替えても
// 大きさが変わらないよう同じ値を使う。正常性確認の結果ポップアップは、ペインが
// 残りの高さを埋めて縮む作り(HealthCheckDetail.jsx の DeviceDetail)なので使わない。
export const RESULT_DIALOG_PANE_HEIGHT = "max-h-[66vh]";

export { Dialog };
