import { cn } from "@/lib/utils";

const VARIANTS = {
  default: "bg-primary text-primary-foreground",
  secondary: "bg-secondary text-secondary-foreground",
  destructive: "bg-destructive text-destructive-foreground",
  success: "bg-success text-success-foreground",
  warning: "bg-warning text-warning-foreground",
};

function Badge({ className, variant = "default", ...props }) {
  return (
    <span
      className={cn(
        "inline-flex w-fit items-center rounded px-2 py-0.5 text-xs font-medium whitespace-nowrap",
        VARIANTS[variant],
        className
      )}
      {...props}
    />
  );
}

export { Badge };
