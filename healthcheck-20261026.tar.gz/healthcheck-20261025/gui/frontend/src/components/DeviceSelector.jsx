import { useMemo, useState } from "react";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { deviceVendorColor, deviceTypeColor } from "@/lib/deviceTypeColor";
import { cn } from "@/lib/utils";
import { ChevronRight } from "lucide-react";
import { TextFilter, SelectFilter } from "@/components/TableFilters";
import HighlightMatch from "@/components/HighlightMatch";

// 機器一覧の表は host/vendor/type/ip/コマンドセット/操作 の6列で全幅だが、
// ここではホスト名・ベンダー・タイプの3列しか持たないため、全幅にはせず「その6列
// テーブルの中でホスト名・ベンダー・タイプが占める幅」に近い幅に抑える。
// 機器選択を使う他の画面(スナップショット取得の確認ステップ等)でも同じ幅を使う。
export const DEVICE_TABLE_WIDTH = "max-w-xl";

const EMPTY_FILTERS = { host: "", vendor: "", type: "" };

// 左: 機器一覧(「機器」セクションの機器一覧タブと同じ見た目 — ホスト名/ベンダー/タイプの
// 列と列フィルタ。クリックで選択・解除)。右: 選択中の機器一覧(クリックで解除)。
// スナップショット取得・正常性確認の機器選択で共有する。
//
// onSelectMany(hosts, selected): 列フィルタで絞り込んだ分をまとめて選択/解除する
// (ベンダーや機種単位でまとめて対象にしたい場合のため)。1件ずつの onToggle を
// 繰り返すのではなく一括で渡し、呼び出し側が1回の更新で反映できるようにする。
export default function DeviceSelector({ devices, loading, error, selectedHosts, onToggle, onSelectMany }) {
  const [filters, setFilters] = useState(EMPTY_FILTERS);
  const setFilter = (key) => (value) => setFilters((prev) => ({ ...prev, [key]: value }));

  const selectedSet = useMemo(() => new Set(selectedHosts), [selectedHosts]);
  const selectedDevices = useMemo(
    () => selectedHosts.map((h) => devices.find((d) => d.host === h)).filter(Boolean),
    [selectedHosts, devices]
  );

  const vendors = useMemo(() => Array.from(new Set(devices.map((d) => d.vendor))).sort(), [devices]);
  const types = useMemo(() => Array.from(new Set(devices.map((d) => d.type))).sort(), [devices]);
  const filteredDevices = useMemo(() => {
    const host = filters.host.trim().toLowerCase();
    return devices
      .filter((d) => {
        if (host && !d.host.toLowerCase().includes(host)) return false;
        if (filters.vendor && d.vendor !== filters.vendor) return false;
        if (filters.type && d.type !== filters.type) return false;
        return true;
      })
      // 機器一覧と同じくホスト名の昇順にする(画面ごとに並びが変わらないように)。
      .sort((a, b) => a.host.localeCompare(b.host, undefined, { numeric: true, sensitivity: "base" }));
  }, [devices, filters]);

  return (
    <div className="space-y-2">
      {error && <p className="text-sm text-destructive">{error}</p>}
      <div className="flex flex-wrap items-start gap-4">
        <div className={cn("w-full space-y-1.5", DEVICE_TABLE_WIDTH)}>
          <div className="flex h-8 items-center justify-between gap-2">
            <Label className="text-sm font-semibold">機器一覧(クリックで選択・解除)</Label>
            <div className="flex gap-1">
              <Button
                size="sm"
                variant="outline"
                disabled={filteredDevices.length === 0}
                onClick={() => onSelectMany(filteredDevices.map((d) => d.host), true)}
              >
                表示中を選択
              </Button>
              <Button
                size="sm"
                variant="outline"
                disabled={filteredDevices.length === 0}
                onClick={() => onSelectMany(filteredDevices.map((d) => d.host), false)}
              >
                表示中を解除
              </Button>
            </div>
          </div>
          <Table containerClassName="max-h-[78vh] overflow-y-auto rounded-md border bg-card">
              <TableHeader className="sticky top-0 z-10 bg-muted">
                <TableRow>
                  <TableHead>ホスト名</TableHead>
                  <TableHead>ベンダー</TableHead>
                  <TableHead>タイプ</TableHead>
                </TableRow>
                <TableRow className="hover:bg-transparent">
                  <TableHead className="py-1.5">
                    <TextFilter value={filters.host} onChange={setFilter("host")} placeholder="絞り込み" />
                  </TableHead>
                  <TableHead className="py-1.5">
                    <SelectFilter value={filters.vendor} onChange={setFilter("vendor")} options={vendors} />
                  </TableHead>
                  <TableHead className="py-1.5">
                    <SelectFilter value={filters.type} onChange={setFilter("type")} options={types} />
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredDevices.map((d) => {
                  const selected = selectedSet.has(d.host);
                  return (
                    <TableRow
                      key={d.host}
                      className={cn("cursor-pointer", selected ? "bg-red-100 hover:bg-red-200" : "hover:bg-accent")}
                      onClick={() => onToggle(d.host)}
                    >
                      <TableCell className="font-medium"><HighlightMatch text={d.host} query={filters.host} /></TableCell>
                      <TableCell>
                        <Badge className={deviceVendorColor(d.vendor)}>{d.vendor}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge className={deviceTypeColor(d.type)}>{d.type}</Badge>
                      </TableCell>
                    </TableRow>
                  );
                })}
                {!loading && filteredDevices.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={3} className="text-center text-sm text-muted-foreground">
                      該当する機器がありません
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
          </Table>
        </div>

        <div className="flex self-stretch items-center pt-8">
          <ChevronRight className="size-6 text-muted-foreground" />
        </div>

        <div className={cn("w-full space-y-1.5", DEVICE_TABLE_WIDTH)}>
          <div className="flex h-8 items-center">
            <Label className="text-sm font-semibold">選択中の機器({selectedHosts.length} 件)</Label>
          </div>
          <Table containerClassName="max-h-[78vh] overflow-y-auto rounded-md border bg-white">
              <TableHeader className="sticky top-0 z-10 bg-muted">
                <TableRow>
                  <TableHead>ホスト名</TableHead>
                  <TableHead>ベンダー</TableHead>
                  <TableHead>タイプ</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {selectedDevices.map((d) => (
                  <TableRow key={d.host} className="cursor-pointer hover:bg-accent" onClick={() => onToggle(d.host)}>
                    <TableCell className="font-medium text-black">{d.host}</TableCell>
                    <TableCell>
                      <Badge className={deviceVendorColor(d.vendor)}>{d.vendor}</Badge>
                    </TableCell>
                    <TableCell>
                      <Badge className={deviceTypeColor(d.type)}>{d.type}</Badge>
                    </TableCell>
                  </TableRow>
                ))}
                {selectedDevices.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={3} className="text-center text-sm text-gray-500">
                      左の一覧から機器を選択してください
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}
