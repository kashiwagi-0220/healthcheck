import { useEffect, useState } from "react";
import { Loader2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

// 実行中であることを示す回転マーク。
export function Spinner({ className }) {
  return <Loader2 className={cn("size-4 shrink-0 animate-spin", className)} aria-hidden="true" />;
}

// 機器ごとの「処理中」バッジ。機器内のコマンドは順次実行で、出力の遅い機器では
// 1台に数分かかる(待ち時間は gui/backend/app/sources.py の CLI_READ_TIMEOUT)。
// その間は進捗イベントが届かないため、回転マークで動いていることを示す。
export function RunningBadge({ children = "処理中" }) {
  return (
    <Badge variant="secondary" className="gap-1">
      <Spinner className="size-3" />
      {children}
    </Badge>
  );
}

// 開始からの経過時間。進捗イベントが来ない間も秒数が進むので、固まっているのか
// 待っているだけなのかが区別できる。
export function Elapsed({ startedAt }) {
  const [now, setNow] = useState(() => Date.now());

  // 1秒ごとに現在時刻を進めるだけ。startedAt が変わった場合も次の tick で
  // 追いつくため、ここで設定し直す必要はない。
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  const total = Math.max(0, Math.floor((now - startedAt) / 1000));
  const text =
    total < 60 ? `${total}秒` : `${Math.floor(total / 60)}分${String(total % 60).padStart(2, "0")}秒`;
  return <span className="text-xs text-muted-foreground tabular-nums">経過 {text}</span>;
}

// 完了機器数の帯。total が 0 のときは割り算を避けて 0% にする。
export function ProgressBar({ done, total }) {
  const percent = total > 0 ? Math.round((done / total) * 100) : 0;
  return (
    <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
      <div
        className="h-full rounded-full bg-primary transition-[width] duration-300"
        style={{ width: `${percent}%` }}
      />
    </div>
  );
}
