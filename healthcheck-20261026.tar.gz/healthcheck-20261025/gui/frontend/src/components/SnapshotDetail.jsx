import { useState } from "react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { RESULT_DIALOG_PANE_HEIGHT } from "@/components/ui/dialog";
import { downloadText, downloadJson, sanitizeFilename } from "@/lib/download";
import { downloadAllRaw, downloadAllParsed, downloadEverything } from "@/lib/snapshotDownload";
import JsonView from "@/components/JsonView";
import { Download } from "lucide-react";

// 1コマンド分の raw/parsed 表示 + ダウンロード。表示順は raw→parsed(タブの並び・
// 既定タブとも raw を先にする)。
function CommandBlock({ host, snapshotId, command, raw, parsed }) {
  const [tab, setTab] = useState("raw");
  const base = `${sanitizeFilename(host)}_${sanitizeFilename(snapshotId)}_${sanitizeFilename(command)}`;

  return (
    <div className="space-y-2 rounded-md border p-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="font-mono text-sm font-medium">{command}</p>
        <div className="flex flex-wrap gap-1">
          <Button size="sm" variant="outline" onClick={() => downloadText(`${base}.raw.txt`, raw ?? "")}>
            <Download /> raw
          </Button>
          <Button
            size="sm"
            variant="outline"
            disabled={parsed == null}
            onClick={() => downloadJson(`${base}.parsed.json`, parsed)}
          >
            <Download /> parsed
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={() => {
              downloadText(`${base}.raw.txt`, raw ?? "");
              if (parsed != null) downloadJson(`${base}.parsed.json`, parsed);
            }}
          >
            <Download /> コマンド全体
          </Button>
        </div>
      </div>
      <div className="flex gap-1">
        <Button size="sm" variant={tab === "raw" ? "default" : "outline"} onClick={() => setTab("raw")}>
          raw
        </Button>
        <Button
          size="sm"
          variant={tab === "parsed" ? "default" : "outline"}
          disabled={parsed == null}
          onClick={() => setTab("parsed")}
        >
          parsed
        </Button>
      </div>
      {tab === "raw" ? (
        <pre className={cn(RESULT_DIALOG_PANE_HEIGHT, "overflow-auto rounded-md bg-muted p-3 text-xs")}>{raw}</pre>
      ) : parsed != null ? (
        <JsonView value={parsed} className={cn(RESULT_DIALOG_PANE_HEIGHT, "overflow-auto rounded-md bg-muted p-3 text-xs")} />
      ) : (
        <pre className={cn(RESULT_DIALOG_PANE_HEIGHT, "overflow-auto rounded-md bg-muted p-3 text-xs")}>(パース結果なし)</pre>
      )}
    </div>
  );
}

// snapshot 1件分の詳細表示 + ダウンロード。スナップショット一覧のポップアップ・
// スナップショット取得の結果表示の両方から共有して使う。
// commands は {command: {raw, parsed}} の形(GET .../full と POST /snapshots/take の
// レスポンスがどちらもこの形を持つ)。コマンドは初めから展開せず、ボタンで選択した
// ものだけ raw/parsed を表示する(全件を最初から開くと縦に長くなりすぎるため)。
// showDownloadAll: 全raw/全parsed/全て の一括ダウンロードボタンをここに出すか
// どうか。スナップショット一覧では表の操作列に同等のボタンがあるため false にして
// 二重表示を避ける。
export default function SnapshotDetail({ host, snapshotId, takenAt, success, error, commands, showDownloadAll = true }) {
  const commandNames = Object.keys(commands);
  const [activeCommand, setActiveCommand] = useState(null);
  const snapshot = { host, id: snapshotId, taken_at: takenAt, success, error, commands };

  return (
    <div className="space-y-3">
      {error && <p className="text-sm text-destructive">{error}</p>}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap gap-1">
          {commandNames.map((cmd) => (
            <Button
              key={cmd}
              size="sm"
              variant={activeCommand === cmd ? "default" : "outline"}
              onClick={() => setActiveCommand(activeCommand === cmd ? null : cmd)}
            >
              {cmd}
            </Button>
          ))}
          {commandNames.length === 0 && <p className="text-sm text-muted-foreground">コマンドがありません</p>}
        </div>
        {showDownloadAll && (
          <div className="flex flex-wrap gap-1">
            <Button size="sm" variant="outline" onClick={() => downloadAllRaw(snapshot)}>
              <Download /> 全raw
            </Button>
            <Button size="sm" variant="outline" onClick={() => downloadAllParsed(snapshot)}>
              <Download /> 全parsed
            </Button>
            <Button size="sm" variant="outline" onClick={() => downloadEverything(snapshot)}>
              <Download /> 全て
            </Button>
          </div>
        )}
      </div>
      {activeCommand && (
        <CommandBlock
          host={host}
          snapshotId={snapshotId}
          command={activeCommand}
          raw={commands[activeCommand].raw}
          parsed={commands[activeCommand].parsed}
        />
      )}
    </div>
  );
}
