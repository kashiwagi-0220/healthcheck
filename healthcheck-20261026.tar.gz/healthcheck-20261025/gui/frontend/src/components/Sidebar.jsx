import { Activity } from "lucide-react";
import { cn } from "@/lib/utils";
import { NAV, defaultKeyFor } from "@/navigation";

// まとめの項目(機器・スナップショット・コマンド)は、その子のどれかを開いている
// 間だけ見出しを明るくする。選択色そのものは子側だけに出し、「いまどの画面か」が
// 1行で分かるようにする。見出しを押したときは最初の子を開く。
function GroupButton({ item, active, onNavigate }) {
  const Icon = item.icon;
  const isOpen = item.children.some((c) => c.key === active);
  return (
    <button
      onClick={() => onNavigate(defaultKeyFor(item))}
      className={cn(
        "flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium transition-colors hover:bg-white/10",
        isOpen ? "text-white" : "text-sidebar-foreground"
      )}
    >
      <Icon className="size-4" />
      {item.label}
    </button>
  );
}

function ChildButton({ item, active, onNavigate }) {
  return (
    <button
      onClick={() => onNavigate(item.key)}
      className={cn(
        "rounded-md px-3 py-1.5 text-left text-sm transition-colors hover:bg-white/10",
        active === item.key
          ? "bg-sidebar-active font-medium text-sidebar-active-foreground hover:bg-sidebar-active"
          : "text-sidebar-foreground/80"
      )}
    >
      {item.label}
    </button>
  );
}

// 子を持たない項目(ログ・利用ガイド)。まとめの見出しと同じ高さに揃える。
function LeafButton({ item, active, onNavigate }) {
  const Icon = item.icon;
  return (
    <button
      onClick={() => onNavigate(item.key)}
      className={cn(
        "flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium transition-colors hover:bg-white/10",
        active === item.key && "bg-sidebar-active text-sidebar-active-foreground hover:bg-sidebar-active"
      )}
    >
      <Icon className="size-4" />
      {item.label}
    </button>
  );
}

export default function Sidebar({ active, onNavigate }) {
  const primary = NAV.find((i) => i.placement === "primary");
  const middle = NAV.filter((i) => !i.placement);
  const footer = NAV.filter((i) => i.placement === "footer");
  const PrimaryIcon = primary.icon;

  return (
    <aside className="flex h-screen w-56 shrink-0 flex-col bg-sidebar text-sidebar-foreground">
      <div className="flex h-14 items-center gap-2 border-b border-white/10 px-4">
        <Activity className="size-5" />
        <span className="font-semibold text-white">healthcheck</span>
      </div>

      <div className="p-2">
        <button
          onClick={() => onNavigate(primary.key)}
          className={cn(
            "flex w-full items-center gap-2 rounded-md border-l-2 border-sidebar-cta px-3 py-2.5 text-sm font-semibold text-white transition hover:bg-white/10",
            active === primary.key && "bg-white/10"
          )}
        >
          <PrimaryIcon className="size-4 text-sidebar-cta" />
          {primary.label}
        </button>
      </div>

      <nav className="flex flex-1 flex-col gap-1 overflow-y-auto p-2 pt-0">
        {middle.map((item) =>
          item.children ? (
            <div key={item.key} className="flex flex-col">
              <GroupButton item={item} active={active} onNavigate={onNavigate} />
              <div className="ml-5 flex flex-col gap-0.5 border-l border-white/15 pl-2">
                {item.children.map((child) => (
                  <ChildButton key={child.key} item={child} active={active} onNavigate={onNavigate} />
                ))}
              </div>
            </div>
          ) : (
            <LeafButton key={item.key} item={item} active={active} onNavigate={onNavigate} />
          )
        )}
        <div className="flex-1" />
        {footer.map((item) => (
          <LeafButton key={item.key} item={item} active={active} onNavigate={onNavigate} />
        ))}
      </nav>
    </aside>
  );
}
