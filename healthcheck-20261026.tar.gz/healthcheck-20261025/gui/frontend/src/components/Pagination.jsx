import { Button } from "@/components/ui/button";

// 一覧の「前へ / 次へ」。ページ番号の計算は hooks/usePagination.js。
export default function Pagination({ page, pageCount, onPageChange }) {
  return (
    <>
      <Button size="sm" variant="outline" disabled={page <= 0} onClick={() => onPageChange(page - 1)}>
        前へ
      </Button>
      <span className="text-xs text-muted-foreground">
        {page + 1} / {pageCount}
      </span>
      <Button
        size="sm"
        variant="outline"
        disabled={page + 1 >= pageCount}
        onClick={() => onPageChange(page + 1)}
      >
        次へ
      </Button>
    </>
  );
}
