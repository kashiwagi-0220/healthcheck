import { useEffect, useMemo, useState } from "react";
import {
  getCommandSets, createCommandSet, updateCommandSet, deleteCommandSet, getCommandCatalog,
  commandSetFilesUrl, uploadCommandSetFiles,
} from "../api/client";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { Plus, Pencil, Trash2, ChevronRight } from "lucide-react";
import { deviceTypeColor, deviceVendorColor } from "@/lib/deviceTypeColor";
import { cn } from "@/lib/utils";
import { TextFilter, SelectFilter } from "@/components/TableFilters";
import FileTransferButtons from "@/components/FileTransferButtons";
import Pagination from "@/components/Pagination";
import { usePageRange, usePageSlice } from "@/hooks/usePagination";

const EMPTY_FILTERS = { name: "", vendor: "", type: "", description: "" };

// コマンドカタログ(選択中 vendor+type の CLI・REST をまとめた一覧)から複数選択する。
// スナップショット取得の機器選択(左に一覧表・右に選択中の一覧)と同じ形にする。
// CLI・REST はコマンドセット側では別々の配列(cli/rest)で持つため、一覧では種別列で
// 区別しつつ、クリックでそれぞれ対応する配列に出し入れする。カタログに無い値が既存データに
// 残っている場合も一覧から消えないようにする(パーサ欄に「カタログ未定義」と表示)。
const EMPTY_COMMAND_FILTERS = { command: "", kind: "", parser: "" };

// 「選択中のコマンド」の表形式表示。CommandPicker(編集画面。クリックで解除可)と
// CommandSetView(閲覧ポップアップ。onRemove無しで読み取り専用)の2箇所で共有する。
// 高さ制御もこのコンポーネント側の containerClassName に一本化し、外側の Dialog と
// 内側リストが同時にスクロール可能になる「2重スクロール」を避ける。
function SelectedCommandsTable({ rows, commands, onRemove, emptyMessage, containerClassName }) {
  return (
    <Table containerClassName={cn("overflow-y-auto rounded-md border bg-white", containerClassName)}>
      <TableHeader className="sticky top-0 z-10 bg-muted">
        <TableRow>
          <TableHead>種別</TableHead>
          <TableHead>コマンド</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {rows.map((row) => (
          <TableRow
            key={`${row.kind}:${row.command}`}
            className={onRemove ? "cursor-pointer hover:bg-accent" : undefined}
            onClick={onRemove ? () => onRemove(row) : undefined}
          >
            <TableCell>
              <Badge variant={row.kind === "rest" ? "default" : "success"}>{row.kind === "rest" ? "REST" : "CLI"}</Badge>
            </TableCell>
            <TableCell className="font-medium" title={commands[row.command]?.description || undefined}>
              {row.command}
            </TableCell>
          </TableRow>
        ))}
        {rows.length === 0 && (
          <TableRow>
            <TableCell colSpan={2} className="text-center text-sm text-muted-foreground">
              {emptyMessage}
            </TableCell>
          </TableRow>
        )}
      </TableBody>
    </Table>
  );
}

function CommandPicker({ ready, commands, selectedCli, selectedRest, onToggleCli, onToggleRest }) {
  const [filters, setFilters] = useState(EMPTY_COMMAND_FILTERS);
  const setFilter = (key) => (value) => setFilters((prev) => ({ ...prev, [key]: value }));

  const catalogNames = useMemo(() => new Set(Object.keys(commands)), [commands]);
  const rows = useMemo(() => {
    const catalogRows = Object.entries(commands).map(([command, spec]) => ({
      command,
      spec,
      kind: spec.parser === "json" ? "rest" : "cli",
    }));
    const extraCli = selectedCli
      .filter((c) => !catalogNames.has(c))
      .map((command) => ({ command, spec: null, kind: "cli" }));
    const extraRest = selectedRest
      .filter((c) => !catalogNames.has(c))
      .map((command) => ({ command, spec: null, kind: "rest" }));
    return [...catalogRows, ...extraCli, ...extraRest].sort((a, b) => a.command.localeCompare(b.command));
  }, [commands, catalogNames, selectedCli, selectedRest]);

  const parserOptions = useMemo(
    () => Array.from(new Set(rows.map((r) => r.spec?.parser).filter(Boolean))).sort(),
    [rows]
  );

  const filteredRows = useMemo(() => {
    const q = filters.command.trim().toLowerCase();
    return rows.filter((r) => {
      if (q && !r.command.toLowerCase().includes(q)) return false;
      if (filters.kind && (r.kind === "rest" ? "REST" : "CLI") !== filters.kind) return false;
      if (filters.parser && r.spec?.parser !== filters.parser) return false;
      return true;
    });
  }, [rows, filters]);

  const isSelected = (row) => (row.kind === "cli" ? selectedCli.includes(row.command) : selectedRest.includes(row.command));
  const toggle = (row) => (row.kind === "cli" ? onToggleCli(row.command) : onToggleRest(row.command));

  const selectedRows = useMemo(() => {
    const cliRows = selectedCli.map((command) => ({ command, kind: "cli" }));
    const restRows = selectedRest.map((command) => ({ command, kind: "rest" }));
    return [...cliRows, ...restRows];
  }, [selectedCli, selectedRest]);

  if (!ready) {
    return <p className="text-xs text-muted-foreground">先にベンダー・タイプを選択してください</p>;
  }
  if (rows.length === 0) {
    return (
      <p className="text-xs text-muted-foreground">
        このベンダー・タイプのコマンドカタログに定義がありません(config/command/command_catalog/ を確認してください)
      </p>
    );
  }

  return (
    <div className="flex flex-wrap items-start gap-4">
      <div className="w-full max-w-xl space-y-1.5">
        <Label className="text-sm font-semibold">コマンド一覧(クリックで選択・解除)</Label>
        <Table containerClassName="max-h-[60vh] overflow-y-auto rounded-md border bg-card">
            <TableHeader className="sticky top-0 z-10 bg-muted">
              <TableRow>
                <TableHead>コマンド</TableHead>
                <TableHead>種別</TableHead>
                <TableHead>パーサ</TableHead>
              </TableRow>
              <TableRow className="hover:bg-transparent">
                <TableHead className="py-1.5">
                  <TextFilter value={filters.command} onChange={setFilter("command")} placeholder="絞り込み" />
                </TableHead>
                <TableHead className="py-1.5">
                  <SelectFilter value={filters.kind} onChange={setFilter("kind")} options={["CLI", "REST"]} />
                </TableHead>
                <TableHead className="py-1.5">
                  <SelectFilter value={filters.parser} onChange={setFilter("parser")} options={parserOptions} />
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredRows.map((row) => {
                const selected = isSelected(row);
                return (
                  <TableRow
                    key={`${row.kind}:${row.command}`}
                    className={cn("cursor-pointer", selected ? "bg-red-100 hover:bg-red-200" : "hover:bg-accent")}
                    onClick={() => toggle(row)}
                  >
                    <TableCell className="font-medium" title={row.spec?.description || undefined}>
                      {row.command}
                    </TableCell>
                    <TableCell>
                      <Badge variant={row.kind === "rest" ? "default" : "success"}>
                        {row.kind === "rest" ? "REST" : "CLI"}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {row.spec ? row.spec.parser : "カタログ未定義"}
                    </TableCell>
                  </TableRow>
                );
              })}
              {filteredRows.length === 0 && (
                <TableRow>
                  <TableCell colSpan={3} className="text-center text-sm text-muted-foreground">
                    該当する項目がありません
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
        </Table>
      </div>

      <div className="flex self-stretch items-center pt-8">
        <ChevronRight className="size-6 text-muted-foreground" />
      </div>

      <div className="w-full max-w-xl space-y-1.5">
        <Label className="text-sm font-semibold">選択中のコマンド({selectedRows.length} 件)</Label>
        <SelectedCommandsTable
          rows={selectedRows}
          commands={commands}
          onRemove={toggle}
          emptyMessage="左の一覧から選択してください"
          containerClassName="max-h-[60vh]"
        />
      </div>
    </div>
  );
}

// 作成・編集共通のフォーム。name は作成時のみ入力(編集時は変更不可なので表示のみ)。
// catalog は vendor -> type -> {command: spec} (GET /command-catalog のレスポンスそのまま。
// コア側の CommandCatalog.by_vendor_type と同じ階層構造)。
// CLI コマンド・REST の key は自由入力ではなく、選択した vendor+type のコマンド
// カタログ(parser が "json" でないもの=CLI側、"json"のもの=REST側)から選ぶ形式に
// する(カタログに無い値は実行時にエラーになるため、そもそも選べないようにして
// 事故を防ぐ)。REST の method/path はコマンドカタログ側が持つため、ここでは
// key を選ぶだけでよい。
function CommandSetForm({ name, initial, catalog, onCancel, onSubmit, submitLabel }) {
  const [nameInput, setNameInput] = useState(name ?? "");
  const [vendor, setVendor] = useState(initial?.vendor ?? "");
  const [type, setType] = useState(initial?.type ?? "");
  const [description, setDescription] = useState(initial?.description ?? "");
  const [selectedCli, setSelectedCli] = useState(initial?.cli ?? []);
  const [selectedRest, setSelectedRest] = useState(initial?.rest ?? []);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  const vendors = useMemo(() => Object.keys(catalog).sort(), [catalog]);
  const types = useMemo(() => Object.keys(catalog[vendor] ?? {}).sort(), [catalog, vendor]);
  const commands = useMemo(() => catalog[vendor]?.[type] ?? {}, [catalog, vendor, type]);
  const ready = Boolean(vendor && type);

  const handleVendorChange = (value) => {
    setVendor(value);
    // vendor が変わったら type・選択済みの CLI・REST をリセットする(別ベンダーの
    // カタログの値を引き継がないため)。
    setType("");
    setSelectedCli([]);
    setSelectedRest([]);
  };
  const handleTypeChange = (value) => {
    setType(value);
    // type が変わったら選択済みの CLI・REST をリセットする(別機種のカタログの
    // 値を引き継がないため)。
    setSelectedCli([]);
    setSelectedRest([]);
  };
  const toggleCli = (command) =>
    setSelectedCli((prev) => (prev.includes(command) ? prev.filter((c) => c !== command) : [...prev, command]));
  const toggleRest = (key) =>
    setSelectedRest((prev) => (prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]));

  const handleSubmit = () => {
    if (!name && !nameInput.trim()) {
      setError("コマンドセット名を入力してください。");
      return;
    }
    if (!ready) {
      setError("ベンダー・タイプを選択してください。");
      return;
    }
    setSaving(true);
    setError(null);
    const payload = {
      vendor,
      type,
      description: description.trim() || null,
      cli: selectedCli,
      rest: selectedRest,
    };
    if (!name) payload.name = nameInput.trim();
    onSubmit(payload)
      .catch((e) => setError(e.message))
      .finally(() => setSaving(false));
  };

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-3 gap-3">
        <div className="space-y-1">
          <Label className="text-sm font-semibold">コマンドセット名</Label>
          {name ? (
            <Input className="h-8" value={name} disabled />
          ) : (
            <Input
              className="h-8"
              placeholder="例: cisco_ios_full"
              value={nameInput}
              onChange={(e) => setNameInput(e.target.value)}
            />
          )}
        </div>
        <div className="space-y-1">
          <Label className="text-sm font-semibold">ベンダー</Label>
          <Select className="h-8" value={vendor} onChange={(e) => handleVendorChange(e.target.value)}>
            <option value="" disabled>
              選択してください
            </option>
            {vendors.map((v) => (
              <option key={v} value={v}>
                {v}
              </option>
            ))}
          </Select>
        </div>
        <div className="space-y-1">
          <Label className="text-sm font-semibold">タイプ</Label>
          <Select className="h-8" value={type} onChange={(e) => handleTypeChange(e.target.value)} disabled={!vendor}>
            <option value="" disabled>
              {vendor ? "選択してください" : "先にベンダーを選択"}
            </option>
            {types.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </Select>
        </div>
      </div>

      <div className="space-y-1">
        <Label className="text-sm font-semibold">説明(任意)</Label>
        <Input className="h-8" value={description} onChange={(e) => setDescription(e.target.value)} />
      </div>

      <CommandPicker
        ready={ready}
        commands={commands}
        selectedCli={selectedCli}
        selectedRest={selectedRest}
        onToggleCli={toggleCli}
        onToggleRest={toggleRest}
      />

      {error && <p className="text-sm text-destructive">{error}</p>}
      <div className="flex items-center gap-2">
        <Button size="sm" onClick={handleSubmit} disabled={saving}>
          {saving ? "保存中..." : submitLabel}
        </Button>
        <Button size="sm" variant="outline" onClick={onCancel} disabled={saving}>
          キャンセル
        </Button>
      </div>
    </div>
  );
}

// CommandSetForm と同じレイアウトの、編集不可(表示専用)版。コマンド選択の
// 部分は選択肢一覧(CommandPicker)を出さず、実際に選択されているコマンドだけを
// 表示する。
function CommandSetView({ name, entry, catalog }) {
  const rows = [
    ...entry.cli.map((command) => ({ command, kind: "cli" })),
    ...entry.rest.map((command) => ({ command, kind: "rest" })),
  ];
  const commands = catalog?.[entry.vendor]?.[entry.type] ?? {};

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-3 gap-3">
        <div className="space-y-1">
          <Label className="text-sm font-semibold">コマンドセット名</Label>
          <p className="text-sm font-medium">{name}</p>
        </div>
        <div className="space-y-1">
          <Label className="text-sm font-semibold">ベンダー</Label>
          <div>
            <Badge className={deviceVendorColor(entry.vendor)}>{entry.vendor}</Badge>
          </div>
        </div>
        <div className="space-y-1">
          <Label className="text-sm font-semibold">タイプ</Label>
          <div>
            <Badge className={deviceTypeColor(entry.type)}>{entry.type}</Badge>
          </div>
        </div>
      </div>

      <div className="space-y-1">
        <Label className="text-sm font-semibold">説明</Label>
        <p className="text-sm">{entry.description || "-"}</p>
      </div>

      <div className="w-full max-w-xl space-y-1.5">
        <Label className="text-sm font-semibold">選択中のコマンド({rows.length} 件)</Label>
        <SelectedCommandsTable
          rows={rows}
          commands={commands}
          emptyMessage="コマンドが選択されていません"
          containerClassName="max-h-[55vh]"
        />
      </div>
    </div>
  );
}

export default function CommandSetsPage() {
  const [commandSets, setCommandSets] = useState(null);
  const [catalog, setCatalog] = useState({});
  const [error, setError] = useState(null);
  const [filters, setFilters] = useState(EMPTY_FILTERS);
  const [page, setPage] = useState(0);
  const [creating, setCreating] = useState(false);
  const [editingName, setEditingName] = useState(null);
  const [viewingName, setViewingName] = useState(null);

  const reload = () => getCommandSets().then(setCommandSets).catch((e) => setError(e.message));
  useEffect(() => {
    reload();
    getCommandCatalog().then(setCatalog).catch((e) => setError(e.message));
  }, []);

  const setFilter = (key) => (value) => {
    setPage(0);
    setFilters((prev) => ({ ...prev, [key]: value }));
  };

  const rows = useMemo(() => {
    if (!commandSets) return [];
    // ベンダー > タイプ > コマンドセット名 の昇順。
    return Object.entries(commandSets).sort(
      ([nameA, a], [nameB, b]) => a.vendor.localeCompare(b.vendor) || a.type.localeCompare(b.type) || nameA.localeCompare(nameB)
    );
  }, [commandSets]);
  const vendors = useMemo(
    () => Array.from(new Set(rows.map(([, entry]) => entry.vendor))).sort(),
    [rows]
  );
  const types = useMemo(
    () => Array.from(new Set(rows.map(([, entry]) => entry.type))).sort(),
    [rows]
  );
  const filtered = useMemo(() => {
    const name = filters.name.trim().toLowerCase();
    const description = filters.description.trim().toLowerCase();
    return rows.filter(([setName, entry]) => {
      if (name && !setName.toLowerCase().includes(name)) return false;
      if (filters.vendor && entry.vendor !== filters.vendor) return false;
      if (filters.type && entry.type !== filters.type) return false;
      if (description && !(entry.description ?? "").toLowerCase().includes(description)) return false;
      return true;
    });
  }, [rows, filters]);

  const { pageCount, rangeStart, rangeEnd } = usePageRange(filtered.length, page);
  const pageRows = usePageSlice(filtered, page);

  const handleCreate = (payload) => createCommandSet(payload).then(() => { setCreating(false); reload(); });
  const handleUpdate = (name) => (payload) => updateCommandSet(name, payload).then(() => { setEditingName(null); reload(); });
  const handleDelete = (name) => {
    if (!window.confirm(`コマンドセット '${name}' を削除しますか?`)) return;
    deleteCommandSet(name).then(reload).catch((e) => setError(e.message));
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          {rangeStart}-{rangeEnd} / {filtered.length} 件(全 {rows.length} 件)
        </p>
        <div className="flex items-center gap-2">
          <Pagination page={page} pageCount={pageCount} onPageChange={setPage} />
          <FileTransferButtons
            downloadUrl={commandSetFilesUrl}
            downloadLabel="YAMLダウンロード"
            uploadLabel="YAMLアップロード"
            accept=".zip,.yaml,.yml"
            onUpload={uploadCommandSetFiles}
            onUploaded={() => reload()}
            onError={setError}
          />
          <Button size="sm" onClick={() => { setEditingName(null); setCreating((v) => !v); }}>
            <Plus /> 新規作成
          </Button>
        </div>
      </div>
      {error && <p className="text-sm text-destructive">{error}</p>}

      <Table className="table-fixed" containerClassName="max-h-[78vh] overflow-y-auto rounded-md border bg-card">
          <TableHeader className="sticky top-0 z-10 bg-muted">
            <TableRow>
              <TableHead className="w-[14%]">コマンドセット</TableHead>
              <TableHead className="w-[10%]">ベンダー</TableHead>
              <TableHead className="w-[10%]">タイプ</TableHead>
              <TableHead className="w-[36%]">説明</TableHead>
              <TableHead className="w-[8%]">CLI</TableHead>
              <TableHead className="w-[8%]">REST</TableHead>
              <TableHead className="w-[14%]">操作</TableHead>
            </TableRow>
            <TableRow className="hover:bg-transparent">
              <TableHead className="py-1.5">
                <TextFilter value={filters.name} onChange={setFilter("name")} placeholder="絞り込み" />
              </TableHead>
              <TableHead className="py-1.5">
                <SelectFilter value={filters.vendor} onChange={setFilter("vendor")} options={vendors} />
              </TableHead>
              <TableHead className="py-1.5">
                <SelectFilter value={filters.type} onChange={setFilter("type")} options={types} />
              </TableHead>
              <TableHead className="py-1.5">
                <TextFilter value={filters.description} onChange={setFilter("description")} placeholder="絞り込み" />
              </TableHead>
              <TableHead className="py-1.5" />
              <TableHead className="py-1.5" />
              <TableHead className="py-1.5" />
            </TableRow>
          </TableHeader>
          <TableBody>
            {pageRows.map(([name, entry]) => (
              <TableRow
                key={name}
                className="cursor-pointer hover:bg-accent"
                onClick={() => setViewingName(name)}
              >
                <TableCell className="font-medium">{name}</TableCell>
                <TableCell>
                  <Badge className={deviceVendorColor(entry.vendor)}>{entry.vendor}</Badge>
                </TableCell>
                <TableCell>
                  <Badge className={deviceTypeColor(entry.type)}>{entry.type}</Badge>
                </TableCell>
                <TableCell className="text-muted-foreground">{entry.description || "-"}</TableCell>
                <TableCell className="text-muted-foreground">{entry.cli.length}件</TableCell>
                <TableCell className="text-muted-foreground">{entry.rest.length}件</TableCell>
                <TableCell>
                  <div className="flex gap-1">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={(e) => { e.stopPropagation(); setCreating(false); setEditingName(name); }}
                    >
                      <Pencil />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={(e) => { e.stopPropagation(); handleDelete(name); }}
                    >
                      <Trash2 />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
            {filtered.length === 0 && (
              <TableRow>
                <TableCell colSpan={7} className="text-center text-sm text-muted-foreground">
                  該当するコマンドセットがありません
                </TableCell>
              </TableRow>
            )}
          </TableBody>
      </Table>

      <Dialog
        open={creating || editingName !== null}
        onClose={() => { setCreating(false); setEditingName(null); }}
        title={creating ? "コマンドセットを新規作成" : `コマンドセットを編集: ${editingName}`}
        className="max-w-8xl"
        contentClassName="min-h-[85vh] max-h-[90vh]"
      >
        {creating && (
          <CommandSetForm
            catalog={catalog}
            submitLabel="作成"
            onCancel={() => setCreating(false)}
            onSubmit={handleCreate}
          />
        )}
        {editingName !== null && (
          <CommandSetForm
            name={editingName}
            initial={commandSets?.[editingName]}
            catalog={catalog}
            submitLabel="保存"
            onCancel={() => setEditingName(null)}
            onSubmit={handleUpdate(editingName)}
          />
        )}
      </Dialog>

      <Dialog
        open={viewingName !== null}
        onClose={() => setViewingName(null)}
        title={`コマンドセット: ${viewingName}`}
        className="max-w-3xl"
        contentClassName="max-h-[90vh]"
      >
        {viewingName !== null && commandSets?.[viewingName] && (
          <CommandSetView name={viewingName} entry={commandSets[viewingName]} catalog={catalog} />
        )}
      </Dialog>
    </div>
  );
}
