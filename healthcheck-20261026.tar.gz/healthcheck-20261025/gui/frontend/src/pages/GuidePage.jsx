const GENIE_FEATURE_BROWSER_URL = "https://pubhub.devnetcloud.com/media/genie-feature-browser/docs/#/parsers";

function Section({ title, children }) {
  return (
    <section className="space-y-2">
      <h2 className="border-b pb-1 text-base font-bold">{title}</h2>
      <div className="space-y-2 text-sm text-muted-foreground">{children}</div>
    </section>
  );
}

function SubSection({ title, children }) {
  return (
    <div className="space-y-2 pt-1">
      <h3 className="text-sm font-semibold text-foreground">{title}</h3>
      {children}
    </div>
  );
}

function Code({ children }) {
  return <pre className="overflow-x-auto rounded-md bg-muted p-3 text-xs text-foreground">{children}</pre>;
}

function Path({ children }) {
  return <code className="font-mono text-foreground">{children}</code>;
}

// 各セクションの概要・使い方・設定方法をまとめた利用ガイド。画面の操作手順と、
// その操作が実際にどのファイルを読み書きするのかを対応づけて書く(設定ファイルを
// 直接編集したい場合にも迷わないようにするため)。
export default function GuidePage() {
  return (
    <div className="max-w-3xl space-y-8 pb-8">
      <Section title="このツールについて">
        <p>
          ネットワーク機器から情報を取得し、2つの時点を比較して差分の有無を判定する正常性確認ツールです。
          作業の前後で同じコマンドを実行し、意図しない変化が起きていないかを確認する用途を想定しています。
        </p>
        <p>
          基本的な流れは「<span className="font-medium text-foreground">機器を登録する</span> →
          <span className="font-medium text-foreground">取得するコマンドを決める</span> →
          <span className="font-medium text-foreground">正常性確認を実行する</span>」です。
          作業前にスナップショットを取得しておき、作業後に「正常性確認」でその時点と比較します。
        </p>
        <p>
          設定はすべて <Path>config/</Path> 配下のファイルで、取得したデータは <Path>data/</Path> 配下に保存されます。
          画面からの操作はそのままこれらのファイルの読み書きになります。
        </p>
      </Section>

      <Section title="正常性確認">
        <p>
          2つの時点を比較して差分を判定する、このツールの中心となる画面です。
          4つのステップ(機器選択 → before/after の指定 → 確認 → 結果)で進みます。
        </p>
        <SubSection title="使い方">
          <ul className="list-disc space-y-1 pl-5">
            <li>
              <span className="font-medium text-foreground">機器選択</span>:
              左の一覧から対象機器をクリックで選びます。列フィルタで絞り込んでから「表示中を選択」を押すと、
              ベンダーや機種単位でまとめて選択できます。
            </li>
            <li>
              <span className="font-medium text-foreground">before / after の指定</span>:
              機器ごとに「今すぐ取得」「最新を選択」、または個別のスナップショットを指定できます。
              作業前に取得済みのスナップショットを before に、作業後の現在の状態を after(今すぐ取得)に
              指定するのが典型的な使い方です。列の見出し下のボタンで、表示中の全機器にまとめて適用できます。
            </li>
            <li>
              <span className="font-medium text-foreground">結果</span>:
              機器ごとに ok(差分なし)/ ng(差分あり)/ skipped / error を判定します。
              行をクリックするとコマンド単位の詳細が開きます。
            </li>
          </ul>
        </SubSection>
        <SubSection title="結果の見方">
          <p>
            コマンド単位の詳細では、「差分」「ノイズ」「raw」「parsed」「正規化後」を切り替えて確認できます。
            差分は左に before・右に after を並べ、行を揃えて表示します(変更は黄色、追加は緑、削除は赤)。
          </p>
          <ul className="list-disc space-y-1 pl-5">
            <li><span className="font-medium text-foreground">差分</span>: 判定の根拠になった差分です。1件でもあれば ng になります。</li>
            <li><span className="font-medium text-foreground">ノイズ</span>: 差分として検出されたものの、コマンドカタログの noise 設定により判定から除外されたものです。uptime やカウンタなど、取得のたびに必ず変わる値がここに入ります。</li>
            <li><span className="font-medium text-foreground">raw / parsed</span>: 機器からの生の出力と、パーサで構造化した結果です。</li>
            <li><span className="font-medium text-foreground">正規化後</span>: 実際に比較へ使われた形です。list は compare_keys でキー化されます。意図したキーで比較できているかはここで確認できます。</li>
          </ul>
          <p>
            差分が多すぎる場合は、そのコマンドの noise 設定を見直してください(「コマンド」セクション参照)。
          </p>
        </SubSection>
      </Section>

      <Section title="機器">
        <p>対象機器と、接続に必要な認証情報・踏み台の設定を管理します。左のメニューから3つの画面を選べます。</p>
        <SubSection title="機器一覧">
          <p>
            <Path>config/devices.csv</Path> を読み書きします。1行が1機器で、
            host(ホスト名)・vendor(ベンダー)・type(機種/OS)・ip・command_set(使用するコマンドセット名)を持ちます。
            機器の関連付けには host を使うため、host は環境内で一意にしてください。
          </p>
          <p>
            画面から1件ずつ追加・編集・削除できるほか、CSVファイルそのもののダウンロード・アップロードもできます。
            多数の機器を一度に登録する場合は、ダウンロードした CSV を編集してアップロードするのが簡単です。
          </p>
          <Code>{`host,vendor,type,ip,command_set
RT-01,cisco,ios,192.168.0.201,cisco_ios
SW-01,cisco,iosxe,192.168.0.202,cisco_iosxe`}</Code>
          <p>
            vendor と type の組み合わせは、コマンドカタログのディレクトリ構成
            (<Path>config/command/command_catalog/&lt;ベンダー&gt;/&lt;タイプ&gt;.yaml</Path>)と対応します。
            command_set に指定したコマンドセットの vendor/type が機器自身のものと一致しない場合は、保存時にエラーになります。
          </p>
        </SubSection>
        <SubSection title="認証情報">
          <p>
            <Path>config/credentials.yaml</Path> を読み書きします。全機器共通の既定アカウント(default。必須)と、
            一部のホストだけ別アカウントを使う場合の上書き(hosts)を持てます。
            ホスト個別の設定があればそれを、無ければ default を使います。
          </p>
          <p>
            secret は enable(特権)パスワードで、必要な機器のみ設定します。
            現時点では平文で保存されるため、ファイルのパーミッションは 600 に設定しています。
          </p>
        </SubSection>
        <SubSection title="プロキシ設定">
          <p>
            踏み台(bastion)経由でしか到達できない機器向けの設定で、<Path>config/proxy.conf</Path> を読み書きします。
            OpenSSH の設定ファイル形式で、画面上で直接編集するか、ファイルをアップロードできます。
          </p>
          <Code>{`Host 192.168.*.*
    ProxyJump bastion.example.com`}</Code>
          <p>
            有効/無効の切り替えはありません。Host パターンに一致しない機器にはそもそも ProxyJump が適用されないため、
            このファイルの内容だけで機器ごとの挙動が決まります。ファイルが無ければ踏み台を使わずに接続します。
          </p>
        </SubSection>
      </Section>

      <Section title="スナップショット">
        <p>
          ある時点の取得結果のまとまりです。機器ごとに「いつ・どのコマンドを実行し・何が返ってきたか」を保持します。
          正常性確認の比較対象(before / after)として使います。
        </p>
        <SubSection title="スナップショット取得">
          <p>
            機器を選んで取得を実行します。「取得して保存」を選ぶと <Path>data/</Path> 配下に保存され、
            後から正常性確認の比較対象として選べるようになります。「取得して表示」を選んだ場合はディスクに何も書かず、
            その場で結果を確認するだけになります。
          </p>
          <p>
            確認ステップでは、各機器に解決されたコマンドセットを表示します。コマンドセットが未設定だったり、
            機器の vendor/type と一致しない場合はここで警告し、実行を止めます(1機器でも解決に失敗すると全体が中断するため)。
          </p>
        </SubSection>
        <SubSection title="スナップショット一覧">
          <p>
            取得済みのスナップショットを新しい順に表示します。行をクリックすると、コマンドごとの raw / parsed を確認できます。
            raw・parsed・その両方をファイルとしてダウンロードすることもできます。
          </p>
        </SubSection>
      </Section>

      <Section title="コマンド">
        <p>
          機器から「何を取得し、どう解析し、比較時に何を無視するか」を定義します。
          コマンドカタログ(機種ごとの定義)とコマンドセット(機器に割り当てる組み合わせ)の2層に分かれています。
        </p>
        <SubSection title="コマンドカタログ">
          <p>
            機種(ベンダー・タイプ)ごとに、「どのコマンド・REST問い合わせを、どのパーサで解析し、
            比較時にどのキーをノイズとして除外するか」を定義したものです。
            <Path>config/command/command_catalog/&lt;ベンダー&gt;/&lt;タイプ&gt;.yaml</Path> に、1機種=1ファイルで保存します。
            各ファイルは CLI コマンド用の <span className="font-mono">cli</span> と、REST 問い合わせ用の
            <span className="font-mono"> rest</span> の2つを持てます(片方だけでも構いません)。
          </p>
          <ul className="list-disc space-y-1 pl-5">
            <li><span className="font-medium text-foreground">parser</span>: genie / textfsm(CLI)または json(REST)</li>
            <li><span className="font-medium text-foreground">noise</span>: 比較時に無視するキーパスの一覧(uptime など、取得のたびに必ず変わる値)</li>
            <li><span className="font-medium text-foreground">compare_keys</span>: 出力に list が含まれる場合の、比較用の一意キー列(パーサ種別を問わず、ネストした list にも使えます)</li>
            <li><span className="font-medium text-foreground">method / path</span>: REST 問い合わせの場合のみ。実際に叩く HTTP メソッド(get のみ)とパス</li>
          </ul>
          <Code>{`# config/command/command_catalog/cisco/ios.yaml
cli:
  "show version":
    description: "バージョン・稼働時間・ハードウェア情報"
    parser: genie
    noise:
      - "uptime"
    compare_keys: null
rest: {}`}</Code>
          <p>
            REST 問い合わせは <span className="font-mono">key</span>(任意の名前)をコマンド名の代わりに使い、
            <span className="font-mono"> method</span> / <span className="font-mono">path</span> で実際に叩く先を指定します。
            CLI のコマンド文字列と同じ「取得単位の名前」として扱われるため、コマンドセット側の書き方は CLI と同じです。
          </p>
          <Code>{`# config/command/command_catalog/cisco/apic.yaml
rest:
  fault_summary:
    description: "障害サマリ"
    parser: json
    method: get
    path: "/api/node/class/faultSummary.json"
    noise: []
    compare_keys: ["imdata[].*.attributes.dn"]`}</Code>
          <p>
            Cisco 機器の CLI コマンドについては、Genie パーサでの対応状況を{" "}
            <a
              href={GENIE_FEATURE_BROWSER_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="text-primary underline underline-offset-2"
            >
              Genie Feature Browser
            </a>{" "}
            で確認できます。掲載されているコマンドであれば <span className="font-mono">parser: genie</span> として利用できます。
            掲載が無いコマンドは <span className="font-mono">parser: textfsm</span> でテンプレートを用意するか、
            比較が不要であれば取り扱い自体を見送ってください。
          </p>
        </SubSection>
        <SubSection title="コマンドセット">
          <p>
            機器に対して実際に取得する内容(CLI コマンド・REST 問い合わせの組み合わせ)をまとめたものです。
            <Path>config/command/command_set/</Path> 配下に、1コマンドセット=1ファイル(ファイル名=コマンドセット名)で保存します。
            どの機器がどのコマンドセットを使うかは、<Path>config/devices.csv</Path> の
            <span className="font-mono"> command_set</span> 列で決まります。
          </p>
          <Code>{`# config/command/command_set/cisco_ios.yaml
vendor: cisco
type: ios
description: "Cisco IOS 標準セット(show系のみ)"
cli:
  - "show version"
  - "show ip interface brief"
rest: []`}</Code>
          <p>
            <span className="font-mono">vendor</span> / <span className="font-mono">type</span> は必須です。
            1つのコマンドセットは必ず1つの vendor+type 向けで、異なる機種のコマンドを混在させることはできません
            (機器本来の vendor/type と一致しない場合は実行時にエラーになります)。
            同じ機種で用途違いのコマンドセットを複数持つこと(例: cisco_ios_full / cisco_ios_minimal)は可能です。
          </p>
          <p>
            コマンドセットに追加できるのは、コマンドカタログに定義済みのコマンドだけです。
            カタログに無いコマンドを使いたい場合は、先にコマンドカタログ側へ登録してください。
          </p>
        </SubSection>
        <SubSection title="設定ファイルのバックアップ・移行">
          <p>
            コマンドカタログ・コマンドセットとも、画面右上の「YAMLダウンロード」でディレクトリ全体を
            ZIP として取得できます。別環境へ移す場合やバックアップを取る場合に使ってください。
          </p>
          <p>
            「YAMLアップロード」は ZIP のほか、単一の .yaml ファイルも受け付けます
            (1機種分・1コマンドセット分だけ持ち込む場合)。<span className="font-medium text-foreground">
            同名のファイルは上書きされ、アップロードに含まれないファイルはそのまま残ります</span>
            (取り違えたファイルで既存の設定が全部消えることを避けるため)。不要になった定義は
            画面上の削除操作で消してください。
          </p>
        </SubSection>
        <SubSection title="差分が多すぎる・意図した比較にならない場合">
          <ul className="list-disc space-y-1 pl-5">
            <li>
              毎回変わる値(uptime・カウンタ・最終受信時刻など)が差分に出る場合は、
              そのコマンドの <span className="font-mono">noise</span> にキーパスを追加します。
            </li>
            <li>
              並び順が変わっただけで差分として出る場合は、<span className="font-mono">compare_keys</span> に
              「その list の要素を一意に識別できるキー」を指定します。正常性確認の「正規化後」で、
              意図したキーで dict 化できているか確認できます。
            </li>
          </ul>
        </SubSection>
      </Section>

      <Section title="ログ">
        <p>
          機器への接続・コマンド実行の記録を <Path>data/healthcheck.log</Path> から読み返します。
          接続の開始/成功/失敗、コマンドごとの実行開始/完了/失敗が記録されます。
        </p>
        <p>
          実行中の進捗は画面上に機器単位で表示されますが、こちらはコマンド単位の詳細を、実行が終わった後からでも確認できます。
          取得が失敗した機器について原因を調べる場合に使ってください。任意の文字列(ホスト名・コマンド名・エラー文言など)で
          部分一致の絞り込みができます。
        </p>
        <p>
          機器の追加・編集・削除、CSV や YAML の取り込み、コマンドカタログ・コマンドセットの変更、認証情報・プロキシ設定の
          変更といった<span className="font-medium text-foreground">設定を書き換える操作</span>も記録されます
          (「いつ・何を変えたか」を後から追えるようにするため)。正常性確認やスナップショット取得そのものは、
          収集の記録だけが残ります。
        </p>
      </Section>
    </div>
  );
}
