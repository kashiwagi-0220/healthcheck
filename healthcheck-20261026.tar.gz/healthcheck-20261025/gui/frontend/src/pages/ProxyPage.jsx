import { useEffect, useState } from "react";
import { getProxy, putProxy, proxyConfDownloadUrl, uploadProxyConf } from "../api/client";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import FileTransferButtons from "@/components/FileTransferButtons";
import { Pencil } from "lucide-react";

// 認証情報ページ(DeviceCredentialsPage)と同じ編集形式: 内容は表示のみで、
// 「編集」ボタンを押すとポップアップ(Dialog)にフォーム(Textarea + 保存/キャンセル)
// が開く形にする。
function ProxyForm({ initialText, onCancel, onSubmit }) {
  const [text, setText] = useState(initialText);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  const handleSubmit = () => {
    setSaving(true);
    setError(null);
    onSubmit(text)
      .catch((e) => setError(e.message))
      .finally(() => setSaving(false));
  };

  return (
    <div className="space-y-3">
      <div className="space-y-1.5">
        <Label className="text-sm font-semibold">内容</Label>
        <Textarea className="h-96 font-mono text-xs" value={text} onChange={(e) => setText(e.target.value)} />
      </div>
      {error && <p className="text-sm text-destructive">{error}</p>}
      <div className="flex items-center gap-2">
        <Button size="sm" onClick={handleSubmit} disabled={saving}>
          {saving ? "保存中..." : "保存"}
        </Button>
        <Button size="sm" variant="outline" onClick={onCancel} disabled={saving}>
          キャンセル
        </Button>
      </div>
    </div>
  );
}

export default function ProxyPage() {
  const [text, setText] = useState(null);
  const [error, setError] = useState(null);
  const [uploadedName, setUploadedName] = useState(null);
  const [editing, setEditing] = useState(false);

  const reload = () => getProxy().then((res) => setText(res.text)).catch((e) => setError(e.message));
  useEffect(() => {
    reload();
  }, []);

  const handleSave = (nextText) => putProxy(nextText).then(() => { setEditing(false); return reload(); });

  if (text === null) {
    return error ? <p className="text-sm text-destructive">{error}</p> : null;
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-end">
        <div className="flex items-center gap-2">
          <FileTransferButtons
            downloadUrl={proxyConfDownloadUrl}
            downloadLabel="ダウンロード"
            uploadLabel="アップロード"
            onUpload={uploadProxyConf}
            onUploaded={(res, file) => { setUploadedName(res.saved ?? file.name); return reload(); }}
            onError={setError}
          />
          <Button size="sm" onClick={() => setEditing(true)}>
            <Pencil /> 編集
          </Button>
        </div>
      </div>

      {error && <p className="text-sm text-destructive">{error}</p>}
      {uploadedName && !error && (
        <p className="text-sm text-muted-foreground">アップロードしました: {uploadedName}</p>
      )}

      <pre className="max-h-[78vh] overflow-auto rounded-md border bg-card p-3 font-mono text-xs">
        {text || "(空)"}
      </pre>

      <Dialog open={editing} onClose={() => setEditing(false)} title="プロキシ設定を編集" className="max-w-3xl">
        {editing && <ProxyForm initialText={text} onCancel={() => setEditing(false)} onSubmit={handleSave} />}
      </Dialog>
    </div>
  );
}
