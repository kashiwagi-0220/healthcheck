import { Activity, Server, Camera, Terminal, ScrollText, BookOpen } from "lucide-react";
import HealthCheckPage from "./pages/HealthCheckPage";
import DeviceListPage from "./pages/DeviceListPage";
import DeviceCredentialsPage from "./pages/DeviceCredentialsPage";
import ProxyPage from "./pages/ProxyPage";
import SnapshotListPage from "./pages/SnapshotListPage";
import SnapshotTakePage from "./pages/SnapshotTakePage";
import CommandCatalogPage from "./pages/CommandCatalogPage";
import CommandSetsPage from "./pages/CommandSetsPage";
import LogsPage from "./pages/LogsPage";
import GuidePage from "./pages/GuidePage";

// 画面の一覧と、サイドバーでの並び・階層。ナビゲーションと表示するページの対応を
// 1箇所にまとめ、App はここから現在のページを引くだけにする。
//
// children を持つ項目は「まとめ」で、それ自体には画面が無い(子を選ぶ)。
// 子を持たない項目(正常性確認・ログ・利用ガイド)は Component を直接持つ。
// placement は サイドバー上の置き場所: "primary" は最上部の強調表示、
// "footer" は最下部(間に余白を挟む)、未指定はその間に順番どおり並ぶ。
export const NAV = [
  {
    key: "healthcheck",
    label: "正常性確認",
    icon: Activity,
    placement: "primary",
    Component: HealthCheckPage,
  },
  {
    key: "snapshots",
    label: "スナップショット",
    icon: Camera,
    children: [
      { key: "snapshots/list", label: "スナップショット一覧", Component: SnapshotListPage },
      { key: "snapshots/take", label: "スナップショット取得", Component: SnapshotTakePage },
    ],
  },
  {
    key: "devices",
    label: "機器",
    icon: Server,
    children: [
      { key: "devices/list", label: "機器一覧", Component: DeviceListPage },
      { key: "devices/credentials", label: "認証情報", Component: DeviceCredentialsPage },
      { key: "devices/proxy", label: "プロキシ設定", Component: ProxyPage },
    ],
  },
  {
    key: "commands",
    label: "コマンド",
    icon: Terminal,
    children: [
      { key: "commands/catalog", label: "コマンドカタログ", Component: CommandCatalogPage },
      { key: "commands/sets", label: "コマンドセット", Component: CommandSetsPage },
    ],
  },
  { key: "logs", label: "ログ", icon: ScrollText, Component: LogsPage },
  { key: "guide", label: "利用ガイド", icon: BookOpen, placement: "footer", Component: GuidePage },
];

// 選択中のキーから、表示するページとその位置(パンくず用の親)を引く。
export function findPage(key) {
  for (const item of NAV) {
    if (item.key === key && item.Component) return { page: item, parent: null };
    for (const child of item.children ?? []) {
      if (child.key === key) return { page: child, parent: item };
    }
  }
  return null;
}

// まとめの項目をクリックしたときに開く画面(最初の子)。
export function defaultKeyFor(item) {
  return item.children ? item.children[0].key : item.key;
}
