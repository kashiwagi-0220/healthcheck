import { useMemo } from "react";

// 一覧のページ送りに使う値の計算。機器カタログ・コマンドセット(クライアント側で
// 全件を持って切り出す)と、スナップショット一覧(サーバ側の limit/offset)の
// 両方で使うため、総件数 total は呼び出し側から受け取る。
// 表示部分は components/Pagination.jsx。

export const PAGE_SIZE = 100;

// ページ番号と総件数から、表示に必要な値を導く。
export function usePageRange(total, page, pageSize = PAGE_SIZE) {
  return useMemo(() => {
    const pageCount = Math.max(1, Math.ceil(total / pageSize));
    return {
      pageCount,
      rangeStart: total === 0 ? 0 : page * pageSize + 1,
      rangeEnd: Math.min(total, (page + 1) * pageSize),
    };
  }, [total, page, pageSize]);
}

// クライアント側で全件を持つ一覧用に、現在ページ分だけを切り出す。
export function usePageSlice(rows, page, pageSize = PAGE_SIZE) {
  return useMemo(
    () => rows.slice(page * pageSize, (page + 1) * pageSize),
    [rows, page, pageSize]
  );
}
