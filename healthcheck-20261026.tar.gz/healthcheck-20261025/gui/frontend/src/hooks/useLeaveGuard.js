import { useEffect } from "react";

// 実行中(正常性確認・スナップショット取得)にページを離れようとしたときの確認。
//
// 離れ方は2通りあり、それぞれ次のように確認する。
// - サイドバーで別の画面へ移る: 実行中の画面は破棄され、進捗と結果の表示が失われる
//   (実行自体はサーバで続く)。App が移動の前に confirmLeave() を呼び、取り消されたら
//   移動しない。文言はここで登録したものを出す。
// - タブを閉じる・再読み込みする: 進行中の段階だけがサーバで最後まで続き、正常性確認
//   なら後半(after・比較)は行われない。beforeunload でブラウザの確認を出す(文言は
//   ブラウザ固定で、ページからは変えられない)。
//
// 同時に実行中の画面は1つ(表示中の画面だけ)なので、登録先は1つで足りる。
let leaveMessage = null;

// 移動してよければ true。実行中でなければ確認せず true を返す。
export function confirmLeave() {
  return leaveMessage == null || window.confirm(leaveMessage);
}

// active の間だけ、離れようとしたときに message で確認する。
export function useLeaveGuard(active, message) {
  useEffect(() => {
    if (!active) return undefined;
    leaveMessage = message;
    const onBeforeUnload = (e) => {
      e.preventDefault();
      e.returnValue = "";
    };
    window.addEventListener("beforeunload", onBeforeUnload);
    return () => {
      leaveMessage = null;
      window.removeEventListener("beforeunload", onBeforeUnload);
    };
  }, [active, message]);
}
