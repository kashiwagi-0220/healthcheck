import { useCallback, useEffect, useState } from "react";
import { listDevices } from "../api/client";

// 数百台規模を想定: 機器一覧は1回だけ取得し、以降の絞り込み・並び替え・
// ページングは呼び出し側がクライアント側で行う(検索のたびにAPIへ往復しない)。
export function useDeviceSearch() {
  const [devices, setDevices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const refetch = useCallback(() => {
    setLoading(true);
    return listDevices()
      .then(setDevices)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    refetch();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return { devices, loading, error, refetch };
}
