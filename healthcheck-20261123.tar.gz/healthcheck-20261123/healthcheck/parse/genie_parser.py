"""
healthcheck.parse.genie_parser — Genie パースエンジン(Cisco系)

Genie(pyATS)で raw をパースする。依存が重く環境によっては未導入のため、
import は parse 実行時に行う(遅延 import)。未導入なら ImportError を説明的に投げる。
パース不可(対応 parser 無し・パース失敗)は None を返す。失敗の理由(Genie の例外)は
捨てずに WARNING でログに残す(必須項目の不足など、原因を後から確かめられるように)。

ただし「出力が空(該当なし)」は失敗ではなく空の dict {} を返す(2026-11-22。ユーザー
承認の上でコア変更)。Genie は出力が空・見出しだけ(EIGRP ネイバーが0件、PIM ネイバー表
が空など)のとき SchemaEmptyParserError を投げるが、これを None にすると比較で skipped
になり、before にあったネイバーが after で全て消えても見逃していた。{} なら通常の diff
で「どのネイバーが消えたか」が削除の差分として出る(TextFSM が空出力で [] を返すのとも
揃う)。機器がコマンドを受け付けなかった出力(`% Invalid input detected` など、`%` で
始まる行を含むもの)は「該当なし」ではないので、従来どおり None(パース不可)にする。

Device の vendor + type(カタログキー。command_catalog のディレクトリ名+ファイル名に
使う値で、利用者が自由に決める分類名)は Genie の os 名と語彙が違うため、ここで変換
する。この変換表はこのエンジンだけが使う独自の対応表で、他層(collect層の
netmiko_collector等)には依存しない(parse層がcollect層に依存しないよう、各パーサが
vendor/type から直接自分の語彙に変換する)。対応表は vendor → type → Genie os 名の
2階層辞書として持つ(結合済み文字列をキーにせず、vendor/type の2軸のまま階層化する)。
cisco/ios・xe・xr・nxos・asa のように vendor+type がそのまま Genie 側でも使う名前の
由来になっている機種は変換不要。
"""

from __future__ import annotations

import logging
import re
from typing import Any

from healthcheck.models import Device
from healthcheck.parse.base import ParserEngine

logger = logging.getLogger(__name__)

# 機器のエラー応答の行(IOS/IOS-XE/NX-OS の "% Invalid input detected ..."・"% Invalid command ..."、
# ASA の "ERROR: % Invalid input detected ...")。これを含む出力は「該当なし」とみなさない。
_CLI_ERROR_LINE = re.compile(r"^\s*(ERROR:\s*)?%", re.MULTILINE)

# vendor -> type -> Genie os 名(変換が要る組み合わせだけ書く)
_VENDOR_TYPE_TO_GENIE = {
    "cisco": {
        "ios": "ios",
        "iosxe": "iosxe",
        "xr": "iosxr",
        "nxos": "nxos",
        "asa": "asa",
    },
}


class GenieParser(ParserEngine):
    def parse(self, device: Device, command: str, raw: str) -> Any | None:
        os_name = _VENDOR_TYPE_TO_GENIE.get(device.vendor, {}).get(device.type)
        if not os_name:
            return None                         # Genie 対象外の機種
        try:
            from genie.conf.base import Device as GenieDevice  # 遅延 import
            from genie.libs.parser.utils import get_parser
            from genie.metaparser.util.exceptions import SchemaEmptyParserError
        except ImportError as e:
            raise ImportError(
                "Genie(pyATS)が未導入です。'pip install pyats[library]' が必要です。"
            ) from e

        try:
            gdev = GenieDevice(name=device.host, os=os_name)
            gdev.custom.setdefault("abstraction", {})["order"] = ["os"]
            return gdev.parse(command, output=raw)      # dict を返す
        except SchemaEmptyParserError as e:
            if not _CLI_ERROR_LINE.search(raw or ""):
                return {}                       # 出力が空(該当なし)。比較できる空の結果
            logger.warning("%s: パース失敗 - %s: %r", device.host, command, e)
            return None                         # 機器がコマンドを受け付けなかった
        except Exception as e:
            # 対応 parser 無し・パース失敗はスキップ扱い(None)
            logger.warning("%s: パース失敗 - %s: %r", device.host, command, e)
            return None
