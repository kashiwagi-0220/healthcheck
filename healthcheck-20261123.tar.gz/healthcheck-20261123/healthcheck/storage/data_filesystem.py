"""
healthcheck.storage.data_filesystem — DataStore のファイルシステム実装

ディスク構造(機器の識別は host):

  <root>/devices/<host>/
    ├── <command_slug>/<timestamp>/     # show 結果(毎回保存・過去保持)
    │   ├── raw.txt
    │   ├── parsed.json                 # パースできた場合のみ
    │   └── meta.json                   # コマンド原文 / 取得時刻
    └── snapshot/<snapshot_id>/
        └── manifest.json               # Snapshot(ポインタ集合。意味づけなし)

DataRef.raw / parsed は「保管ルートからの相対パス」を持つ。load 時に root と
結合して開くため、保管場所を移してもツール側の参照は壊れにくい。

timestamp はマイクロ秒精度(秒精度だと同一秒内の再取得で上書きされるため)。

削除(delete_snapshot)は snapshot/<snapshot_id>/ と、manifest が指す
<command_slug>/<timestamp>/ を消す。消す場所はすべて <root>/devices/<host>/ の配下に
限る(host・snapshot_id はパスの1要素であることを確かめ、manifest 内の参照も解決後の
場所がその機器のディレクトリ配下にあることを確かめる)。空になった <command_slug>/ も消す。
"""

from __future__ import annotations

import json
import re
import shutil
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path

from healthcheck.models import DataRef, Snapshot
from healthcheck.storage.base import DataStore


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _ts(dt: datetime) -> str:
    """時刻を並べ替え可能なコンパクト表記に(マイクロ秒精度。例 20260809T101530123456Z)。"""
    return dt.astimezone(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")


def _is_path_component(value: str) -> bool:
    """パスの1要素として安全か(区切り文字・"."・".."・空を含まない)。"""
    return bool(value) and value not in (".", "..") and "/" not in value and "\\" not in value and "\0" not in value


def _slug(command: str) -> str:
    """コマンド文字列をディレクトリ名に使える形へ。原文は meta.json が保持する。"""
    s = command.strip().lower()
    s = re.sub(r"[^\w]+", "_", s)      # 英数字以外を _ に
    return re.sub(r"_+", "_", s).strip("_")


class FilesystemStore(DataStore):
    def __init__(self, root: str | Path):
        self.root = Path(root)

    # ---- パス組み立て(内部) ----

    def _device_dir(self, host: str) -> Path:
        return self.root / "devices" / host

    # ---- show コマンド結果(毎回保存) ----

    def save_command(self, host, command, raw, parsed=None, taken_at=None) -> DataRef:
        taken_at = taken_at or _utcnow()
        ts = _ts(taken_at)
        cmd_dir = self._device_dir(host) / _slug(command) / ts
        cmd_dir.mkdir(parents=True, exist_ok=True)

        (cmd_dir / "raw.txt").write_text(raw, encoding="utf-8")
        if parsed is not None:
            (cmd_dir / "parsed.json").write_text(
                json.dumps(parsed, ensure_ascii=False, indent=2), encoding="utf-8"
            )
        (cmd_dir / "meta.json").write_text(
            json.dumps({"command": command, "taken_at": taken_at.isoformat()},
                       ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

        rel = cmd_dir.relative_to(self.root)
        return DataRef(
            backend="filesystem",
            raw=str(rel / "raw.txt"),
            parsed=str(rel / "parsed.json") if parsed is not None else None,
        )

    # ---- snapshot(ポインタ集合) ----

    def save_snapshot(self, snapshot: Snapshot) -> None:
        snap_dir = self._device_dir(snapshot.host) / "snapshot" / snapshot.id
        snap_dir.mkdir(parents=True, exist_ok=True)
        (snap_dir / "manifest.json").write_text(
            json.dumps(_snapshot_to_dict(snapshot), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def get_snapshot(self, host, snapshot_id) -> Snapshot | None:
        manifest = self._device_dir(host) / "snapshot" / snapshot_id / "manifest.json"
        if not manifest.exists():
            return None
        return _snapshot_from_dict(json.loads(manifest.read_text(encoding="utf-8")))

    def list_snapshots(self, host=None, since=None) -> list[Snapshot]:
        result: list[Snapshot] = []
        if host:
            hosts = [host]
        else:
            devices_root = self.root / "devices"
            hosts = [p.name for p in devices_root.iterdir()] if devices_root.exists() else []

        for h in hosts:
            snap_root = self._device_dir(h) / "snapshot"
            if not snap_root.exists():
                continue
            for snap_dir in sorted(snap_root.iterdir()):   # snapshot_id=timestamp なので時系列順
                manifest = snap_dir / "manifest.json"
                if not manifest.exists():
                    continue
                snap = _snapshot_from_dict(json.loads(manifest.read_text(encoding="utf-8")))
                if since and snap.taken_at and snap.taken_at < since:
                    continue
                result.append(snap)
        return result

    def delete_snapshot(self, host, snapshot_id) -> bool:
        for name, value in (("host", host), ("snapshot_id", snapshot_id)):
            if not _is_path_component(value):
                raise ValueError(f"{name} に使えない値です: {value!r}")
        device_dir = self._device_dir(host).resolve()
        snap_dir = self._device_dir(host) / "snapshot" / snapshot_id
        manifest = snap_dir / "manifest.json"
        if not manifest.exists():
            return False
        snap = _snapshot_from_dict(json.loads(manifest.read_text(encoding="utf-8")))

        # 他の snapshot(同じ機器)が指している実データの場所。これらは残す。
        in_use: set[Path] = set()
        for other in self.list_snapshots(host=host):
            if other.id == snapshot_id:
                continue
            for ref in other.refs.values():
                cmd_dir = self._command_dir_of(ref, device_dir)
                if cmd_dir is not None:
                    in_use.add(cmd_dir)

        # 先に manifest(snapshot 本体)を消す。途中で失敗しても、一覧から消えていれば
        # 残った実データは参照されないだけで、比較などを誤らせない。
        shutil.rmtree(snap_dir)
        for ref in snap.refs.values():
            cmd_dir = self._command_dir_of(ref, device_dir)
            if cmd_dir is None or cmd_dir in in_use or not cmd_dir.exists():
                continue
            shutil.rmtree(cmd_dir)
            slug_dir = cmd_dir.parent
            if slug_dir != device_dir and not any(slug_dir.iterdir()):
                slug_dir.rmdir()
        return True

    def _command_dir_of(self, ref: DataRef, device_dir: Path) -> Path | None:
        """参照が指す <command_slug>/<timestamp>/ の場所。その機器のディレクトリ配下で、
        snapshot/ 以外の2階層下にあるときだけ返す(manifest が壊れていても、想定外の
        場所を消さないため)。"""
        if ref.backend != "filesystem" or not ref.raw:
            return None
        cmd_dir = (self.root / ref.raw).resolve().parent
        try:
            rel = cmd_dir.relative_to(device_dir)
        except ValueError:
            return None
        if len(rel.parts) != 2 or rel.parts[0] == "snapshot":
            return None
        return cmd_dir

    # ---- 実体ロード ----

    def load_raw(self, ref: DataRef) -> str:
        if ref.backend != "filesystem" or not ref.raw:
            raise ValueError(f"unsupported or empty ref for filesystem: {ref}")
        return (self.root / ref.raw).read_text(encoding="utf-8")

    def load_parsed(self, ref: DataRef) -> dict | None:
        # パースできなかった command は parsed を持たない(比較時にスキップ扱い)
        if ref.backend != "filesystem" or not ref.parsed:
            return None
        return json.loads((self.root / ref.parsed).read_text(encoding="utf-8"))


# ---- Snapshot <-> dict(manifest.json のシリアライズ) ----

def _snapshot_to_dict(snap: Snapshot) -> dict:
    return {
        "id": snap.id,
        "host": snap.host,
        "taken_at": snap.taken_at.isoformat() if snap.taken_at else None,
        "success": snap.success,
        "error": snap.error,
        "refs": {cmd: asdict(ref) for cmd, ref in snap.refs.items()},
    }


def _snapshot_from_dict(d: dict) -> Snapshot:
    return Snapshot(
        id=d["id"],
        host=d["host"],
        taken_at=datetime.fromisoformat(d["taken_at"]) if d.get("taken_at") else None,
        refs={cmd: DataRef(**ref) for cmd, ref in d.get("refs", {}).items()},
        success=d.get("success", True),
        error=d.get("error"),
    )
