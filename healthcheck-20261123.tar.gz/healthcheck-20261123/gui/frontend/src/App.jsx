import { useEffect, useState } from "react";
import { Toaster } from "sonner";
import Sidebar from "@/components/Sidebar";
import { findPage, KEEP_ALIVE_PAGES } from "@/navigation";
import { ConfirmProvider } from "@/components/ConfirmDialog";
import { TooltipProvider } from "@/components/ui/tooltip";

// 画面の切り替え。表示中の画面は URL の # 以降に出す(例 #/commands/catalog)。再読み込み
// しても同じ画面に戻り、ブラウザの「戻る」「進む」でも画面を移れる。ルーターのライブラリは
// 入れず、hashchange を受けて表示を切り替えるだけにする(画面は NAV の1階層の key だけで
// 決まり、URL に機器名などの情報は載せない)。知らない key のときは正常性確認を出す。
//
// 実行の画面(正常性確認・スナップショット取得。KEEP_ALIVE_PAGES)は、一度開いたら他の画面へ
// 移っても破棄せず、見えなくするだけにする。実行中に移っても進捗と結果が残り、戻れば続きが
// 見える(以前は移ると表示が失われ、実行はサーバで続くのに結果を見る方法が無かった)。
// それ以外の画面は今までどおり、表示中のものだけを置く。
const DEFAULT_PAGE = "healthcheck";

function pageFromHash() {
  let key = "";
  try {
    key = decodeURIComponent(window.location.hash.replace(/^#\/?/, ""));
  } catch {
    // 壊れた %xx は既定の画面に倒す。
  }
  return findPage(key) ? key : DEFAULT_PAGE;
}

function Shell() {
  const [active, setActive] = useState(pageFromHash);
  const [opened, setOpened] = useState(() => new Set(KEEP_ALIVE_PAGES.includes(active) ? [active] : []));
  const { page, parent } = findPage(active);

  // URL(# 以降)が変わったら表示を合わせる。サイドバーのクリックも URL を変えるだけにして、
  // 表示の切り替えはここ1か所で行う(戻る・進む・手入力と同じ道を通す)。
  useEffect(() => {
    const onHashChange = () => {
      const key = pageFromHash();
      if (KEEP_ALIVE_PAGES.includes(key)) setOpened((prev) => (prev.has(key) ? prev : new Set(prev).add(key)));
      setActive(key);
    };
    window.addEventListener("hashchange", onHashChange);
    return () => window.removeEventListener("hashchange", onHashChange);
  }, []);

  const navigate = (key) => {
    if (key === active) return;
    window.location.hash = `/${key}`;
  };

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar active={active} onNavigate={navigate} />
      <div className="flex flex-1 flex-col overflow-hidden">
        <header className="flex h-14 shrink-0 items-center gap-1.5 border-b px-6 text-sm">
          {parent && <span className="text-muted-foreground">{parent.label}</span>}
          {parent && <span className="text-muted-foreground">/</span>}
          <h1 className="font-semibold">{page.label}</h1>
        </header>
        <main className="flex-1 overflow-y-auto p-6">
          {KEEP_ALIVE_PAGES.filter((key) => opened.has(key)).map((key) => {
            const { Component } = findPage(key).page;
            return (
              <div key={key} hidden={key !== active}>
                <Component />
              </div>
            );
          })}
          {!KEEP_ALIVE_PAGES.includes(active) && <page.Component key={active} />}
        </main>
      </div>
    </div>
  );
}

// 画面全体で共有するもの: 確認ダイアログ(useConfirm)、ツールチップの表示待ち時間、
// 完了・失敗を知らせる通知(sonner の toast。右下に数秒出す)。
function App() {
  return (
    <TooltipProvider>
      <ConfirmProvider>
        <Shell />
      </ConfirmProvider>
      <Toaster position="bottom-right" richColors closeButton duration={5000} />
    </TooltipProvider>
  );
}

export default App;
