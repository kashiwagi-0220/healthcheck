import { useCallback, useRef, useState } from "react";
import { AlertDialog } from "radix-ui";
import { Button } from "@/components/ui/button";
import { ConfirmContext } from "@/hooks/useConfirm";
import { useFocusReturn } from "@/lib/focusReturn";

// 画面内の確認ダイアログ(ブラウザ標準の window.confirm の置き換え)。Radix UI の
// AlertDialog を使う(Esc では「キャンセル」扱い、背景のクリックでは閉じない、開いたら
// 「キャンセル」にフォーカスが入る、という確認用の振る舞いを Radix が受け持つ)。
//
// 使い方: App の最上位に <ConfirmProvider> を置き、各画面で hooks/useConfirm.js の
// useConfirm() を使って Promise<boolean> として待つ。同時に開く確認は1つだけ(操作のたびに1つ)。

export function ConfirmProvider({ children }) {
  const [request, setRequest] = useState(null);   // { title, description, confirmLabel, destructive }
  const resolveRef = useRef(null);
  // 閉じたら、確認を出したボタン(削除ボタン等)へフォーカスを戻す(lib/focusReturn.js)。
  const onCloseAutoFocus = useFocusReturn(request !== null);

  const confirm = useCallback((options) => {
    // 前の確認が開いたままなら、それは取り消しとして閉じる(二重に待たせない)。
    resolveRef.current?.(false);
    return new Promise((resolve) => {
      resolveRef.current = resolve;
      setRequest(options);
    });
  }, []);

  const finish = (result) => {
    resolveRef.current?.(result);
    resolveRef.current = null;
    setRequest(null);
  };

  return (
    <ConfirmContext.Provider value={confirm}>
      {children}
      <AlertDialog.Root open={request !== null} onOpenChange={(open) => { if (!open) finish(false); }}>
        <AlertDialog.Portal>
          <AlertDialog.Overlay className="fixed inset-0 z-50 bg-black/50" />
          <AlertDialog.Content
            onCloseAutoFocus={onCloseAutoFocus}
            className="fixed left-1/2 top-[20vh] z-50 w-[calc(100%-2rem)] max-w-md -translate-x-1/2 rounded-lg border bg-card p-5 shadow-lg outline-none">
            <AlertDialog.Title className="text-base font-semibold">{request?.title}</AlertDialog.Title>
            <AlertDialog.Description className="mt-2 whitespace-pre-line text-sm text-muted-foreground">
              {request?.description}
            </AlertDialog.Description>
            <div className="mt-5 flex justify-end gap-2">
              <AlertDialog.Cancel asChild>
                <Button size="sm" variant="outline">キャンセル</Button>
              </AlertDialog.Cancel>
              <AlertDialog.Action asChild>
                <Button
                  size="sm"
                  variant={request?.destructive ? "destructive" : "default"}
                  onClick={() => finish(true)}
                >
                  {request?.confirmLabel ?? "OK"}
                </Button>
              </AlertDialog.Action>
            </div>
          </AlertDialog.Content>
        </AlertDialog.Portal>
      </AlertDialog.Root>
    </ConfirmContext.Provider>
  );
}
