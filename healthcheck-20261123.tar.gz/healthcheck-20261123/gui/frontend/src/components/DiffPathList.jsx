import { useEffect, useRef, useState } from "react";
import CopyButton from "@/components/CopyButton";
import { cn } from "@/lib/utils";
import { PATH_SEP } from "@/lib/keyPaths";

// 結果の詳細の「差分」「ノイズ」タブの中身(2026-11-22。以前は左右並べの木の表示)。
// 上から「パス一覧」「変更内容(BEFORE・AFTER)」「ノイズに追加する場合のパス」の順に縦に並べる
// (2026-11-22 ユーザー指示。パス一覧・変更内容の見出しは出さない)。まず「どのパスで差分・ノイズが出ているか」を一覧で把握し、次に選んだ行の
// 内容(BEFORE・AFTER の値)を確かめ、除外したければパスをコピーする、という順に見られる
// ようにするため。パスは確認ステップの「追加登録のノイズ」やコマンドカタログの noise に
// そのまま貼れる。
//
// diffs は CommandComparison の all_diffs / effective_diffs の要素
// ({path: [キー...], type: "changed"|"added"|"removed", before?, after?})。path は配列のまま
// 受け取る(キー自体に区切り文字を含む値がありうるため。healthcheck.common.diff 参照)。

// 種別ごとの印・色・名前。色は変更=黄・追加=緑・削除=赤(以前の木の表示と同じ)。色だけに
// 頼らず印でも分かるようにする。sides は変更内容で色を付ける側(追加は AFTER だけ、削除は
// BEFORE だけに値がある)。
const KIND = {
  changed: { mark: "~", label: "変更", className: "bg-yellow-100", sides: ["before", "after"] },
  added: { mark: "+", label: "追加", className: "bg-green-100", sides: ["after"] },
  removed: { mark: "−", label: "削除", className: "bg-red-100", sides: ["before"] },
};

function Mark({ type }) {
  return (
    <span className={cn("inline-block w-5 shrink-0 rounded-sm text-center font-mono text-foreground", KIND[type]?.className)}>
      {KIND[type]?.mark ?? "?"}
    </span>
  );
}

function Legend() {
  return (
    <div className="flex shrink-0 flex-wrap items-center gap-3 text-xs text-muted-foreground">
      {Object.entries(KIND).map(([type, { label }]) => (
        <span key={type} className="inline-flex items-center gap-1">
          <Mark type={type} />
          {label}
        </span>
      ))}
    </div>
  );
}

function formatValue(value) {
  if (value === undefined) return "(なし)";
  if (typeof value === "string") return value;
  return JSON.stringify(value, null, 2);
}

function SectionHeading({ children }) {
  return <p className="text-xs font-semibold text-muted-foreground">{children}</p>;
}

// 変更内容: BEFORE・AFTER の値。種別は枠の色で示す(変更は両方を黄、追加は AFTER だけを緑、
// 削除は BEFORE だけを赤。値の無い側は灰色のまま「(なし)」)。種別の名前の行は出さない
// (一覧の印と枠の色で分かるため。2026-11-22 ユーザー指示)。
function DiffChange({ diff }) {
  const colored = KIND[diff.type]?.sides ?? [];
  return (
    <div className="grid grid-cols-1 gap-2 md:grid-cols-2">
        {["before", "after"].map((side) => (
          <div key={side} className="min-w-0 space-y-1">
            <p className="text-xs font-semibold text-muted-foreground">{side.toUpperCase()}</p>
            <pre
              className={cn(
                "max-h-60 overflow-auto rounded-md border px-2 py-1 font-mono text-xs whitespace-pre-wrap break-all",
                colored.includes(side) ? KIND[diff.type].className : "bg-muted",
                diff[side] === undefined && "text-muted-foreground"
              )}
            >
              {formatValue(diff[side])}
            </pre>
          </div>
        ))}
    </div>
  );
}

// ノイズに追加する場合のパス(":" 区切り)とコピー。
function DiffNoisePath({ diff }) {
  const notation = diff.path.join(PATH_SEP);
  // キーに区切り文字(":")を含む階層は、そのままではノイズに書けない(IPv6 アドレスなど)。
  const unsafe = diff.path.filter((k) => String(k).includes(PATH_SEP));

  return (
    <div className="space-y-1">
      <SectionHeading>ノイズに追加する場合のパス</SectionHeading>
      <div className="flex items-start gap-2">
        <code className="min-w-0 flex-1 rounded-md border bg-muted px-2 py-1 font-mono text-xs break-all">{notation}</code>
        {/* コピーは他の画面と同じ部品(押すとボタンが「コピーしました」に変わる)。 */}
        <CopyButton getText={() => notation} />
      </div>
      {unsafe.length > 0 && (
        <p className="text-xs text-warning">
          「{PATH_SEP}」を含む階層({unsafe.join(", ")})は、ノイズに書くときは「*」にしてください。
        </p>
      )}
    </div>
  );
}

// 一覧はキーボードの上下でも選べる(一覧にフォーカスを置き、↑↓・Home・End)。
export default function DiffPathList({ title, diffs, empty }) {
  const [selected, setSelected] = useState(0);
  const listRef = useRef(null);
  const index = Math.min(selected, Math.max(diffs.length - 1, 0));
  const current = diffs[index];

  // 選んだ行が見えるようにする(キーボードで一覧の外へ進んだとき)。
  useEffect(() => {
    listRef.current?.querySelector(`[data-index="${index}"]`)?.scrollIntoView({ block: "nearest" });
  }, [index]);

  const onKeyDown = (e) => {
    const last = diffs.length - 1;
    const next = { ArrowDown: index + 1, ArrowUp: index - 1, Home: 0, End: last }[e.key];
    if (next === undefined) return;
    e.preventDefault();
    setSelected(Math.max(0, Math.min(last, next)));
  };

  return (
    <div className="flex min-h-0 flex-col gap-2 rounded-md border p-3">
      <p className="shrink-0 text-base font-bold">
        {title} <span className="text-sm font-normal text-muted-foreground">({diffs.length} 件)</span>
      </p>
      {diffs.length === 0 ? (
        <p className="text-sm text-muted-foreground">{empty}</p>
      ) : (
        <>
          <div className="flex min-h-0 flex-1 flex-col gap-3 overflow-auto">
            <Legend />
            <div
              ref={listRef}
              role="listbox"
              aria-label={`${title}のパス`}
              aria-activedescendant={`diff-${index}`}
              tabIndex={0}
              onKeyDown={onKeyDown}
              className="max-h-48 shrink-0 overflow-auto rounded-md border bg-card outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              {diffs.map((d, i) => (
                <div
                  key={i}
                  id={`diff-${i}`}
                  data-index={i}
                  role="option"
                  aria-selected={i === index}
                  onClick={() => setSelected(i)}
                  className={cn(
                    "flex cursor-pointer items-start gap-2 border-b px-2 py-1 font-mono text-xs last:border-b-0",
                    i === index ? "bg-primary/15" : "hover:bg-muted"
                  )}
                >
                  <Mark type={d.type} />
                  <span className="min-w-0 break-all">
                    {d.path.map((k, j) => (
                      <span key={j}>
                        {j > 0 && <span className="text-muted-foreground"> › </span>}
                        {String(k)}
                      </span>
                    ))}
                  </span>
                </div>
              ))}
            </div>
            {current && <DiffChange diff={current} />}
            {current && <DiffNoisePath diff={current} />}
          </div>
        </>
      )}
    </div>
  );
}
