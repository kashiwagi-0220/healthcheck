import { ArrowDown, ArrowUp, ArrowUpDown } from "lucide-react";
import { TableHead } from "@/components/ui/table";
import { cn } from "@/lib/utils";

// 並べ替えできる列の見出し(hooks/useSort.js と組で使う)。見出しの文字をボタンにし、
// 右に今の向きを矢印で出す(並べ替えていない列は薄い上下の矢印)。読み上げ向けに
// aria-sort も付ける。
export default function SortableHead({ sortKey, sort, onSort, className, children }) {
  const dir = sort?.key === sortKey ? sort.dir : null;
  const Icon = dir === "asc" ? ArrowUp : dir === "desc" ? ArrowDown : ArrowUpDown;
  const next = dir === "asc" ? "降順に並べ替え" : dir === "desc" ? "元の並びに戻す" : "昇順に並べ替え";
  return (
    <TableHead
      className={className}
      aria-sort={dir === "asc" ? "ascending" : dir === "desc" ? "descending" : "none"}
    >
      <button
        type="button"
        onClick={() => onSort(sortKey)}
        title={next}
        className="-mx-1 inline-flex items-center gap-1 rounded-sm px-1 outline-none hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring"
      >
        {children}
        <Icon className={cn("size-3.5 shrink-0", !dir && "opacity-40")} />
      </button>
    </TableHead>
  );
}
