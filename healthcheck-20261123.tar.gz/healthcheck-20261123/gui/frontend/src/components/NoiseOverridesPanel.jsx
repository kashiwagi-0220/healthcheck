import { useId } from "react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { pathProblem, splitLines } from "@/lib/keyPaths";
import { EMPTY_NOISE_OVERRIDES, keyOf, summarizeNoiseOverrides } from "@/lib/noiseOverrides";

// 正常性確認の確認ステップの「差分判定のノイズを調整する(この実行のみで有効)」(2026-11-22)。
// - 登録済みのノイズ: チェックを付けたものは、今回は差分判定に利用する(ノイズとして除外しない)
// - 追加登録のノイズ: カタログに無いパスを、今回だけノイズに加えて差分判定に利用しない
//   (1行1件、":" 区切り)
// その実行の比較にだけ効き、カタログには保存しない(サーバ側は gui/backend/app/noise_overrides.py。
// 送る値の名前は exclude(登録済みのうち判定に利用するもの)・add(追加登録のノイズ))。
//
// 色は他の画面に合わせる: コマンドセットの見出しの帯は表の見出し行と同じ bg-muted、判定に
// 利用するノイズは機器選択の「選択中」と同じ bg-primary/15、調整したコマンドの行は主色の枠と
// bg-accent(淡い主色)。
//
// 開閉の印はブラウザ既定の ▶ を消して矢印のアイコンに揃える(見出しを flex にすると既定の
// 印が出なくなり、開け閉めできると分かりにくかったため)。
const SUMMARY_CLASS = "flex cursor-pointer list-none items-center gap-2 select-none [&::-webkit-details-marker]:hidden";
// コマンドセットごとの折りたたみの矢印(開いたら下向き)。
const SetChevron = () => <ChevronRight className="size-4 shrink-0 transition-transform group-open/set:rotate-90" />;

// value は { "vendor/type/command": { exclude: [パス...], addText: "1行1件のテキスト" } }。
// 同じ機種のコマンドが複数のコマンドセットに出てくる場合は、同じ指定を共有する
// (サーバへはコマンド単位で送るため)。

function CommandRow({ vendor, type, command, spec, value, onChange }) {
  const id = useId();
  const key = keyOf(vendor, type, command);
  const ov = value[key] ?? { exclude: [], addText: "" };
  const noise = spec?.noise ?? [];
  const update = (patch) => onChange({ ...value, [key]: { ...ov, ...patch } });
  const toggle = (path, checked) =>
    update({ exclude: checked ? [...ov.exclude, path] : ov.exclude.filter((p) => p !== path) });
  const addProblems = splitLines(ov.addText).map(pathProblem).filter(Boolean);
  const changed = ov.exclude.length > 0 || splitLines(ov.addText).length > 0;

  return (
    <div
      className={cn(
        "grid grid-cols-1 gap-2 rounded-md border bg-card p-2 lg:grid-cols-[minmax(12rem,1fr)_2fr_2fr]",
        changed && "border-primary bg-accent"
      )}
    >
      <div className="min-w-0">
        <span className="font-mono text-xs font-semibold break-all">{command}</span>
      </div>
      <div className="min-w-0 space-y-1">
        <p className="text-xs font-semibold text-muted-foreground">登録済みのノイズ(チェックで差分判定に利用する)</p>
        {noise.length === 0 && <p className="text-xs text-muted-foreground">なし</p>}
        {noise.map((path) => {
          const used = ov.exclude.includes(path);
          return (
            <label
              key={path}
              className={cn("flex items-start gap-1.5 rounded-sm px-1 py-0.5 text-xs", used && "bg-primary/15")}
            >
              <Checkbox className="mt-0.5" checked={used} onChange={(e) => toggle(path, e.target.checked)} />
              <span className={cn("font-mono break-all", used ? "font-medium text-foreground" : "text-muted-foreground")}>
                {path}
              </span>
            </label>
          );
        })}
      </div>
      <div className="min-w-0 space-y-1">
        <label htmlFor={`${id}-add`} className="text-xs font-semibold text-muted-foreground">
          追加登録のノイズ(追加で差分判定に利用しない)
        </label>
        <Textarea
          id={`${id}-add`}
          className={cn(
            "h-14 font-mono text-xs",
            splitLines(ov.addText).length > 0 && "border-primary",
            addProblems.length > 0 && "border-destructive"
          )}
          value={ov.addText}
          onChange={(e) => update({ addText: e.target.value })}
          placeholder="例: interfaces:*:counters(1行1件。階層は「:」区切り)"
        />
        {addProblems.map((p) => (
          <p key={p} role="alert" className="text-xs text-destructive">{p}</p>
        ))}
      </div>
    </div>
  );
}

// groups は [{ name: コマンドセット名, vendor, type, commands: [コマンド名...] }]。
// catalog は GET /command-catalog の応答(vendor -> type -> {command: spec})。
// 確認ステップで「差分判定のノイズを調整する」にチェックを付けたときだけ表示する
// (pages/HealthCheckPage.jsx)。
export default function NoiseOverridesPanel({ groups, catalog, value, onChange }) {
  const { excluded, added } = summarizeNoiseOverrides(value);
  const active = excluded + added > 0;
  return (
    <div className={cn("space-y-3 rounded-md border bg-muted/50 p-3", active && "border-primary")}>
      <div className="flex justify-end">
        <Button size="sm" variant="outline" disabled={!active} onClick={() => onChange(EMPTY_NOISE_OVERRIDES)}>
          すべて元に戻す
        </Button>
      </div>
      {groups.length === 0 && <p className="text-sm text-muted-foreground">コマンドセットが割り当てられた機器がありません。</p>}
      {groups.map((g) => (
        <details key={g.name} className="group/set overflow-hidden rounded-md border bg-card">
          <summary className={cn(SUMMARY_CLASS, "bg-muted px-3 py-1.5 text-sm hover:bg-muted/70")}>
            <SetChevron />
            <span className="font-medium">{g.name}</span>
            <span className="ml-2 text-xs text-muted-foreground">{g.vendor}/{g.type}・{g.commands.length} コマンド</span>
          </summary>
          <div className="space-y-2 border-t p-2">
            {g.commands.map((command) => (
              <CommandRow
                key={command}
                vendor={g.vendor}
                type={g.type}
                command={command}
                spec={catalog?.[g.vendor]?.[g.type]?.[command]}
                value={value}
                onChange={onChange}
              />
            ))}
          </div>
        </details>
      ))}
    </div>
  );
}
