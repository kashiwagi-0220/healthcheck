import { Button } from "@/components/ui/button";
import { TableRow, TableCell } from "@/components/ui/table";
import { Spinner } from "@/components/Running";
import { RefreshCw } from "lucide-react";

// 読み込み中・エラー・0件の表示を全画面でそろえる部品(api/queries.js の結果と組で使う)。
// 以前は画面ごとに書き方が違い、読み込み中なのに「該当なし」「0件」が出る画面があった。

export function LoadingText({ className }) {
  return (
    <span className={`inline-flex items-center gap-1.5 text-sm text-muted-foreground ${className ?? ""}`}>
      <Spinner className="size-3.5" />読み込み中...
    </span>
  );
}

// 読み込みの失敗。再試行ボタンを付ける(一時的な失敗ならその場でやり直せる)。
export function LoadError({ error, onRetry, what }) {
  if (!error) return null;
  return (
    <div role="alert" className="flex items-center gap-2 text-sm text-destructive">
      <span>{what ? `${what}を読み込めませんでした` : "読み込めませんでした"}: {error.message ?? String(error)}</span>
      {onRetry && (
        <Button size="sm" variant="outline" onClick={() => onRetry()}>
          <RefreshCw /> 再試行
        </Button>
      )}
    </div>
  );
}

// 表の本文の末尾に置く1行。読み込み中(まだ1件も無い)・エラー・0件のどれかを出す。
// 行が表示されているときは何も出さない。
export function TableStatusRow({ colSpan, isPending, isError, isEmpty, emptyText }) {
  let content = null;
  if (isPending) content = <LoadingText />;
  else if (isError) content = <span className="text-sm text-muted-foreground">表示できる行がありません(上のエラーを確認してください)</span>;
  else if (isEmpty) content = <span className="text-sm text-muted-foreground">{emptyText}</span>;
  if (!content) return null;
  return (
    <TableRow className="hover:bg-transparent">
      <TableCell colSpan={colSpan} className="text-center">{content}</TableCell>
    </TableRow>
  );
}
