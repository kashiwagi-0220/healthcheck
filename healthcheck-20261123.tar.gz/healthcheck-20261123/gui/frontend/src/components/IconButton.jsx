import { Button } from "@/components/ui/button";
import { Tooltip } from "@/components/ui/tooltip";

// アイコンだけのボタン(表の行の「編集」「削除」など)。label を読み上げ用の名前
// (aria-label)と、マウスを乗せたときの説明(ツールチップ)の両方に使う。アイコンだけだと
// 何のボタンか分からない・読み上げで名前が無い、という問題への対処。
export default function IconButton({ label, children, variant = "outline", ...props }) {
  return (
    <Tooltip content={label}>
      <Button size="icon" variant={variant} aria-label={label} {...props}>
        {children}
      </Button>
    </Tooltip>
  );
}
