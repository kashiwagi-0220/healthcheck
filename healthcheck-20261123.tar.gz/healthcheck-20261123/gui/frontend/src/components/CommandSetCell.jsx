import { Badge } from "@/components/ui/badge";

// 確認ステップの表の「コマンドセット」の欄(正常性確認・スナップショット取得で共通)。
// 正しく解決できるものは文字だけ(機器一覧の表示と同じ)、未設定・機種の不一致は警告の
// バッジで示す。コマンドセットを読み込み終わるまでは判定を出さない(checking)。
// 判定は lib/commandSetCheck.js の checkCommandSet。
export default function CommandSetCell({ check, checking }) {
  if (checking || check.valid) {
    return <span className="text-muted-foreground">{check.name ?? "-"}</span>;
  }
  return <Badge variant="warning">{check.name ? `不整合(${check.name})` : "未設定"}</Badge>;
}
