import { useMemo, useState } from "react";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell, ClickableRow } from "@/components/ui/table";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { deviceVendorColor, deviceTypeColor } from "@/lib/deviceTypeColor";
import { cn } from "@/lib/utils";
import { Check, ChevronRight } from "lucide-react";
import { TextFilter, SelectFilter } from "@/components/TableFilters";
import HighlightMatch from "@/components/HighlightMatch";
import { EMPTY_TEXT_QUERY, compileTextQuery } from "@/lib/textQuery";

// 機器一覧の表は host/vendor/type/ip/コマンドセット/操作 の6列で全幅だが、
// ここではホスト名・ベンダー・タイプの3列しか持たないため、全幅にはせず「その6列
// テーブルの中でホスト名・ベンダー・タイプが占める幅」に近い幅に抑える。
// 機器選択を使う他の画面(スナップショット取得の確認ステップ等)でも同じ幅を使う。
// 広い画面(2xl = 1536px 以上)では一段広げ、右半分が大きく空かないようにする。
export const DEVICE_TABLE_WIDTH = "max-w-xl 2xl:max-w-3xl";

const EMPTY_FILTERS = { host: EMPTY_TEXT_QUERY, vendor: "", type: "" };

// 左: 機器一覧(「機器」セクションの機器一覧タブと同じ見た目 — ホスト名/ベンダー/タイプの
// 列と列フィルタ。クリックで選択・解除)。右: 選択中の機器一覧(クリックで解除)。
// スナップショット取得・正常性確認の機器選択で共有する。
//
// onSelectMany(hosts, selected): 列フィルタで絞り込んだ分をまとめて選択/解除する
// (ベンダーや機種単位でまとめて対象にしたい場合のため)。1件ずつの onToggle を
// 繰り返すのではなく一括で渡し、呼び出し側が1回の更新で反映できるようにする。
export default function DeviceSelector({ devices, loading, error, selectedHosts, onToggle, onSelectMany }) {
  const [filters, setFilters] = useState(EMPTY_FILTERS);
  const setFilter = (key) => (value) => setFilters((prev) => ({ ...prev, [key]: value }));

  const selectedSet = useMemo(() => new Set(selectedHosts), [selectedHosts]);
  const selectedDevices = useMemo(
    () => selectedHosts.map((h) => devices.find((d) => d.host === h)).filter(Boolean),
    [selectedHosts, devices]
  );

  const vendors = useMemo(() => Array.from(new Set(devices.map((d) => d.vendor))).sort(), [devices]);
  const types = useMemo(() => Array.from(new Set(devices.map((d) => d.type))).sort(), [devices]);
  const hostMatcher = useMemo(() => compileTextQuery(filters.host), [filters.host]);
  const filteredDevices = useMemo(() => {
    return devices
      .filter((d) => {
        if (!hostMatcher.test(d.host)) return false;
        if (filters.vendor && d.vendor !== filters.vendor) return false;
        if (filters.type && d.type !== filters.type) return false;
        return true;
      })
      // 機器一覧と同じくホスト名の昇順にする(画面ごとに並びが変わらないように)。
      .sort((a, b) => a.host.localeCompare(b.host, undefined, { numeric: true, sensitivity: "base" }));
  }, [devices, filters, hostMatcher]);

  // 左右の一覧は残りの幅を分け合う(flex-1)。以前は幅を固定していたため、1366 幅の画面では
  // 横に収まらず右の一覧が下へ回り込み、「次へ」が画面の外へ押し出されていた。
  return (
    <div className="space-y-2">
      {error && <p className="text-sm text-destructive">{error}</p>}
      <div className="flex flex-wrap items-start gap-4">
        <div className={cn("min-w-[20rem] flex-1 space-y-1.5", DEVICE_TABLE_WIDTH)}>
          <div className="flex h-8 items-center justify-between gap-2">
            <Label className="text-sm font-semibold">機器一覧(クリックで選択・解除)</Label>
            <div className="flex gap-1">
              <Button
                size="sm"
                variant="outline"
                disabled={filteredDevices.length === 0}
                onClick={() => onSelectMany(filteredDevices.map((d) => d.host), true)}
              >
                表示中を選択
              </Button>
              <Button
                size="sm"
                variant="outline"
                disabled={filteredDevices.length === 0}
                onClick={() => onSelectMany(filteredDevices.map((d) => d.host), false)}
              >
                表示中を解除
              </Button>
            </div>
          </div>
          <Table containerClassName="max-h-[calc(100vh-13rem)] overflow-y-auto rounded-md border bg-card">
              <TableHeader className="sticky top-0 z-10 bg-muted">
                <TableRow>
                  <TableHead>ホスト名</TableHead>
                  <TableHead>ベンダー</TableHead>
                  <TableHead>タイプ</TableHead>
                </TableRow>
                <TableRow className="hover:bg-transparent">
                  <TableHead className="py-1.5">
                    <TextFilter value={filters.host} onChange={setFilter("host")} placeholder="絞り込み" />
                  </TableHead>
                  <TableHead className="py-1.5">
                    <SelectFilter value={filters.vendor} onChange={setFilter("vendor")} options={vendors} />
                  </TableHead>
                  <TableHead className="py-1.5">
                    <SelectFilter value={filters.type} onChange={setFilter("type")} options={types} />
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredDevices.map((d) => {
                  const selected = selectedSet.has(d.host);
                  return (
                    <ClickableRow
                      key={d.host}
                      selected={selected}
                      // 選択中は主色の淡い色+チェックの印(色だけに頼らない)。赤系は「差分あり」「削除」と
                      // 紛らわしいため使わない。
                      className={selected ? "bg-primary/15 hover:bg-primary/20" : "hover:bg-muted"}
                      onActivate={() => onToggle(d.host)}
                    >
                      <TableCell className="font-medium">
                        <span className="inline-flex items-center gap-1">
                          <Check className={cn("size-3.5 shrink-0 text-primary", !selected && "invisible")} aria-hidden="true" />
                          <HighlightMatch text={d.host} matcher={hostMatcher} />
                        </span>
                      </TableCell>
                      <TableCell>
                        <Badge className={deviceVendorColor(d.vendor)}>{d.vendor}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge className={deviceTypeColor(d.type)}>{d.type}</Badge>
                      </TableCell>
                    </ClickableRow>
                  );
                })}
                {!loading && filteredDevices.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={3} className="text-center text-sm text-muted-foreground">
                      該当する機器がありません
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
          </Table>
        </div>

        <div className="flex self-stretch items-center pt-8">
          <ChevronRight className="size-6 text-muted-foreground" />
        </div>

        <div className={cn("min-w-[20rem] flex-1 space-y-1.5", DEVICE_TABLE_WIDTH)}>
          <div className="flex h-8 items-center">
            <Label className="text-sm font-semibold">選択中の機器({selectedHosts.length} 件)</Label>
          </div>
          <Table containerClassName="max-h-[calc(100vh-13rem)] overflow-y-auto rounded-md border bg-card">
              <TableHeader className="sticky top-0 z-10 bg-muted">
                <TableRow>
                  <TableHead>ホスト名</TableHead>
                  <TableHead>ベンダー</TableHead>
                  <TableHead>タイプ</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {selectedDevices.map((d) => (
                  <ClickableRow
                    key={d.host}
                    className="hover:bg-accent"
                    title="クリック(または Enter)で選択を解除"
                    onActivate={() => onToggle(d.host)}
                  >
                    <TableCell className="font-medium">{d.host}</TableCell>
                    <TableCell>
                      <Badge className={deviceVendorColor(d.vendor)}>{d.vendor}</Badge>
                    </TableCell>
                    <TableCell>
                      <Badge className={deviceTypeColor(d.type)}>{d.type}</Badge>
                    </TableCell>
                  </ClickableRow>
                ))}
                {selectedDevices.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={3} className="text-center text-sm text-gray-500">
                      左の一覧から機器を選択してください
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}
