import { cn } from "@/lib/utils";
import { NAV, defaultKeyFor } from "@/navigation";
import { useRunningPages } from "@/hooks/useRunGuard";
import { Spinner } from "@/components/Running";

// 実行中の画面があることを示す(他の画面にいても、実行が続いていることが分かるように)。
// 印を足すと幅を取って項目名が省略されたり、区切り線と重なったりするため、既にある
// アイコンを回転マークに差し替える(正常性確認は自分のアイコン、スナップショット取得は
// まとめの見出し「スナップショット」のアイコン)。項目名の幅・位置は変わらない。
// 子項目には、読み上げ用の文言とマウスを乗せたときの説明で「実行中」を伝える。
function ItemIcon({ icon: Icon, running }) {
  if (running) return <Spinner className="size-4 text-sidebar-cta" />;
  return <Icon className="size-4" />;
}

// まとめの項目(機器・スナップショット・コマンド)は、その子のどれかを開いている
// 間だけ見出しを明るくする。選択色そのものは子側だけに出し、「いまどの画面か」が
// 1行で分かるようにする。見出しを押したときは最初の子を開く。
function GroupButton({ item, active, onNavigate }) {
  const runningPages = useRunningPages();
  const isOpen = item.children.some((c) => c.key === active);
  const running = item.children.some((c) => runningPages.includes(c.key));
  return (
    <button
      onClick={() => onNavigate(defaultKeyFor(item))}
      className={cn(
        "flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium transition-colors hover:bg-white/10",
        isOpen ? "text-white" : "text-sidebar-foreground"
      )}
    >
      <ItemIcon icon={item.icon} running={running} />
      {item.label}
    </button>
  );
}

function ChildButton({ item, active, onNavigate }) {
  const running = useRunningPages().includes(item.key);
  return (
    <button
      onClick={() => onNavigate(item.key)}
      title={running ? `${item.label}(実行中)` : undefined}
      className={cn(
        "rounded-md px-3 py-1.5 text-left text-sm transition-colors hover:bg-white/10",
        active === item.key
          ? "bg-sidebar-active font-medium text-sidebar-active-foreground hover:bg-sidebar-active"
          : "text-sidebar-foreground/80"
      )}
    >
      {item.label}
      {running && <span className="sr-only">(実行中)</span>}
    </button>
  );
}

// 子を持たない項目(ログ・利用ガイド)。まとめの見出しと同じ高さに揃える。
function LeafButton({ item, active, onNavigate }) {
  const Icon = item.icon;
  return (
    <button
      onClick={() => onNavigate(item.key)}
      className={cn(
        "flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium transition-colors hover:bg-white/10",
        active === item.key && "bg-sidebar-active text-sidebar-active-foreground hover:bg-sidebar-active"
      )}
    >
      <Icon className="size-4" />
      {item.label}
    </button>
  );
}

export default function Sidebar({ active, onNavigate }) {
  const primary = NAV.find((i) => i.placement === "primary");
  const middle = NAV.filter((i) => !i.placement);
  const footer = NAV.filter((i) => i.placement === "footer");
  const PrimaryIcon = primary.icon;
  const primaryRunning = useRunningPages().includes(primary.key);

  return (
    <aside className="flex h-screen w-56 shrink-0 flex-col bg-sidebar text-sidebar-foreground">
      <div className="flex h-14 items-center gap-2 border-b border-white/10 px-4">
        {/* ブラウザのタブのアイコン(index.html の favicon)と同じファイルを使い、
            見た目を揃える。public/ 配下はビルド後も同じパスで配信される。 */}
        <img src="/favicon.svg" alt="" className="size-6" />
        <span className="font-semibold text-white">healthcheck</span>
      </div>

      <div className="p-2">
        <button
          onClick={() => onNavigate(primary.key)}
          title={primaryRunning ? `${primary.label}(実行中)` : undefined}
          // 他の項目(ログ・利用ガイド)と同じ見た目にする。位置だけ最上部に置く。
          className={cn(
            "flex w-full items-center gap-2 rounded-md px-3 py-2 text-sm font-medium transition-colors hover:bg-white/10",
            active === primary.key && "bg-sidebar-active text-sidebar-active-foreground hover:bg-sidebar-active"
          )}
        >
          {primaryRunning ? <Spinner className="size-4 text-sidebar-cta" /> : <PrimaryIcon className="size-4" />}
          {primary.label}
          {primaryRunning && <span className="sr-only">(実行中)</span>}
        </button>
      </div>

      <nav className="flex flex-1 flex-col gap-1 overflow-y-auto p-2 pt-0">
        {middle.map((item) =>
          item.children ? (
            <div key={item.key} className="flex flex-col">
              <GroupButton item={item} active={active} onNavigate={onNavigate} />
              <div className="ml-5 flex flex-col gap-0.5 border-l border-white/15 pl-2">
                {item.children.map((child) => (
                  <ChildButton key={child.key} item={child} active={active} onNavigate={onNavigate} />
                ))}
              </div>
            </div>
          ) : (
            <LeafButton key={item.key} item={item} active={active} onNavigate={onNavigate} />
          )
        )}
        <div className="flex-1" />
        {footer.map((item) => (
          <LeafButton key={item.key} item={item} active={active} onNavigate={onNavigate} />
        ))}
      </nav>
    </aside>
  );
}
