import { useRef, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Spinner } from "@/components/Running";
import { saveBlob } from "@/lib/download";
import { Download, Upload } from "lucide-react";

// 設定ファイルのダウンロード/アップロードのボタン組。機器一覧(CSV)・コマンド
// カタログ/コマンドセット(ZIP・YAML)・プロキシ設定で同じ形にするため共有する。
// アップロードの結果は通知(toast)で知らせ、成功したら onUploaded で呼び出し側に
// 再読み込みさせる。
//
// confirmUpload を渡すと、ファイルを選んだ後・送る前に呼ぶ(file を受け取り Promise<boolean>)。
// ファイル全体を置き換える取り込み(機器 CSV・プロキシ設定)で、確認なしに置き換わるのを防ぐ。
//
// onDownload は {blob, filename} を返す関数(api/client.js の download*)。画面の中で受け取って
// 保存するので、失敗しても(ファイルが無い等)アプリから離れず、通知で理由を出す
// (以前は <a href> で開いていて、失敗すると生の JSON エラーの画面へ移っていた)。
// accept はファイル選択ダイアログで出す拡張子。
export default function FileTransferButtons({
  onDownload,
  downloadLabel,
  uploadLabel,
  accept,
  onUpload,
  onUploaded,
  confirmUpload,
}) {
  const inputRef = useRef(null);
  const [uploading, setUploading] = useState(false);
  const [downloading, setDownloading] = useState(false);

  const handleDownload = async () => {
    setDownloading(true);
    try {
      const { blob, filename } = await onDownload();
      saveBlob(filename, blob);
    } catch (err) {
      toast.error(`ダウンロードできませんでした: ${err.message}`);
    } finally {
      setDownloading(false);
    }
  };

  const handleChange = async (e) => {
    const file = e.target.files?.[0];
    if (inputRef.current) inputRef.current.value = "";   // 同じファイルを続けて選べるように
    if (!file) return;
    if (confirmUpload && !(await confirmUpload(file))) return;
    setUploading(true);
    try {
      const res = await onUpload(file);
      const saved = Array.isArray(res?.saved) ? res.saved.join(", ") : (res?.saved ?? file.name);
      toast.success(`取り込みました: ${saved}`);
      await onUploaded?.(res, file);
    } catch (err) {
      toast.error(`取り込めませんでした: ${err.message}`);
    } finally {
      setUploading(false);
    }
  };

  return (
    <>
      <Button size="sm" variant="outline" onClick={handleDownload} disabled={downloading}>
        {downloading ? <Spinner /> : <Download />} {downloadLabel}
      </Button>
      <Button size="sm" variant="outline" onClick={() => inputRef.current?.click()} disabled={uploading}>
        <Upload /> {uploading ? "アップロード中..." : uploadLabel}
      </Button>
      <input ref={inputRef} type="file" accept={accept} onChange={handleChange} className="hidden" />
    </>
  );
}
