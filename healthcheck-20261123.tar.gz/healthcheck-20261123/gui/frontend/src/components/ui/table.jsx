import { useEffect, useRef } from "react";
import { cn } from "@/lib/utils";

// containerClassName: 縦スクロール(sticky ヘッダー)を使うページは、ここに
// max-h-*/overflow-y-auto を渡す。横スクロール用の overflow-x-auto と別々の div に
// 分けると、position: sticky の基準になる「直近のスクロール祖先」が内側の div
// (横方向にしかスクロールしないが、CSSの仕様上そちらも overflow:auto 相当になり
// スクロールコンテナとして認識される)になってしまい、外側の div をスクロールしても
// ヘッダーが一緒に流れてしまう。縦横どちらのスクロールも
// 同じ1つの div に持たせることでこれを避ける。
//
// 縦スクロールバーは見出し(thead。列名と絞り込みの行)の横には出さず、本文の横だけに
// 収める(table-scroll。index.css)。見出しの高さは中身で変わる(絞り込み行の有無など)ため、
// 実際の高さを測って CSS 変数 --thead-h に入れ、スクロールバーの溝の上端をその分下げる。
function Table({ className, containerClassName, ...props }) {
  const ref = useRef(null);
  useEffect(() => {
    const container = ref.current;
    const thead = container?.querySelector("thead");
    if (!container || !thead) return undefined;
    const update = () => container.style.setProperty("--thead-h", `${thead.offsetHeight}px`);
    update();
    const observer = new ResizeObserver(update);
    observer.observe(thead);
    return () => observer.disconnect();
  }, []);
  return (
    <div ref={ref} className={cn("table-scroll relative w-full overflow-x-auto", containerClassName)}>
      {/* border-separate: collapse だと隣接行のボーダーが競合解決の対象になり、
          組み合わせによっては描画されない/太さが揃わないことがあるため、
          行ごとに独立してボーダーを描く separate モードに固定する。 */}
      <table
        className={cn("w-full border-separate border-spacing-0 caption-bottom text-sm", className)}
        {...props}
      />
    </div>
  );
}

function TableHeader({ className, ...props }) {
  return <thead className={className} {...props} />;
}

// border-separate モードでは行(tr)自体のボーダーはブラウザが描画しない(セル=th/td
// にのみボーダーを持たせる必要がある)ため、最終行のボーダーもセル側(td)を対象に消す。
function TableBody({ className, ...props }) {
  return <tbody className={cn("[&_tr:last-child_td]:border-b-0", className)} {...props} />;
}

function TableRow({ className, ...props }) {
  return (
    <tr
      className={cn("transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted", className)}
      {...props}
    />
  );
}

// 行全体をクリックで操作する行(機器の選択・詳細を開く等)。マウスだけでなくキーボードでも
// 操作できるようにする: Tab で行に移り、Enter・Space でクリックと同じ動きをする。キーボードで
// 移ったときは枠線で位置を示す。selected を渡すと「選択できる行」として、選択中かどうかを
// 読み上げに伝える(aria-selected)。
// 行の中のボタン(編集・削除など)は自分でキー操作を受けるので、行のキー操作はその行自身に
// フォーカスがあるときだけ動かす(ボタンの Enter で行の動きが二重に起きないように)。
function ClickableRow({ onActivate, selected, className, ...props }) {
  const handleKeyDown = (e) => {
    if (e.target !== e.currentTarget) return;
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      onActivate();
    }
  };
  return (
    <TableRow
      tabIndex={0}
      aria-selected={selected}
      onClick={onActivate}
      onKeyDown={handleKeyDown}
      className={cn(
        "cursor-pointer outline-none focus-visible:outline-2 focus-visible:outline-solid focus-visible:-outline-offset-2 focus-visible:outline-ring",
        className
      )}
      {...props}
    />
  );
}

function TableHead({ className, ...props }) {
  return (
    <th
      className={cn(
        "h-9 border-b border-muted-foreground px-3 text-left align-middle font-semibold text-foreground whitespace-nowrap",
        className
      )}
      {...props}
    />
  );
}

function TableCell({ className, ...props }) {
  return (
    // 縦の余白は控えめにする(画面の高さが 768 程度でも一度に見える行を増やすため)。
    <td className={cn("border-b border-muted-foreground px-3 py-2 align-middle", className)} {...props} />
  );
}

export { Table, TableHeader, TableBody, TableRow, TableHead, TableCell, ClickableRow };
