import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";

// shadcn/ui の Select は Radix 製だが、依存を増やさないためネイティブ <select> を
// 同等の見た目にラップしたもの(挙動は素朴だが単体ツールのGUIとしては十分)。
// className(高さ・幅・文字サイズ等)は外側の relative div(矢印の配置基準)に適用し、
// 内側の select は常に h-full w-full で追従させる。className を select 側だけに
// 適用すると、w-* で幅を上書きしたときに矢印(right-2 top-1/2 で div 基準に置く)と
// select 本体の右端がずれるため。
//
// compact: 表の絞り込み欄のような小さな欄向けに、左右の余白と矢印を詰める(細い列でも
// 「すべて」が切れないように)。
function Select({ className, children, compact = false, ...props }) {
  return (
    <div className={cn("relative h-9 w-full text-sm", className)}>
      <select
        className={cn(
          "flex h-full w-full appearance-none items-center rounded-md border border-input bg-card py-1 shadow-xs outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:bg-muted disabled:text-muted-foreground",
          compact ? "pr-5 pl-2" : "px-3 pr-8"
        )}
        {...props}
      >
        {children}
      </select>
      <ChevronDown
        className={cn(
          "pointer-events-none absolute top-1/2 -translate-y-1/2 opacity-50",
          compact ? "right-1 size-3.5" : "right-2 size-4"
        )}
      />
    </div>
  );
}

export { Select };
