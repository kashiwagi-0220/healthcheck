import { Tooltip as TooltipPrimitive } from "radix-ui";
import { cn } from "@/lib/utils";

// マウスを乗せた・キーボードで移ったときに出る短い説明。Radix UI の Tooltip を使う。
// App の最上位に TooltipProvider を1つ置く(表示までの待ち時間を画面全体でそろえるため)。
export function TooltipProvider({ children }) {
  return <TooltipPrimitive.Provider delayDuration={300}>{children}</TooltipPrimitive.Provider>;
}

export function Tooltip({ content, children, side = "top" }) {
  return (
    <TooltipPrimitive.Root>
      <TooltipPrimitive.Trigger asChild>{children}</TooltipPrimitive.Trigger>
      <TooltipPrimitive.Portal>
        <TooltipPrimitive.Content
          side={side}
          sideOffset={4}
          className={cn("z-[60] rounded-md bg-foreground px-2 py-1 text-xs text-background shadow")}
        >
          {content}
        </TooltipPrimitive.Content>
      </TooltipPrimitive.Portal>
    </TooltipPrimitive.Root>
  );
}
