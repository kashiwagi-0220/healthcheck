import { cn } from "@/lib/utils";

const VARIANTS = {
  default: "bg-primary text-primary-foreground hover:bg-primary/90",
  outline: "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
  ghost: "hover:bg-accent hover:text-accent-foreground",
  destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
  // 削除など取り消せない操作の、表の行に置く控えめなボタン(枠と文字だけ赤系)。
  "destructive-outline": "border border-destructive/40 bg-background text-destructive hover:bg-destructive/10",
  // 実行ではあるが、主の実行(保存する)とは意味合いの違う操作(スナップショット取得の「取得して
  // 表示」= 保存しない)。正常性確認の OK などで使う淡い緑(lib/statusVariant.js の
  // STATUS_SOFT_CLASS.ok)と同じ色にする。
  "success-soft": "border border-green-200 bg-green-100 text-green-900 hover:bg-green-200",
};

const SIZES = {
  default: "h-9 px-4 py-2",
  sm: "h-8 px-3 text-xs",
  icon: "size-8",
};

// type の既定は "button"(フォームの中に置いても、意図せず送信しないように)。
// 送信ボタンにだけ type="submit" を指定する。
function Button({ className, variant = "default", size = "default", type = "button", ...props }) {
  return (
    <button
      type={type}
      className={cn(
        "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors disabled:pointer-events-none disabled:opacity-50 [&_svg]:size-4 outline-none focus-visible:ring-2 focus-visible:ring-ring",
        VARIANTS[variant],
        SIZES[size],
        className
      )}
      {...props}
    />
  );
}

export { Button };
