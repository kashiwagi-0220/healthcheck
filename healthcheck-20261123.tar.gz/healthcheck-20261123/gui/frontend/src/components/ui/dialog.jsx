import { Dialog as DialogPrimitive } from "radix-ui";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";
import { useFocusReturn } from "@/lib/focusReturn";

// ポップアップ。Radix UI の Dialog の上に、見た目(Tailwind)と閉じ方の指定だけを足す。
// フォーカスの閉じ込め(Tab がポップアップの中で回る)・閉じたら開いたボタンへ戻る・
// 読み上げ用の属性(role="dialog" / aria-modal / 題名との関連付け)・背面のスクロール停止は
// Radix が受け持つ。
//
// 閉じ方:
//   - 既定は × ・Esc・背景のクリックで閉じる(結果や詳細を見るだけのポップアップ向け)。
//   - dismissible={false}: Esc・背景のクリックでは閉じない(編集フォーム向け。うっかり
//     押して入力が消えるのを防ぐ。× とキャンセルでは閉じる)。
//   - busy: 保存中など。× を含め、どの方法でも閉じない。
//
// 枠全体の高さは「画面の高さ − 外側の余白(上 1vh・下 1rem)」までに抑え、題名の帯は
// 固定、中身(contentClassName)はその枠の中で縮んでスクロールする。中身だけに高さの
// 上限を付ける作りだと、題名の帯と余白の分だけ枠が画面からはみ出し、ポップアップ
// 全体がわずかにスクロールしてしまうため(画面が縦に長いほど起きやすい)。
// 保存・キャンセルのボタンは DialogFooter に入れると、中身をスクロールしても下端に
// 残る(画面が低いと「作成」が隠れていた問題への対処)。
// 枠には overflow-hidden を付け、角の丸みの外へ中身がはみ出さないようにする(DialogFooter の
// 背景や中身のスクロールバーが四角いまま角に重なり、下側の角が丸く見えなかったため)。
function Dialog({
  open, onClose, title, children, className, contentClassName, dismissible = true, busy = false,
}) {
  const blockClose = (e) => {
    if (busy || !dismissible) e.preventDefault();
  };
  // 閉じたら、開く前にフォーカスがあった要素(表の行・編集ボタン等)へ戻す(lib/focusReturn.js)。
  const onCloseAutoFocus = useFocusReturn(open);
  return (
    <DialogPrimitive.Root open={open} onOpenChange={(next) => { if (!next && !busy) onClose(); }}>
      <DialogPrimitive.Portal>
        <DialogPrimitive.Overlay className="fixed inset-0 z-50 bg-black/50" />
        <DialogPrimitive.Content
          aria-describedby={undefined}
          onCloseAutoFocus={onCloseAutoFocus}
          onEscapeKeyDown={blockClose}
          onPointerDownOutside={blockClose}
          onInteractOutside={blockClose}
          className={cn(
            "fixed left-1/2 top-[1vh] z-50 flex max-h-[calc(99vh-1.5rem)] w-[calc(100%-2rem)] max-w-2xl -translate-x-1/2 flex-col overflow-hidden rounded-lg border bg-card shadow-lg outline-none",
            className
          )}
        >
          <div className="flex shrink-0 items-center justify-between gap-3 border-b px-4 py-3">
            <DialogPrimitive.Title className="text-sm font-semibold">{title}</DialogPrimitive.Title>
            <DialogPrimitive.Close
              aria-label="閉じる"
              title="閉じる"
              disabled={busy}
              className="rounded-sm p-1 text-muted-foreground outline-none hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-50"
            >
              <X className="size-4" />
            </DialogPrimitive.Close>
          </div>
          <div className={cn("min-h-0 flex-1 overflow-y-auto p-4", contentClassName)}>{children}</div>
        </DialogPrimitive.Content>
      </DialogPrimitive.Portal>
    </DialogPrimitive.Root>
  );
}

// フォームの下端に固定するボタンの帯。ボタンは右寄せで「キャンセル → 主ボタン」の順に置く
// (主ボタンが右。ウィザードの「戻る → 次へ」と同じ並び)。中身のスクロールの中で下端に
// 貼り付くよう sticky にし、Dialog の中身の余白(p-4)を打ち消して帯を端まで伸ばす。
// 貼り付く位置は中身の下の余白(1rem)ぶん下げる(-bottom-4)。bottom-0 だと、中身が収まって
// いるときでも帯が余白ぶん上へずれ、区切り線が入力欄の下端に重なって見えていた。
// 上の入力欄との間は mt-6 空ける。
function DialogFooter({ children, className }) {
  return (
    <div
      className={cn(
        "sticky -bottom-4 -mx-4 -mb-4 mt-6 flex items-center justify-end gap-2 border-t bg-card px-4 py-3",
        className
      )}
    >
      {children}
    </div>
  );
}

// 結果表示(正常性確認の結果・スナップショットの詳細)のポップアップは raw や
// 差分で横にも長くなるため、幅を画面いっぱいに近いところまで広げる。
export const RESULT_DIALOG_WIDTH = "max-w-9xl";

// 中身が多いときに、ポップアップ全体ではなく中の一部(表・raw・差分など)だけを
// スクロールさせるための中身の指定。中身を縦並び(flex)にする。中の部品は、大きさを
// 保ちたい部分(ボタン・見出し・タブ)に shrink-0 を、スクロールさせたい部分に min-h-0 と
// overflow-auto を付ける(min-h-0 は縮むことを許すために、そこまでの途中の階層すべてに必要)。
export const DIALOG_CONTENT_FLEX = "flex flex-col";

// 枠を画面の高さいっぱいに固定する。絞り込みで中身の量が変わっても枠の大きさが
// 変わらないようにしたいポップアップで使い、中身には DIALOG_CONTENT_FLEX と flex-1 を
// 合わせて指定する。値は上の枠の上限(max-h)と同じにする。
export const DIALOG_FULL_HEIGHT = "h-[calc(99vh-1.5rem)]";

export { Dialog, DialogFooter };
