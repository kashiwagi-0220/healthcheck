import { DropdownMenu as DropdownMenuPrimitive } from "radix-ui";
import { cn } from "@/lib/utils";

// ボタンを押すと項目の一覧が開くメニュー。Radix UI の DropdownMenu を使う(キーボードの
// 上下キーでの移動・Esc で閉じる・閉じたらボタンへ戻る、は Radix が受け持つ)。
// trigger はボタン要素(asChild で包む)、items は [{ key, label, icon, onSelect, disabled }]。
//
// 表の行(ClickableRow)の中に置くことがあるため、メニューの中のクリックは行へ伝えない
// (Portal で外に描いても React のイベントは行まで伝わるので、ここで止める)。
export function DropdownMenu({ trigger, items, align = "end" }) {
  return (
    <DropdownMenuPrimitive.Root>
      <DropdownMenuPrimitive.Trigger asChild>{trigger}</DropdownMenuPrimitive.Trigger>
      <DropdownMenuPrimitive.Portal>
        <DropdownMenuPrimitive.Content
          align={align}
          sideOffset={4}
          onClick={(e) => e.stopPropagation()}
          className="z-50 min-w-[10rem] rounded-md border bg-card p-1 shadow-md"
        >
          {items.map(({ key, label, icon: Icon, onSelect, disabled }) => (
            <DropdownMenuPrimitive.Item
              key={key}
              disabled={disabled}
              onSelect={onSelect}
              className={cn(
                "flex cursor-pointer items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none select-none",
                "data-[highlighted]:bg-accent data-[highlighted]:text-accent-foreground",
                "data-[disabled]:pointer-events-none data-[disabled]:opacity-50"
              )}
            >
              {Icon && <Icon className="size-4" />}
              {label}
            </DropdownMenuPrimitive.Item>
          ))}
        </DropdownMenuPrimitive.Content>
      </DropdownMenuPrimitive.Portal>
    </DropdownMenuPrimitive.Root>
  );
}
