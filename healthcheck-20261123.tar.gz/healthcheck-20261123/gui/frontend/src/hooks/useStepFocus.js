import { useEffect, useRef } from "react";

// 段階(step)で画面が切り替わる画面(正常性確認・スナップショット取得)で、段階が変わったら
// その段階の見出しへフォーカスを移す。押したボタンが切り替えで消えるとフォーカスがページの
// 先頭へ戻ってしまい、キーボードで操作している人が、どこにいるか分からなくなるため。
// 返す ref を画面全体を囲む要素に付け、各段階の見出しに data-step-heading と
// tabIndex={-1} を付ける。最初の表示ではフォーカスを動かさない。画面が隠れている間
// (他の画面を開いている間に実行が終わった等)は動かさない。
export function useStepFocus(step) {
  const ref = useRef(null);
  const first = useRef(true);
  useEffect(() => {
    if (first.current) {
      first.current = false;
      return;
    }
    const root = ref.current;
    if (!root || root.closest("[hidden]")) return;
    root.querySelector("[data-step-heading]")?.focus();
  }, [step]);
  return ref;
}
