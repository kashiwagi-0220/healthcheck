import { useEffect, useSyncExternalStore } from "react";

// 実行中(正常性確認・スナップショット取得)の画面のための仕組み。
//
// 実行の画面は、サイドバーで他の画面へ移っても破棄せずに裏で保持する(App.jsx)。移っても
// 進捗と結果は残り、戻れば続きが見えるので、画面を移るときの確認は出さない。代わりに、
// どの画面が実行中かをサイドバーに出す(useRunningPages)。
// タブを閉じる・再読み込みするときだけは表示が失われる(進行中の段階だけがサーバで最後まで
// 続き、正常性確認なら後半(after・比較)は行われない)ので、beforeunload でブラウザの
// 確認を出す(文言はブラウザ固定で、ページからは変えられない)。

const running = new Set();
const listeners = new Set();
let snapshot = [];
function notify() {
  snapshot = [...running];
  for (const fn of listeners) fn();
}

// pageKey(navigation.js のキー)の画面が active の間、実行中として登録し、ブラウザを
// 閉じる・再読み込みするときに確認を出す。
export function useRunGuard(pageKey, active) {
  useEffect(() => {
    if (!active) return undefined;
    running.add(pageKey);
    notify();
    const onBeforeUnload = (e) => {
      e.preventDefault();
      e.returnValue = "";
    };
    window.addEventListener("beforeunload", onBeforeUnload);
    return () => {
      running.delete(pageKey);
      notify();
      window.removeEventListener("beforeunload", onBeforeUnload);
    };
  }, [pageKey, active]);
}

// 実行中の画面のキーの一覧(サイドバーの表示用)。
export function useRunningPages() {
  return useSyncExternalStore(
    (fn) => {
      listeners.add(fn);
      return () => listeners.delete(fn);
    },
    () => snapshot
  );
}
