import { createContext, useContext } from "react";

// 画面内の確認ダイアログ(components/ConfirmDialog.jsx の ConfirmProvider)を呼ぶフック。
//   const confirm = useConfirm();
//   if (!(await confirm({ title, description, confirmLabel, destructive: true }))) return;
// 部品(ConfirmProvider)とフックを別ファイルにするのは、開発時の再読み込み(Fast Refresh)が
// 部品だけを書き出すファイルでしか効かないため。
export const ConfirmContext = createContext(null);

export function useConfirm() {
  const confirm = useContext(ConfirmContext);
  if (!confirm) throw new Error("useConfirm は ConfirmProvider の内側で使ってください。");
  return confirm;
}
