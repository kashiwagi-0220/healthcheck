import { useMemo, useState } from "react";

// 表の列の並べ替え(画面の中だけ。サーバへは問い合わせない)。見出しを押すたびに
// 昇順 → 降順 → 元の並び と切り替わる。
//
// rows は絞り込み後の行、getters は { 列のキー: (行) => 比べる値 }。getters はページの
// 外(モジュールの定数)に置き、毎回作り直さないこと(作り直すと毎回並べ直しになる)。
// 並べ替えは絞り込みの後・ページ分けの前に掛ける(件数表示とページ番号の補正
// (usePagination)がそのまま使える)。
//
// 値の比べ方: 数値は大小、それ以外は文字列として日本語の辞書順で比べ、"RT-2" と "RT-10" の
// ような数字を含む名前は数字の大きさで並べる(numeric)。空(null・undefined・"")は
// 昇順・降順どちらでも最後に置く。値が同じ行は元の並びを保つ(Array.prototype.sort は安定)。
const collator = new Intl.Collator("ja", { numeric: true, sensitivity: "base" });

function isBlank(v) {
  return v === null || v === undefined || v === "";
}

function compareValues(a, b) {
  if (typeof a === "number" && typeof b === "number") return a - b;
  return collator.compare(String(a), String(b));
}

// 並べ替えの状態だけを持つ(見出しを押すたびに 昇順 → 降順 → 元の並び)。並べ替えそのものを
// サーバに任せる表(スナップショット一覧。ページ分けをサーバで行うため)はこれだけを使い、
// sort をサーバへの問い合わせに渡す。onChange は状態が変わったときに呼ぶ(例: 先頭ページへ戻す)。
export function useSortState(onChange) {
  const [sort, setSort] = useState(null); // { key, dir: "asc" | "desc" } または null(元の並び)
  const toggle = (key) => {
    setSort((prev) => {
      if (!prev || prev.key !== key) return { key, dir: "asc" };
      if (prev.dir === "asc") return { key, dir: "desc" };
      return null;
    });
    onChange?.();
  };
  return { sort, toggle };
}

export function useSort(rows, getters, onChange) {
  const { sort, toggle } = useSortState(onChange);

  const sorted = useMemo(() => {
    const get = sort && getters[sort.key];
    if (!get) return rows;
    const sign = sort.dir === "desc" ? -1 : 1;
    return [...rows].sort((x, y) => {
      const a = get(x);
      const b = get(y);
      if (isBlank(a) || isBlank(b)) return isBlank(a) === isBlank(b) ? 0 : isBlank(a) ? 1 : -1;
      return sign * compareValues(a, b);
    });
  }, [rows, getters, sort]);

  return { sorted, sort, toggle };
}
