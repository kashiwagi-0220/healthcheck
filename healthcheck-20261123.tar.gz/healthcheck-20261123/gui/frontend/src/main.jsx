import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import './index.css'
import App from './App.jsx'

// サーバからの読み込みのキャッシュ(api/queries.js)。
// - 画面を開くたびに裏で読み込み直す(staleTime 0。キャッシュはすぐ表示する)。
// - ウィンドウに戻っただけでは読み込み直さない(編集中に版が変わって保存が断られるのを避ける)。
// - 失敗したら1回だけ再試行する(一時的な失敗のため。それでも失敗したらエラーを表示する)。
const queryClient = new QueryClient({
  defaultOptions: {
    queries: { refetchOnWindowFocus: false, retry: 1 },
  },
})

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <QueryClientProvider client={queryClient}>
      <App />
    </QueryClientProvider>
  </StrictMode>,
)
