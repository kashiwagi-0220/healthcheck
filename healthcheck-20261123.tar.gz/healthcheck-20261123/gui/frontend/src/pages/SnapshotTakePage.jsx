import { useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { takeSnapshotStream } from "../api/client";
import { useConfirm } from "@/hooks/useConfirm";
import { queryKeys, useCommandSets, useDeviceList, useInvalidate } from "../api/queries";
import { LoadingText, LoadError } from "@/components/QueryStatus";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell, ClickableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import DeviceSelector, { DEVICE_TABLE_WIDTH } from "@/components/DeviceSelector";
import { Spinner, RunningBadge, Elapsed, ProgressBar } from "@/components/Running";
import RunLogPanel from "@/components/RunLogPanel";
import { useRunGuard } from "@/hooks/useRunGuard";
import { useStepFocus } from "@/hooks/useStepFocus";
import SnapshotDetail from "@/components/SnapshotDetail";
import { Dialog, RESULT_DIALOG_WIDTH, DIALOG_CONTENT_FLEX } from "@/components/ui/dialog";
import { formatDateTime } from "@/lib/format";
import { deviceVendorColor, deviceTypeColor } from "@/lib/deviceTypeColor";
import { cn } from "@/lib/utils";
import { downloadAllRaw, downloadAllParsed, downloadEverything, NOTHING_TO_DOWNLOAD } from "@/lib/snapshotDownload";
import { ChevronDown, Download, Square, ScrollText } from "lucide-react";
import { DropdownMenu } from "@/components/ui/dropdown-menu";
import CommandSetCell from "@/components/CommandSetCell";
import { checkCommandSet, COMMAND_SET_INVALID_MESSAGE } from "@/lib/commandSetCheck";

// 確認ステップ: 対象機器とそのコマンドセットを表示する。コマンドセット未設定・
// vendor/type不一致は取得時に失敗する(CommandSet.for_device() が例外を投げる)ため、
// ここで事前に検出して警告し、取得実行ボタンを止める。
function ConfirmStep({ devices, commandSets, commandSetsQuery, onBack, onConfirm, running, onShowLastResult }) {
  // コマンドセットを読み込み終わるまでは、検証の結果(未設定・不整合)を出さない
  // (以前は読み込み中に全機器が「未設定」と表示され、実行も止まっていた)。
  const checking = !commandSetsQuery.data;
  const rows = useMemo(
    () => devices.map((d) => ({ device: d, check: checkCommandSet(d, commandSets) })),
    [devices, commandSets]
  );
  const hasInvalid = !checking && rows.some((r) => !r.check.valid);

  return (
    <div className="space-y-3">
      <h3 tabIndex={-1} data-step-heading className="text-sm font-semibold outline-none">確認({rows.length} 件)</h3>
      {/* 正常性確認の確認ステップと同じ作り(全幅・同じ列幅・コマンドセットの表示と検査)。 */}
      <Table className="table-fixed" containerClassName="max-h-[calc(100vh-13rem)] overflow-y-auto rounded-md border bg-card">
          <TableHeader className="sticky top-0 z-10 bg-muted">
            <TableRow>
              <TableHead className="w-[17%]">ホスト名</TableHead>
              <TableHead className="w-[9%]">ベンダー</TableHead>
              <TableHead className="w-[9%]">タイプ</TableHead>
              <TableHead>コマンドセット</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows.map(({ device, check }) => (
              <TableRow key={device.host}>
                <TableCell className="font-medium">{device.host}</TableCell>
                <TableCell>
                  <Badge className={deviceVendorColor(device.vendor)}>{device.vendor}</Badge>
                </TableCell>
                <TableCell>
                  <Badge className={deviceTypeColor(device.type)}>{device.type}</Badge>
                </TableCell>
                <TableCell className="truncate">
                  <CommandSetCell check={check} checking={checking} />
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
      </Table>
      {checking && !commandSetsQuery.isError && <LoadingText />}
      <LoadError what="コマンドセット" error={commandSetsQuery.error} onRetry={commandSetsQuery.refetch} />
      {hasInvalid && <p className="text-sm text-destructive">{COMMAND_SET_INVALID_MESSAGE}</p>}
      <div className="flex items-center gap-2">
        <Button size="sm" variant="outline" onClick={onBack} disabled={running}>
          戻る
        </Button>
        <Button size="sm" onClick={() => onConfirm(true)} disabled={running || checking || hasInvalid}>
          {running ? <><Spinner />取得中...</> : "取得して保存"}
        </Button>
        <Button size="sm"
          variant="success-soft"
          onClick={() => onConfirm(false)}
          disabled={running || checking || hasInvalid}
        >
          取得して表示
        </Button>
        {onShowLastResult && (
          <Button size="sm" variant="outline" onClick={onShowLastResult} disabled={running}>
            前回の結果を表示
          </Button>
        )}
      </div>
    </div>
  );
}

// 取得中の進捗パネルの最大の高さと、その右のログ欄の高さ。機器が多いときに両者の
// 下端が揃うよう同じ値にする(Tailwind はクラス名を文字列のまま探すため2つに分けて持つ)。
// 上限はパネル全体に掛け、見出しと進捗バーは大きさを保ったまま機器の一覧だけが
// 縮んでスクロールする。
// ページ自体がスクロールしない範囲で画面の下端まで使う: 画面の高さから、上部の
// ヘッダ(App.jsx の h-14 = 3.5rem)と main の上下の余白(p-6 = 3rem)を引き、少し
// 余裕を残す(取得中の画面ではこのパネルより上に出るものが無いため)。
const NO_COMMAND_SETS = {};
const PROGRESS_PANEL_MAX_HEIGHT = "max-h-[calc(100vh-7rem)]";
const RUN_LOG_HEIGHT = "h-[calc(100vh-7rem)]";

// 取得中の進捗表示。deviceStatuses は {host: {status: "pending"|"done", success}}。
// take_snapshot() が機器ごとに完了した順に結果を返すため(healthcheck/common/
// snapshot.py 参照)、ここでもその順で "処理中"→"完了/失敗" に切り替わる。
// 機器の行をクリックすると、右のログ欄をその機器だけに絞り込む(focusHost)。
function ProgressPanel({ deviceStatuses, done, total, startedAt, focusHost, onToggleFocus, onAbort }) {
  const hosts = Object.keys(deviceStatuses);
  return (
    <div
      className={cn(
        "flex w-full flex-col gap-3 rounded-md border bg-muted/20 p-4",
        PROGRESS_PANEL_MAX_HEIGHT,
        DEVICE_TABLE_WIDTH
      )}
    >
      <div className="flex shrink-0 items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Spinner />
          <h3 tabIndex={-1} data-step-heading className="text-sm font-semibold outline-none">取得中...</h3>
          {startedAt && <Elapsed startedAt={startedAt} />}
        </div>
        <div className="flex items-center gap-2">
          <p className="text-xs text-muted-foreground">{done} / {total} 完了</p>
          <Button size="sm" variant="destructive-outline" onClick={onAbort}>
            <Square /> 中止
          </Button>
        </div>
      </div>
      <div className="shrink-0">
        <ProgressBar done={done} total={total} />
      </div>
      <div className="min-h-0 overflow-y-auto rounded-md border bg-card">
        {hosts.map((host) => {
          const st = deviceStatuses[host];
          return (
            // ボタンにして、キーボード(Tab・Enter・Space)でもログの絞り込みを切り替えられるようにする。
            <button
              type="button"
              key={host}
              aria-pressed={focusHost === host}
              title="クリック(または Enter)で、ログをこの機器だけに絞り込む"
              className={cn(
                "flex w-full cursor-pointer items-center gap-2 border-b px-3 py-1.5 text-left text-sm outline-none last:border-0 focus-visible:outline-2 focus-visible:outline-solid focus-visible:-outline-offset-2 focus-visible:outline-ring",
                focusHost === host ? "bg-accent" : "hover:bg-accent"
              )}
              onClick={() => onToggleFocus(host)}
            >
              <span className="font-medium">{host}</span>
              {st.status === "pending" ? (
                <span className="ml-auto">
                  <RunningBadge />
                </span>
              ) : (
                <Badge variant={st.success ? "success" : "warning"} className="ml-auto">
                  {st.success ? "完了" : "失敗"}
                </Badge>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}

export default function SnapshotTakePage() {
  const { devices, loading, error: devicesError } = useDeviceList();
  const commandSetsQuery = useCommandSets();
  const commandSets = commandSetsQuery.data ?? NO_COMMAND_SETS;
  const invalidate = useInvalidate();
  const [selectedHosts, setSelectedHosts] = useState([]);
  const [step, setStep] = useState("select"); // select -> confirm -> running -> result
  const [running, setRunning] = useState(false);
  const [deviceStatuses, setDeviceStatuses] = useState({});
  const [progress, setProgress] = useState({ done: 0, total: 0 });
  const [startedAt, setStartedAt] = useState(null);  // 取得開始時刻(経過時間の表示用)
  const [logSince, setLogSince] = useState(null);     // ログ欄の起点(開始イベントのサーバ時刻)
  const [logFocusHost, setLogFocusHost] = useState(null); // ログ欄を絞り込む機器(null は全機器)
  useRunGuard("snapshots/take", step === "running");
  const pageRef = useStepFocus(step);
  const abortRef = useRef(null);                       // 実行中の受け取りを中止する AbortController
  const confirm = useConfirm();
  const [showResultLog, setShowResultLog] = useState(false); // 結果画面でログ欄を開いているか
  const [results, setResults] = useState(null);
  const [error, setError] = useState(null);
  const [selected, setSelected] = useState(null); // 選択中の結果(snapshot形)。選択中はポップアップ表示する。

  // コマンドセットは確認ステップでの検証(機器に割り当てられたセットが実在し、
  // vendor/type が一致するか)に使う(読み込みの状態は ConfirmStep が表示する)。

  const toggleHost = (host) =>
    setSelectedHosts((prev) => (prev.includes(host) ? prev.filter((h) => h !== host) : [...prev, host]));

  // 列フィルタで絞り込んだ分をまとめて選択/解除する(1回の更新で反映する)。
  const selectManyHosts = (hosts, selected) =>
    setSelectedHosts((prev) => {
      const next = new Set(prev);
      for (const h of hosts) {
        if (selected) next.add(h);
        else next.delete(h);
      }
      return [...next];
    });

  const selectedDevices = useMemo(
    () => selectedHosts.map((h) => devices.find((d) => d.host === h)).filter(Boolean),
    [selectedHosts, devices]
  );

  const handleNext = () => {
    if (selectedHosts.length === 0) {
      setError("機器を選択してください。");
      return;
    }
    setError(null);
    setStep("confirm");
  };

  const handleRun = (save) => {
    setRunning(true);
    setStartedAt(Date.now());
    setError(null);
    const initialStatuses = Object.fromEntries(selectedHosts.map((h) => [h, { status: "pending" }]));
    setDeviceStatuses(initialStatuses);
    setProgress({ done: 0, total: selectedHosts.length });
    setResults([]);
    setLogSince(null);
    setLogFocusHost(null);
    setShowResultLog(false);
    setStep("running");
    const controller = new AbortController();
    abortRef.current = controller;
    let received = 0;

    takeSnapshotStream({ hosts: selectedHosts, save }, (event) => {
      if (event.type === "start") {
        setProgress({ done: 0, total: event.total });
        setLogSince(event.log_since);
      } else if (event.type === "device_done") {
        setDeviceStatuses((prev) => ({ ...prev, [event.host]: { status: "done", success: event.success } }));
        setProgress({ done: event.done, total: event.total });
        setResults((prev) => [...prev, event]);
        received += 1;
      } else if (event.type === "error") {
        setError(event.message);
      }
    }, controller.signal)
      .then(() => setStep("result"))
      .catch((e) => {
        if (e.name === "AbortError") {
          toast.info("中止しました。取得中だった機器はサーバで最後まで処理されます(「取得して保存」の場合は保存されます)。");
          // 中止までに終わった機器の結果は見られるようにする。
          setStep(received > 0 ? "result" : "confirm");
        } else {
          setError(e.message);
          setStep("confirm");
        }
      })
      .finally(() => {
        abortRef.current = null;
        setRunning(false);
        // 保存した場合はスナップショット一覧・正常性確認の選択肢に新しい分を出す。
        if (save) invalidate(queryKeys.snapshots);
      });
  };

  const handleAbort = async () => {
    const ok = await confirm({
      title: "取得を中止しますか?",
      description:
        "画面での受け取りを止めます。取得中の機器はサーバで最後まで処理され、"
        + "「取得して保存」の場合は保存されます。中止までに終わった機器の結果は表示します。",
      confirmLabel: "中止する",
      destructive: true,
    });
    if (ok) abortRef.current?.abort();
  };

  const handleReset = () => {
    setSelectedHosts([]);
    setResults(null);
    setDeviceStatuses({});
    setProgress({ done: 0, total: 0 });
    setError(null);
    setLogFocusHost(null);
    setShowResultLog(false);
    setStep("select");
  };

  // 結果は消さずに確認画面へ戻る(確認画面の「前回の結果を表示」で戻ってこられる)。
  // 選択中の機器もそのまま。handleReset は選択・結果とも消して最初からやり直す。
  const handleBackToConfirm = () => {
    setError(null);
    setStep("confirm");
  };

  // 結果は機器名の順に並べる(届いた順=完了順だと、探しにくいため)。
  const sortedResults = useMemo(
    () => [...(results ?? [])].sort((a, b) => a.host.localeCompare(b.host, undefined, { numeric: true, sensitivity: "base" })),
    [results]
  );
  const succeeded = sortedResults.filter((r) => r.success).length;

  return (
    <div ref={pageRef} className="space-y-4">
      {error && <p className="text-sm text-destructive">{error}</p>}

      {step === "select" && (
        <>
          <h3 tabIndex={-1} data-step-heading className="sr-only">機器選択</h3>
          <DeviceSelector
            devices={devices}
            loading={loading}
            error={devicesError}
            selectedHosts={selectedHosts}
            onToggle={toggleHost}
            onSelectMany={selectManyHosts}
          />
          <Button size="sm" onClick={handleNext}>次へ(確認)</Button>
        </>
      )}

      {step === "confirm" && (
        <ConfirmStep
          devices={selectedDevices}
          commandSets={commandSets}
          commandSetsQuery={commandSetsQuery}
          onBack={() => setStep("select")}
          onConfirm={handleRun}
          running={running}
          onShowLastResult={results?.length ? () => setStep("result") : undefined}
        />
      )}

      {step === "running" && (
        // 進捗は機器選択時の機器一覧と同じ幅にし、残りの幅にログを出す。
        // 画面が狭いときはログが進捗の下に回り込む。
        <div className="flex flex-wrap items-start gap-4">
          <ProgressPanel
            deviceStatuses={deviceStatuses}
            done={progress.done}
            total={progress.total}
            startedAt={startedAt}
            focusHost={logFocusHost}
            onToggleFocus={(host) => setLogFocusHost((prev) => (prev === host ? null : host))}
            onAbort={handleAbort}
          />
          <RunLogPanel
            className={RUN_LOG_HEIGHT}
            since={logSince}
            hosts={selectedHosts}
            focusHost={logFocusHost}
            onClearFocus={() => setLogFocusHost(null)}
          />
        </div>
      )}

      {step === "result" && results && (
        <div className="space-y-3">
          {/* 件数の行の右に、ログの表示を置く(正常性確認の結果画面と同じ並び)。 */}
          <div className="flex flex-wrap items-center justify-between gap-2">
            <p tabIndex={-1} data-step-heading className="text-sm text-muted-foreground outline-none">
              {sortedResults.length} 件中 成功 {succeeded} 件・失敗 {sortedResults.length - succeeded} 件
              {sortedResults.length < selectedHosts.length && `(中止したため ${selectedHosts.length - sortedResults.length} 件は結果がありません)`}
            </p>
            <Button size="sm" variant="outline" onClick={() => setShowResultLog((v) => !v)} aria-expanded={showResultLog}>
              <ScrollText /> {showResultLog ? "ログを隠す" : "この実行のログを表示"}
            </Button>
          </div>

          <Table className="table-fixed" containerClassName="max-h-[calc(100vh-13rem)] overflow-y-auto rounded-md border bg-card">
            <TableHeader className="sticky top-0 z-10 bg-muted">
              <TableRow>
                <TableHead className="w-[22%]">ホスト名</TableHead>
                <TableHead className="w-[26%]">取得時刻</TableHead>
                <TableHead className="w-[12%]">ステータス</TableHead>
                <TableHead className="w-[12%]">保存</TableHead>
                <TableHead className="w-[28%]">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedResults.map((r) => {
                const snapshot = { host: r.host, id: r.id, taken_at: r.taken_at, success: r.success, error: r.error, commands: r.commands };
                const empty = Object.keys(r.commands ?? {}).length === 0;
                return (
                  <ClickableRow
                    key={`${r.host}:${r.id}`}
                    className="hover:bg-accent"
                    onActivate={() => setSelected(snapshot)}
                  >
                    <TableCell className="font-medium">{r.host}</TableCell>
                    <TableCell>{formatDateTime(r.taken_at)}</TableCell>
                    <TableCell>
                      <Badge variant={r.success ? "success" : "warning"}>{r.success ? "成功" : "失敗"}</Badge>
                    </TableCell>
                    <TableCell>
                      {/* 失敗も記録として保存されるが、緑の「保存済み」だと成功に見えるため分ける。 */}
                      {r.saved ? (
                        r.success
                          ? <Badge variant="success">保存済み</Badge>
                          : <Badge variant="secondary">失敗を記録</Badge>
                      ) : (
                        <Badge variant="secondary">表示のみ</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex" title={empty ? NOTHING_TO_DOWNLOAD : undefined}>
                        <DropdownMenu
                          trigger={
                            <Button size="sm" variant="outline" disabled={empty} aria-label={`${r.host} の取得結果をダウンロード`}
                              onClick={(e) => e.stopPropagation()}>
                              <Download /> ダウンロード <ChevronDown />
                            </Button>
                          }
                          items={[
                            { key: "raw", label: "生データ", icon: Download, onSelect: () => downloadAllRaw(snapshot) },
                            { key: "parsed", label: "パース後", icon: Download, onSelect: () => downloadAllParsed(snapshot) },
                            { key: "all", label: "全て", icon: Download, onSelect: () => downloadEverything(snapshot) },
                          ]}
                        />
                      </div>
                    </TableCell>
                  </ClickableRow>
                );
              })}
            </TableBody>
          </Table>

          <Dialog
            open={Boolean(selected)}
            onClose={() => setSelected(null)}
            title={selected ? `${selected.host} / ${selected.id}` : ""}
            className={RESULT_DIALOG_WIDTH}
            contentClassName={DIALOG_CONTENT_FLEX}
          >
            {selected && (
              <SnapshotDetail
                host={selected.host}
                snapshotId={selected.id}
                takenAt={selected.taken_at}
                success={selected.success}
                error={selected.error}
                commands={selected.commands}
                showDownloadAll={false}
              />
            )}
          </Dialog>

          <div className="flex flex-wrap items-center gap-2">
            <Button size="sm" variant="outline" onClick={handleBackToConfirm}>
              戻る
            </Button>
            <Button size="sm" variant="outline" onClick={handleReset}>
              最初からやり直す
            </Button>
          </div>
          {showResultLog && (
            <RunLogPanel
              className="h-72"
              live={false}
              since={logSince}
              hosts={selectedHosts}
              focusHost={logFocusHost}
              onClearFocus={() => setLogFocusHost(null)}
            />
          )}
        </div>
      )}
    </div>
  );
}
