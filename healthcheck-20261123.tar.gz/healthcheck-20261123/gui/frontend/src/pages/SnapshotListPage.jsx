import { useMemo, useState } from "react";
import { toast } from "sonner";
import { getSnapshotFull, deleteSnapshot } from "../api/client";
import {
  queryKeys, useDebouncedValue, useInvalidate, useSnapshotFull, useSnapshotHosts, useSnapshotList,
} from "../api/queries";
import { useConfirm } from "@/hooks/useConfirm";
import IconButton from "@/components/IconButton";
import { useSortState } from "@/hooks/useSort";
import SortableHead from "@/components/SortableHead";
import { LoadingText, LoadError, TableStatusRow } from "@/components/QueryStatus";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell, ClickableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, RESULT_DIALOG_WIDTH, DIALOG_CONTENT_FLEX } from "@/components/ui/dialog";
import SnapshotDetail from "@/components/SnapshotDetail";
import { downloadAllRaw, downloadAllParsed, downloadEverything, NOTHING_TO_DOWNLOAD } from "@/lib/snapshotDownload";
import { formatDateTime } from "@/lib/format";
import Pagination from "@/components/Pagination";
import HighlightMatch from "@/components/HighlightMatch";
import { EMPTY_TEXT_QUERY, compileTextQuery } from "@/lib/textQuery";
import { Spinner } from "@/components/Running";
import { PAGE_SIZE, usePageRange } from "@/hooks/usePagination";
import { ChevronDown, Download, Trash2 } from "lucide-react";
import { DropdownMenu } from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import { TextFilter, SelectFilter } from "@/components/TableFilters";

// "YYYY-MM-DDTHH:mm" 形式(datetime-local の value と同じ形)のローカル時刻文字列を、
// バックエンドへ渡す ISO8601 文字列に変換する。toISOString() の "Z" は "+00:00" に
// 置き換え、UTC であることを時差の数値で示す。
// endOfMinute: 期間の終わり用。指定した分の終わり(59.999秒)までを含める
// (「〜 23:59」が 23:59:00 で切れて、その1分間の取得が外れないように)。
function toBackendIso(localValue, { endOfMinute = false } = {}) {
  if (!localValue) return null;
  const d = new Date(endOfMinute ? `${localValue}:59.999` : localValue);
  if (Number.isNaN(d.getTime())) return null;
  return d.toISOString().replace("Z", "+00:00");
}

// 日付と時刻の入力。ブラウザの <input type="date"/"time"> は表示がブラウザの言語設定に
// 左右され(英語の Chrome では「mm/dd/yyyy」「午前/午後」)、年・月・日ごとに Tab で止まる
// ため、文字で入力する欄にする。日付は「2026/11/21」(「2026-11-21」「20261121」も可)、
// 時刻は 24 時間表記の「13:05」(「1305」も可)。読める形になった時点で反映し、欄を離れると
// 「YYYY/MM/DD」「HH:MM」に整える。読めない間は赤枠にして、絞り込みには使わない。
// value(呼び出し側とのやり取り)は datetime-local と同じ "YYYY-MM-DDTHH:mm" 形式。
// defaultTime は日付だけを入れたときの時刻。期間の始まりは "00:00"、終わりは "23:59" に
// して、日付だけで「その日を含む」範囲になるようにする。
function parseDate(text) {
  const m = /^(\d{4})[/-]?(\d{1,2})[/-]?(\d{1,2})$/.exec(text.trim());
  if (!m) return null;
  const [y, mo, d] = [Number(m[1]), Number(m[2]), Number(m[3])];
  const dt = new Date(y, mo - 1, d);
  if (dt.getFullYear() !== y || dt.getMonth() !== mo - 1 || dt.getDate() !== d) return null;
  return `${m[1]}-${String(mo).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
}

function parseTime(text) {
  const m = /^(\d{1,2}):?(\d{2})$/.exec(text.trim());
  if (!m || Number(m[1]) > 23 || Number(m[2]) > 59) return null;
  return `${m[1].padStart(2, "0")}:${m[2]}`;
}

function DateTime24Input({ value, onChange, defaultTime = "00:00", label }) {
  const [initialDate, initialTime] = value ? value.split("T") : ["", ""];
  const [dateText, setDateText] = useState(initialDate.replaceAll("-", "/"));
  const [timeText, setTimeText] = useState(initialTime);
  const dateValue = parseDate(dateText);
  const timeValue = parseTime(timeText);
  const dateInvalid = dateText.trim() !== "" && !dateValue;
  const timeInvalid = timeText.trim() !== "" && !timeValue;

  // 入力が読める形になったときだけ呼び出し側へ伝える(読めない間は前の条件のまま)。
  const emit = (nextDateText, nextTimeText) => {
    const d = parseDate(nextDateText);
    const t = parseTime(nextTimeText);
    if (nextDateText.trim() === "") onChange("");
    else if (d && (t || nextTimeText.trim() === "")) onChange(`${d}T${t ?? defaultTime}`);
  };

  return (
    <div className="flex items-center gap-1">
      <Input
        className={cn("h-7 w-[6.5rem] text-xs tabular-nums", dateInvalid && "border-destructive")}
        aria-label={`${label}の日付(例 2026/11/21)`}
        aria-invalid={dateInvalid}
        title={dateInvalid ? "日付は 2026/11/21 の形で入力してください" : undefined}
        placeholder="YYYY/MM/DD"
        inputMode="numeric"
        value={dateText}
        onChange={(e) => { setDateText(e.target.value); emit(e.target.value, timeText); }}
        onBlur={() => { if (dateValue) setDateText(dateValue.replaceAll("-", "/")); }}
      />
      <Input
        className={cn("h-7 w-[3.75rem] text-xs tabular-nums", timeInvalid && "border-destructive")}
        aria-label={`${label}の時刻(24時間表記。例 13:05)`}
        aria-invalid={timeInvalid}
        title={timeInvalid ? "時刻は 24 時間表記の 13:05 の形で入力してください" : `空欄なら ${defaultTime}`}
        placeholder={defaultTime}
        inputMode="numeric"
        value={timeText}
        disabled={!dateValue}
        onChange={(e) => { setTimeText(e.target.value); emit(dateText, e.target.value); }}
        onBlur={() => { if (timeValue) setTimeText(timeValue); }}
      />
    </div>
  );
}

// 展開時に GET .../full を1回だけ呼び、コマンドごとの raw/parsed をまとめて取得する
// (保存済みの中身は変わらないので、一度読んだものは開き直しても読み直さない)。
function SnapshotDetailLoader({ host, snapshotId }) {
  const { data, error, refetch } = useSnapshotFull(host, snapshotId);

  if (error) return <LoadError what="スナップショット" error={error} onRetry={refetch} />;
  if (!data) return <LoadingText />;

  return (
    <SnapshotDetail
      host={host}
      snapshotId={data.id}
      takenAt={data.taken_at}
      success={data.success}
      error={data.error}
      commands={data.commands}
      showDownloadAll={false}
    />
  );
}

// 一括ダウンロードは表側に raw/parsed を持たないため、押された時点で
// GET .../full を取ってから組み立てる(ポップアップを開く場合と同じ取得元)。
const DOWNLOAD_KINDS = {
  raw: { label: "生データ", run: downloadAllRaw },
  parsed: { label: "パース後", run: downloadAllParsed },
  all: { label: "全て", run: downloadEverything },
};

// 行ごとのダウンロード。3種類のボタンを並べると狭い画面で2段に折り返して行が倍の高さに
// なるため、1つのボタンからメニューで選ぶ形にする。
function RowDownloadMenu({ host, id, empty, pendingKey, onPendingChange }) {
  const pending = pendingKey === `${host}:${id}`;
  const run = (kind) => {
    onPendingChange(`${host}:${id}`);
    getSnapshotFull(host, id)
      .then((data) => DOWNLOAD_KINDS[kind].run(data))
      .catch((e) => toast.error(`ダウンロードできませんでした: ${e.message}`))
      .finally(() => onPendingChange(null));
  };
  return (
    <DropdownMenu
      trigger={
        <Button
          size="sm"
          variant="outline"
          disabled={pending || empty}
          aria-label={`${host} のスナップショットをダウンロード`}
          onClick={(e) => e.stopPropagation()}
        >
          {pending ? <Spinner /> : <Download />} ダウンロード <ChevronDown />
        </Button>
      }
      items={Object.entries(DOWNLOAD_KINDS).map(([kind, { label }]) => ({
        key: kind,
        label,
        icon: Download,
        onSelect: () => run(kind),
      }))}
    />
  );
}

const EMPTY_FILTERS = { host: EMPTY_TEXT_QUERY, status: "", since: "", until: "" };
// 一覧の項目は中身(raw/parsed)を持たないが、コマンドごとの保存先(refs)は持つ。
// refs が空 = ダウンロードできるコマンドが無い(取得に失敗したスナップショット)。
const emptyRefs = (s) => Object.keys(s.refs ?? {}).length === 0;
const STATUS_TO_SUCCESS = { 成功: true, 失敗: false };
const NO_ITEMS = [];

// 列の見出しのキー → GET /snapshots の sort の値。並べ替えていないときは取得時刻の新しい順。
const SORT_PARAM = { host: "host", takenAt: "taken_at", status: "success" };

export default function SnapshotListPage() {
  const [pageInput, setPage] = useState(0);
  const [filters, setFilters] = useState(EMPTY_FILTERS);
  const [selected, setSelected] = useState(null); // {host, id} | null。選択中は詳細をポップアップ表示する。
  const [pendingDownload, setPendingDownload] = useState(null); // "host:id:kind" | null
  const confirm = useConfirm();
  const invalidate = useInvalidate();
  const setFilter = (key) => (value) => {
    setPage(0);
    setFilters((prev) => ({ ...prev, [key]: value }));
  };
  // 列の並べ替え。ページ分けをサーバで行うため、並べ替えもサーバに任せる(画面の中で
  // 並べると、表示中の1ページの中だけが並ぶことになる)。並べ替えを変えたら先頭ページへ。
  const { sort, toggle: toggleSort } = useSortState(() => setPage(0));

  // ホスト名の絞り込み。部分一致はサーバ(host_contains)に任せる。正規表現はサーバでは
  // 実行せず、snapshot があるホスト名の一覧に対してここで判定し、一致したホスト名だけを
  // サーバに渡す(極端に遅い正規表現を入力されても、サーバの処理を止めないため)。
  // 文字の入力は少し待ってから問い合わせる(1文字ごとにサーバへ問い合わせない)。
  const hostQuery = useDebouncedValue(filters.host);
  const hostMatcher = useMemo(() => compileTextQuery(filters.host), [filters.host]);
  const debouncedMatcher = useMemo(() => compileTextQuery(hostQuery), [hostQuery]);
  const hostsQuery = useSnapshotHosts({ enabled: hostQuery.regex });
  // 正規表現のとき、サーバへ渡す一致したホスト名。null は絞り込まない(部分一致のとき、
  // 正規表現が空・正しくないとき)。
  const regexHosts = useMemo(() => {
    if (!hostQuery.regex || !debouncedMatcher.active || !hostsQuery.data) return null;
    return hostsQuery.data.hosts.filter((h) => debouncedMatcher.test(h));
  }, [hostQuery.regex, debouncedMatcher, hostsQuery.data]);
  const waitingHosts = hostQuery.regex && debouncedMatcher.active && hostsQuery.isPending;
  // 一致するホストが無いと分かっている場合は問い合わせない(hosts を空で送る手段が
  // 無く、送らないと全件になってしまうため)。表示側で 0 件として扱う。
  const noHostMatch = regexHosts !== null && regexHosts.length === 0;

  // ステータス(成功/失敗)もサーバで絞り込む(以前は表示中の1ページ分だけを絞り込んで
  // いたため、他のページの失敗が出ず、件数も絞り込み前のままだった)。
  const params = {
    hostContains: hostQuery.regex ? undefined : hostQuery.text.trim() || undefined,
    hosts: regexHosts ?? undefined,
    since: toBackendIso(filters.since) || undefined,
    until: toBackendIso(filters.until, { endOfMinute: true }) || undefined,
    success: STATUS_TO_SUCCESS[filters.status],
    sort: sort ? SORT_PARAM[sort.key] : undefined,
    order: sort?.dir,
    limit: PAGE_SIZE,
    offset: pageInput * PAGE_SIZE,
  };
  const listQuery = useSnapshotList(params, { enabled: !waitingHosts && !noHostMatch });

  const snapshots = noHostMatch ? NO_ITEMS : listQuery.data?.items ?? NO_ITEMS;
  const shownTotal = noHostMatch ? 0 : listQuery.data?.total ?? 0;
  const { page, pageCount, rangeStart, rangeEnd } = usePageRange(shownTotal, pageInput);
  const loading = (listQuery.isFetching && !noHostMatch) || waitingHosts;

  // 削除したら、一覧・ホスト名一覧・正常性確認の BEFORE/AFTER の選択肢を読み直す。
  // 開いていた詳細が消えた場合は閉じる。
  const afterDelete = (removed) => {
    if (selected && removed.some((r) => r.host === selected.host && r.id === selected.id)) setSelected(null);
    return invalidate(queryKeys.snapshots);
  };

  const handleDeleteOne = async (snap) => {
    const ok = await confirm({
      title: "スナップショットを削除しますか?",
      description: `${snap.host} の ${formatDateTime(snap.taken_at)} のスナップショットと、その取得データを削除します。\nこの操作は取り消せません。`,
      confirmLabel: "削除",
      destructive: true,
    });
    if (!ok) return;
    try {
      await deleteSnapshot(snap.host, snap.id);
      toast.success(`${snap.host} の ${formatDateTime(snap.taken_at)} のスナップショットを削除しました`);
    } catch (e) {
      toast.error(`削除できませんでした: ${e.message}`);
    }
    await afterDelete([snap]);
  };

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="flex items-center gap-1.5 text-sm text-muted-foreground">
          {loading ? <LoadingText /> : listQuery.data || noHostMatch ? `${rangeStart}-${rangeEnd} / ${shownTotal} 件` : "-"}
        </p>
        <div className="flex items-center gap-2">
          <Pagination page={page} pageCount={pageCount} onPageChange={setPage} />
        </div>
      </div>
      <LoadError what="スナップショット一覧" error={listQuery.error} onRetry={listQuery.refetch} />
      <LoadError what="ホスト名の一覧" error={hostsQuery.error} onRetry={hostsQuery.refetch} />

      {/* table-fixed: 展開行の raw/JSON はスペースも改行も無い1行の生データ
          (例: REST応答の生JSON)になることがあり、その場合 <pre> に
          overflow-auto を付けても、table-layout:auto の列幅計算は
          「折り返し不可能な内容の最小幅」を無視できない(overflow による
          最小幅0扱いは flex/grid 専用の仕様で、table には適用されない)ため、
          表全体が中身の幅まで伸びてしまう。table-fixed は列幅を中身から
          完全に切り離す(1行目の指定幅のみで決まる)ため、これを防げる。 */}
      <Table
        className="min-w-[52rem] table-fixed"
        containerClassName="max-h-[78vh] overflow-y-auto rounded-md border bg-card"
      >
          <TableHeader className="sticky top-0 z-10 bg-muted">
            <TableRow>
              <SortableHead sortKey="host" sort={sort} onSort={toggleSort}>ホスト名</SortableHead>
              <SortableHead className="w-[23rem]" sortKey="takenAt" sort={sort} onSort={toggleSort}>取得時刻</SortableHead>
              <SortableHead className="w-28" sortKey="status" sort={sort} onSort={toggleSort}>ステータス</SortableHead>
              <TableHead className="w-52">操作</TableHead>
            </TableRow>
            <TableRow className="hover:bg-transparent">
              <TableHead className="py-1.5">
                <TextFilter value={filters.host} onChange={setFilter("host")} placeholder="絞り込み" />
              </TableHead>
              <TableHead className="py-1.5">
                <div className="flex items-center gap-1">
                  <DateTime24Input label="開始" value={filters.since} onChange={setFilter("since")} />
                  <span className="text-xs text-muted-foreground">〜</span>
                  <DateTime24Input label="終了" defaultTime="23:59" value={filters.until} onChange={setFilter("until")} />
                </div>
              </TableHead>
              <TableHead className="py-1.5">
                <SelectFilter value={filters.status} onChange={setFilter("status")} options={["成功", "失敗"]} />
              </TableHead>
              <TableHead className="py-1.5" />
            </TableRow>
          </TableHeader>
          <TableBody>
            {snapshots.map((s) => {
              const key = `${s.host}:${s.id}`;
              return (
                <ClickableRow key={key} className="hover:bg-accent" onActivate={() => setSelected({ host: s.host, id: s.id, takenAt: s.taken_at })}>
                  <TableCell className="font-medium"><HighlightMatch text={s.host} matcher={hostMatcher} /></TableCell>
                  <TableCell>{formatDateTime(s.taken_at)}</TableCell>
                  <TableCell>
                    <Badge variant={s.success ? "success" : "warning"}>{s.success ? "成功" : "失敗"}</Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      <span className="flex" title={emptyRefs(s) ? NOTHING_TO_DOWNLOAD : undefined}>
                        <RowDownloadMenu
                          host={s.host}
                          id={s.id}
                          empty={emptyRefs(s)}
                          pendingKey={pendingDownload}
                          onPendingChange={setPendingDownload}
                        />
                      </span>
                      <IconButton
                        label={`${s.host} の ${formatDateTime(s.taken_at)} のスナップショットを削除`}
                        variant="destructive-outline"
                        onClick={(e) => { e.stopPropagation(); handleDeleteOne(s); }}
                      >
                        <Trash2 />
                      </IconButton>
                    </div>
                  </TableCell>
                </ClickableRow>
              );
            })}
            <TableStatusRow
              colSpan={4}
              isPending={(listQuery.isPending && !noHostMatch) || waitingHosts}
              isError={listQuery.isError}
              isEmpty={snapshots.length === 0}
              emptyText="該当するスナップショットがありません"
            />
          </TableBody>
      </Table>

      <Dialog
        open={Boolean(selected)}
        onClose={() => setSelected(null)}
        // 題名は一覧と同じく日時で出す(以前は内部の ID のままだった)。
        title={selected ? `${selected.host} / ${formatDateTime(selected.takenAt)}` : ""}
        className={RESULT_DIALOG_WIDTH}
        contentClassName={DIALOG_CONTENT_FLEX}
      >
        {selected && <SnapshotDetailLoader host={selected.host} snapshotId={selected.id} />}
      </Dialog>
    </div>
  );
}
