import { useId, useMemo, useState } from "react";
import { toast } from "sonner";
import {
  createCommandSet, updateCommandSet, deleteCommandSet, downloadCommandSetFiles, uploadCommandSetFiles,
} from "../api/client";
import { queryKeys, useCommandSets, useCommandCatalog, useDevices, useInvalidate } from "../api/queries";
import { LoadingText, LoadError, TableStatusRow } from "@/components/QueryStatus";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell, ClickableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Dialog, DialogFooter, DIALOG_CONTENT_FLEX, DIALOG_FULL_HEIGHT } from "@/components/ui/dialog";
import IconButton from "@/components/IconButton";
import { useConfirm } from "@/hooks/useConfirm";
import { Plus, Pencil, Trash2, ChevronRight, Check } from "lucide-react";
import { deviceTypeColor, deviceVendorColor } from "@/lib/deviceTypeColor";
import { cn } from "@/lib/utils";
import { TextFilter, SelectFilter } from "@/components/TableFilters";
import HighlightMatch from "@/components/HighlightMatch";
import { EMPTY_TEXT_QUERY, compileTextQuery } from "@/lib/textQuery";
import FileTransferButtons from "@/components/FileTransferButtons";
import Pagination from "@/components/Pagination";
import { usePageRange, usePageSlice } from "@/hooks/usePagination";
import { useSort } from "@/hooks/useSort";
import SortableHead from "@/components/SortableHead";

const EMPTY_FILTERS = { name: EMPTY_TEXT_QUERY, vendor: "", type: "", description: EMPTY_TEXT_QUERY };
const NO_CATALOG = {};

// コマンドカタログ(選択中 vendor+type の CLI・REST をまとめた一覧)から複数選択する。
// スナップショット取得の機器選択(左に一覧表・右に選択中の一覧)と同じ形にする。
// CLI・REST はコマンドセット側では別々の配列(cli/rest)で持つため、一覧では種別列で
// 区別しつつ、クリックでそれぞれ対応する配列に出し入れする。カタログに無い値が既存データに
// 残っている場合も一覧から消えないようにする(パーサ欄に「カタログ未定義」と表示)。
const EMPTY_COMMAND_FILTERS = { command: EMPTY_TEXT_QUERY, kind: "", parser: "" };

const EMPTY_SELECTED_FILTERS = { kind: "", command: EMPTY_TEXT_QUERY };

// 「選択中のコマンド」の表形式表示。CommandPicker(編集画面。クリックで解除可)と
// CommandSetView(閲覧ポップアップ。onRemove無しで読み取り専用)の2箇所で共有する。
// 表はポップアップの残りの高さに収まるよう縮み、表の中だけがスクロールする
// (ポップアップ全体はスクロールしない。呼び出し側が縦並びの中に置く)。
// 種別とコマンド名で絞り込める(コマンド一覧の表と同じ形)。
function SelectedCommandsTable({ rows, commands, onRemove, emptyMessage }) {
  const [filters, setFilters] = useState(EMPTY_SELECTED_FILTERS);
  const setFilter = (key) => (value) => setFilters((prev) => ({ ...prev, [key]: value }));
  const commandMatcher = useMemo(() => compileTextQuery(filters.command), [filters.command]);
  const filteredRows = useMemo(() => {
    return rows.filter((r) => {
      if (filters.kind && (r.kind === "rest" ? "REST" : "CLI") !== filters.kind) return false;
      if (!commandMatcher.test(r.command)) return false;
      return true;
    });
  }, [rows, filters, commandMatcher]);

  return (
    <Table containerClassName="min-h-0 overflow-y-auto rounded-md border bg-card">
      <TableHeader className="sticky top-0 z-10 bg-muted">
        <TableRow>
          <TableHead>種別</TableHead>
          <TableHead>コマンド</TableHead>
        </TableRow>
        <TableRow className="hover:bg-transparent">
          <TableHead className="py-1.5">
            <SelectFilter value={filters.kind} onChange={setFilter("kind")} options={["CLI", "REST"]} />
          </TableHead>
          <TableHead className="py-1.5">
            <TextFilter value={filters.command} onChange={setFilter("command")} placeholder="絞り込み" />
          </TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {filteredRows.map((row) => {
          // 編集中は行を押すと選択から外す。表示専用(onRemove 無し)はただの行にする。
          const Row = onRemove ? ClickableRow : TableRow;
          const rowProps = onRemove
            ? { className: "hover:bg-accent", onActivate: () => onRemove(row), title: "クリック(または Enter)で選択から外す" }
            : {};
          return (
          <Row key={`${row.kind}:${row.command}`} {...rowProps}>
            <TableCell>
              <Badge variant={row.kind === "rest" ? "outline" : "secondary"}>{row.kind === "rest" ? "REST" : "CLI"}</Badge>
            </TableCell>
            <TableCell className="font-medium" title={commands[row.command]?.description || undefined}>
              <HighlightMatch text={row.command} matcher={commandMatcher} />
            </TableCell>
          </Row>
          );
        })}
        {filteredRows.length === 0 && (
          <TableRow>
            <TableCell colSpan={2} className="text-center text-sm text-muted-foreground">
              {rows.length === 0 ? emptyMessage : "該当するコマンドがありません"}
            </TableCell>
          </TableRow>
        )}
      </TableBody>
    </Table>
  );
}

function CommandPicker({ ready, commands, selectedCli, selectedRest, onToggleCli, onToggleRest }) {
  const [filters, setFilters] = useState(EMPTY_COMMAND_FILTERS);
  const setFilter = (key) => (value) => setFilters((prev) => ({ ...prev, [key]: value }));

  const catalogNames = useMemo(() => new Set(Object.keys(commands)), [commands]);
  const rows = useMemo(() => {
    const catalogRows = Object.entries(commands).map(([command, spec]) => ({
      command,
      spec,
      kind: spec.parser === "json" ? "rest" : "cli",
    }));
    const extraCli = selectedCli
      .filter((c) => !catalogNames.has(c))
      .map((command) => ({ command, spec: null, kind: "cli" }));
    const extraRest = selectedRest
      .filter((c) => !catalogNames.has(c))
      .map((command) => ({ command, spec: null, kind: "rest" }));
    return [...catalogRows, ...extraCli, ...extraRest].sort((a, b) => a.command.localeCompare(b.command));
  }, [commands, catalogNames, selectedCli, selectedRest]);

  const parserOptions = useMemo(
    () => Array.from(new Set(rows.map((r) => r.spec?.parser).filter(Boolean))).sort(),
    [rows]
  );

  const commandMatcher = useMemo(() => compileTextQuery(filters.command), [filters.command]);
  const filteredRows = useMemo(() => {
    return rows.filter((r) => {
      if (!commandMatcher.test(r.command)) return false;
      if (filters.kind && (r.kind === "rest" ? "REST" : "CLI") !== filters.kind) return false;
      if (filters.parser && r.spec?.parser !== filters.parser) return false;
      return true;
    });
  }, [rows, filters, commandMatcher]);

  const isSelected = (row) => (row.kind === "cli" ? selectedCli.includes(row.command) : selectedRest.includes(row.command));
  const toggle = (row) => (row.kind === "cli" ? onToggleCli(row.command) : onToggleRest(row.command));

  const selectedRows = useMemo(() => {
    const cliRows = selectedCli.map((command) => ({ command, kind: "cli" }));
    const restRows = selectedRest.map((command) => ({ command, kind: "rest" }));
    return [...cliRows, ...restRows];
  }, [selectedCli, selectedRest]);

  if (!ready) {
    return <p className="text-xs text-muted-foreground">先にベンダー・タイプを選択してください</p>;
  }
  if (rows.length === 0) {
    return (
      <p className="text-xs text-muted-foreground">
        このベンダー・タイプのコマンドカタログに定義がありません(config/command/command_catalog/ を確認してください)
      </p>
    );
  }

  // 2つの表は折り返さずに横に並べる。折り返しを許すと各行の高さが中身の量で決まり、
  // 表がポップアップの残りの高さに収まるよう縮まなくなる(ポップアップ全体が
  // スクロールしてしまう)ため。
  return (
    <div className="flex min-h-0 flex-1 gap-4">
      <div className="flex min-h-0 min-w-0 flex-1 flex-col gap-1.5">
        <Label className="shrink-0 text-sm font-semibold">コマンド一覧(クリックで選択・解除)</Label>
        <Table containerClassName="min-h-0 overflow-y-auto rounded-md border bg-card">
            <TableHeader className="sticky top-0 z-10 bg-muted">
              <TableRow>
                <TableHead>コマンド</TableHead>
                <TableHead>種別</TableHead>
                <TableHead>パーサ</TableHead>
              </TableRow>
              <TableRow className="hover:bg-transparent">
                <TableHead className="py-1.5">
                  <TextFilter value={filters.command} onChange={setFilter("command")} placeholder="絞り込み" />
                </TableHead>
                <TableHead className="py-1.5">
                  <SelectFilter value={filters.kind} onChange={setFilter("kind")} options={["CLI", "REST"]} />
                </TableHead>
                <TableHead className="py-1.5">
                  <SelectFilter value={filters.parser} onChange={setFilter("parser")} options={parserOptions} />
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredRows.map((row) => {
                const selected = isSelected(row);
                return (
                  <ClickableRow
                    key={`${row.kind}:${row.command}`}
                    selected={selected}
                    className={selected ? "bg-primary/15 hover:bg-primary/20" : "hover:bg-muted"}
                    onActivate={() => toggle(row)}
                  >
                    <TableCell className="font-medium" title={row.spec?.description || undefined}>
                      <span className="inline-flex items-center gap-1">
                        <Check className={cn("size-3.5 shrink-0 text-primary", !selected && "invisible")} aria-hidden="true" />
                        <HighlightMatch text={row.command} matcher={commandMatcher} />
                      </span>
                    </TableCell>
                    <TableCell>
                      <Badge variant={row.kind === "rest" ? "outline" : "secondary"}>
                        {row.kind === "rest" ? "REST" : "CLI"}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {row.spec ? row.spec.parser : "カタログ未定義"}
                    </TableCell>
                  </ClickableRow>
                );
              })}
              {filteredRows.length === 0 && (
                <TableRow>
                  <TableCell colSpan={3} className="text-center text-sm text-muted-foreground">
                    該当する項目がありません
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
        </Table>
      </div>

      <div className="flex shrink-0 self-stretch items-center pt-8">
        <ChevronRight className="size-6 text-muted-foreground" />
      </div>

      <div className="flex min-h-0 min-w-0 flex-1 flex-col gap-1.5">
        <Label className="shrink-0 text-sm font-semibold">選択中のコマンド({selectedRows.length} 件)</Label>
        <SelectedCommandsTable
          rows={selectedRows}
          commands={commands}
          onRemove={toggle}
          emptyMessage="左の一覧から選択してください"
        />
      </div>
    </div>
  );
}

// 作成・編集共通のフォーム。name は作成時のみ入力(編集時は変更不可なので表示のみ)。
// catalog は vendor -> type -> {command: spec} (GET /command-catalog のレスポンスそのまま。
// コア側の CommandCatalog.by_vendor_type と同じ階層構造)。
// CLI コマンド・REST の key は自由入力ではなく、選択した vendor+type のコマンド
// カタログ(parser が "json" でないもの=CLI側、"json"のもの=REST側)から選ぶ形式に
// する(カタログに無い値は実行時にエラーになるため、そもそも選べないようにして
// 事故を防ぐ)。REST の method/path はコマンドカタログ側が持つため、ここでは
// key を選ぶだけでよい。
function CommandSetForm({ name, initial, catalog, onCancel, onSubmit, submitLabel, onSavingChange }) {
  const id = useId();
  const [nameInput, setNameInput] = useState(name ?? "");
  const [vendor, setVendor] = useState(initial?.vendor ?? "");
  const [type, setType] = useState(initial?.type ?? "");
  const [description, setDescription] = useState(initial?.description ?? "");
  const [selectedCli, setSelectedCli] = useState(initial?.cli ?? []);
  const [selectedRest, setSelectedRest] = useState(initial?.rest ?? []);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  const vendors = useMemo(() => Object.keys(catalog).sort(), [catalog]);
  const types = useMemo(() => Object.keys(catalog[vendor] ?? {}).sort(), [catalog, vendor]);
  const commands = useMemo(() => catalog[vendor]?.[type] ?? {}, [catalog, vendor, type]);
  const ready = Boolean(vendor && type);

  const handleVendorChange = (value) => {
    setVendor(value);
    // vendor が変わったら type・選択済みの CLI・REST をリセットする(別ベンダーの
    // カタログの値を引き継がないため)。
    setType("");
    setSelectedCli([]);
    setSelectedRest([]);
  };
  const handleTypeChange = (value) => {
    setType(value);
    // type が変わったら選択済みの CLI・REST をリセットする(別機種のカタログの
    // 値を引き継がないため)。
    setSelectedCli([]);
    setSelectedRest([]);
  };
  const toggleCli = (command) =>
    setSelectedCli((prev) => (prev.includes(command) ? prev.filter((c) => c !== command) : [...prev, command]));
  const toggleRest = (key) =>
    setSelectedRest((prev) => (prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]));

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!name && !nameInput.trim()) {
      setError("コマンドセット名を入力してください。");
      return;
    }
    if (!ready) {
      setError("ベンダー・タイプを選択してください。");
      return;
    }
    setSaving(true);
    onSavingChange?.(true);
    setError(null);
    const payload = {
      vendor,
      type,
      description: description.trim() || null,
      cli: selectedCli,
      rest: selectedRest,
    };
    if (!name) payload.name = nameInput.trim();
    onSubmit(payload)
      .catch((err) => setError(err.message))
      .finally(() => { setSaving(false); onSavingChange?.(false); });
  };

  return (
    <form className="flex min-h-0 flex-1 flex-col gap-3" onSubmit={handleSubmit}>
      <div className="grid shrink-0 grid-cols-3 gap-3">
        <div className="space-y-1">
          <Label htmlFor={`${id}-name`} className="text-sm font-semibold">コマンドセット名</Label>
          {name ? (
            <Input id={`${id}-name`} className="h-8" value={name} disabled />
          ) : (
            <Input
              id={`${id}-name`}
              autoFocus
              className="h-8"
              placeholder="例: cisco_ios_full"
              value={nameInput}
              onChange={(e) => setNameInput(e.target.value)}
            />
          )}
        </div>
        <div className="space-y-1">
          <Label htmlFor={`${id}-vendor`} className="text-sm font-semibold">ベンダー</Label>
          <Select id={`${id}-vendor`} className="h-8" value={vendor} onChange={(e) => handleVendorChange(e.target.value)}>
            <option value="" disabled>
              選択してください
            </option>
            {vendors.map((v) => (
              <option key={v} value={v}>
                {v}
              </option>
            ))}
          </Select>
        </div>
        <div className="space-y-1">
          <Label htmlFor={`${id}-type`} className="text-sm font-semibold">タイプ</Label>
          <Select id={`${id}-type`} className="h-8" value={type} onChange={(e) => handleTypeChange(e.target.value)} disabled={!vendor}>
            <option value="" disabled>
              {vendor ? "選択してください" : "先にベンダーを選択"}
            </option>
            {types.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </Select>
        </div>
      </div>

      <div className="shrink-0 space-y-1">
        <Label htmlFor={`${id}-desc`} className="text-sm font-semibold">説明(任意)</Label>
        <Input id={`${id}-desc`} autoFocus={Boolean(name)} className="h-8" value={description} onChange={(e) => setDescription(e.target.value)} />
      </div>

      <CommandPicker
        ready={ready}
        commands={commands}
        selectedCli={selectedCli}
        selectedRest={selectedRest}
        onToggleCli={toggleCli}
        onToggleRest={toggleRest}
      />

      {error && <p role="alert" className="shrink-0 text-sm text-destructive">{error}</p>}
      <DialogFooter className="mt-0 shrink-0">
        <Button size="sm" variant="outline" onClick={onCancel} disabled={saving}>
          キャンセル
        </Button>
        <Button size="sm" type="submit" disabled={saving}>
          {saving ? "保存中..." : submitLabel}
        </Button>
      </DialogFooter>
    </form>
  );
}

// CommandSetForm と同じレイアウトの、編集不可(表示専用)版。コマンド選択の
// 部分は選択肢一覧(CommandPicker)を出さず、実際に選択されているコマンドだけを
// 表示する。
function CommandSetView({ name, entry, catalog }) {
  const rows = [
    ...entry.cli.map((command) => ({ command, kind: "cli" })),
    ...entry.rest.map((command) => ({ command, kind: "rest" })),
  ];
  const commands = catalog?.[entry.vendor]?.[entry.type] ?? {};

  return (
    <div className="flex min-h-0 flex-1 flex-col gap-3">
      <div className="grid shrink-0 grid-cols-3 gap-3">
        <div className="space-y-1">
          <Label className="text-sm font-semibold">コマンドセット名</Label>
          <p className="text-sm font-medium">{name}</p>
        </div>
        <div className="space-y-1">
          <Label className="text-sm font-semibold">ベンダー</Label>
          <div>
            <Badge className={deviceVendorColor(entry.vendor)}>{entry.vendor}</Badge>
          </div>
        </div>
        <div className="space-y-1">
          <Label className="text-sm font-semibold">タイプ</Label>
          <div>
            <Badge className={deviceTypeColor(entry.type)}>{entry.type}</Badge>
          </div>
        </div>
      </div>

      <div className="shrink-0 space-y-1">
        <Label className="text-sm font-semibold">説明</Label>
        <p className="text-sm">{entry.description || "-"}</p>
      </div>

      <div className="flex min-h-0 w-full max-w-xl flex-col gap-1.5">
        <Label className="shrink-0 text-sm font-semibold">選択中のコマンド({rows.length} 件)</Label>
        <SelectedCommandsTable
          rows={rows}
          commands={commands}
          emptyMessage="コマンドが選択されていません"
        />
      </div>
    </div>
  );
}

export default function CommandSetsPage() {
  const commandSetsQuery = useCommandSets();
  const catalogQuery = useCommandCatalog();
  const devicesQuery = useDevices();
  const commandSets = commandSetsQuery.data ?? null;
  const catalog = catalogQuery.data ?? NO_CATALOG;
  const invalidate = useInvalidate();
  const [filters, setFilters] = useState(EMPTY_FILTERS);
  const [pageInput, setPage] = useState(0);
  const [creating, setCreating] = useState(false);
  const [editingName, setEditingName] = useState(null);
  const [viewingName, setViewingName] = useState(null);
  const [saving, setSaving] = useState(false);
  const confirm = useConfirm();

  const reload = () => invalidate(queryKeys.commandSets);

  const setFilter = (key) => (value) => {
    setPage(0);
    setFilters((prev) => ({ ...prev, [key]: value }));
  };

  const rows = useMemo(() => {
    if (!commandSets) return [];
    // ベンダー > タイプ > コマンドセット名 の昇順。
    return Object.entries(commandSets).sort(
      ([nameA, a], [nameB, b]) => a.vendor.localeCompare(b.vendor) || a.type.localeCompare(b.type) || nameA.localeCompare(nameB)
    );
  }, [commandSets]);
  const vendors = useMemo(
    () => Array.from(new Set(rows.map(([, entry]) => entry.vendor))).sort(),
    [rows]
  );
  const types = useMemo(
    () => Array.from(new Set(rows.map(([, entry]) => entry.type))).sort(),
    [rows]
  );
  // コマンドセットごとの使用中の機器の数(機器一覧の command_set 列から数える)。削除の
  // 可否(使用中は 409 で断られる)を一覧で先に分かるようにする。機器一覧が読めないときは null。
  const deviceCounts = useMemo(() => {
    if (!devicesQuery.data) return null;
    const counts = {};
    for (const d of devicesQuery.data) {
      const name = d.meta?.command_set;
      if (name) counts[name] = (counts[name] ?? 0) + 1;
    }
    return counts;
  }, [devicesQuery.data]);
  const nameMatcher = useMemo(() => compileTextQuery(filters.name), [filters.name]);
  const descriptionMatcher = useMemo(() => compileTextQuery(filters.description), [filters.description]);
  const filtered = useMemo(() => {
    return rows.filter(([setName, entry]) => {
      if (!nameMatcher.test(setName)) return false;
      if (filters.vendor && entry.vendor !== filters.vendor) return false;
      if (filters.type && entry.type !== filters.type) return false;
      if (!descriptionMatcher.test(entry.description)) return false;
      return true;
    });
  }, [rows, filters, nameMatcher, descriptionMatcher]);

  const { page, pageCount, rangeStart, rangeEnd } = usePageRange(filtered.length, pageInput);
  // 列の並べ替え(hooks/useSort.js)。使用機器数は機器一覧の読み込みに依存するので、
  // 比べる値の組はそれに合わせて作り直す。
  const sortGetters = useMemo(() => ({
    name: ([name]) => name,
    vendor: ([, e]) => e.vendor,
    type: ([, e]) => e.type,
    description: ([, e]) => e.description,
    cli: ([, e]) => e.cli.length,
    rest: ([, e]) => e.rest.length,
    devices: ([name]) => (deviceCounts ? deviceCounts[name] ?? 0 : null),
  }), [deviceCounts]);
  const { sorted, sort, toggle: toggleSort } = useSort(filtered, sortGetters, () => setPage(0));
  const pageRows = usePageSlice(sorted, page);

  const handleCreate = (payload) =>
    createCommandSet(payload).then(() => {
      setCreating(false);
      toast.success(`コマンドセット '${payload.name}' を作成しました`);
      return reload();
    });
  const handleUpdate = (name) => (payload) =>
    updateCommandSet(name, payload).then(() => {
      setEditingName(null);
      toast.success(`コマンドセット '${name}' を保存しました`);
      return reload();
    });
  const handleDelete = async (name) => {
    const ok = await confirm({
      title: `コマンドセット '${name}' を削除しますか?`,
      description: "この操作は取り消せません。",
      confirmLabel: "削除",
      destructive: true,
    });
    if (!ok) return;
    try {
      await deleteCommandSet(name);
      toast.success(`コマンドセット '${name}' を削除しました`);
      await reload();
    } catch (e) {
      toast.error(`削除できませんでした: ${e.message}`);
    }
  };

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="text-sm text-muted-foreground">
          {commandSetsQuery.isPending ? <LoadingText /> : commandSetsQuery.data ? `${rangeStart}-${rangeEnd} / ${filtered.length} 件` : "-"}
        </p>
        <div className="flex items-center gap-2">
          <Pagination page={page} pageCount={pageCount} onPageChange={setPage} />
          <FileTransferButtons
            onDownload={downloadCommandSetFiles}
            downloadLabel="YAMLダウンロード"
            uploadLabel="YAMLアップロード"
            accept=".zip,.yaml"
            onUpload={uploadCommandSetFiles}
            onUploaded={() => reload()}
          />
          <Button size="sm" onClick={() => { setEditingName(null); setCreating((v) => !v); }}>
            <Plus /> 新規作成
          </Button>
        </div>
      </div>
      <LoadError what="コマンドセット" error={commandSetsQuery.error} onRetry={commandSetsQuery.refetch} />
      <LoadError what="コマンドカタログ" error={catalogQuery.error} onRetry={catalogQuery.refetch} />
      <LoadError what="機器一覧" error={devicesQuery.error} onRetry={devicesQuery.refetch} />

      <Table className="min-w-[62rem] table-fixed" containerClassName="max-h-[78vh] overflow-y-auto rounded-md border bg-card">
          <TableHeader className="sticky top-0 z-10 bg-muted">
            <TableRow>
              <SortableHead className="w-48" sortKey="name" sort={sort} onSort={toggleSort}>コマンドセット</SortableHead>
              <SortableHead className="w-28" sortKey="vendor" sort={sort} onSort={toggleSort}>ベンダー</SortableHead>
              <SortableHead className="w-28" sortKey="type" sort={sort} onSort={toggleSort}>タイプ</SortableHead>
              <SortableHead sortKey="description" sort={sort} onSort={toggleSort}>説明</SortableHead>
              <SortableHead className="w-20" sortKey="cli" sort={sort} onSort={toggleSort}>CLI</SortableHead>
              <SortableHead className="w-20" sortKey="rest" sort={sort} onSort={toggleSort}>REST</SortableHead>
              <SortableHead className="w-28" sortKey="devices" sort={sort} onSort={toggleSort}>使用機器</SortableHead>
              <TableHead className="w-24">操作</TableHead>
            </TableRow>
            <TableRow className="hover:bg-transparent">
              <TableHead className="py-1.5">
                <TextFilter value={filters.name} onChange={setFilter("name")} placeholder="絞り込み" />
              </TableHead>
              <TableHead className="py-1.5">
                <SelectFilter value={filters.vendor} onChange={setFilter("vendor")} options={vendors} />
              </TableHead>
              <TableHead className="py-1.5">
                <SelectFilter value={filters.type} onChange={setFilter("type")} options={types} />
              </TableHead>
              <TableHead className="py-1.5">
                <TextFilter value={filters.description} onChange={setFilter("description")} placeholder="絞り込み" />
              </TableHead>
              <TableHead className="py-1.5" />
              <TableHead className="py-1.5" />
              <TableHead className="py-1.5" />
              <TableHead className="py-1.5" />
            </TableRow>
          </TableHeader>
          <TableBody>
            {pageRows.map(([name, entry]) => (
              <ClickableRow
                key={name}
                className="hover:bg-accent"
                onActivate={() => setViewingName(name)}
              >
                <TableCell className="font-medium">
                  <HighlightMatch text={name} matcher={nameMatcher} />
                </TableCell>
                <TableCell>
                  <Badge className={deviceVendorColor(entry.vendor)}>{entry.vendor}</Badge>
                </TableCell>
                <TableCell>
                  <Badge className={deviceTypeColor(entry.type)}>{entry.type}</Badge>
                </TableCell>
                <TableCell className="text-muted-foreground">
                  {entry.description ? <HighlightMatch text={entry.description} matcher={descriptionMatcher} /> : "-"}
                </TableCell>
                <TableCell className="text-muted-foreground">{entry.cli.length} 件</TableCell>
                <TableCell className="text-muted-foreground">{entry.rest.length} 件</TableCell>
                <TableCell className="text-muted-foreground">
                  {deviceCounts ? `${deviceCounts[name] ?? 0} 台` : "-"}
                </TableCell>
                <TableCell>
                  <div className="flex gap-1">
                    <IconButton
                      label={`${name} を編集`}
                      onClick={(e) => { e.stopPropagation(); setCreating(false); setEditingName(name); }}
                    >
                      <Pencil />
                    </IconButton>
                    <IconButton
                      label={`${name} を削除`}
                      variant="destructive-outline"
                      onClick={(e) => { e.stopPropagation(); handleDelete(name); }}
                    >
                      <Trash2 />
                    </IconButton>
                  </div>
                </TableCell>
              </ClickableRow>
            ))}
            <TableStatusRow
              colSpan={8}
              isPending={commandSetsQuery.isPending}
              isError={commandSetsQuery.isError}
              isEmpty={filtered.length === 0}
              emptyText="該当するコマンドセットがありません"
            />
          </TableBody>
      </Table>

      <Dialog
        open={creating || editingName !== null}
        onClose={() => { setCreating(false); setEditingName(null); }}
        title={creating ? "コマンドセットを新規作成" : `コマンドセットを編集: ${editingName}`}
        className={cn("max-w-8xl", DIALOG_FULL_HEIGHT)}
        contentClassName={cn(DIALOG_CONTENT_FLEX, "flex-1")}
        dismissible={false}
        busy={saving}
      >
        {/* 選択肢はコマンドカタログから作るので、読み込みが終わるまでフォームを出さない
            (出すと「このベンダー・タイプのコマンドカタログに定義がありません」と誤って表示される)。 */}
        {(creating || editingName !== null) && !catalogQuery.data && (
          catalogQuery.isError
            ? <LoadError what="コマンドカタログ" error={catalogQuery.error} onRetry={catalogQuery.refetch} />
            : <LoadingText />
        )}
        {creating && catalogQuery.data && (
          <CommandSetForm
            catalog={catalog}
            submitLabel="作成"
            onCancel={() => setCreating(false)}
            onSubmit={handleCreate}
            onSavingChange={setSaving}
          />
        )}
        {editingName !== null && catalogQuery.data && (
          <CommandSetForm
            name={editingName}
            initial={commandSets?.[editingName]}
            catalog={catalog}
            submitLabel="保存"
            onCancel={() => setEditingName(null)}
            onSubmit={handleUpdate(editingName)}
            onSavingChange={setSaving}
          />
        )}
      </Dialog>

      <Dialog
        open={viewingName !== null}
        onClose={() => setViewingName(null)}
        title={`コマンドセット: ${viewingName}`}
        className={cn("max-w-3xl", DIALOG_FULL_HEIGHT)}
        contentClassName={cn(DIALOG_CONTENT_FLEX, "flex-1")}
      >
        {viewingName !== null && commandSets?.[viewingName] && (
          <CommandSetView name={viewingName} entry={commandSets[viewingName]} catalog={catalog} />
        )}
      </Dialog>
    </div>
  );
}
