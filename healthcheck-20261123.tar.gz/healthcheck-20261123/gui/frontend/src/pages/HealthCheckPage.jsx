import { useMemo, useRef, useState } from "react";
import { useQueries } from "@tanstack/react-query";
import { toast } from "sonner";
import { runHealthcheckStream, listSnapshots } from "../api/client";
import { queryKeys, useCommandCatalog, useCommandSets, useDeviceList, useInvalidate } from "../api/queries";
import NoiseOverridesPanel from "@/components/NoiseOverridesPanel";
import CommandSetCell from "@/components/CommandSetCell";
import { checkCommandSet, COMMAND_SET_INVALID_MESSAGE } from "@/lib/commandSetCheck";
import { EMPTY_NOISE_OVERRIDES, summarizeNoiseOverrides, toNoiseOverrides } from "@/lib/noiseOverrides";
import { useConfirm } from "@/hooks/useConfirm";
import { downloadJson } from "@/lib/download";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell, ClickableRow } from "@/components/ui/table";
import { Dialog, RESULT_DIALOG_WIDTH, DIALOG_CONTENT_FLEX } from "@/components/ui/dialog";
import { Spinner, RunningBadge, Elapsed, ProgressBar } from "@/components/Running";
import DeviceSelector, { DEVICE_TABLE_WIDTH } from "@/components/DeviceSelector";
import RunLogPanel from "@/components/RunLogPanel";
import { useRunGuard } from "@/hooks/useRunGuard";
import { useStepFocus } from "@/hooks/useStepFocus";
import { formatDateTime } from "@/lib/format";
import { deviceVendorColor, deviceTypeColor } from "@/lib/deviceTypeColor";
import { Play, Square, Download, ScrollText } from "lucide-react";
import { TextFilter, SelectFilter } from "@/components/TableFilters";
import { DeviceDetail } from "@/components/HealthCheckDetail";
import { STATUS_VARIANT, STATUS_SOFT_CLASS, ZERO_COUNT_CLASS, countCommandsByStatus } from "@/lib/statusVariant";
import { cn } from "@/lib/utils";
import HighlightMatch from "@/components/HighlightMatch";
import { EMPTY_TEXT_QUERY, compileTextQuery } from "@/lib/textQuery";
import { useSort } from "@/hooks/useSort";
import SortableHead from "@/components/SortableHead";


// before/after の snapshot_ids[host] は "now"(今すぐ取得)/ "latest"(最新)/
// 実際の snapshot id のいずれか。未設定(host のキーが無い)は defaultChoice
// (before は "latest"、after は "now"。機器を選択した直後の既定値)を返す。
function getChoice(target, host, defaultChoice) {
  return target.snapshot_ids?.[host] ?? defaultChoice;
}

// 「スナップショットとして保存する」はホストごとに個別に持つ(choice==="now" の
// 時だけ意味を持つ)。未設定は false。
function getSave(target, host) {
  return target.saves?.[host] ?? false;
}

// before/after の1つを POST /healthcheck/stream が受け付けるホストごとの形
// ({host: {mode:"now",save} | {mode:"snapshot",snapshot_id}})に変換する。
// "latest" は byHost(取得済みの一覧)から現時点の最新へその場で解決する
// (これはネットワークI/O不要でここで完結できる)。実際の取得・保存有無の
// 混在解決・進捗配信はサーバ側(POST /healthcheck/stream)が行う。「今すぐ取得・
// 保存しない」ホストの一時データ(InMemoryDataStore。そのリクエスト限り)は
// 後続のリクエストから参照できないため、取得と比較は1リクエスト内で完結させる。
function buildHostTargets(target, hosts, byHost, defaultChoice) {
  const out = {};
  for (const host of hosts) {
    const choice = getChoice(target, host, defaultChoice);
    if (choice === "now") {
      out[host] = { mode: "now", save: getSave(target, host) };
    } else if (choice === "latest") {
      const latest = (byHost[host] ?? [])[0];
      out[host] = latest
        ? { mode: "snapshot", snapshot_id: latest.id }
        : { mode: "now", save: getSave(target, host) }; // 履歴が無ければ今すぐ取得にフォールバック
    } else {
      out[host] = { mode: "snapshot", snapshot_id: choice };
    }
  }
  return out;
}

// 最新のスナップショットに添える印。日時の後ろに全角空白(U+3000)を挟んで「日時 ●最新」の
// 形で出す(2026-11-22 ユーザー指示)。将来、定時に取得したものを同じ形の「日時 ★ゴールド
// イメージ」として選べるようにする構想があり、それと並べて見分けられる形にしている。
const LATEST_MARK = "\u3000●最新";
// 取得に失敗したスナップショットに添える印(同じ形で「日時 ×取得失敗」)。
const FAILED_MARK = "\u3000×取得失敗";

// 確認画面の表で、1機器分の before/after セルに表示する文言。
// "now" は保存有無も添える。"latest" は現時点の最新スナップショットの時刻を
// (解決できていれば)添える。それ以外は指定されたスナップショットの時刻を表示する。
function describeChoice(target, host, byHost, defaultChoice, loading) {
  const choice = getChoice(target, host, defaultChoice);
  if (choice === "now") {
    return getSave(target, host) ? "今すぐ取得(保存する)" : "今すぐ取得";
  }
  if (loading) return "読み込み中...";
  const list = byHost[host] ?? [];
  if (choice === "latest") {
    const latest = list[0];
    return latest ? `${formatDateTime(latest.taken_at)}${LATEST_MARK}` : "最新(スナップショットが無いため今すぐ取得)";
  }
  const snap = list.find((s) => s.id === choice);
  if (!snap) return choice;
  // 一覧から選んだものがその時点の最新なら、「最新を選択」と同じく印を付ける(選択リストの
  // 表示とそろえる。値は固定の ID なので、後から新しい取得があっても追従はしない)。
  return snap.id === list[0]?.id ? `${formatDateTime(snap.taken_at)}${LATEST_MARK}` : formatDateTime(snap.taken_at);
}


// 選択中の全機器について、host ごとの snapshot 一覧を読み込む。機器ごとに別々に
// キャッシュするので、機器を1台足しても他の機器は読み直さない。enabled が false の間
// (機器を選んでいる最中)は読み込まない(以前は1台選ぶたびに選択中の全機器分を
// 読み直していた)。GET /snapshots は taken_at 降順(新しい順)で返すため、
// byHost[host][0] が常にその機器の最新の成功スナップショットになる。失敗したスナップ
// ショット(success: false。多くは refs が空でコマンド結果を持たない)は
// before/after の比較対象として選べても意味が無いため、byHost からは除外する
// (プルダウンの選択肢・「最新を選択」の自動解決の両方に効く)。attemptsByHost は失敗も含めた全件(新しい順)で、プルダウンに直近の取得の成否を出すのに使う。
function useSnapshotsByHost(hosts, enabled) {
  const results = useQueries({
    queries: hosts.map((h) => ({
      queryKey: [...queryKeys.snapshots, "host", h],
      // 一覧ではなく「この機器の履歴から before/after を選ぶ」用途のため、ページングは
      // せず limit を上限いっぱい(1000)にして丸ごと読む。
      queryFn: () => listSnapshots({ host: h, limit: 1000 }),
      enabled,
    })),
  });
  const byHost = {};
  const attemptsByHost = {};
  hosts.forEach((h, i) => {
    const items = results[i]?.data?.items;
    if (items) {
      byHost[h] = items.filter((s) => s.success);
      attemptsByHost[h] = items;
    }
  });
  const loading = enabled && results.some((r) => r.isPending);
  const error = results.find((r) => r.error)?.error?.message ?? null;
  return { byHost, attemptsByHost, loading, error };
}

// before/after 列の操作行(他の表の絞り込み行と同じ、列タイトルの下の行に置く)。
// 表示中の全ホストへ一括で "今すぐ取得"/"最新"、保存有無を適用するトリガーを
// ここに置く。ホストごとの個別状態は TargetCell(各行のボタン・プルダウン・
// 保存チェックボックス)側が持つため、ここはあくまで一括操作のトリガーであり、
// ボタン自体は選択状態を持たない(常に outline)。保存チェックボックスだけは
// 性質上どうしても on/off の見た目が要るため、表示中の全ホストが保存 on なら
// チェック済みで表示する(いわゆる「全選択」チェックボックスと同じ考え方)。
function TargetColumnControls({ value, onChange, hosts }) {
  const applyChoiceToAll = (choice) => {
    const snapshot_ids = { ...value.snapshot_ids };
    for (const host of hosts) snapshot_ids[host] = choice;
    onChange({ ...value, snapshot_ids });
  };
  const applySaveToAll = (checked) => {
    const saves = { ...value.saves };
    for (const host of hosts) saves[host] = checked;
    onChange({ ...value, saves });
  };
  const allSaved = hosts.length > 0 && hosts.every((h) => getSave(value, h));

  return (
    <div className="space-y-1">
      <div className="flex gap-1">
        <Button size="sm" variant="outline" onClick={() => applyChoiceToAll("now")}>
          今すぐ取得
        </Button>
        <Button size="sm" variant="outline" onClick={() => applyChoiceToAll("latest")}>
          最新を選択
        </Button>
      </div>
      <Label className="flex items-center gap-1 text-xs font-normal text-muted-foreground">
        <Checkbox checked={allSaved} onChange={(e) => applySaveToAll(e.target.checked)} />
        スナップショットとして保存する
      </Label>
    </div>
  );
}

// プルダウンの1件分の文言。attempts は taken_at 降順(新しい順)なので、成功した中で最初の
// ものが最新。失敗した取得は比較に使えないため選べない形(disabled)で「取得失敗」と出す
// (いつ失敗したかが分かるように、一覧からは消さない)。一覧はまとまりに分けず、取得時刻の
// 新しい順に並べるだけにする(2026-11-22 ユーザー指示)。
function snapshotOptionLabel(snapshot, isLatest) {
  const time = formatDateTime(snapshot.taken_at);
  if (!snapshot.success) return `${time}${FAILED_MARK}`;
  return isLatest ? `${time}${LATEST_MARK}` : time;
}

// before/after 列の1機器分のセル。「今すぐ取得」「最新を選択」ボタン+プルダウンを
// 機器ごとに持つ。現在の状態(getChoice)が "now"/"latest" ならそれぞれのボタンを
// 選択色にし、プルダウンでそれ以外(実際のスナップショット)を選ぶとボタンは
// どちらも非選択の見た目に戻る("now"/"latest" と一致しなくなるため)。
// プルダウン自体は「今すぐ取得」も選択肢として持ち、"latest" の間は見た目上
// 現在の最新スナップショットを選んだ状態で表示する(値そのものは "latest" の
// ままなので、byHost が更新されればボタンの色・プルダウンの表示位置は
// 自動的に最新へ追従する)。「スナップショットとして保存する」もホストごとに
// 個別に持ち、choice==="now" の時だけ表示する(それ以外は取得自体が発生しない
// ため意味を持たない)。
function TargetCell({ target, host, byHost, attemptsByHost, loading, onSetSnapshotId, onSetSave, defaultChoice }) {
  const choice = getChoice(target, host, defaultChoice);
  const list = byHost[host] ?? [];
  const latestId = list[0]?.id;
  const displayValue = choice === "latest" ? (latestId ?? "") : choice;
  const attempts = attemptsByHost[host] ?? [];

  return (
    <div className="space-y-1">
      <div className="flex flex-wrap items-center gap-1">
        <Button
          size="sm"
          variant={choice === "now" ? "default" : "outline"}
          onClick={() => onSetSnapshotId(host, "now")}
        >
          今すぐ取得
        </Button>
        <Button
          size="sm"
          variant={choice === "latest" ? "default" : "outline"}
          onClick={() => onSetSnapshotId(host, "latest")}
        >
          最新を選択
        </Button>
        {loading ? (
          <span className="text-xs text-muted-foreground">読み込み中...</span>
        ) : (
          <Select
            className="h-8 min-w-0 flex-1 text-xs"
            value={displayValue}
            onChange={(e) => onSetSnapshotId(host, e.target.value)}
          >
            <option value="now">今すぐ取得</option>
            {list.length === 0 && displayValue === "" && (
              <option value="" disabled>
                スナップショットがありません
              </option>
            )}
            {attempts.map((s) => (
              <option key={s.id} value={s.id} disabled={!s.success}>
                {snapshotOptionLabel(s, s.id === latestId)}
              </option>
            ))}
          </Select>
        )}
      </div>
      {choice === "now" && (
        <Label className="flex items-center gap-1 text-xs font-normal text-muted-foreground">
          <Checkbox checked={getSave(target, host)} onChange={(e) => onSetSave(host, e.target.checked)} />
          スナップショットとして保存する
        </Label>
      )}
    </div>
  );
}

function overallStatus(summary) {
  if (summary.ng > 0) return "ng";
  if (summary.error > 0) return "error";
  if (summary.ok > 0) return "ok";
  return "skipped";
}

const EMPTY_RESULT_FILTERS = { host: EMPTY_TEXT_QUERY, vendor: "", type: "", status: "" };

// 結果の表の並べ替え(hooks/useSort.js)で比べる値。判定は文字の順ではなく、見るべき順
// (NG → ERROR → SKIPPED → OK)に並べる。元の並び(並べ替えなし)は機器名の順。
const STATUS_RANK = { ng: 0, error: 1, skipped: 2, ok: 3 };
const RESULT_SORT_GETTERS = {
  host: (f) => f.device.host,
  vendor: (f) => f.device.vendor,
  type: (f) => f.device.type,
  status: (f) => STATUS_RANK[f.status] ?? 9,
};

// 実行中テーブルの1セル(host × before/after)の状態。before/after は
// サーバ側で順番に処理される(before が全機器終わってから after が始まる)ため、
// まだ進捗イベントが届いていないフェーズは「待機中」、今まさに処理中の
// フェーズは「処理中」、イベントが届いたホストは成否に応じて「完了」か「失敗」にする
// (以前は進捗に成否が無く、接続できなかった機器も「完了」と出ていた)。
const PHASE_ORDER = { before: 0, after: 1, comparing: 2 };
function phaseCellStatus(progress, phase, host) {
  const status = progress.statuses[`${phase}:${host}`];
  if (status === "failed") return "失敗";
  if (status === "done") return "完了";
  return PHASE_ORDER[progress.phase] > PHASE_ORDER[phase] ? "完了" : PHASE_ORDER[progress.phase] < PHASE_ORDER[phase] ? "待機中" : "処理中";
}

const CELL_VARIANT = { 完了: "success", 失敗: "warning", 待機中: "secondary" };
function ProgressCellBadge({ label }) {
  if (label === "処理中") return <RunningBadge />;
  return (
    <Badge variant={CELL_VARIANT[label]} className={label === "待機中" ? "opacity-50" : undefined}>
      {label}
    </Badge>
  );
}

// 結果の並び(機器名の昇順。数字を含む名前が見た目どおりに並ぶよう numeric 比較)。
const byHostName = (a, b) => a.device.host.localeCompare(b.device.host, undefined, { numeric: true, sensitivity: "base" });

function hasSaveTarget(...targets) {
  return targets.some((t) => Object.values(t).some((v) => v.mode === "now" && v.save));
}

// 実行中の表の最大の高さと、その右のログ欄の高さ。機器が多いときに両者の下端が
// 揃うよう同じ値にする(Tailwind はクラス名を文字列のまま探すため2つに分けて持つ)。
// ページ自体がスクロールしない範囲で画面の下端まで使う: 画面の高さから、上部の
// ヘッダ(App.jsx の h-14 = 3.5rem)・main の上下の余白(p-6 = 3rem)・この表の上に
// ある「実行中...」の見出しと進捗の文言・進捗バー(約 5rem)を引き、少し余裕を残す。
const RUN_TABLE_MAX_HEIGHT = "max-h-[calc(100vh-12rem)]";
const RUN_LOG_HEIGHT = "h-[calc(100vh-12rem)]";

// 結果画面全体の最大の高さ。画面の高さから上部のヘッダ(3.5rem)と main の上下の余白
// (3rem)を引き、少し余裕を残す。結果画面は縦並びにして見出し・件数・ボタンは
// 大きさを保ち、機器が多いときは表だけが縮んで表の中でスクロールする(ページ全体は
// スクロールしない)。表に高さを直接指定しないのは、見出しやボタンの高さが変わっても
// 計算し直さずに済むようにするため。
const RESULT_MAX_HEIGHT = "max-h-[calc(100vh-7rem)]";

// 「理由」列に並べる件数の種類と並び順。
const REASON_COUNTS = [
  { status: "ok", label: "差分なし" },
  { status: "ng", label: "差分あり" },
  { status: "skipped", label: "スキップ" },
];

// コマンド単位の件数を、ポップアップのコマンドボタンと同じ色のバッジで並べる。
// 機器ごとに位置がずれないよう3種類を常に同じ順で出し、0 件のものは薄くする。
// ERROR の理由の要点。サーバの文は「AFTER 側の取得に失敗しました: connection timeout: TCP
// connection to device failed. Common causes …」のように長く、表の行が何行にも伸びるので、
// 1行目の「:」で区切った先頭2つまで(何が・どう失敗したか)を、文の切れ目(". ")の手前までに
// して出す。全文は行を選んだポップアップに出す(components/HealthCheckDetail.jsx)。
const SHORT_REASON_MAX = 80;
function shortReason(message) {
  if (!message) return "-";
  const firstLine = message.split("\n")[0];
  let text = firstLine.split(": ").slice(0, 2).join(": ");
  const sentenceEnd = text.indexOf(". ");
  if (sentenceEnd >= 0) text = text.slice(0, sentenceEnd);
  if (text.length > SHORT_REASON_MAX) text = `${text.slice(0, SHORT_REASON_MAX)}…`;
  return text;
}

function ReasonCell({ f }) {
  if (f.status === "error") return <span className="text-muted-foreground">{shortReason(f.message)}</span>;
  const counts = countCommandsByStatus(f);
  return (
    <div className="flex flex-wrap gap-1">
      {REASON_COUNTS.map(({ status, label }) => (
        <Badge
          key={status}
          className={cn("border tabular-nums", counts[status] === 0 ? ZERO_COUNT_CLASS : STATUS_SOFT_CLASS[status])}
        >
          {label} {counts[status]}
        </Badge>
      ))}
    </div>
  );
}

// クリックで詳細(コマンドごとの結果)をポップアップ表示する(行の下に展開する形
// だと、その状態のまま「実行」ボタンを誤って再度押す事故が起きやすいため)。
function DeviceRow({ f, onSelect, hostMatcher }) {
  return (
    <ClickableRow className="hover:bg-accent" onActivate={() => onSelect(f)}>
      <TableCell className="font-medium">
        <HighlightMatch text={f.device.host} matcher={hostMatcher} />
      </TableCell>
      <TableCell>
        <Badge className={deviceVendorColor(f.device.vendor)}>{f.device.vendor}</Badge>
      </TableCell>
      <TableCell>
        <Badge className={deviceTypeColor(f.device.type)}>{f.device.type}</Badge>
      </TableCell>
      <TableCell>
        {/* 機器ごとの判定は、総合判定と同じく大文字で表示する(値は小文字のまま)。 */}
        <Badge variant={STATUS_VARIANT[f.status] ?? "secondary"}>{f.status.toUpperCase()}</Badge>
      </TableCell>
      <TableCell>
        <ReasonCell f={f} />
      </TableCell>
    </ClickableRow>
  );
}

export default function HealthCheckPage() {
  const { devices, loading, error: devicesError } = useDeviceList();
  const commandSetsQuery = useCommandSets();
  const commandCatalogQuery = useCommandCatalog();
  const runRequestRef = useRef(null); // 直近の実行で送った内容(結果のダウンロードに今回のノイズ調整を残すため)
  const [selectedHosts, setSelectedHosts] = useState([]);
  const [before, setBefore] = useState({ snapshot_ids: {}, saves: {} });
  const [after, setAfter] = useState({ snapshot_ids: {}, saves: {} });
  const [step, setStep] = useState("devices"); // devices -> targets -> summary -> running -> result
  const [result, setResult] = useState(null);
  const [details, setDetails] = useState(null); // {host: {before,after: {command: {raw,parsed}}}}
  const [error, setError] = useState(null);
  const [progress, setProgress] = useState(null); // 実行中の進捗。{phase, done, total, statuses}
  const [startedAt, setStartedAt] = useState(null);  // 実行開始時刻(経過時間の表示用)
  const [logSince, setLogSince] = useState(null);     // ログ欄の起点(開始イベントのサーバ時刻)
  const [logFocusHost, setLogFocusHost] = useState(null); // ログ欄を絞り込む機器(null は全機器)
  const [showResultLog, setShowResultLog] = useState(false); // 結果画面でログ欄を開いているか
  const abortRef = useRef(null);                       // 実行中の受け取りを中止する AbortController
  const confirm = useConfirm();
  const invalidate = useInvalidate();
  // 確認ステップの「差分判定のノイズを調整する(この実行のみで有効)」。チェックを付けたときだけ編集の欄を出し、
  // 調整を実行に使う。チェックを外しても入力は残す(うっかり外して消えないように)が、実行には
  // 使わない。どちらも画面の中だけで持ち、「最初からやり直す」で消える。
  const [noiseAdjust, setNoiseAdjust] = useState(false);
  const [noiseOverrides, setNoiseOverrides] = useState(EMPTY_NOISE_OVERRIDES);
  const noiseSummary = summarizeNoiseOverrides(noiseOverrides);
  const noiseProblems = noiseAdjust ? noiseSummary.problems : [];
  // 確認ステップのコマンドセットの検査(スナップショット取得と同じ。lib/commandSetCheck.js)。
  // 読み込み中は判定しない。
  const commandSetInvalid = Boolean(commandSetsQuery.data) && selectedHosts.some(
    (h) => !checkCommandSet(devices.find((d) => d.host === h), commandSetsQuery.data).valid
  );
  useRunGuard("healthcheck", step === "running");
  const pageRef = useStepFocus(step);
  const [targetHostFilter, setTargetHostFilter] = useState(EMPTY_TEXT_QUERY);
  const [selectedFinding, setSelectedFinding] = useState(null); // 結果画面でポップアップ表示中の機器
  const [resultFilters, setResultFilters] = useState(EMPTY_RESULT_FILTERS);
  const setResultFilter = (key) => (value) => setResultFilters((prev) => ({ ...prev, [key]: value }));

  // 結果の表も他の一覧表と同じく列フィルタで絞り込める(機器数が多いときに
  // ng の機器だけを見る、といった使い方のため)。結果は取得済みの配列なので
  // 絞り込みはすべてクライアント側で行う。
  const findings = useMemo(() => result?.findings ?? [], [result]);
  const resultVendors = useMemo(
    () => Array.from(new Set(findings.map((f) => f.device.vendor))).sort(),
    [findings]
  );
  const resultTypes = useMemo(() => Array.from(new Set(findings.map((f) => f.device.type))).sort(), [findings]);
  const resultStatuses = useMemo(
    () => Array.from(new Set(findings.map((f) => f.status.toUpperCase()))).sort(),
    [findings]
  );
  const resultHostMatcher = useMemo(() => compileTextQuery(resultFilters.host), [resultFilters.host]);
  const filteredFindings = useMemo(() => {
    return findings
      .filter((f) => {
        if (!resultHostMatcher.test(f.device.host)) return false;
        if (resultFilters.vendor && f.device.vendor !== resultFilters.vendor) return false;
        if (resultFilters.type && f.device.type !== resultFilters.type) return false;
        if (resultFilters.status && f.status.toUpperCase() !== resultFilters.status) return false;
        return true;
      })
      .sort(byHostName);
  }, [findings, resultFilters, resultHostMatcher]);
  const { sorted: sortedFindings, sort: resultSort, toggle: toggleResultSort } =
    useSort(filteredFindings, RESULT_SORT_GETTERS);

  // before/after を同じ表で扱うため、選択機器のスナップショット一覧はここで1回だけ
  // 取得し、両方で共有する。
  const { byHost, attemptsByHost, loading: snapshotsLoading, error: snapshotsError } =
    useSnapshotsByHost(selectedHosts, step !== "devices");

  // ホスト名検索の結果に絞った一覧。表の表示行と、before/after の
  // 今すぐ取得・最新を選択ボタンの適用範囲の両方をこれに合わせる
  // (実行時の対象機器はあくまで selectedHosts 全体のまま変わらない)。
  const targetHostMatcher = useMemo(() => compileTextQuery(targetHostFilter), [targetHostFilter]);
  const targetHosts = selectedHosts.filter((h) => targetHostMatcher.test(h));

  // 確認ステップの「ノイズの調整」に出す、選んだ機器が使うコマンドセットとそのコマンド
  // (コマンドセット名の順)。コマンドセットが未設定・見つからない機器は出さない(その機器は
  // 確認ステップの表で分かる)。
  const noiseGroups = useMemo(() => {
    const sets = commandSetsQuery.data ?? {};
    const names = new Set(
      selectedHosts.map((h) => devices.find((d) => d.host === h)?.meta?.command_set).filter((n) => n && sets[n])
    );
    return [...names].sort().map((name) => ({
      name,
      vendor: sets[name].vendor,
      type: sets[name].type,
      commands: [...sets[name].cli, ...sets[name].rest],
    }));
  }, [selectedHosts, devices, commandSetsQuery.data]);

  const setBeforeSnapshotId = (host, id) =>
    setBefore((prev) => ({ ...prev, snapshot_ids: { ...prev.snapshot_ids, [host]: id } }));
  const setAfterSnapshotId = (host, id) =>
    setAfter((prev) => ({ ...prev, snapshot_ids: { ...prev.snapshot_ids, [host]: id } }));
  const setBeforeSave = (host, checked) =>
    setBefore((prev) => ({ ...prev, saves: { ...prev.saves, [host]: checked } }));
  const setAfterSave = (host, checked) =>
    setAfter((prev) => ({ ...prev, saves: { ...prev.saves, [host]: checked } }));

  const toggleHost = (host) => {
    setSelectedHosts((prev) =>
      prev.includes(host) ? prev.filter((h) => h !== host) : [...prev, host]
    );
  };

  // 列フィルタで絞り込んだ分をまとめて選択/解除する(1回の更新で反映する)。
  const selectManyHosts = (hosts, selected) =>
    setSelectedHosts((prev) => {
      const next = new Set(prev);
      for (const h of hosts) {
        if (selected) next.add(h);
        else next.delete(h);
      }
      return [...next];
    });

  // POST /healthcheck/stream で機器ごとの取得進捗(before取得→after取得→比較)を
  // SSEで受け取りながら実行する。実行中は running ステップに
  // 移る(summary 画面に残ったままだと「実行」ボタンが結果のすぐ上に居座り続け、
  // 誤って再度押してしまいやすいため)。
  const run = () => {
    setError(null);
    setResult(null);
    setShowResultLog(false);
    setStep("running");
    setStartedAt(Date.now());
    setLogSince(null);
    setLogFocusHost(null);
    setProgress({ phase: "before", done: 0, total: selectedHosts.length, statuses: {} });

    const beforeTargets = buildHostTargets(before, selectedHosts, byHost, "latest");
    const afterTargets = buildHostTargets(after, selectedHosts, byHost, "now");
    const saving = hasSaveTarget(beforeTargets, afterTargets);
    let finalResult = null;
    let finalDetails = null;
    const controller = new AbortController();
    abortRef.current = controller;

    const body = { hosts: selectedHosts, before: beforeTargets, after: afterTargets, noise_overrides: noiseAdjust ? toNoiseOverrides(noiseOverrides) : {} };
    runRequestRef.current = body;
    runHealthcheckStream(body, (event) => {
      if (event.type === "start") {
        setLogSince(event.log_since);
      } else if (event.type === "progress") {
        setProgress((prev) => ({
          ...prev,
          phase: event.phase,
          done: event.done,
          total: event.total,
          statuses: {
            ...prev.statuses,
            [`${event.phase}:${event.host}`]: event.success === false ? "failed" : "done",
          },
        }));
      } else if (event.type === "phase") {
        // before が全機器終わり after に移った時点で届く。最初の after の機器が
        // 終わるまで表示が「before を取得中」のまま残らないようにする。
        setProgress((prev) => ({ ...prev, phase: event.phase, done: 0, total: event.total }));
      } else if (event.type === "comparing") {
        setProgress((prev) => ({ ...prev, phase: "comparing" }));
      } else if (event.type === "error") {
        setError(event.message);
      } else if (event.type === "complete") {
        finalResult = event.result;
        finalDetails = event.details;
      }
    }, controller.signal)
      .then(() => {
        if (finalResult) {
          setResult(finalResult);
          setDetails(finalDetails);
          setStep("result");
        } else {
          setStep("summary");
        }
      })
      .catch((e) => {
        if (e.name === "AbortError") {
          toast.info("中止しました。取得中だった段階の機器はサーバで最後まで処理されます(保存を指定した分は保存されます)。");
        } else {
          setError(e.message);
        }
        setStep("summary");
      })
      .finally(() => {
        abortRef.current = null;
        // 保存した場合は、スナップショット一覧と before/after の選択肢に新しい分を出す。
        if (saving) invalidate(queryKeys.snapshots);
      });
  };

  const handleAbort = async () => {
    const ok = await confirm({
      title: "実行を中止しますか?",
      description:
        "画面での受け取りを止めます。取得中の段階(BEFORE または AFTER)の機器はサーバで最後まで"
        + "処理され、保存を指定した分は保存されます。まだ始まっていない段階と比較は行いません。",
      confirmLabel: "中止する",
      destructive: true,
    });
    if (ok) abortRef.current?.abort();
  };

  const downloadResult = () => {
    const stamp = new Date().toISOString().replace(/[-:]/g, "").replace(/\..+/, "");
    // 今回だけのノイズ調整も記録する(判定の根拠を後から追えるようにするため)。
    downloadJson(`healthcheck_${stamp}.json`, { result, details, noise_overrides: runRequestRef.current?.noise_overrides ?? {} });
  };

  const handleNextFromDevices = () => {
    if (selectedHosts.length === 0) {
      setError("機器を選択してください。");
      return;
    }
    setError(null);
    setStep("targets");
  };

  const handleReset = () => {
    setSelectedHosts([]);
    setResultFilters(EMPTY_RESULT_FILTERS);
    setBefore({ snapshot_ids: {}, saves: {} });
    setAfter({ snapshot_ids: {}, saves: {} });
    setResult(null);
    setDetails(null);
    setError(null);
    setProgress(null);
    setSelectedFinding(null);
    setTargetHostFilter(EMPTY_TEXT_QUERY);   // 前回の絞り込みが残って機器が見えない、を防ぐ
    setLogFocusHost(null);
    setShowResultLog(false);
    setNoiseAdjust(false);
    setNoiseOverrides(EMPTY_NOISE_OVERRIDES);
    setStep("devices");
  };

  return (
    <div ref={pageRef} className="space-y-6">
      {error && <p className="text-sm text-destructive">{error}</p>}

      {step === "devices" && (
        <div className="space-y-3">
          <h3 tabIndex={-1} data-step-heading className="sr-only">機器選択</h3>
          <DeviceSelector
            devices={devices}
            loading={loading}
            error={devicesError}
            selectedHosts={selectedHosts}
            onToggle={toggleHost}
            onSelectMany={selectManyHosts}
          />
          <Button size="sm" onClick={handleNextFromDevices}>次へ(BEFORE/AFTER)</Button>
        </div>
      )}

      {step === "targets" && (
        <div className="space-y-4">
          <h3 tabIndex={-1} data-step-heading className="text-sm font-semibold outline-none">BEFORE / AFTER を指定</h3>
          {snapshotsError && <p className="text-sm text-destructive">{snapshotsError}</p>}
          <Table className="table-fixed" containerClassName="max-h-[calc(100vh-13rem)] overflow-y-auto rounded-md border bg-card">
              <TableHeader className="sticky top-0 z-10 bg-muted">
                <TableRow>
                  <TableHead className="w-[22%]">ホスト名</TableHead>
                  <TableHead className="w-[39%]">BEFORE</TableHead>
                  <TableHead className="w-[39%]">AFTER</TableHead>
                </TableRow>
                <TableRow className="hover:bg-transparent">
                  <TableHead className="py-1.5">
                    <TextFilter value={targetHostFilter} onChange={setTargetHostFilter} placeholder="絞り込み" />
                  </TableHead>
                  <TableHead className="py-1.5 align-top">
                    <TargetColumnControls value={before} onChange={setBefore} hosts={targetHosts} />
                  </TableHead>
                  <TableHead className="py-1.5 align-top">
                    <TargetColumnControls value={after} onChange={setAfter} hosts={targetHosts} />
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {targetHosts.map((host) => (
                  <TableRow key={host}>
                    <TableCell className="font-medium">
                      <HighlightMatch text={host} matcher={targetHostMatcher} />
                    </TableCell>
                    <TableCell>
                      <TargetCell
                        target={before}
                        host={host}
                        byHost={byHost}
                        attemptsByHost={attemptsByHost}
                        loading={snapshotsLoading}
                        onSetSnapshotId={setBeforeSnapshotId}
                        onSetSave={setBeforeSave}
                        defaultChoice="latest"
                      />
                    </TableCell>
                    <TableCell>
                      <TargetCell
                        target={after}
                        host={host}
                        byHost={byHost}
                        attemptsByHost={attemptsByHost}
                        loading={snapshotsLoading}
                        onSetSnapshotId={setAfterSnapshotId}
                        onSetSave={setAfterSave}
                        defaultChoice="now"
                      />
                    </TableCell>
                  </TableRow>
                ))}
                {targetHosts.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={3} className="text-center text-sm text-muted-foreground">
                      {selectedHosts.length === 0 ? "機器が選択されていません" : "該当する機器がありません"}
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
          </Table>
          <div className="flex items-center gap-2">
            <Button size="sm" variant="outline" onClick={() => setStep("devices")}>
              戻る
            </Button>
            <Button size="sm" onClick={() => setStep("summary")}>次へ(確認)</Button>
          </div>
        </div>
      )}

      {step === "summary" && (
        <div className="space-y-4">
          <h3 tabIndex={-1} data-step-heading className="text-sm font-semibold outline-none">確認({selectedHosts.length} 件)</h3>
          <Table className="table-fixed" containerClassName="max-h-[calc(100vh-13rem)] overflow-y-auto rounded-md border bg-card">
              <TableHeader className="sticky top-0 z-10 bg-muted">
                <TableRow>
                  <TableHead className="w-[17%]">ホスト名</TableHead>
                  <TableHead className="w-[9%]">ベンダー</TableHead>
                  <TableHead className="w-[9%]">タイプ</TableHead>
                  <TableHead className="w-[13%]">コマンドセット</TableHead>
                  <TableHead className="w-[26%]">BEFORE</TableHead>
                  <TableHead className="w-[26%]">AFTER</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {selectedHosts.map((host) => {
                  const device = devices.find((d) => d.host === host);
                  return (
                    <TableRow key={host}>
                      <TableCell className="font-medium">{host}</TableCell>
                      <TableCell>
                        {device && <Badge className={deviceVendorColor(device.vendor)}>{device.vendor}</Badge>}
                      </TableCell>
                      <TableCell>
                        {device && <Badge className={deviceTypeColor(device.type)}>{device.type}</Badge>}
                      </TableCell>
                      <TableCell className="truncate">
                        <CommandSetCell check={checkCommandSet(device, commandSetsQuery.data)} checking={!commandSetsQuery.data} />
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {describeChoice(before, host, byHost, "latest", snapshotsLoading)}
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {describeChoice(after, host, byHost, "now", snapshotsLoading)}
                      </TableCell>
                    </TableRow>
                  );
                })}
                {selectedHosts.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-sm text-muted-foreground">
                      機器が選択されていません
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
          </Table>
          {commandSetInvalid && <p className="text-sm text-destructive">{COMMAND_SET_INVALID_MESSAGE}</p>}
          <div className="flex flex-wrap items-center gap-2">
            <Label className="flex items-center gap-2 text-sm font-normal">
              <Checkbox checked={noiseAdjust} onChange={(e) => setNoiseAdjust(e.target.checked)} />
              差分判定のノイズを調整する(この実行のみで有効)
            </Label>
            {noiseAdjust && noiseSummary.excluded + noiseSummary.added > 0 && (
              <Badge>調整あり</Badge>
            )}
          </div>
          {noiseAdjust && (
            <NoiseOverridesPanel
              groups={noiseGroups}
              catalog={commandCatalogQuery.data}
              value={noiseOverrides}
              onChange={setNoiseOverrides}
            />
          )}
          {noiseProblems.length > 0 && (
            <p role="alert" className="text-sm text-destructive">
              「追加登録のノイズ」の書き方に誤りがあるため実行できません: {noiseProblems[0]}
            </p>
          )}
          <div className="flex items-center gap-2">
            <Button size="sm" variant="outline" onClick={() => setStep("targets")}>
              戻る
            </Button>
            <Button size="sm" onClick={run} disabled={snapshotsLoading || selectedHosts.length === 0 || noiseProblems.length > 0 || commandSetInvalid || !commandSetsQuery.data}>
              <Play />
              実行
            </Button>
            {result && (
              <Button size="sm" variant="outline" onClick={() => setStep("result")}>
                前回の結果を表示
              </Button>
            )}
          </div>
        </div>
      )}

      {step === "running" && (
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Spinner />
            <h3 tabIndex={-1} data-step-heading className="text-sm font-semibold outline-none">実行中...</h3>
            {startedAt && <Elapsed startedAt={startedAt} />}
            <Button size="sm" variant="destructive-outline" className="ml-auto" onClick={handleAbort}>
              <Square /> 中止
            </Button>
          </div>
          {progress && (
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">
                {progress.phase === "before" && `BEFORE を取得中... (${progress.done}/${progress.total})`}
                {progress.phase === "after" && `AFTER を取得中... (${progress.done}/${progress.total})`}
                {progress.phase === "comparing" && "比較中..."}
              </p>
              <ProgressBar done={progress.done} total={progress.total} />
              {/* 表は機器選択時の機器一覧と同じ幅にし、残りの幅にログを出す。
                  画面が狭いときはログが表の下に回り込む。 */}
              <div className="flex flex-wrap items-start gap-4">
                <Table
                  className="table-fixed"
                  containerClassName={cn("w-full overflow-y-auto rounded-md border bg-card", RUN_TABLE_MAX_HEIGHT, DEVICE_TABLE_WIDTH)}
                >
                    <TableHeader className="sticky top-0 z-10 bg-muted">
                      <TableRow>
                        <TableHead className="w-[40%]">ホスト名</TableHead>
                        <TableHead className="w-[30%]">BEFORE</TableHead>
                        <TableHead className="w-[30%]">AFTER</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {selectedHosts.map((host) => (
                        <ClickableRow
                          key={host}
                          selected={logFocusHost === host}
                          title="クリック(または Enter)で、ログをこの機器だけに絞り込む"
                          className={logFocusHost === host ? "bg-accent" : "hover:bg-accent"}
                          onActivate={() => setLogFocusHost((prev) => (prev === host ? null : host))}
                        >
                          <TableCell className="font-medium">{host}</TableCell>
                          <TableCell>
                            <ProgressCellBadge label={phaseCellStatus(progress, "before", host)} />
                          </TableCell>
                          <TableCell>
                            <ProgressCellBadge label={phaseCellStatus(progress, "after", host)} />
                          </TableCell>
                        </ClickableRow>
                      ))}
                    </TableBody>
                </Table>
                <RunLogPanel
                  className={RUN_LOG_HEIGHT}
                  since={logSince}
                  hosts={selectedHosts}
                  focusHost={logFocusHost}
                  onClearFocus={() => setLogFocusHost(null)}
                />
              </div>
            </div>
          )}
        </div>
      )}

      {step === "result" && result && (
        // ログを開いている間は高さの上限を外し、ページ全体をスクロールさせる(上限を付けた
        // ままだと、ログの分だけ結果の表が縮んで見えなくなるため)。
        <div className={cn("flex flex-col gap-4", !showResultLog && RESULT_MAX_HEIGHT)}>
          <div className="shrink-0">
            <div className="flex flex-wrap items-center gap-3">
              <h3 tabIndex={-1} data-step-heading className="text-sm font-semibold outline-none">結果</h3>
              <Badge
                variant={STATUS_VARIANT[overallStatus(result.summary)] ?? "secondary"}
                className="px-3 py-1 text-sm font-bold"
              >
                {overallStatus(result.summary).toUpperCase()}
              </Badge>
              <span className="text-sm text-muted-foreground">
                {Object.entries(result.summary)
                  .map(([k, v]) => `${k.toUpperCase()}: ${v}`)
                  .join(" / ")}
              </span>
            </div>
          </div>
          {/* 件数の行の右に、結果のダウンロードとログの表示を置く(表の下のボタン群から移した)。 */}
          <div className="flex shrink-0 flex-wrap items-center justify-between gap-2">
            <p className="text-sm text-muted-foreground">
              {filteredFindings.length === 0 ? 0 : 1}-{filteredFindings.length} / {filteredFindings.length} 件
            </p>
            <div className="flex flex-wrap gap-2">
              <Button size="sm" variant="outline" onClick={downloadResult}>
                <Download /> 結果をダウンロード(JSON)
              </Button>
              <Button size="sm" variant="outline" onClick={() => setShowResultLog((v) => !v)} aria-expanded={showResultLog}>
                <ScrollText /> {showResultLog ? "ログを隠す" : "この実行のログを表示"}
              </Button>
            </div>
          </div>
          <Table className="table-fixed" containerClassName="min-h-0 overflow-y-auto rounded-md border bg-card">
              <TableHeader className="sticky top-0 z-10 bg-muted">
                <TableRow>
                  <SortableHead className="w-[22%]" sortKey="host" sort={resultSort} onSort={toggleResultSort}>機器</SortableHead>
                  <SortableHead className="w-[12%]" sortKey="vendor" sort={resultSort} onSort={toggleResultSort}>ベンダー</SortableHead>
                  <SortableHead className="w-[12%]" sortKey="type" sort={resultSort} onSort={toggleResultSort}>タイプ</SortableHead>
                  <SortableHead className="w-[14%]" sortKey="status" sort={resultSort} onSort={toggleResultSort}>ステータス</SortableHead>
                  <TableHead className="w-[40%]">理由</TableHead>
                </TableRow>
                <TableRow className="hover:bg-transparent">
                  <TableHead className="py-1.5">
                    <TextFilter value={resultFilters.host} onChange={setResultFilter("host")} placeholder="絞り込み" />
                  </TableHead>
                  <TableHead className="py-1.5">
                    <SelectFilter
                      value={resultFilters.vendor}
                      onChange={setResultFilter("vendor")}
                      options={resultVendors}
                    />
                  </TableHead>
                  <TableHead className="py-1.5">
                    <SelectFilter value={resultFilters.type} onChange={setResultFilter("type")} options={resultTypes} />
                  </TableHead>
                  <TableHead className="py-1.5">
                    <SelectFilter
                      value={resultFilters.status}
                      onChange={setResultFilter("status")}
                      options={resultStatuses}
                    />
                  </TableHead>
                  <TableHead className="py-1.5" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {sortedFindings.map((f) => (
                  <DeviceRow key={f.device.host} f={f} onSelect={setSelectedFinding} hostMatcher={resultHostMatcher} />
                ))}
                {filteredFindings.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center text-sm text-muted-foreground">
                      該当する機器がありません
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
          </Table>
          <div className="flex shrink-0 flex-wrap items-center gap-2">
            <Button size="sm" variant="outline" onClick={() => setStep("summary")}>
              戻る
            </Button>
            <Button size="sm" variant="outline" onClick={handleReset}>
              最初からやり直す
            </Button>
          </div>
          {showResultLog && (
            <RunLogPanel
              className="h-72 shrink-0"
              live={false}
              since={logSince}
              hosts={selectedHosts}
              focusHost={logFocusHost}
              onClearFocus={() => setLogFocusHost(null)}
            />
          )}

          <Dialog
            open={Boolean(selectedFinding)}
            onClose={() => setSelectedFinding(null)}
            title={selectedFinding ? selectedFinding.device.host : ""}
            className={RESULT_DIALOG_WIDTH}
            contentClassName={DIALOG_CONTENT_FLEX}
          >
            {selectedFinding && (
              <DeviceDetail f={selectedFinding} details={details?.[selectedFinding.device.host]} />
            )}
          </Dialog>
        </div>
      )}
    </div>
  );
}
