import { useId, useMemo, useState } from "react";
import { toast } from "sonner";
import { queryKeys, useCommandCatalog, useInvalidate } from "../api/queries";
import { LoadingText, LoadError, TableStatusRow } from "@/components/QueryStatus";
import {
  createCommandCatalogEntry,
  updateCommandCatalogEntry,
  deleteCommandCatalogEntry,
  downloadCommandCatalogFiles,
  uploadCommandCatalogFiles,
} from "../api/client";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell, ClickableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Dialog, DialogFooter } from "@/components/ui/dialog";
import IconButton from "@/components/IconButton";
import { useConfirm } from "@/hooks/useConfirm";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { deviceVendorColor, deviceTypeColor } from "@/lib/deviceTypeColor";
import { TextFilter, SelectFilter } from "@/components/TableFilters";
import HighlightMatch from "@/components/HighlightMatch";
import { EMPTY_TEXT_QUERY, compileTextQuery } from "@/lib/textQuery";
import FileTransferButtons from "@/components/FileTransferButtons";
import Pagination from "@/components/Pagination";
import { usePageRange, usePageSlice } from "@/hooks/usePagination";
import { useSort } from "@/hooks/useSort";
import SortableHead from "@/components/SortableHead";

// REST 由来のコマンドは収集時に必ず parser: json を使う(コア側の不変条件。
// healthcheck/command/command_catalog.py 参照)ため、parser の値だけで CLI/REST を判別できる。
function typeOf(parser) {
  return parser === "json" ? "REST" : "CLI";
}

// 「比較キー」列の表示・絞り込みで共有する判定。compare_keys はパース結果の中の
// list(トップレベル・dict にネストしたもの問わず)の要素を対応付けるためだけに使い、
// パーサ種別は問わない(healthcheck/common/diff.py の normalize 参照)。genie の結果も
// 中に list を含むことがあるため、どのパーサでも設定有無で判定する。
function keyStatusOf(spec) {
  return spec.compare_keys && spec.compare_keys.length > 0 ? "設定済み" : "未設定";
}

// catalog は GET /command-catalog のレスポンスそのまま(vendor -> type -> {command: spec}
// の3階層。コア側の CommandCatalog.by_vendor_type と同じ階層構造)。
function flatten(catalog) {
  const rows = [];
  for (const [vendor, types] of Object.entries(catalog)) {
    for (const [type, commands] of Object.entries(types)) {
      for (const [command, spec] of Object.entries(commands)) {
        rows.push({ vendor, type, command, spec });
      }
    }
  }
  // ベンダー > タイプ > コマンド名 の昇順。
  rows.sort((a, b) => a.vendor.localeCompare(b.vendor) || a.type.localeCompare(b.type) || a.command.localeCompare(b.command));
  return rows;
}

// 列の並べ替え(hooks/useSort.js)で比べる値。
const SORT_GETTERS = {
  vendor: (r) => r.vendor,
  type: (r) => r.type,
  command: (r) => r.command,
  description: (r) => r.spec.description,
  kind: (r) => typeOf(r.spec.parser),
  parser: (r) => r.spec.parser,
  keyStatus: (r) => keyStatusOf(r.spec),
  noise: (r) => r.spec.noise.length,
};

const EMPTY_FILTERS = {
  vendor: "", type: "", command: EMPTY_TEXT_QUERY, description: EMPTY_TEXT_QUERY, type_: "", parser: "", keyStatus: "",
};

// 作成・編集共通のフォーム。vendor/type/command は作成時のみ入力できる(編集時は
// 変更不可。キーそのものの変更はここでは扱わない。CommandSetForm 等と同じ考え方)。
// 新規作成時のベンダー・タイプは、既存カタログに実在するもの(catalog)から選ぶ
// プルダウンにする(CommandSetForm と同じ考え方。表記ゆれを防ぐため)。
function CommandCatalogEntryForm({ vendor, type, command, initial, catalog, onCancel, onSubmit, submitLabel, onSavingChange }) {
  const id = useId();
  const isNew = !vendor;
  const [vendorInput, setVendorInput] = useState(vendor ?? "");
  const [typeInput, setTypeInput] = useState(type ?? "");
  const [commandInput, setCommandInput] = useState(command ?? "");
  // 種別(CLI/REST)を明示的に選ばせる(parser の値だけから連想させない。REST は
  // 常に parser: json 固定なので、種別=REST を選んだ時点で parser は自動的に
  // "json" にする)。
  const [entryType, setEntryType] = useState(initial ? typeOf(initial.parser) : "CLI");
  const [parser, setParser] = useState(initial?.parser ?? "genie");
  const [noise, setNoise] = useState((initial?.noise ?? []).join("\n"));
  const [compareKeys, setCompareKeys] = useState((initial?.compare_keys ?? []).join("\n"));
  const [path, setPath] = useState(initial?.path ?? "");
  const [description, setDescription] = useState(initial?.description ?? "");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  const isRest = entryType === "REST";
  const vendorOptions = useMemo(() => Object.keys(catalog ?? {}).sort(), [catalog]);
  const typeOptions = useMemo(
    () => Object.keys(catalog?.[vendorInput] ?? {}).sort(),
    [catalog, vendorInput]
  );

  const handleVendorChange = (value) => {
    setVendorInput(value);
    // vendor が変わったら type をリセットする(別ベンダーの type を引き継がない)。
    setTypeInput("");
  };

  const handleEntryTypeChange = (value) => {
    setEntryType(value);
    if (value === "REST") {
      setParser("json");
    } else if (parser === "json") {
      setParser("genie");
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (isNew && (!vendorInput || !typeInput || !commandInput.trim())) {
      setError("ベンダー・タイプ・コマンドを入力してください。");
      return;
    }
    if (isRest && !path.trim()) {
      setError("種別がRESTの場合は path を指定してください。");
      return;
    }
    setSaving(true);
    onSavingChange?.(true);
    setError(null);
    const payload = {
      parser,
      noise: noise.split("\n").map((s) => s.trim()).filter(Boolean),
      // 空なら null(未設定)。パーサを切り替えても入力済みの値は消さずに保存する。
      compare_keys: compareKeys.trim()
        ? compareKeys.split("\n").map((s) => s.trim()).filter(Boolean)
        : null,
      method: "get",
      path: isRest ? path.trim() : null,
      description: description.trim() || null,
    };
    if (isNew) {
      payload.vendor = vendorInput;
      payload.type = typeInput;
      payload.command = commandInput.trim();
    }
    onSubmit(payload)
      .catch((err) => setError(err.message))
      .finally(() => { setSaving(false); onSavingChange?.(false); });
  };

  return (
    <form className="space-y-3" onSubmit={handleSubmit}>
      <div className="grid grid-cols-4 gap-3">
        <div className="space-y-1">
          <Label htmlFor={`${id}-vendor`} className="text-sm font-semibold">ベンダー</Label>
          {isNew ? (
            <Select id={`${id}-vendor`} autoFocus className="h-8" value={vendorInput} onChange={(e) => handleVendorChange(e.target.value)}>
              <option value="" disabled>
                選択してください
              </option>
              {vendorOptions.map((v) => (
                <option key={v} value={v}>
                  {v}
                </option>
              ))}
            </Select>
          ) : (
            <Input id={`${id}-vendor`} className="h-8" value={vendor} disabled />
          )}
        </div>
        <div className="space-y-1">
          <Label htmlFor={`${id}-type`} className="text-sm font-semibold">タイプ</Label>
          {isNew ? (
            <Select
              id={`${id}-type`}
              className="h-8"
              value={typeInput}
              onChange={(e) => setTypeInput(e.target.value)}
              disabled={!vendorInput}
            >
              <option value="" disabled>
                {vendorInput ? "選択してください" : "先にベンダーを選択"}
              </option>
              {typeOptions.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </Select>
          ) : (
            <Input id={`${id}-type`} className="h-8" value={type} disabled />
          )}
        </div>
        <div className="col-span-2 space-y-1">
          <Label htmlFor={`${id}-cmd`} className="text-sm font-semibold">コマンド</Label>
          {isNew ? (
            <Input
              id={`${id}-cmd`}
              className="h-8"
              placeholder='例: show version / fault_summary'
              value={commandInput}
              onChange={(e) => setCommandInput(e.target.value)}
            />
          ) : (
            <Input id={`${id}-cmd`} className="h-8" value={command} disabled />
          )}
        </div>
      </div>

      <div className="space-y-1">
        <Label htmlFor={`${id}-desc`} className="text-sm font-semibold">説明(任意)</Label>
        <Input id={`${id}-desc`} autoFocus={!isNew} className="h-8" value={description} onChange={(e) => setDescription(e.target.value)} />
      </div>

      <div className="grid grid-cols-3 gap-3">
        <div className="space-y-1">
          <Label htmlFor={`${id}-kind`} className="text-sm font-semibold">種別</Label>
          <Select id={`${id}-kind`} className="h-8" value={entryType} onChange={(e) => handleEntryTypeChange(e.target.value)}>
            <option value="CLI">CLI</option>
            <option value="REST">REST</option>
          </Select>
        </div>
        {isRest ? (
          <div className="col-span-2 space-y-1">
            <Label htmlFor={`${id}-path`} className="text-sm font-semibold">APIパス</Label>
            <Input
              id={`${id}-path`}
              className="h-8"
              placeholder="/api/node/class/faultSummary.json"
              value={path}
              onChange={(e) => setPath(e.target.value)}
            />
          </div>
        ) : (
          <div className="space-y-1">
            <Label htmlFor={`${id}-parser`} className="text-sm font-semibold">パーサ</Label>
            <Select id={`${id}-parser`} className="h-8" value={parser} onChange={(e) => setParser(e.target.value)}>
              <option value="genie">genie</option>
              <option value="textfsm">textfsm</option>
            </Select>
          </div>
        )}
      </div>

      {/* ノイズと比較キーは、どちらも1行1件のキーパスで横幅が要るため縦に並べる。 */}
      <div className="space-y-3">
        <div className="space-y-1">
          <Label htmlFor={`${id}-noise`} className="text-sm font-semibold">ノイズ(比較時に無視するキーパス。1行1件)</Label>
          <Textarea
            id={`${id}-noise`}
            className="h-24 font-mono text-xs"
            value={noise}
            onChange={(e) => setNoise(e.target.value)}
            placeholder="例: interfaces:*:last_change(階層は「:」区切り。「*」は任意の1階層)"
          />
        </div>
        <div className="space-y-1">
          <Label htmlFor={`${id}-keys`} className="text-sm font-semibold">比較キー(list の要素を対応付けるキー。1行1件・任意)</Label>
          <Textarea
            id={`${id}-keys`}
            className="h-24 font-mono text-xs"
            value={compareKeys}
            onChange={(e) => setCompareKeys(e.target.value)}
            placeholder="例: imdata[]:*:attributes:dn(階層は「:」区切り。未設定なら list は並び順で対応付けます)"
          />
        </div>
      </div>

      {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
      <DialogFooter>
        <Button size="sm" variant="outline" onClick={onCancel} disabled={saving}>
          キャンセル
        </Button>
        <Button size="sm" type="submit" disabled={saving}>
          {saving ? "保存中..." : submitLabel}
        </Button>
      </DialogFooter>
    </form>
  );
}

// CommandCatalogEntryForm と同じレイアウトの、編集不可(表示専用)版。表から
// ノイズ・キー列を削除した代わりに、コマンドをクリックするとここで内容
// (ノイズ・比較キーも含む)を確認できるようにする。
function CommandCatalogEntryView({ vendor, type, command, spec }) {
  const isRest = typeOf(spec.parser) === "REST";
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-4 gap-3">
        <div className="space-y-1">
          <Label className="text-sm font-semibold">ベンダー</Label>
          <div>
            <Badge className={deviceVendorColor(vendor)}>{vendor}</Badge>
          </div>
        </div>
        <div className="space-y-1">
          <Label className="text-sm font-semibold">タイプ</Label>
          <div>
            <Badge className={deviceTypeColor(type)}>{type}</Badge>
          </div>
        </div>
        <div className="col-span-2 space-y-1">
          <Label className="text-sm font-semibold">コマンド</Label>
          <p className="text-sm font-medium">{command}</p>
        </div>
      </div>

      <div className="space-y-1">
        <Label className="text-sm font-semibold">説明</Label>
        <p className="text-sm">{spec.description || "-"}</p>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <div className="space-y-1">
          <Label className="text-sm font-semibold">種別</Label>
          <div>
            <Badge variant={isRest ? "default" : "success"}>{typeOf(spec.parser)}</Badge>
          </div>
        </div>
        {isRest ? (
          <div className="col-span-2 space-y-1">
            <Label className="text-sm font-semibold">APIパス</Label>
            <p className="font-mono text-sm">{spec.path || "-"}</p>
          </div>
        ) : (
          <div className="space-y-1">
            <Label className="text-sm font-semibold">パーサ</Label>
            <div>
              <Badge variant="secondary">{spec.parser}</Badge>
            </div>
          </div>
        )}
      </div>

      {/* ノイズと比較キーは、どちらも1行1件のキーパスで横幅が要るため縦に並べる。 */}
      <div className="space-y-3">
        <div className="space-y-1">
          <Label className="text-sm font-semibold">ノイズ(比較時に無視するキーパス)</Label>
          <div className="min-h-24 space-y-0.5 rounded-md border bg-muted/30 p-2 font-mono text-xs">
            {spec.noise.length > 0 ? (
              spec.noise.map((n) => <p key={n}>{n}</p>)
            ) : (
              <p className="text-muted-foreground">(なし)</p>
            )}
          </div>
        </div>
        <div className="space-y-1">
          <Label className="text-sm font-semibold">比較キー(list の要素を対応付けるキー)</Label>
          <div className="min-h-24 space-y-0.5 rounded-md border bg-muted/30 p-2 font-mono text-xs">
            {spec.compare_keys && spec.compare_keys.length > 0 ? (
              spec.compare_keys.map((k) => <p key={k}>{k}</p>)
            ) : (
              <p className="text-muted-foreground">(なし)</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// 件数が多くなりうるため(Genieパーサーが対応するコマンドを幅広く登録しているため)、
// クライアント側でページングする(一覧APIはページング無しで全件返すが、DOMへは
// 100件ずつしか描画しない。一覧のブラウザ描画が重くなるのを防ぐため)。

export default function CommandCatalogPage() {
  const catalogQuery = useCommandCatalog();
  const catalog = catalogQuery.data ?? null;
  const invalidate = useInvalidate();
  const [filters, setFilters] = useState(EMPTY_FILTERS);
  const [pageInput, setPage] = useState(0);
  const [creating, setCreating] = useState(false);
  const [editingKey, setEditingKey] = useState(null);
  const [viewingKey, setViewingKey] = useState(null);
  const [saving, setSaving] = useState(false);
  const confirm = useConfirm();

  // カタログの変更はコマンドセットの編集画面の選択肢にも効くので、両方を読み込み直す。
  const reload = () => Promise.all([invalidate(queryKeys.commandCatalog), invalidate(queryKeys.commandSets)]);

  const setFilter = (key) => (value) => {
    setPage(0);
    setFilters((prev) => ({ ...prev, [key]: value }));
  };

  const rows = useMemo(() => (catalog ? flatten(catalog) : []), [catalog]);
  const editingRow = useMemo(
    () => rows.find((r) => `${r.vendor}:${r.type}:${r.command}` === editingKey) ?? null,
    [rows, editingKey]
  );
  const viewingRow = useMemo(
    () => rows.find((r) => `${r.vendor}:${r.type}:${r.command}` === viewingKey) ?? null,
    [rows, viewingKey]
  );
  const vendors = useMemo(() => Array.from(new Set(rows.map((r) => r.vendor))).sort(), [rows]);
  const types = useMemo(() => Array.from(new Set(rows.map((r) => r.type))).sort(), [rows]);
  const parsers = useMemo(() => Array.from(new Set(rows.map((r) => r.spec.parser))).sort(), [rows]);

  const commandMatcher = useMemo(() => compileTextQuery(filters.command), [filters.command]);
  const descriptionMatcher = useMemo(() => compileTextQuery(filters.description), [filters.description]);
  const filtered = useMemo(() => {
    return rows.filter((r) => {
      if (filters.vendor && r.vendor !== filters.vendor) return false;
      if (filters.type && r.type !== filters.type) return false;
      // コマンド欄の絞り込みは、REST の path にも当てる(REST はコマンド名が任意の名前で、
      // 実際に叩く先は path で探したいことが多いため)。
      if (!commandMatcher.test(r.command) && !(r.spec.path && commandMatcher.test(r.spec.path))) return false;
      if (!descriptionMatcher.test(r.spec.description ?? "")) return false;
      if (filters.type_ && typeOf(r.spec.parser) !== filters.type_) return false;
      if (filters.parser && r.spec.parser !== filters.parser) return false;
      if (filters.keyStatus && keyStatusOf(r.spec) !== filters.keyStatus) return false;
      return true;
    });
  }, [rows, filters, commandMatcher, descriptionMatcher]);

  const { sorted, sort, toggle: toggleSort } = useSort(filtered, SORT_GETTERS, () => setPage(0));
  const { page, pageCount, rangeStart, rangeEnd } = usePageRange(filtered.length, pageInput);
  const pageRows = usePageSlice(sorted, page);

  const handleCreate = (payload) =>
    createCommandCatalogEntry(payload).then(() => {
      setCreating(false);
      toast.success(`'${payload.command}' を作成しました(${payload.vendor}/${payload.type})`);
      return reload();
    });
  const handleUpdate = (vendor, type, command) => (payload) =>
    updateCommandCatalogEntry(vendor, type, command, payload).then(() => {
      setEditingKey(null);
      toast.success(`'${command}' を保存しました(${vendor}/${type})`);
      return reload();
    });
  const handleDelete = async (vendor, type, command) => {
    const ok = await confirm({
      title: `'${command}' を削除しますか?`,
      description: `${vendor}/${type} のコマンドカタログから削除します。この操作は取り消せません。`,
      confirmLabel: "削除",
      destructive: true,
    });
    if (!ok) return;
    try {
      await deleteCommandCatalogEntry(vendor, type, command);
      toast.success(`'${command}' を削除しました(${vendor}/${type})`);
      await reload();
    } catch (e) {
      toast.error(`削除できませんでした: ${e.message}`);
    }
  };

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="text-sm text-muted-foreground">
          {catalogQuery.isPending ? <LoadingText /> : catalogQuery.data ? `${rangeStart}-${rangeEnd} / ${filtered.length} 件` : "-"}
        </p>
        <div className="flex items-center gap-2">
          <Pagination page={page} pageCount={pageCount} onPageChange={setPage} />
          <FileTransferButtons
            onDownload={downloadCommandCatalogFiles}
            downloadLabel="ZIPダウンロード"
            uploadLabel="ZIPアップロード"
            accept=".zip"
            onUpload={uploadCommandCatalogFiles}
            onUploaded={() => reload()}
          />
          <Button size="sm" onClick={() => { setEditingKey(null); setCreating((v) => !v); }}>
            <Plus /> 新規作成
          </Button>
        </div>
      </div>
      <LoadError what="コマンドカタログ" error={catalogQuery.error} onRetry={catalogQuery.refetch} />

      {/* table-fixed: 列幅を % で指定し、ウィンドウ幅が狭くなったら表全体が
          比例して縮むようにする(auto レイアウト + 固定px幅のヒントだと、
          ウィンドウを縮めても表の実寸は縮まず、代わりに表がはみ出して横
          スクロールになってしまうため)。 */}
      <Table className="min-w-[60rem] table-fixed" containerClassName="max-h-[78vh] overflow-y-auto rounded-md border bg-card">
          <TableHeader className="sticky top-0 z-10 bg-muted">
            <TableRow>
              {/* 1366 幅の画面でも「操作」列まで枠に収まるよう、固定幅の列は中身に合わせて
                  詰め、コマンドと説明に残りを回す(min-w は 60rem = 960px)。 */}
              <SortableHead className="w-24" sortKey="vendor" sort={sort} onSort={toggleSort}>ベンダー</SortableHead>
              <SortableHead className="w-24" sortKey="type" sort={sort} onSort={toggleSort}>タイプ</SortableHead>
              <SortableHead sortKey="command" sort={sort} onSort={toggleSort}>コマンド</SortableHead>
              <SortableHead className="w-[20%]" sortKey="description" sort={sort} onSort={toggleSort}>説明</SortableHead>
              <SortableHead className="w-24" sortKey="kind" sort={sort} onSort={toggleSort}>種別</SortableHead>
              <SortableHead className="w-24" sortKey="parser" sort={sort} onSort={toggleSort}>パーサ</SortableHead>
              <SortableHead className="w-24" sortKey="keyStatus" sort={sort} onSort={toggleSort}>比較キー</SortableHead>
              <SortableHead className="w-20" sortKey="noise" sort={sort} onSort={toggleSort}>ノイズ</SortableHead>
              <TableHead className="w-24">操作</TableHead>
            </TableRow>
            <TableRow className="hover:bg-transparent">
              <TableHead className="py-1.5">
                <SelectFilter value={filters.vendor} onChange={setFilter("vendor")} options={vendors} />
              </TableHead>
              <TableHead className="py-1.5">
                <SelectFilter value={filters.type} onChange={setFilter("type")} options={types} />
              </TableHead>
              <TableHead className="py-1.5">
                <TextFilter value={filters.command} onChange={setFilter("command")} placeholder="コマンド・パス" />
              </TableHead>
              <TableHead className="py-1.5">
                <TextFilter value={filters.description} onChange={setFilter("description")} placeholder="絞り込み" />
              </TableHead>
              <TableHead className="py-1.5">
                <SelectFilter value={filters.type_} onChange={setFilter("type_")} options={["CLI", "REST"]} />
              </TableHead>
              <TableHead className="py-1.5">
                <SelectFilter value={filters.parser} onChange={setFilter("parser")} options={parsers} />
              </TableHead>
              <TableHead className="py-1.5">
                <SelectFilter
                  value={filters.keyStatus}
                  onChange={setFilter("keyStatus")}
                  options={["設定済み", "未設定"]}
                />
              </TableHead>
              <TableHead className="py-1.5" />
              <TableHead className="py-1.5" />
            </TableRow>
          </TableHeader>
          <TableBody>
            {pageRows.map(({ vendor, type, command, spec }) => {
              const key = `${vendor}:${type}:${command}`;
              return (
                <ClickableRow
                  key={key}
                  className="hover:bg-accent"
                  onActivate={() => setViewingKey(key)}
                >
                  <TableCell>
                    <Badge className={deviceVendorColor(vendor)}>{vendor}</Badge>
                  </TableCell>
                  <TableCell>
                    <Badge className={deviceTypeColor(type)}>{type}</Badge>
                  </TableCell>
                  {/* REST は実際に叩くパスを、コマンド名の下に小さく出す。 */}
                  <TableCell className="font-medium">
                    <HighlightMatch text={command} matcher={commandMatcher} />
                    {spec.path && (
                      <p className="truncate font-mono text-xs font-normal text-muted-foreground" title={spec.path}>
                        <HighlightMatch text={spec.path} matcher={commandMatcher} />
                      </p>
                    )}
                  </TableCell>
                  <TableCell className="truncate text-muted-foreground" title={spec.description || undefined}>
                    {spec.description ? <HighlightMatch text={spec.description} matcher={descriptionMatcher} /> : "-"}
                  </TableCell>
                  <TableCell>
                    <Badge variant={typeOf(spec.parser) === "REST" ? "outline" : "secondary"}>
                      {typeOf(spec.parser)}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge variant="secondary">{spec.parser}</Badge>
                  </TableCell>
                  <TableCell className="text-muted-foreground">
                    {keyStatusOf(spec)}
                  </TableCell>
                  <TableCell className="text-muted-foreground">{spec.noise.length} 件</TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      <IconButton
                        label={`${command} を編集`}
                        onClick={(e) => { e.stopPropagation(); setCreating(false); setEditingKey(key); }}
                      >
                        <Pencil />
                      </IconButton>
                      <IconButton
                        label={`${command} を削除`}
                        variant="destructive-outline"
                        onClick={(e) => { e.stopPropagation(); handleDelete(vendor, type, command); }}
                      >
                        <Trash2 />
                      </IconButton>
                    </div>
                  </TableCell>
                </ClickableRow>
              );
            })}
            <TableStatusRow
              colSpan={9}
              isPending={catalogQuery.isPending}
              isError={catalogQuery.isError}
              isEmpty={filtered.length === 0}
              emptyText="該当するコマンドがありません"
            />
          </TableBody>
      </Table>

      <Dialog
        open={creating || editingKey !== null}
        onClose={() => { setCreating(false); setEditingKey(null); }}
        title={creating ? "コマンドカタログを新規作成" : `コマンドカタログを編集: ${editingKey}`}
        className="max-w-8xl"
        dismissible={false}
        busy={saving}
      >
        {creating && (
          <CommandCatalogEntryForm
            catalog={catalog}
            submitLabel="作成"
            onCancel={() => setCreating(false)}
            onSubmit={handleCreate}
            onSavingChange={setSaving}
          />
        )}
        {editingKey !== null && editingRow && (
          <CommandCatalogEntryForm
            vendor={editingRow.vendor}
            type={editingRow.type}
            command={editingRow.command}
            initial={editingRow.spec}
            submitLabel="保存"
            onCancel={() => setEditingKey(null)}
            onSubmit={handleUpdate(editingRow.vendor, editingRow.type, editingRow.command)}
            onSavingChange={setSaving}
          />
        )}
      </Dialog>

      <Dialog
        open={viewingKey !== null}
        onClose={() => setViewingKey(null)}
        title={`コマンドカタログ: ${viewingKey}`}
        className="max-w-8xl"
      >
        {viewingRow && (
          <CommandCatalogEntryView
            vendor={viewingRow.vendor}
            type={viewingRow.type}
            command={viewingRow.command}
            spec={viewingRow.spec}
          />
        )}
      </Dialog>
    </div>
  );
}
