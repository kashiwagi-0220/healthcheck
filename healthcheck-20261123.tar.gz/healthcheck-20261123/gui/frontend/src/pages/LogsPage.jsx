import { useEffect, useMemo, useRef, useState } from "react";
import { useLogs } from "../api/queries";
import { parseLogLine } from "@/lib/logLine";
import { LoadingText, LoadError } from "@/components/QueryStatus";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import LogLines from "@/components/LogLines";
import { RefreshCw } from "lucide-react";

const LIMIT_OPTIONS = [100, 500, 1000, 5000];

// 重要度の絞り込み。指定したレベル以上の行だけを出す(画面の中で絞る。サーバへは送らない)。
const LEVELS = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"];
const LEVEL_OPTIONS = [
  { value: "", label: "すべて" },
  { value: "WARNING", label: "WARNING 以上" },
  { value: "ERROR", label: "ERROR 以上" },
];

// 時刻で始まらない行(例外の詳細など)は直前の行の続きなので、直前の行と同じ扱いにする。
function filterByLevel(lines, minLevel) {
  if (!minLevel) return lines;
  const min = LEVELS.indexOf(minLevel);
  let keep = false;
  return lines.filter((line) => {
    const entry = parseLogLine(line);
    if (entry) keep = LEVELS.indexOf(entry.level) >= min;
    return keep;
  });
}

// 実行ログ(data/healthcheck.log)の照会ページ。収集層(healthcheck/collect/*)が
// コマンド・問い合わせ単位で記録したログを、正常性確認・スナップショット取得を
// 実行した後からでも確認できるようにする。行はレベル・ロガーごとに色分けする
// (色の決め方は lib/logLine.js。実行中の画面のログ欄と共通)。
export default function LogsPage() {
  const [query, setQuery] = useState("");          // 入力中の文字列
  const [submitted, setSubmitted] = useState("");  // 検索に使う文字列(Enter・更新で確定)
  const [limit, setLimit] = useState(500);
  const [minLevel, setMinLevel] = useState("");
  const logsQuery = useLogs({ q: submitted || undefined, limit });
  const allLines = logsQuery.data?.lines;
  const lines = useMemo(() => filterByLevel(allLines ?? [], minLevel), [allLines, minLevel]);
  const total = logsQuery.data?.total ?? 0;
  const loading = logsQuery.isFetching;

  // 読み込んだら、いちばん新しい行(末尾)が見えるところまで送る(以前は先頭=古い側で開き、
  // 最新を見るには下までスクロールする必要があった)。
  const scrollRef = useRef(null);
  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [lines]);

  // 文字列が同じなら読み込み直す(新しく出たログを見るため)。違えば新しい条件で読み込む。
  const reload = () => {
    if (query === submitted) logsQuery.refetch();
    else setSubmitted(query);
  };

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div className="flex flex-wrap items-end gap-3">
          <div className="space-y-1">
            <Label htmlFor="logs-q" className="text-sm font-semibold">文字列(部分一致)</Label>
            <Input
              id="logs-q"
              className="h-8 w-56"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && reload()}
              placeholder="例: RT-01 / show ip route / 失敗"
            />
          </div>
          <div className="space-y-1">
            <Label htmlFor="logs-limit" className="text-sm font-semibold">表示件数(末尾から)</Label>
            <Select id="logs-limit" className="h-8 w-28" value={limit} onChange={(e) => setLimit(Number(e.target.value))}>
              {LIMIT_OPTIONS.map((n) => (
                <option key={n} value={n}>
                  {n}
                </option>
              ))}
            </Select>
          </div>
          <div className="space-y-1">
            <Label htmlFor="logs-level" className="text-sm font-semibold">重要度</Label>
            <Select id="logs-level" className="h-8 w-36" value={minLevel} onChange={(e) => setMinLevel(e.target.value)}>
              {LEVEL_OPTIONS.map((o) => (
                <option key={o.value} value={o.value}>
                  {o.label}
                </option>
              ))}
            </Select>
          </div>
          <Button size="sm" variant="outline" onClick={reload} disabled={loading}>
            <RefreshCw /> 更新
          </Button>
        </div>
        <p className="text-sm text-muted-foreground">
          {loading ? <LoadingText /> : minLevel ? `${lines.length} 行(読み込んだ ${allLines?.length ?? 0} 行のうち / 全 ${total} 行)` : `${lines.length} / ${total} 行`}
        </p>
      </div>

      <LoadError what="ログ" error={logsQuery.error} onRetry={logsQuery.refetch} />

      <div ref={scrollRef} className="max-h-[calc(100vh-13rem)] overflow-auto rounded-md border bg-card p-3 font-mono text-xs leading-5 text-foreground">
        {lines.length > 0 ? (
          <LogLines lines={lines} />
        ) : (
          !logsQuery.isPending && <p className="text-muted-foreground">ログがありません</p>
        )}
      </div>
    </div>
  );
}
