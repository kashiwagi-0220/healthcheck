import { useId, useMemo, useState } from "react";
import { toast } from "sonner";
import {
  createDevice, updateDevice, deleteDevice, downloadDevicesCsv, uploadDevicesCsv,
} from "../api/client";
import {
  queryKeys, useDevices, useCommandSets, useCommandCatalog, useInvalidate,
} from "../api/queries";
import { LoadingText, LoadError, TableStatusRow } from "@/components/QueryStatus";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogFooter } from "@/components/ui/dialog";
import IconButton from "@/components/IconButton";
import { useConfirm } from "@/hooks/useConfirm";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { deviceTypeColor, deviceVendorColor } from "@/lib/deviceTypeColor";
import { TextFilter, SelectFilter } from "@/components/TableFilters";
import FileTransferButtons from "@/components/FileTransferButtons";
import Pagination from "@/components/Pagination";
import HighlightMatch from "@/components/HighlightMatch";
import { EMPTY_TEXT_QUERY, compileTextQuery } from "@/lib/textQuery";
import { usePageRange, usePageSlice } from "@/hooks/usePagination";
import { useSort } from "@/hooks/useSort";
import SortableHead from "@/components/SortableHead";

// 作成・編集共通のフォーム(CommandSetsPage の CommandSetForm を参考にした形)。
// host は作成時のみ入力(編集時は変更不可なので表示のみ)。ベンダー・タイプは
// コマンドカタログ(vendor -> type -> {command: spec})から選ぶ形式にし、自由入力による
// 表記ゆれを防ぐ。コマンドセットは選択したベンダー・タイプに一致するものだけに絞る
// (現在値が一致しなくても選択肢の先頭に加えて消さない)。コマンドセットの変更は
// この編集フォームからのみ行う(一覧の行内でのクイック切り替えは持たない)。
function DeviceForm({ host, initial, catalog, commandSets, onCancel, onSubmit, submitLabel, onSavingChange }) {
  const id = useId();
  const [hostInput, setHostInput] = useState(host ?? "");
  const [vendor, setVendor] = useState(initial?.vendor ?? "");
  const [type, setType] = useState(initial?.type ?? "");
  const [ip, setIp] = useState(initial?.ip ?? "");
  const [commandSet, setCommandSet] = useState(initial?.meta?.command_set ?? "");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  const vendors = useMemo(() => Object.keys(catalog).sort(), [catalog]);
  const types = useMemo(() => Object.keys(catalog[vendor] ?? {}).sort(), [catalog, vendor]);
  const compatibleCommandSets = useMemo(() => {
    const list = Object.keys(commandSets)
      .filter((name) => commandSets[name].vendor === vendor && commandSets[name].type === type)
      .sort();
    return commandSet && !list.includes(commandSet) ? [commandSet, ...list] : list;
  }, [commandSets, vendor, type, commandSet]);
  const ready = Boolean(vendor && type);

  const handleVendorChange = (value) => {
    setVendor(value);
    // vendor が変わったら type・コマンドセットをリセットする(別ベンダーの値を
    // 引き継がないため)。
    setType("");
    setCommandSet("");
  };
  const handleTypeChange = (value) => {
    setType(value);
    // type が変わったらコマンドセットをリセットする(別機種の値を引き継がない)。
    setCommandSet("");
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!host && !hostInput.trim()) {
      setError("ホスト名を入力してください。");
      return;
    }
    if (!ready) {
      setError("ベンダー・タイプを選択してください。");
      return;
    }
    setSaving(true);
    onSavingChange?.(true);
    setError(null);
    const payload = { vendor, type, ip: ip.trim() || null, command_set: commandSet || null };
    onSubmit(host ?? hostInput.trim(), payload)
      .catch((err) => setError(err.message))
      .finally(() => { setSaving(false); onSavingChange?.(false); });
  };

  return (
    <form className="space-y-3" onSubmit={handleSubmit}>
      <div className="space-y-1">
        <Label htmlFor={`${id}-host`} className="text-sm font-semibold">ホスト名</Label>
        {host ? (
          <Input id={`${id}-host`} className="h-8 max-w-xs" value={host} disabled />
        ) : (
          <Input
            id={`${id}-host`}
            autoFocus
            className="h-8 max-w-xs"
            placeholder="例: RT-11"
            value={hostInput}
            onChange={(e) => setHostInput(e.target.value)}
          />
        )}
      </div>

      <div className="grid grid-cols-4 gap-3">
        <div className="space-y-1">
          <Label htmlFor={`${id}-vendor`} className="text-sm font-semibold">ベンダー</Label>
          <Select id={`${id}-vendor`} className="h-8" value={vendor} onChange={(e) => handleVendorChange(e.target.value)}>
            <option value="" disabled>
              選択してください
            </option>
            {vendors.map((v) => (
              <option key={v} value={v}>
                {v}
              </option>
            ))}
          </Select>
        </div>
        <div className="space-y-1">
          <Label htmlFor={`${id}-type`} className="text-sm font-semibold">タイプ</Label>
          <Select id={`${id}-type`} className="h-8" value={type} onChange={(e) => handleTypeChange(e.target.value)} disabled={!vendor}>
            <option value="" disabled>
              {vendor ? "選択してください" : "先にベンダーを選択"}
            </option>
            {types.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </Select>
        </div>
        <div className="space-y-1">
          <Label htmlFor={`${id}-ip`} className="text-sm font-semibold">IPアドレス(任意)</Label>
          <Input id={`${id}-ip`} className="h-8" value={ip} onChange={(e) => setIp(e.target.value)} />
        </div>
        <div className="space-y-1">
          <Label htmlFor={`${id}-cs`} className="text-sm font-semibold">コマンドセット(任意)</Label>
          <Select
            id={`${id}-cs`}
            className="h-8"
            value={commandSet}
            onChange={(e) => setCommandSet(e.target.value)}
            disabled={!ready}
          >
            <option value="">未設定</option>
            {compatibleCommandSets.map((name) => (
              <option key={name} value={name}>
                {name}
              </option>
            ))}
          </Select>
        </div>
      </div>

      {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
      <DialogFooter>
        <Button size="sm" variant="outline" onClick={onCancel} disabled={saving}>
          キャンセル
        </Button>
        <Button size="sm" type="submit" disabled={saving}>
          {saving ? "保存中..." : submitLabel}
        </Button>
      </DialogFooter>
    </form>
  );
}

const EMPTY_FILTERS = { host: EMPTY_TEXT_QUERY, vendor: "", type: "", ip: EMPTY_TEXT_QUERY, commandSet: "" };
const NO_DEVICES = [];
// 列の並べ替え(hooks/useSort.js)で比べる値。
const SORT_GETTERS = {
  host: (d) => d.host,
  vendor: (d) => d.vendor,
  type: (d) => d.type,
  ip: (d) => d.ip,
  commandSet: (d) => d.meta?.command_set,
};
const NO_ENTRIES = {};

export default function DeviceListPage() {
  const devicesQuery = useDevices();
  // コマンドセット・コマンドカタログは編集フォームの選択肢に使う補助データ。
  // 取れなくても一覧の表示自体は続けられるが、黙って選択肢が空になると原因が
  // 分からないため、理由を出す。
  const commandSetsQuery = useCommandSets();
  const catalogQuery = useCommandCatalog();
  const devices = devicesQuery.data ?? NO_DEVICES;
  const commandSets = commandSetsQuery.data ?? NO_ENTRIES;
  const catalog = catalogQuery.data ?? NO_ENTRIES;
  const invalidate = useInvalidate();
  const refetch = () => invalidate(queryKeys.devices);
  const [filters, setFilters] = useState(EMPTY_FILTERS);
  const [creating, setCreating] = useState(false);
  const [editingHost, setEditingHost] = useState(null);
  const [saving, setSaving] = useState(false);
  const confirm = useConfirm();
  const setFilter = (key) => (value) => {
    setPage(0);                       // 絞り込みを変えたら先頭ページへ戻す
    setFilters((prev) => ({ ...prev, [key]: value }));
  };

  const vendors = useMemo(() => Array.from(new Set(devices.map((d) => d.vendor))).sort(), [devices]);
  const types = useMemo(() => Array.from(new Set(devices.map((d) => d.type))).sort(), [devices]);
  const commandSetNames = useMemo(
    () => Array.from(new Set(devices.map((d) => d.meta?.command_set).filter(Boolean))).sort(),
    [devices]
  );

  const [pageInput, setPage] = useState(0);

  const hostMatcher = useMemo(() => compileTextQuery(filters.host), [filters.host]);
  const ipMatcher = useMemo(() => compileTextQuery(filters.ip), [filters.ip]);
  const filtered = useMemo(() => {
    return devices
      .filter((d) => {
        if (!hostMatcher.test(d.host)) return false;
        if (filters.vendor && d.vendor !== filters.vendor) return false;
        if (filters.type && d.type !== filters.type) return false;
        if (!ipMatcher.test(d.ip)) return false;
        if (filters.commandSet && (d.meta?.command_set ?? "") !== filters.commandSet) return false;
        return true;
      })
      // ホスト名の昇順。数字を含む名前(SW-2 と SW-10 など)が見た目どおりに
      // 並ぶよう numeric 比較にする。
      .sort((a, b) => a.host.localeCompare(b.host, undefined, { numeric: true, sensitivity: "base" }));
  }, [devices, filters, hostMatcher, ipMatcher]);

  const { sorted, sort, toggle: toggleSort } = useSort(filtered, SORT_GETTERS, () => setPage(0));
  const { page, pageCount, rangeStart, rangeEnd } = usePageRange(filtered.length, pageInput);
  const pageRows = usePageSlice(sorted, page);

  const handleCreate = (host, payload) =>
    createDevice({ host, ...payload }).then(() => {
      setCreating(false);
      toast.success(`機器 '${host}' を作成しました`);
      return refetch();
    });
  const handleUpdate = (host) => (_host, payload) =>
    updateDevice(host, payload).then(() => {
      setEditingHost(null);
      toast.success(`機器 '${host}' を保存しました`);
      return refetch();
    });
  const handleDelete = async (host) => {
    const ok = await confirm({
      title: `機器 '${host}' を削除しますか?`,
      description: "機器一覧から削除します。この操作は取り消せません(保存済みのスナップショットは残ります)。",
      confirmLabel: "削除",
      destructive: true,
    });
    if (!ok) return;
    try {
      await deleteDevice(host);
      toast.success(`機器 '${host}' を削除しました`);
      await refetch();
    } catch (e) {
      toast.error(`削除できませんでした: ${e.message}`);
    }
  };
  const confirmCsvUpload = (file) =>
    confirm({
      title: "機器一覧を置き換えますか?",
      description: `「${file.name}」の内容で、機器一覧(devices.csv)の全体を置き換えます。今の一覧に無い機器は消えます。`,
      confirmLabel: "置き換える",
      destructive: true,
    });

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="text-sm text-muted-foreground">
          {devicesQuery.isPending
            ? <LoadingText />
            : devicesQuery.data ? `${rangeStart}-${rangeEnd} / ${filtered.length} 件` : "-"}
        </p>
        <div className="flex items-center gap-2">
          <Pagination page={page} pageCount={pageCount} onPageChange={setPage} />
          <FileTransferButtons
            onDownload={downloadDevicesCsv}
            downloadLabel="CSVダウンロード"
            uploadLabel="CSVアップロード"
            accept=".csv"
            onUpload={uploadDevicesCsv}
            onUploaded={() => refetch()}
            confirmUpload={confirmCsvUpload}
          />
          <Button size="sm" onClick={() => { setEditingHost(null); setCreating((v) => !v); }}>
            <Plus /> 新規作成
          </Button>
        </div>
      </div>
      <LoadError what="機器一覧" error={devicesQuery.error} onRetry={devicesQuery.refetch} />
      <LoadError what="コマンドセット" error={commandSetsQuery.error} onRetry={commandSetsQuery.refetch} />
      <LoadError what="コマンドカタログ" error={catalogQuery.error} onRetry={catalogQuery.refetch} />

      <Table containerClassName="max-h-[78vh] overflow-y-auto rounded-md border bg-card">
          <TableHeader className="sticky top-0 z-10 bg-muted">
            <TableRow>
              <SortableHead sortKey="host" sort={sort} onSort={toggleSort}>ホスト名</SortableHead>
              <SortableHead sortKey="vendor" sort={sort} onSort={toggleSort}>ベンダー</SortableHead>
              <SortableHead sortKey="type" sort={sort} onSort={toggleSort}>タイプ</SortableHead>
              <SortableHead sortKey="ip" sort={sort} onSort={toggleSort}>IPアドレス</SortableHead>
              <SortableHead sortKey="commandSet" sort={sort} onSort={toggleSort}>コマンドセット</SortableHead>
              <TableHead>操作</TableHead>
            </TableRow>
            <TableRow className="hover:bg-transparent">
              <TableHead className="py-1.5">
                <TextFilter value={filters.host} onChange={setFilter("host")} placeholder="絞り込み" />
              </TableHead>
              <TableHead className="py-1.5">
                <SelectFilter value={filters.vendor} onChange={setFilter("vendor")} options={vendors} />
              </TableHead>
              <TableHead className="py-1.5">
                <SelectFilter value={filters.type} onChange={setFilter("type")} options={types} />
              </TableHead>
              <TableHead className="py-1.5">
                <TextFilter value={filters.ip} onChange={setFilter("ip")} placeholder="絞り込み" />
              </TableHead>
              <TableHead className="py-1.5">
                <SelectFilter value={filters.commandSet} onChange={setFilter("commandSet")} options={commandSetNames} />
              </TableHead>
              <TableHead className="py-1.5" />
            </TableRow>
          </TableHeader>
          <TableBody>
            {pageRows.map((d) => (
              <TableRow key={d.host} className="hover:bg-accent">
                <TableCell className="font-medium"><HighlightMatch text={d.host} matcher={hostMatcher} /></TableCell>
                <TableCell>
                  <Badge className={deviceVendorColor(d.vendor)}>{d.vendor}</Badge>
                </TableCell>
                <TableCell>
                  <Badge className={deviceTypeColor(d.type)}>{d.type}</Badge>
                </TableCell>
                <TableCell><HighlightMatch text={d.ip} matcher={ipMatcher} /></TableCell>
                <TableCell>{d.meta?.command_set || "-"}</TableCell>
                <TableCell>
                  <div className="flex gap-1">
                    <IconButton
                      label={`${d.host} を編集`}
                      onClick={() => { setCreating(false); setEditingHost(d.host); }}
                    >
                      <Pencil />
                    </IconButton>
                    <IconButton
                      label={`${d.host} を削除`}
                      variant="destructive-outline"
                      onClick={() => handleDelete(d.host)}
                    >
                      <Trash2 />
                    </IconButton>
                  </div>
                </TableCell>
              </TableRow>
            ))}
            <TableStatusRow
              colSpan={6}
              isPending={devicesQuery.isPending}
              isError={devicesQuery.isError}
              isEmpty={filtered.length === 0}
              emptyText="該当する機器がありません"
            />
          </TableBody>
      </Table>

      <Dialog
        open={creating || editingHost !== null}
        onClose={() => { setCreating(false); setEditingHost(null); }}
        title={creating ? "機器を新規作成" : `機器を編集: ${editingHost}`}
        className="max-w-3xl"
        dismissible={false}
        busy={saving}
      >
        {creating && (
          <DeviceForm
            catalog={catalog}
            commandSets={commandSets}
            submitLabel="作成"
            onCancel={() => setCreating(false)}
            onSubmit={handleCreate}
            onSavingChange={setSaving}
          />
        )}
        {editingHost !== null && (
          <DeviceForm
            host={editingHost}
            initial={devices.find((d) => d.host === editingHost)}
            catalog={catalog}
            commandSets={commandSets}
            submitLabel="保存"
            onCancel={() => setEditingHost(null)}
            onSubmit={handleUpdate(editingHost)}
            onSavingChange={setSaving}
          />
        )}
      </Dialog>
    </div>
  );
}
