import { useId, useState } from "react";
import { toast } from "sonner";
import { setDefaultCredential, setHostCredential, deleteHostCredential } from "../api/client";
import { queryKeys, useCredentials, useDevices, useInvalidate } from "../api/queries";
import { LoadingText, LoadError } from "@/components/QueryStatus";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Dialog, DialogFooter } from "@/components/ui/dialog";
import IconButton from "@/components/IconButton";
import { useConfirm } from "@/hooks/useConfirm";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { TextFilter } from "@/components/TableFilters";
import HighlightMatch from "@/components/HighlightMatch";
import { EMPTY_TEXT_QUERY, compileTextQuery } from "@/lib/textQuery";

const DEFAULT_LABEL = "デフォルト";

// 編集中の対象。デフォルトはホスト名と衝突しない専用の値で表す(以前は文字列 "default" を
// 使っていたため、ホスト名が "default" の行を編集するとデフォルトの編集画面が開いていた)。
const EDIT_DEFAULT = { kind: "default" };
const editHost = (host) => ({ kind: "host", host });

// パスワード類の値はサーバから受け取らない(GET /credentials は「設定済みか」だけを返す)。
// そのため編集フォームのパスワード欄は空で開き、空欄のまま保存すると今の値を残す
// (サーバ側で今の値と合成する。gui/backend/app/api/credentials.py)。
// hostOptions はホスト名の入力候補(機器一覧のうち、まだ個別の認証情報が無いもの)。
// datalist で出すだけなので、一覧に無いホスト名も入力できる(機器より先に認証情報を
// 登録する場合や、機器一覧が読めない場合のため)。
function CredentialForm({ host, initial, onCancel, onSubmit, submitLabel, showHostInput, hostOptions = [], onSavingChange }) {
  const id = useId();
  const isNew = !initial;
  const [hostInput, setHostInput] = useState(host ?? "");
  const [username, setUsername] = useState(initial?.username ?? "");
  const [password, setPassword] = useState("");
  const [secret, setSecret] = useState("");
  const [clearSecret, setClearSecret] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (showHostInput) {
      if (!hostInput.trim()) {
        setError("ホスト名を入力してください。");
        return;
      }
      if (hostInput.trim() === DEFAULT_LABEL) {
        setError(`'${DEFAULT_LABEL}' は予約されています。別のホスト名を使用してください。`);
        return;
      }
    }
    if (!username.trim()) {
      setError("ユーザ名を入力してください。");
      return;
    }
    if (isNew && !password) {
      setError("パスワードを入力してください。");
      return;
    }
    setSaving(true);
    onSavingChange?.(true);
    setError(null);
    const payload = {
      username: username.trim(),
      password: password || null,               // 空欄 = 変更しない
      secret: clearSecret ? null : secret || null,  // 空欄 = 変更しない
      clear_secret: clearSecret,
    };
    onSubmit(showHostInput ? hostInput.trim() : host, payload)
      .catch((err) => setError(err.message))
      .finally(() => { setSaving(false); onSavingChange?.(false); });
  };

  const keepHint = "設定済み";
  return (
    <form className="space-y-3" onSubmit={handleSubmit}>
      <div className="grid grid-cols-4 gap-3">
        <div className="space-y-1">
          <Label htmlFor={`${id}-host`} className="text-sm font-semibold">ホスト名</Label>
          {showHostInput ? (
            <>
              <Input id={`${id}-host`} autoFocus className="h-8" placeholder="機器一覧から選ぶか入力" value={hostInput}
                list={`${id}-hosts`} autoComplete="off" onChange={(e) => setHostInput(e.target.value)} />
              <datalist id={`${id}-hosts`}>
                {hostOptions.map((h) => <option key={h} value={h} />)}
              </datalist>
            </>
          ) : (
            <Input id={`${id}-host`} className="h-8" value={host} disabled />
          )}
        </div>
        <div className="space-y-1">
          <Label htmlFor={`${id}-user`} className="text-sm font-semibold">ユーザ名</Label>
          <Input id={`${id}-user`} autoFocus={!showHostInput} className="h-8" autoComplete="off" value={username}
            onChange={(e) => setUsername(e.target.value)} />
        </div>
        <div className="space-y-1">
          <Label htmlFor={`${id}-pw`} className="text-sm font-semibold">パスワード</Label>
          <Input id={`${id}-pw`} className="h-8" type="password" autoComplete="new-password" value={password}
            placeholder={initial?.has_password ? keepHint : ""} onChange={(e) => setPassword(e.target.value)} />
        </div>
        <div className="space-y-1">
          <Label htmlFor={`${id}-secret`} className="text-sm font-semibold">enableパスワード(任意)</Label>
          <Input id={`${id}-secret`} className="h-8" type="password" autoComplete="new-password" value={secret}
            disabled={clearSecret} placeholder={initial?.has_secret && !clearSecret ? keepHint : ""}
            onChange={(e) => setSecret(e.target.value)} />
          {initial?.has_secret && (
            <Label className="pt-1 text-xs font-normal">
              <Checkbox checked={clearSecret} onChange={(e) => { setClearSecret(e.target.checked); setSecret(""); }} />
              enableパスワードを消す
            </Label>
          )}
        </div>
      </div>
      {!isNew && (
        <p className="text-xs text-muted-foreground">
          パスワード・enableパスワードは画面に表示しません。変えるときだけ入力してください。
        </p>
      )}

      {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
      <DialogFooter>
        <Button size="sm" variant="outline" onClick={onCancel} disabled={saving}>
          キャンセル
        </Button>
        <Button size="sm" type="submit" disabled={saving}>
          {saving ? "保存中..." : submitLabel}
        </Button>
      </DialogFooter>
    </form>
  );
}

const mask = (flag) => (flag ? "*****" : "-");

export default function DeviceCredentialsPage() {
  const credentialsQuery = useCredentials();
  const credentials = credentialsQuery.data;
  const devicesQuery = useDevices();
  const invalidate = useInvalidate();
  const [creating, setCreating] = useState(false);
  const [editing, setEditing] = useState(null);   // EDIT_DEFAULT | editHost(host) | null
  const [saving, setSaving] = useState(false);
  const [hostFilter, setHostFilter] = useState(EMPTY_TEXT_QUERY);
  const confirm = useConfirm();

  const reload = () => invalidate(queryKeys.credentials);

  const handleSaveDefault = (_host, payload) =>
    setDefaultCredential(payload).then(() => {
      setEditing(null);
      toast.success("デフォルトの認証情報を保存しました");
      return reload();
    });
  const handleCreateHost = (host, payload) =>
    setHostCredential(host, payload).then(() => {
      setCreating(false);
      toast.success(`'${host}' の認証情報を作成しました`);
      return reload();
    });
  const handleUpdateHost = (host) => (_host, payload) =>
    setHostCredential(host, payload).then(() => {
      setEditing(null);
      toast.success(`'${host}' の認証情報を保存しました`);
      return reload();
    });
  const handleDeleteHost = async (host) => {
    const ok = await confirm({
      title: `'${host}' の認証情報を削除しますか?`,
      description: "このホスト専用の設定を削除します。以後このホストにはデフォルトの認証情報を使います。この操作は取り消せません。",
      confirmLabel: "削除",
      destructive: true,
    });
    if (!ok) return;
    try {
      await deleteHostCredential(host);
      toast.success(`'${host}' の認証情報を削除しました`);
      await reload();
    } catch (e) {
      toast.error(`削除できませんでした: ${e.message}`);
    }
  };

  if (!credentials) {
    return credentialsQuery.isError
      ? <LoadError what="認証情報" error={credentialsQuery.error} onRetry={credentialsQuery.refetch} />
      : <LoadingText />;
  }

  const hostEntries = Object.entries(credentials.hosts);
  const hostMatcher = compileTextQuery(hostFilter);
  const filteredHostEntries = hostEntries.filter(([host]) => hostMatcher.test(host));
  const editingHost = editing?.kind === "host" ? editing.host : null;

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="text-sm text-muted-foreground">
          {/* 他の一覧と同じ「a-b / n 件」の書き方にする。デフォルトの行も1件と数える。 */}
          1-{filteredHostEntries.length + 1} / {filteredHostEntries.length + 1} 件(デフォルトを含む)
        </p>
        <Button size="sm" onClick={() => { setEditing(null); setCreating(true); }}>
          <Plus /> 新規作成
        </Button>
      </div>
      <LoadError what="認証情報" error={credentialsQuery.error} onRetry={credentialsQuery.refetch} />

      <Table containerClassName="max-h-[78vh] overflow-y-auto rounded-md border bg-card">
          <TableHeader className="sticky top-0 z-10 bg-muted">
            <TableRow>
              <TableHead>ホスト名</TableHead>
              <TableHead>ユーザ名</TableHead>
              <TableHead>パスワード</TableHead>
              <TableHead>enableパスワード</TableHead>
              <TableHead>操作</TableHead>
            </TableRow>
            <TableRow className="hover:bg-transparent">
              <TableHead className="py-1.5">
                <TextFilter value={hostFilter} onChange={setHostFilter} placeholder="絞り込み" />
              </TableHead>
              <TableHead className="py-1.5" />
              <TableHead className="py-1.5" />
              <TableHead className="py-1.5" />
              <TableHead className="py-1.5" />
            </TableRow>
          </TableHeader>
          <TableBody>
            <TableRow className="hover:bg-accent">
              <TableCell className="font-medium">{DEFAULT_LABEL}</TableCell>
              <TableCell>{credentials.default.username}</TableCell>
              <TableCell className="text-muted-foreground">{mask(credentials.default.has_password)}</TableCell>
              <TableCell className="text-muted-foreground">{mask(credentials.default.has_secret)}</TableCell>
              <TableCell>
                <IconButton
                  label="デフォルトの認証情報を編集"
                  onClick={() => { setCreating(false); setEditing(EDIT_DEFAULT); }}
                >
                  <Pencil />
                </IconButton>
              </TableCell>
            </TableRow>

            {filteredHostEntries.map(([host, entry]) => (
              <TableRow key={host} className="hover:bg-accent">
                <TableCell className="font-medium">
                  <HighlightMatch text={host} matcher={hostMatcher} />
                </TableCell>
                <TableCell>{entry.username}</TableCell>
                <TableCell className="text-muted-foreground">{mask(entry.has_password)}</TableCell>
                <TableCell className="text-muted-foreground">{mask(entry.has_secret)}</TableCell>
                <TableCell>
                  <div className="flex gap-1">
                    <IconButton
                      label={`${host} の認証情報を編集`}
                      onClick={() => { setCreating(false); setEditing(editHost(host)); }}
                    >
                      <Pencil />
                    </IconButton>
                    <IconButton
                      label={`${host} の認証情報を削除`}
                      variant="destructive-outline"
                      onClick={() => handleDeleteHost(host)}
                    >
                      <Trash2 />
                    </IconButton>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
      </Table>

      <Dialog
        open={creating || editing !== null}
        onClose={() => { setCreating(false); setEditing(null); }}
        title={
          creating
            ? "認証情報を新規作成"
            : editing?.kind === "default"
              ? "デフォルト認証情報を編集"
              : `認証情報を編集: ${editingHost}`
        }
        className="max-w-3xl"
        dismissible={false}
        busy={saving}
      >
        {creating && (
          <CredentialForm
            showHostInput
            hostOptions={(devicesQuery.data ?? [])
              .map((d) => d.host)
              .filter((h) => !(h in (credentials?.hosts ?? {})))
              .sort()}
            submitLabel="作成"
            onCancel={() => setCreating(false)}
            onSubmit={handleCreateHost}
            onSavingChange={setSaving}
          />
        )}
        {editing?.kind === "default" && (
          <CredentialForm
            host={DEFAULT_LABEL}
            initial={credentials.default}
            submitLabel="保存"
            onCancel={() => setEditing(null)}
            onSubmit={handleSaveDefault}
            onSavingChange={setSaving}
          />
        )}
        {editingHost !== null && (
          <CredentialForm
            key={editingHost}
            host={editingHost}
            initial={credentials.hosts[editingHost]}
            submitLabel="保存"
            onCancel={() => setEditing(null)}
            onSubmit={handleUpdateHost(editingHost)}
            onSavingChange={setSaving}
          />
        )}
      </Dialog>
    </div>
  );
}
