import { useId, useState } from "react";
import { toast } from "sonner";
import { putProxy, downloadProxyConf, uploadProxyConf } from "../api/client";
import { queryKeys, useProxy, useInvalidate } from "../api/queries";
import { LoadingText, LoadError } from "@/components/QueryStatus";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Dialog, DialogFooter } from "@/components/ui/dialog";
import { useConfirm } from "@/hooks/useConfirm";
import FileTransferButtons from "@/components/FileTransferButtons";
import { Pencil } from "lucide-react";

// 認証情報ページ(DeviceCredentialsPage)と同じ編集形式: 内容は表示のみで、
// 「編集」ボタンを押すとポップアップ(Dialog)にフォーム(Textarea + 保存/キャンセル)
// が開く形にする。
function ProxyForm({ initialText, onCancel, onSubmit, onSavingChange }) {
  const id = useId();
  const [text, setText] = useState(initialText);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  // 複数行のテキストを編集するので、Enter は改行のまま(送信は「保存」ボタン)。
  const handleSubmit = (e) => {
    e.preventDefault();
    setSaving(true);
    onSavingChange?.(true);
    setError(null);
    onSubmit(text)
      .catch((err) => setError(err.message))
      .finally(() => { setSaving(false); onSavingChange?.(false); });
  };

  return (
    <form className="space-y-3" onSubmit={handleSubmit}>
      <div className="space-y-1.5">
        <Label htmlFor={`${id}-text`} className="text-sm font-semibold">内容</Label>
        <Textarea id={`${id}-text`} autoFocus className="h-96 font-mono text-xs" value={text}
          onChange={(e) => setText(e.target.value)} />
      </div>
      {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
      <DialogFooter>
        <Button size="sm" variant="outline" onClick={onCancel} disabled={saving}>
          キャンセル
        </Button>
        <Button size="sm" type="submit" disabled={saving}>
          {saving ? "保存中..." : "保存"}
        </Button>
      </DialogFooter>
    </form>
  );
}

export default function ProxyPage() {
  const proxyQuery = useProxy();
  const text = proxyQuery.data?.text ?? null;
  const invalidate = useInvalidate();
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const confirm = useConfirm();

  const reload = () => invalidate(queryKeys.proxy);

  const handleSave = (nextText) =>
    putProxy(nextText).then(() => {
      setEditing(false);
      toast.success("プロキシ設定を保存しました");
      return reload();
    });
  const confirmUpload = (file) =>
    confirm({
      title: "プロキシ設定を置き換えますか?",
      description: `「${file.name}」の内容で、プロキシ設定(proxy.conf)の全体を置き換えます。`,
      confirmLabel: "置き換える",
      destructive: true,
    });

  if (text === null) {
    return proxyQuery.isError
      ? <LoadError what="プロキシ設定" error={proxyQuery.error} onRetry={proxyQuery.refetch} />
      : <LoadingText />;
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-end">
        <div className="flex items-center gap-2">
          <FileTransferButtons
            onDownload={downloadProxyConf}
            downloadLabel="ダウンロード"
            uploadLabel="アップロード"
            onUpload={uploadProxyConf}
            onUploaded={() => reload()}
            confirmUpload={confirmUpload}
          />
          <Button size="sm" onClick={() => setEditing(true)}>
            <Pencil /> 編集
          </Button>
        </div>
      </div>

      <LoadError what="プロキシ設定" error={proxyQuery.error} onRetry={proxyQuery.refetch} />

      <pre className="max-h-[78vh] overflow-auto rounded-md border bg-card p-3 font-mono text-xs">
        {text || "(空)"}
      </pre>

      <Dialog
        open={editing}
        onClose={() => setEditing(false)}
        title="プロキシ設定を編集"
        className="max-w-3xl"
        dismissible={false}
        busy={saving}
      >
        {editing && (
          <ProxyForm initialText={text} onCancel={() => setEditing(false)} onSubmit={handleSave}
            onSavingChange={setSaving} />
        )}
      </Dialog>
    </div>
  );
}
