// gui/backend の FastAPI エンドポイントを呼ぶ薄いクライアント。
//
// 本番ビルドでは空文字(=相対パス)にする。ビルド済みの画面は API と同じ FastAPI が
// 配信するため同一オリジンになり、URL を埋め込む必要がない(埋め込むと、展開先の
// ホスト名が変わるたびにビルドし直しになる)。
// 開発時(Vite の開発サーバー)は画面が 5173・API が 8000 と別オリジンになるため、
// uvicorn の既定を指す。VITE_API_BASE_URL を設定すればどちらも上書きできる。
export const BASE_URL =
  import.meta.env.VITE_API_BASE_URL ?? (import.meta.env.DEV ? "http://localhost:8000" : "");

// 設定(機器一覧・コマンドセット・コマンドカタログ・認証情報・プロキシ設定)の版。
// サーバは読み込みの応答に ETag で版を付け、保存のときは If-Match で「読み込んだ時の
// 版」を求める。読み込んだ後に他の利用者が変更していれば、412 で保存を断る
// (gui/backend/app/config_files.py)。
// 各画面は表示の前に必ず読み込み、保存の後にも読み込み直すため、ここで設定の種類
// ごとに最後に受け取った版を覚えておき、保存のときに自動で付ける。保存の応答にも
// 新しい版が付くので、続けて保存しても自分の変更で断られることはない。
const VERSIONED = new Set(["devices", "command-sets", "command-catalog", "credentials", "proxy"]);
const versions = {};

// "/devices/SW-01" → "devices"。版を持たない API(取得の実行やログなど)は null。
function versionedResource(path) {
  const name = path.split(/[/?]/)[1];
  return VERSIONED.has(name) ? name : null;
}

function rememberVersion(path, res) {
  const resource = versionedResource(path);
  const etag = res.headers.get("ETag");
  if (resource && etag) versions[resource] = etag;
}

function versionHeader(path, method) {
  const resource = versionedResource(path);
  if (!resource || method === "GET" || !versions[resource]) return {};
  return { "If-Match": versions[resource] };
}

// サーバに届かなかったとき(停止中・ネットワーク断)、ブラウザは "Failed to fetch" という
// 英語の TypeError を投げる。利用者に分かる日本語のエラーに置き換える。
async function fetchOrExplain(url, init) {
  try {
    return await fetch(url, init);
  } catch (e) {
    if (e?.name === "AbortError") throw e;
    throw new Error("サーバに接続できませんでした。サーバが動いているか、ネットワークを確認してください。");
  }
}

// 412(読み込んだ後にほかの利用者が保存した)・428(版が付いていない)は、サーバの
// 文言ではなく「どうすればよいか」が分かる文言にする。それ以外はサーバの detail を出す。
const VERSION_CONFLICT_MESSAGE =
  "ほかの利用者が先に変更しました。画面を読み込み直してから、もう一度保存してください。";

async function errorFromResponse(res) {
  if (res.status === 412 || res.status === 428) return new Error(VERSION_CONFLICT_MESSAGE);
  const body = await res.json().catch(() => null);
  const detail = body?.detail ?? `HTTP ${res.status}`;
  return new Error(typeof detail === "string" ? detail : JSON.stringify(detail));
}

async function request(path, options = {}) {
  const res = await fetchOrExplain(`${BASE_URL}${path}`, {
    ...options,
    headers: { "Content-Type": "application/json", ...versionHeader(path, options.method ?? "GET") },
  });
  rememberVersion(path, res);
  if (!res.ok) throw await errorFromResponse(res);
  if (res.status === 204) return null;
  return res.json();
}

// ファイルアップロード用(multipart/form-data。request() は常に
// Content-Type: application/json を付けるため使えず、別関数にする)。
async function uploadFile(path, file) {
  const form = new FormData();
  form.append("file", file);
  const res = await fetchOrExplain(`${BASE_URL}${path}`, {
    method: "POST",
    body: form,
    headers: versionHeader(path, "POST"),
  });
  rememberVersion(path, res);
  if (!res.ok) throw await errorFromResponse(res);
  return res.json();
}

// 設定ファイルのダウンロード用。<a href> で開くと、失敗したとき(ファイルが無い等)に
// アプリから離れて生の JSON エラーの画面へ移ってしまうため、fetch で受け取って
// {blob, filename} を返す(保存は lib/download.js の saveBlob)。失敗は request() と同じく
// サーバの detail を持つ Error を投げる。キャッシュは使わない(編集直後に古い内容を
// 保存しないため。サーバ側も Cache-Control: no-store を付けている)。
async function downloadFile(path, fallbackName) {
  const res = await fetchOrExplain(`${BASE_URL}${path}`, { cache: "no-store" });
  if (!res.ok) throw await errorFromResponse(res);
  const disposition = res.headers.get("Content-Disposition") ?? "";
  const match = disposition.match(/filename="?([^";]+)"?/);
  return { blob: await res.blob(), filename: match ? match[1] : fallbackName };
}

// Server-Sent Events(text/event-stream)を受け取るPOST用(進捗表示など)。
// ブラウザ標準の EventSource は GET専用でPOSTボディを送れないため、fetch +
// ストリーム読み取りで自前実装する。イベントが届くたびに onEvent(parsed) を呼ぶ。
// 呼び出し側の Promise はストリームが正常終了した時点で解決する。
// signal(AbortController の signal)で受け取りを中止できる。中止すると AbortError で終わる。
// サーバは接続が切れたことに次の送信で気づき、まだ始まっていない段階は行わない
// (実行中の段階の機器は最後まで処理される)。
async function requestStream(path, body, onEvent, signal) {
  const res = await fetchOrExplain(`${BASE_URL}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
    signal,
  });
  if (!res.ok) {
    const errBody = await res.json().catch(() => null);
    const detail = errBody?.detail ?? `HTTP ${res.status}`;
    throw new Error(typeof detail === "string" ? detail : JSON.stringify(detail));
  }
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    let sep;
    while ((sep = buffer.indexOf("\n\n")) !== -1) {
      const chunk = buffer.slice(0, sep);
      buffer = buffer.slice(sep + 2);
      const line = chunk.split("\n").find((l) => l.startsWith("data: "));
      if (line) onEvent(JSON.parse(line.slice("data: ".length)));
    }
  }
}

export function listDevices(filter) {
  const qs = filter ? `?filter=${encodeURIComponent(JSON.stringify(filter))}` : "";
  return request(`/devices${qs}`);
}

export function createDevice(body) {
  return request(`/devices`, { method: "POST", body: JSON.stringify(body) });
}

export function updateDevice(host, body) {
  return request(`/devices/${encodeURIComponent(host)}`, { method: "PUT", body: JSON.stringify(body) });
}

export function deleteDevice(host) {
  return request(`/devices/${encodeURIComponent(host)}`, { method: "DELETE" });
}

// success: true なら成功のみ、false なら失敗のみ(省略・null なら両方)。
export function listSnapshots({ host, hostContains, hosts, since, until, success, sort, order, limit, offset } = {}) {
  const params = new URLSearchParams();
  if (host) params.set("host", host);
  if (hostContains) params.set("host_contains", hostContains);
  for (const h of hosts ?? []) params.append("hosts", h);
  if (since) params.set("since", since);
  if (until) params.set("until", until);
  if (success != null) params.set("success", success ? "true" : "false");
  if (sort) params.set("sort", sort);
  if (order) params.set("order", order);
  if (limit != null) params.set("limit", limit);
  if (offset != null) params.set("offset", offset);
  const qs = params.toString() ? `?${params}` : "";
  return request(`/snapshots${qs}`);
}

// スナップショット1件の削除(取り消し不可)。スナップショットと、それが指す取得データを消す。
export function deleteSnapshot(host, snapshotId) {
  return request(`/snapshots/${encodeURIComponent(host)}/${encodeURIComponent(snapshotId)}`, { method: "DELETE" });
}

// snapshot があるホスト名の一覧。一覧画面の正規表現の絞り込みで、ブラウザ側で一致を
// 判定する対象に使う(正規表現そのものはサーバに送らない)。
export function listSnapshotHosts() {
  return request("/snapshots/hosts");
}

// before/after は host ごとに個別の対象({mode:"now",save} または
// {mode:"snapshot",snapshot_id})を持てる。
export function runHealthcheck(body) {
  return request(`/healthcheck`, { method: "POST", body: JSON.stringify(body) });
}

// POST /healthcheck/stream は同じ body を受け、機器ごとの取得進捗を
// Server-Sent Events で流す。onEvent はイベントごとに呼ばれる
// ({"type": "start"|"progress"|"comparing"|"error"|"complete", ...})。
// "complete" イベントの result が最終的な HealthCheckResult(runHealthcheck の
// 戻り値の result と同じ形)。
export function runHealthcheckStream(body, onEvent, signal) {
  return requestStream(`/healthcheck/stream`, body, onEvent, signal);
}

export function getSnapshotCommand(host, snapshotId, command) {
  return request(
    `/snapshots/${encodeURIComponent(host)}/${encodeURIComponent(snapshotId)}/commands/${encodeURIComponent(command)}`
  );
}

export function getSnapshotFull(host, snapshotId) {
  return request(`/snapshots/${encodeURIComponent(host)}/${encodeURIComponent(snapshotId)}/full`);
}

// POST /snapshots/take は進捗を Server-Sent Events で流す(機器ごとに完了した
// 順にイベントが届く)。onEvent はイベントごとに呼ばれる
// ({"type": "start"|"device_done"|"error"|"complete", ...})。
export function takeSnapshotStream(body, onEvent, signal) {
  return requestStream(`/snapshots/take`, body, onEvent, signal);
}

export function getCommandSets() {
  return request(`/command-sets`);
}

export function createCommandSet(body) {
  return request(`/command-sets`, { method: "POST", body: JSON.stringify(body) });
}

export function updateCommandSet(name, body) {
  return request(`/command-sets/${encodeURIComponent(name)}`, { method: "PUT", body: JSON.stringify(body) });
}

export function deleteCommandSet(name) {
  return request(`/command-sets/${encodeURIComponent(name)}`, { method: "DELETE" });
}

export function getCommandCatalog() {
  return request(`/command-catalog`);
}

export function createCommandCatalogEntry(body) {
  return request(`/command-catalog`, { method: "POST", body: JSON.stringify(body) });
}

export function updateCommandCatalogEntry(vendor, type, command, body) {
  return request(
    `/command-catalog/${encodeURIComponent(vendor)}/${encodeURIComponent(type)}/${encodeURIComponent(command)}`,
    { method: "PUT", body: JSON.stringify(body) }
  );
}

export function deleteCommandCatalogEntry(vendor, type, command) {
  return request(
    `/command-catalog/${encodeURIComponent(vendor)}/${encodeURIComponent(type)}/${encodeURIComponent(command)}`,
    { method: "DELETE" }
  );
}

// config/devices.csv(機器一覧の取得元。固定の1ファイル)。
export function downloadDevicesCsv() {
  return downloadFile(`/devices/csv`, "devices.csv");
}

export function uploadDevicesCsv(file) {
  return uploadFile(`/devices/csv`, file);
}

// コマンドカタログ・コマンドセットの設定YAML。どちらも複数ファイルのため、
// ディレクトリ単位(ZIP)でやり取りする。アップロードは同名を上書きし、含まれない
// ファイルはそのまま残す(カタログは ZIP のみ、コマンドセットは単一の .yaml も可)。
export function downloadCommandCatalogFiles() {
  return downloadFile(`/command-catalog/files`, "command_catalog.zip");
}

export function uploadCommandCatalogFiles(file) {
  return uploadFile(`/command-catalog/files`, file);
}

export function downloadCommandSetFiles() {
  return downloadFile(`/command-sets/files`, "command_set.zip");
}

export function uploadCommandSetFiles(file) {
  return uploadFile(`/command-sets/files`, file);
}

// config/proxy.conf(SSHプロキシ設定。固定の1ファイル)。
export function getProxy() {
  return request(`/proxy`);
}

export function putProxy(text) {
  return request(`/proxy`, { method: "PUT", body: JSON.stringify({ text }) });
}

export function downloadProxyConf() {
  return downloadFile(`/proxy/conf`, "proxy.conf");
}

export function uploadProxyConf(file) {
  return uploadFile(`/proxy/conf`, file);
}

export function getCredentials() {
  return request(`/credentials`);
}

export function setDefaultCredential(body) {
  return request(`/credentials/default`, { method: "PUT", body: JSON.stringify(body) });
}

export function setHostCredential(host, body) {
  return request(`/credentials/hosts/${encodeURIComponent(host)}`, { method: "PUT", body: JSON.stringify(body) });
}

export function deleteHostCredential(host) {
  return request(`/credentials/hosts/${encodeURIComponent(host)}`, { method: "DELETE" });
}

// 実行ログ(data/healthcheck.log。収集層がコマンド・問い合わせ単位で記録したもの)。
// q は任意の文字列の部分一致(ホスト名・コマンド名・エラー文言等、行の中身全体が対象)。
// since は開始イベントの log_since(サーバ時刻)で、それ以降の行だけに絞る。
// hosts を渡すと、その機器のログ行だけに絞る。
export function getLogs({ q, limit, since, hosts } = {}) {
  const params = new URLSearchParams();
  if (q) params.set("q", q);
  if (limit != null) params.set("limit", limit);
  if (since) params.set("since", since);
  for (const host of hosts ?? []) params.append("hosts", host);
  const qs = params.toString() ? `?${params}` : "";
  return request(`/logs${qs}`);
}
