import { useEffect, useState } from "react";
import { keepPreviousData, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  listDevices, getCommandSets, getCommandCatalog, getCredentials, getProxy,
  listSnapshots, listSnapshotHosts, getSnapshotFull, getLogs,
} from "./client";

// サーバからの読み込み(TanStack Query)を資源ごとに1か所にまとめる。
//
// - 読み込み中・エラー・結果の状態は Query が持つ(各画面で loading/error の state を
//   書かない)。表示は components/QueryStatus.jsx の部品でそろえる。
// - 同じ資源は画面をまたいで共有する(例: 機器一覧は機器の画面・正常性確認・取得で同じ
//   キャッシュ)。画面を開き直すとキャッシュをすぐ表示し、裏で読み込み直す。
// - 保存・削除・取り込みの後は useInvalidate() で該当する資源を読み込み直す。
// - 引数の違う問い合わせ(スナップショット一覧の絞り込み)はキーで区別するので、遅れて
//   届いた古い応答が新しい表示を上書きすることはない。
// - 版(If-Match)の扱いは client.js が読み込みの応答から覚えるので、ここでは何もしない。
//
// 実行の進捗(SSE)は Query の対象にしない(一度きりの処理で、キャッシュする意味が無いため)。

export const queryKeys = {
  devices: ["devices"],
  commandSets: ["command-sets"],
  commandCatalog: ["command-catalog"],
  credentials: ["credentials"],
  proxy: ["proxy"],
  snapshots: ["snapshots"],               // 一覧(引数付き)・ホスト名一覧・詳細の共通の先頭
  logs: ["logs"],
};

export function useDevices() {
  return useQuery({ queryKey: queryKeys.devices, queryFn: () => listDevices() });
}

export function useCommandSets() {
  return useQuery({ queryKey: queryKeys.commandSets, queryFn: getCommandSets });
}

export function useCommandCatalog() {
  return useQuery({ queryKey: queryKeys.commandCatalog, queryFn: getCommandCatalog });
}

export function useCredentials() {
  return useQuery({ queryKey: queryKeys.credentials, queryFn: getCredentials });
}

export function useProxy() {
  return useQuery({ queryKey: queryKeys.proxy, queryFn: getProxy });
}

// スナップショット一覧(サーバ側でページング・絞り込み)。ページや条件を変えている間は
// 前の結果を出したまま(keepPreviousData)にして、表が一瞬空になるのを防ぐ。
// enabled=false の間は問い合わせない(正規表現に一致するホストを判定中など)。
export function useSnapshotList(params, { enabled = true } = {}) {
  return useQuery({
    queryKey: [...queryKeys.snapshots, "list", params],
    queryFn: () => listSnapshots(params),
    placeholderData: keepPreviousData,
    enabled,
  });
}

export function useSnapshotHosts({ enabled = true } = {}) {
  return useQuery({
    queryKey: [...queryKeys.snapshots, "hosts"],
    queryFn: listSnapshotHosts,
    enabled,
  });
}

export function useSnapshotFull(host, snapshotId) {
  return useQuery({
    queryKey: [...queryKeys.snapshots, "full", host, snapshotId],
    queryFn: () => getSnapshotFull(host, snapshotId),
    enabled: Boolean(host && snapshotId),
    staleTime: Infinity,                  // 保存済みのスナップショットの中身は変わらない
  });
}

export function useLogs(params) {
  return useQuery({
    queryKey: [...queryKeys.logs, params],
    queryFn: () => getLogs(params),
    placeholderData: keepPreviousData,
  });
}

// 保存・削除・取り込みの後に、該当する資源を読み込み直す。
//   const invalidate = useInvalidate();  await invalidate(queryKeys.devices);
export function useInvalidate() {
  const queryClient = useQueryClient();
  return (key) => queryClient.invalidateQueries({ queryKey: key });
}

// 入力に追従する値を、入力が止まってから delay ミリ秒後に反映する(1文字ごとに
// サーバへ問い合わせないため)。
export function useDebouncedValue(value, delay = 300) {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const timer = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(timer);
  }, [value, delay]);
  return debounced;
}

// 機器一覧を、機器選択の部品(components/DeviceSelector.jsx)が受け取る形で返す
// (正常性確認・スナップショット取得の機器選択で使う。以前の hooks/useDeviceSearch.js の置き換え)。
const NO_DEVICES = [];
export function useDeviceList() {
  const query = useDevices();
  return {
    devices: query.data ?? NO_DEVICES,
    loading: query.isPending,
    error: query.error ? `機器一覧を読み込めませんでした: ${query.error.message}` : null,
    refetch: query.refetch,
  };
}
