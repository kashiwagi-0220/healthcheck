import path from 'node:path'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import { defineConfig } from 'vite'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      '@': path.resolve(import.meta.dirname, './src'),
    },
  },
  build: {
    // 画面は社内ネットワークで API と同じサーバから配信し、assets/ は長期キャッシュされる
    // (gui/backend/app/main.py)ため、1ファイル 500 KB 前後でも表示の遅さは問題にならない。
    // 分割の設定を増やすより単純さを優先し、警告の目安だけを上げる(gzip 後は 150 KB 程度)。
    chunkSizeWarningLimit: 800,
  },
})
