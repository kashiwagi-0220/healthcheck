"""
gui.backend.app.noise_overrides — 正常性確認の「差分判定のノイズを調整する(この実行のみで有効)」

正常性確認の確認ステップで、その実行だけノイズを調整する(2026-11-22)。画面での呼び方:
- exclude(登録済みのノイズのうち「差分判定に利用する」もの): カタログに登録済みのノイズを、
  今回は効かせない(その差分も判定に入る)。
- add(「追加登録のノイズ」): カタログに無いパスを、今回だけノイズに加える(差分判定に利用しない)。

実行に使うカタログの写しを作って compare_device に渡すだけで、カタログのファイルも
コア(healthcheck/)も変えない。写しはその実行の中だけで使うので、ほかの利用者の
実行には影響しない。取得(take_snapshot)はノイズを使わないので、写しは比較にだけ使う。
"""

from __future__ import annotations

from dataclasses import replace

from healthcheck.command import CommandCatalog

from app.key_paths import path_problem


def apply_noise_overrides(catalog: CommandCatalog, overrides) -> CommandCatalog:
    """overrides({vendor: {type: {command: NoiseOverrideIn}}})を当てたカタログの写しを返す。
    指定が無ければ catalog をそのまま返す。指定に問題があれば ValueError(取得を始める前に
    呼び、不正な指定で機器に接続しないようにする)。

    写しの noise は「カタログの noise − exclude + add」(順序はカタログの並びのあとに add)。
    add がカタログに既にあるパスなら重ねない。同じパスを exclude と add の両方に書いたら断る。"""
    if not overrides:
        return catalog
    by_vendor_type = {v: {t: dict(cmds) for t, cmds in types.items()}
                      for v, types in catalog.by_vendor_type.items()}
    for vendor, types in overrides.items():
        for type_, commands in types.items():
            for command, ov in commands.items():
                where = f"{vendor}/{type_} '{command}'"
                spec = by_vendor_type.get(vendor, {}).get(type_, {}).get(command)
                if spec is None:
                    raise ValueError(f"{where}: コマンドカタログに無いコマンドです。")
                exclude, add = list(ov.exclude), list(ov.add)
                unknown = [p for p in exclude if p not in spec.noise]
                if unknown:
                    raise ValueError(f"{where}: 差分判定に利用する指定ができるのは登録済みのノイズだけです: {', '.join(unknown)}")
                both = sorted(set(exclude) & set(add))
                if both:
                    raise ValueError(f"{where}: 同じパスを「差分判定に利用する」と「追加登録のノイズ」の両方に指定しています: {', '.join(both)}")
                for p in add:
                    problem = path_problem(p)
                    if problem:
                        raise ValueError(f"{where}: 追加登録のノイズ: {problem}")
                noise = [p for p in spec.noise if p not in exclude]
                noise += [p for p in dict.fromkeys(add) if p not in noise]
                by_vendor_type[vendor][type_][command] = replace(spec, noise=noise)
    return CommandCatalog(by_vendor_type=by_vendor_type)


def describe_overrides(overrides) -> str:
    """ログ用の1行要約(例 "cisco/ios 'show version' 判定に利用1 追加登録2")。"""
    parts = []
    for vendor, types in (overrides or {}).items():
        for type_, commands in types.items():
            for command, ov in commands.items():
                if ov.exclude or ov.add:
                    parts.append(f"{vendor}/{type_} '{command}' 判定に利用{len(ov.exclude)} 追加登録{len(ov.add)}")
    return "; ".join(parts)
