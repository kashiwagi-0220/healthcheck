"""
gui.backend.app.schemas — GUI固有のリクエスト/レスポンス型(pydantic)

healthcheck パッケージの dataclass(Device/Snapshot/HealthCheckResult 等)は
response としてそのまま使う(app/api/*.py 参照)。ここに置くのは、CLIコアには
存在しないGUI固有の入力形状(例: before/after の mode 判別)のみ。
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class HostTargetIn(BaseModel):
    """1機器分の比較対象。mode="now" なら今すぐ取得(save で保存有無)、
    mode="snapshot" なら snapshot_id を直接指定する(「最新」は GUI 側が現時点の
    最新 snapshot_id にあらかじめ解決してから渡す)。"""
    mode: Literal["now", "snapshot"]
    snapshot_id: str | None = None   # mode="snapshot" の時のみ
    save: bool = False               # mode="now" の時のみ意味を持つ


class NoiseOverrideIn(BaseModel):
    """1コマンド分の、その実行だけのノイズ調整(app/noise_overrides.py)。exclude は登録済みの
    ノイズのうち今回は差分判定に利用するもの(ノイズとして効かせない)、add は追加登録のノイズ
    (今回だけ足すパス。区切りは ":")。"""
    exclude: list[str] = Field(default_factory=list)
    add: list[str] = Field(default_factory=list)


class HealthCheckRequest(BaseModel):
    """POST /healthcheck・POST /healthcheck/stream 共通。host ごとに独立した
    比較対象(今すぐ取得/個別スナップショット指定)を混在させられる。
    noise_overrides は {vendor: {type: {command: NoiseOverrideIn}}} で、その実行の比較に
    だけ効く(保存しない。2026-11-22)。"""
    hosts: list[str]
    before: dict[str, HostTargetIn]
    after: dict[str, HostTargetIn]
    max_concurrency: int = 10
    retries: int = 1
    noise_overrides: dict[str, dict[str, dict[str, NoiseOverrideIn]]] = Field(default_factory=dict)


class CommandSetIn(BaseModel):
    """コマンドセットの中身(名前を除く)。作成・更新どちらの本文にも使う。
    cli・rest はどちらも文字列のリスト(rest は CommandCatalog に定義された
    REST の key。実行内容の method/path はコマンドカタログ側が持つため、ここでは
    持たない)。vendor/type はこのコマンドセットが対象とする機種(両方必須)。"""
    vendor: str
    type: str
    description: str | None = None
    cli: list[str] = Field(default_factory=list)
    rest: list[str] = Field(default_factory=list)


class CommandSetCreateIn(CommandSetIn):
    name: str


class DeviceIn(BaseModel):
    """機器1件分の入力(host を除く)。新規作成・編集どちらの本文にも使う。
    command_set は任意(未指定なら空欄のまま)。"""
    vendor: str
    type: str
    ip: str | None = None
    command_set: str | None = None


class DeviceCreateIn(DeviceIn):
    host: str


class CredentialEntryIn(BaseModel):
    """認証情報1件分の変更内容(config/credentials.yaml の default / hosts.<host> に書く)。

    パスワード類はブラウザへ返さないため(GET は設定済みかどうかだけを返す)、画面は今の値を
    知らない。そのため「空 = 変更しない」とする:
      - password: 空(None/"")なら今の値を残す。今の値が無い(新規)のに空なら 400。
      - secret(enable/特権パスワード): 空なら今の値を残す。clear_secret=True なら消す
        (secret と同時に指定した場合は 400)。
    """
    username: str
    password: str | None = None
    secret: str | None = None
    clear_secret: bool = False


class CredentialEntryOut(BaseModel):
    """認証情報1件分の表示用。パスワード類の値は含めず、設定済みかどうかだけを返す。"""
    username: str | None
    has_password: bool
    has_secret: bool


class CommandCatalogEntryIn(BaseModel):
    """コマンドカタログ1件分(vendor/type/commandを除く。CommandSpecと同じ形)。
    作成・更新どちらの本文にも使う。保存前に CliPolicy(CLI のコマンド)・RestPolicy
    (REST の method)で検査する(command_catalog.py 参照)。"""
    parser: Literal["genie", "textfsm", "json"]
    noise: list[str] = Field(default_factory=list)
    compare_keys: list[str] | None = None
    method: str = "get"
    path: str | None = None
    description: str | None = None


class CommandCatalogEntryCreateIn(CommandCatalogEntryIn):
    vendor: str
    type: str
    command: str
