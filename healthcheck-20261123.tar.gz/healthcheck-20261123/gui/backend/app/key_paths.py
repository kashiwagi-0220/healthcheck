"""
gui.backend.app.key_paths — ノイズ・比較キーのパス表記の検査

パスの区切りは ":"(healthcheck.common.diff.PATH_SEP。2026-11-22 に "." から変更)。
区切りを変えたため、古い書き方("a.b.c")のパスは、コアでは「"." を含む1つのキー」として
読まれ、どこにも一致せず黙って効かなくなる。古いバックアップの取り込みや書き間違いで
そうならないよう、保存・取り込み・実行時の指定(追加登録のノイズ)の前にここで断る。

規則:
- "." を含み ":" を含まないパスは古い書き方として断る。そのため、1階層だけで "." を含む
  キー(トップレベルの経路など)は書けない(取得済みのパース結果のトップレベルにそうした
  キーは無いため、制約として受け入れる)。
- 空の階層("a::b"、先頭・末尾の ":")は断る(書き間違いで、どこにも一致しないため)。
"""

from __future__ import annotations

from healthcheck.common.diff import PATH_SEP


def path_problem(path: str) -> str | None:
    """パスの書き方に問題があれば理由を返す(問題が無ければ None)。"""
    if not path or not path.strip():
        return "空のパスは指定できません。"
    if "." in path and PATH_SEP not in path:
        return (f"'{path}' は古い書き方の可能性があります。階層の区切りは「{PATH_SEP}」です"
                f"(例 interfaces{PATH_SEP}*{PATH_SEP}last_change)。")
    if any(part == "" for part in path.split(PATH_SEP)):
        return f"'{path}' に空の階層があります(「{PATH_SEP}」が続いているか、先頭・末尾にあります)。"
    return None


def first_problem(paths: list[str] | None, label: str) -> str | None:
    """paths の中で最初に見つかった問題を、label(例 "noise")を添えて返す。"""
    for p in paths or []:
        problem = path_problem(p)
        if problem:
            return f"{label}: {problem}"
    return None
