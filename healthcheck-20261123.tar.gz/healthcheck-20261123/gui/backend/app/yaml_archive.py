"""
gui.backend.app.yaml_archive — 設定YAMLディレクトリのZIP入出力

コマンドカタログ(config/command/command_catalog/)とコマンドセット
(config/command/command_set/)は複数ファイルで構成されるため、devices.csv のような
1ファイルのやり取りではなくディレクトリ単位(ZIP)でダウンロード/アップロードする。
コマンドセットは単一の .yaml を直接アップロードすることもできる(他環境から1件だけ
持ち込む場合。ファイル名がそのままコマンドセット名になる)。コマンドカタログは
<vendor>/<type>.yaml の2階層で、単一の YAML ではどのベンダーに置くか決まらないため
ZIP のみ受け付ける(以前は直下に置いてしまい、カタログ全体が読めなくなっていた)。

アップロードは「同名は上書き、それ以外の既存ファイルは残す」マージ方式。ZIPに無い
ファイルを消さないのは、復元のつもりが取り違えたZIPで全件消える事故を避けるため
(不要なファイルの削除は画面側の削除操作で行う)。

展開先はアーカイブ内のパスをそのまま使うため、次を満たさないメンバーは拒否する:
  - 絶対パス・`..` を含むパス(展開先ディレクトリの外へ書き出させない)
  - `.yaml` 以外の拡張子(読み込み側は *.yaml しか見ないため、.yml は黙って無視される
    ことになる。気づきにくいので受け付けない)
  - 階層が想定と違うもの(カタログは <vendor>/<type>.yaml のちょうど2階層、セットは
    <name>.yaml の1階層)と、名前に英数字・`_`・`-` 以外を含むもの(画面から編集・削除
    できる名前に限る)
さらに、書き込む前に「今の一式+取り込むファイル」を一時ディレクトリに組み立て、
呼び出し側が渡す validate(コアの読み込み関数そのもの)で読めるかを確かめる。1件でも
読めなければ何も書き込まずに中断する(一部だけ反映された状態や、読み込み時に全体が
失敗する状態を作らないため。検査の基準を実行時の読み込みと同じにするため、独自の
構造チェックは最小限にする)。
"""

from __future__ import annotations

import io
import re
import shutil
import tempfile
import zipfile
from pathlib import Path
from typing import Callable

import yaml

from app.config_files import atomic_write_text

_YAML_SUFFIX = ".yaml"
_NAME_RE = re.compile(r"^[A-Za-z0-9_-]+$")


def build_zip(root: Path) -> bytes:
    """root 配下の YAML を、root からの相対パスでZIPに詰めて返す。"""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(root.rglob("*")):
            if path.is_file() and path.suffix == _YAML_SUFFIX:
                zf.write(path, path.relative_to(root).as_posix())
    return buf.getvalue()


def _check_member_path(name: str, depth: int) -> Path:
    """ZIPメンバー名を検証し、root からの相対パスとして返す。depth はちょうどの階層数。"""
    if name.endswith("/"):
        raise ValueError(f"ディレクトリは含められません: {name}")
    rel = Path(name)
    if rel.is_absolute() or ".." in rel.parts:
        raise ValueError(f"使用できないパスです: {name}")
    if rel.suffix != _YAML_SUFFIX:
        raise ValueError(f"拡張子が .yaml のファイル以外は含められません: {name}")
    if len(rel.parts) != depth:
        shape = "<ベンダー>/<タイプ>.yaml" if depth == 2 else "<名前>.yaml"
        raise ValueError(f"置き場所が違います({shape} の形にしてください): {name}")
    for part in (*rel.parts[:-1], rel.stem):
        if not _NAME_RE.match(part):
            raise ValueError(f"名前には半角英数字・アンダースコア(_)・ハイフン(-)のみ使用できます: {name}")
    return rel


def save_upload(
    root: Path, filename: str, content: bytes, *, depth: int, validate: Callable[[Path], None],
) -> list[str]:
    """アップロードされた ZIP または単一 YAML を root 配下へ保存する。

    depth は root からの階層数(コマンドカタログは <vendor>/<type>.yaml の2、
    コマンドセットは <name>.yaml の1)。単一 YAML は depth=1 のときだけ受け付ける。
    validate は一時ディレクトリ(今の一式+取り込み分)を受け取り、読めなければ例外を
    投げる関数(コアの from_directory を使う)。保存したファイルの相対パス一覧を返す。
    """
    name = (filename or "").strip()
    if name.lower().endswith(".zip"):
        entries = _read_zip(content, depth)
    elif name.lower().endswith(_YAML_SUFFIX) and depth == 1:
        rel = _check_member_path(Path(name).name, depth=1)
        entries = [(rel, _parse_yaml(content, rel.as_posix()))]
    elif depth == 1:
        raise ValueError("ZIP(.zip)または YAML(.yaml)ファイルを指定してください。")
    else:
        raise ValueError("ZIP(.zip)ファイルを指定してください(<ベンダー>/<タイプ>.yaml の形で入れたもの)。")

    if not entries:
        raise ValueError("保存できるYAMLファイルが含まれていません。")

    _validate_merged(root, entries, validate)

    saved = []
    for rel, text in entries:
        atomic_write_text(root / rel, text)
        saved.append(rel.as_posix())
    return saved


def _validate_merged(root: Path, entries: list[tuple[Path, str]], validate: Callable[[Path], None]) -> None:
    """今の一式に取り込み分を重ねた状態を一時ディレクトリに作り、validate で読めるかを確かめる。"""
    with tempfile.TemporaryDirectory(prefix="hc-upload-") as tmp:
        merged = Path(tmp) / "root"
        shutil.copytree(root, merged)
        for rel, text in entries:
            (merged / rel).parent.mkdir(parents=True, exist_ok=True)
            (merged / rel).write_text(text, encoding="utf-8")
        try:
            validate(merged)
        except Exception as e:
            # 一時ディレクトリのパスは利用者に意味が無いので、メッセージから取り除く
            msg = str(e).replace(str(merged) + "/", "").replace(str(merged), "")
            raise ValueError(f"取り込んだ後の設定に問題があるため、取り込みませんでした: {msg}")


def _read_zip(content: bytes, depth: int) -> list[tuple[Path, str]]:
    try:
        zf = zipfile.ZipFile(io.BytesIO(content))
    except zipfile.BadZipFile:
        raise ValueError("ZIPファイルとして読み込めません。")
    with zf:
        entries = []
        for info in zf.infolist():
            if info.is_dir():
                continue
            rel = _check_member_path(info.filename, depth)
            entries.append((rel, _parse_yaml(zf.read(info), info.filename)))
    return entries


def _parse_yaml(raw: bytes, label: str) -> str:
    """YAMLとして妥当なことだけ確認し、元のテキストをそのまま返す。

    中身の構造(コマンドカタログなら cli/rest 等)はここでは見ない。取り込んだ後の一式
    として読めるかは、save_upload が validate(コアの from_directory)で確かめる。
    """
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        raise ValueError(f"UTF-8として読み込めません: {label}")
    try:
        yaml.safe_load(text)
    except yaml.YAMLError as e:
        raise ValueError(f"YAMLとして読み込めません({label}): {e}")
    return text
