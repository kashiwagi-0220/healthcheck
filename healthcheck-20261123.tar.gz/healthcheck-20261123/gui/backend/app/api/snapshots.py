"""
gui.backend.app.api.snapshots — snapshot一覧・取得API

既存の healthcheck.storage.FilesystemStore をそのまま呼ぶだけの薄いエンドポイント
(照会系。GUI が「どの snapshot と比較するか」を選択・解決するために使う)。
一覧(GET /snapshots)は until・ページング(limit/offset)付きで
`{"items": [...], "total": N}` を返す(コアの list_snapshots 自体は絞り込みを
持たず、GUI側で絞り込み・並び替え・切り出しを行う)。

一覧に加え、1つの snapshot 内の1コマンド分の実データ(raw / parsed)を取得する
エンドポイント、全コマンド分をまとめて取得するエンドポイント(GUI側での一括
ダウンロード用)を持つ(いずれも DataStore.load_raw / load_parsed をそのまま
呼ぶだけ)。

「スナップショット取得」(POST /snapshots/take)は healthcheck.common.take_snapshot
をそのまま呼ぶ実行系エンドポイント(healthchecks.py の execute_healthcheck と同じ
構成部品の組み立て方)。save の値に関わらず取得直後のレスポンスで結果をそのまま
表示・ダウンロードできる(SSEイベントに raw/parsed をそのまま埋め込むため)。
save=True なら FilesystemStore(ディスクへ保存)、save=False なら InMemoryDataStore
(ディスクへは一切書かない。リクエスト限りのメモリ上のみ)を data_store として渡す。
「保存しない」場合に本当に何もディスクへ残らないようにするため、manifest だけでなく
store 自体を切り替える(take_snapshot は DataStore という抽象IFにしか依存しないため、
渡す実装を変えるだけで済む)。

POST /snapshots/take は Server-Sent Events(text/event-stream)で進捗を流す。
take_snapshot() が完了した機器から順に yield する(healthcheck/common/snapshot.py
参照)ため、GUI側もリスト化して待たず、結果が届いた端からイベントとして流す。
イベント種別は
{"type": "start", "total": N, "log_since": ...}(開始。N は要求された host 数。実際に
取得対象となる機器数(コマンド未定義の機器はtake_snapshot側でスキップされる)と
一致しない場合があるが、進捗表示の目安としては十分。log_since はこの時点のサーバ
時刻で、画面がこの実行のログだけを GET /logs から取るための起点)/
{"type": "device_done", "done": M, "total": N, "host": ..., ...}(1機器完了)/
{"type": "error", "message": ...}(検証エラー等で中断)/
{"type": "complete"}(全機器完了)。コアには進捗通知の仕組みを持ち込まず、GUI側が
take_snapshot() の既存のyield(機器ごとの完了)をそのままSSEに変換するだけに
留めている。

削除(2026-11-22)は DELETE /snapshots/{host}/{id}(1件ずつ)。コアの
DataStore.delete_snapshot を呼ぶだけで、スナップショットとそれが指すコマンドの取得データを
消す(取り消し不可)。
"""

from __future__ import annotations

import logging
import re
import threading
from datetime import datetime, timezone
from typing import Literal

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from healthcheck.storage import FilesystemStore, InMemoryDataStore
from healthcheck.models import Snapshot
from healthcheck.common.snapshot import take_snapshot

from app.config import DATA_ROOT
from app.logging_config import log_timestamp
from app.sources import build_collection_parts, resolve_devices
from app.sse import sse_event

logger = logging.getLogger(__name__)

router = APIRouter()


def _store() -> FilesystemStore:
    return FilesystemStore(DATA_ROOT)


def _natural_key(text: str) -> list:
    """数字の部分を数として比べるための並べ替えキー("RT-2" < "RT-10")。大小文字は区別しない。"""
    return [(0, int(part), "") if part.isdigit() else (1, 0, part.lower())
            for part in re.split(r"(\d+)", text) if part != ""]


def _parse_iso(value: str | None, name: str) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=f"{name} が不正なISO8601です: {e}")


@router.get("/snapshots")
def list_snapshots(
    host: str | None = Query(default=None, description="完全一致。省略時は全機器"),
    host_contains: str | None = Query(
        default=None, description="ホスト名の部分一致(大小文字区別なし。一覧画面の自由語検索用)"
    ),
    since: str | None = Query(
        default=None, description="ISO8601(例 2026-09-01T00:00:00+00:00)。指定時刻以降のみ"
    ),
    until: str | None = Query(
        default=None, description="ISO8601。指定時刻以前のみ"
    ),
    hosts: list[str] | None = Query(
        default=None,
        description="ホスト名の完全一致の一覧(複数指定可)。一覧画面の正規表現の絞り込みで使う",
    ),
    success: bool | None = Query(
        default=None, description="true なら成功のみ、false なら失敗のみ。省略時は両方"
    ),
    sort: Literal["taken_at", "host", "success"] = Query(
        default="taken_at", description="並べ替えの列。省略時は取得時刻"
    ),
    order: Literal["asc", "desc"] = Query(
        default="desc", description="asc(昇順)/ desc(降順)。省略時は降順(新しい順)"
    ),
    limit: int = Query(default=100, ge=1, le=1000, description="1ページの件数"),
    offset: int = Query(default=0, ge=0, description="先頭からのスキップ件数"),
):
    """snapshot 一覧(ページング付き)。コア(healthcheck.storage)の list_snapshots は
    host(完全一致)/since までしか絞り込めない(CLI側の用途では十分なため)。
    host_contains・until・ページングは GUI一覧画面が大量の snapshot で固まらない
    ようにするための表示都合の機能なので、コアには持ち込まずここ(GUIバックエンド)
    で行う(host 単位・時系列の全件を一度読んでから絞り込む。機器数・snapshot数が
    今の規模(実機ラボ相当)であれば十分)。host(完全一致)は他の呼び出し側
    (healthchecks.py の前提となる「特定ホストのsnapshotだけを引く」用途)がそのまま
    使えるよう挙動を変えていない。host_contains を使う場合は絞り込みのため全件を
    読む(host のような1機器分だけを読むディレクトリ限定はできない)。新しい順
    (taken_at 降順)に並べてから offset/limit で切り出す。

    hosts は一覧画面の正規表現の絞り込み用。正規表現はサーバでは実行せず、画面が
    GET /snapshots/hosts のホスト名に対してブラウザ側で判定し、一致したホスト名を
    ここに渡す(任意の正規表現をサーバで実行すると、極端に遅い正規表現でサーバの
    処理を止められてしまうため)。

    success は成否の絞り込み(manifest に既にある値なので追加の読み込みは無い)。以前は
    画面が表示中の1ページ分だけを絞り込んでいたため、他のページの失敗が出ず、件数も
    絞り込み前のままだった。total は全ての絞り込みを掛けた後の件数。

    sort/order は列の並べ替え(2026-11-22)。ページ分けをここで行うため、画面の中だけでは
    全体を正しく並べられず、サーバで並べる。まず取得時刻の新しい順に並べ、そのうえで
    指定の列で安定ソートする(同じホスト・同じ成否の中は新しい順のまま)。ホスト名は
    数字を数の大きさで比べる(RT-2 が RT-10 より前)。成否の昇順は失敗が先。"""
    since_dt = _parse_iso(since, "since")
    until_dt = _parse_iso(until, "until")

    snapshots = _store().list_snapshots(host=host, since=since_dt)
    if host_contains:
        needle = host_contains.strip().lower()
        snapshots = [s for s in snapshots if needle in s.host.lower()]
    if hosts is not None:
        wanted = set(hosts)
        snapshots = [s for s in snapshots if s.host in wanted]
    if until_dt:
        snapshots = [s for s in snapshots if not s.taken_at or s.taken_at <= until_dt]
    if success is not None:
        snapshots = [s for s in snapshots if bool(s.success) == success]
    snapshots.sort(key=lambda s: s.taken_at or datetime.min.replace(tzinfo=timezone.utc), reverse=True)
    if sort == "taken_at":
        if order == "asc":
            snapshots.reverse()
    else:
        key = (lambda s: _natural_key(s.host)) if sort == "host" else (lambda s: bool(s.success))
        snapshots.sort(key=key, reverse=(order == "desc"))

    total = len(snapshots)
    return {"items": snapshots[offset:offset + limit], "total": total}


@router.get("/snapshots/hosts")
def list_snapshot_hosts() -> dict:
    """snapshot があるホスト名の一覧(重複なし・名前順)。一覧画面の正規表現の絞り込みが、
    ブラウザ側で一致を判定する対象として使う(GET /snapshots の hosts を参照)。インベントリ
    から外した機器の snapshot も残っているため、機器一覧ではなく snapshot から集める。"""
    return {"hosts": sorted({s.host for s in _store().list_snapshots()})}


# 削除は同じ機器の manifest を読み比べてから消すため、削除どうしが重ならないようにする
# (プロセス内のロック。uvicorn は1プロセスで動かす前提。README の起動方法どおり)。
_delete_lock = threading.Lock()


@router.delete("/snapshots/{host}/{snapshot_id}", status_code=204)
def delete_snapshot(host: str, snapshot_id: str) -> None:
    """スナップショット1件と、それが指すコマンドの取得データを削除する(取り消し不可。
    healthcheck.storage の DataStore.delete_snapshot)。無ければ 404、host・id が不正なら 400。"""
    with _delete_lock:
        try:
            deleted = _store().delete_snapshot(host, snapshot_id)
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))
    if not deleted:
        raise HTTPException(status_code=404, detail="スナップショットが見つかりません(すでに削除された可能性があります)")
    logger.info("スナップショットを削除しました: %s %s", host, snapshot_id)


@router.get("/snapshots/{host}/{snapshot_id}", response_model=Snapshot)
def get_snapshot(host: str, snapshot_id: str) -> Snapshot:
    snap = _store().get_snapshot(host, snapshot_id)
    if snap is None:
        raise HTTPException(status_code=404, detail="スナップショットが見つかりません")
    return snap


@router.get("/snapshots/{host}/{snapshot_id}/commands/{command}")
def get_snapshot_command(host: str, snapshot_id: str, command: str):
    snap = _store().get_snapshot(host, snapshot_id)
    if snap is None:
        raise HTTPException(status_code=404, detail="スナップショットが見つかりません")
    ref = snap.refs.get(command)
    if ref is None:
        raise HTTPException(status_code=404, detail=f"このスナップショットにコマンドがありません: {command}")
    store = _store()
    return {
        "command": command,
        "raw": store.load_raw(ref),
        "parsed": store.load_parsed(ref),
    }


@router.get("/snapshots/{host}/{snapshot_id}/full")
def get_snapshot_full(host: str, snapshot_id: str):
    """1つの snapshot の全コマンド分の raw/parsed をまとめて返す(一覧画面での
    詳細表示・一括ダウンロード用)。"""
    snap = _store().get_snapshot(host, snapshot_id)
    if snap is None:
        raise HTTPException(status_code=404, detail="スナップショットが見つかりません")
    store = _store()
    return {
        "host": host,
        "id": snap.id,
        "taken_at": snap.taken_at,
        "success": snap.success,
        "error": snap.error,
        "commands": {
            cmd: {"raw": store.load_raw(ref), "parsed": store.load_parsed(ref)}
            for cmd, ref in snap.refs.items()
        },
    }


class TakeSnapshotIn(BaseModel):
    hosts: list[str]
    save: bool = True
    max_concurrency: int = 10
    retries: int = 1


def _take_snapshot_events(
    devices, *, command_set, command_catalog, cli_collector, save, max_concurrency, retries,
):
    # save=False の場合、ディスクには一切書き込まない InMemoryDataStore を使う。
    store = _store() if save else InMemoryDataStore()
    total = len(devices)
    yield sse_event("start", total=total, log_since=log_timestamp())

    done = 0
    try:
        for snap in take_snapshot(
            devices,
            data_store=store,
            command_set=command_set,
            command_catalog=command_catalog,
            cli_collector=cli_collector,
            max_concurrency=max_concurrency,
            retries=retries,
            save=save,
        ):
            done += 1
            yield sse_event(
                "device_done",
                done=done,
                total=total,
                host=snap.host,
                id=snap.id,
                taken_at=snap.taken_at,
                success=snap.success,
                error=snap.error,
                saved=save,
                commands={
                    cmd: {"raw": store.load_raw(ref), "parsed": store.load_parsed(ref)}
                    for cmd, ref in snap.refs.items()
                },
            )
    except ValueError as e:
        yield sse_event("error", message=str(e))
        return
    except ImportError as e:
        yield sse_event("error", message=f"収集エンジンの読み込みに失敗しました: {e}")
        return

    yield sse_event("complete")


@router.post("/snapshots/take")
def take_snapshot_now(req: TakeSnapshotIn) -> StreamingResponse:
    devices = resolve_devices(req.hosts)

    command_set, command_catalog, cli_collector = build_collection_parts()

    return StreamingResponse(
        _take_snapshot_events(
            devices, command_set=command_set, command_catalog=command_catalog,
            cli_collector=cli_collector, save=req.save,
            max_concurrency=req.max_concurrency, retries=req.retries,
        ),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache"},
    )
