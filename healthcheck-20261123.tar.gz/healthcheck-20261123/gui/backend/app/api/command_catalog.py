"""
gui.backend.app.api.command_catalog — コマンドカタログ照会・作成・更新・削除API

既存の healthcheck.command.CommandCatalog(config/command/command_catalog/<vendor>/<type>.yaml
から1ファイル=1機種で読み込み)を使う。読み込みは CommandCatalog.from_directory()
にそのまま委ねるが、作成/更新/削除(ファイルの書き込み)はコアに持ち込まず、ここ
(GUIバックエンド)に閉じる方針(command_sets.py と同じ考え方)。

1エントリ = 1つの (vendor, type, command)。vendor/type/command は作成時のみ指定でき、
編集時は固定(command_sets.py の name・devices.py の host と同じく、キーそのものの
変更はここでは扱わない。変えたい場合は削除して作り直す)。

parser が "json" かどうかで、ファイル内の cli ブロックと rest ブロックのどちらに
書くかを機械的に決める(コア側の不変条件と同じ。command_catalog.py 参照)。
vendor/type はディレクトリ名・ファイル名になるため、パス上安全な文字(英数字・
アンダースコア・ハイフン)のみ許可する(パストラバーサル対策。command はファイル名に
ならない=辞書のキーでしかないため制限しない。空白を含む CLI コマンドもそのまま使える)。
作成時の command は、前後の空白を取り続いた空白を1つにまとめてから保存する(大文字・
小文字は変えない)。
1件の作成・更新では、取得の実行時と同じ CliPolicy(CLI のコマンドが show 等で始まるか)・
RestPolicy(REST の method が get か)で検査し、許可されないものは保存しない(実行時に
弾かれるだけの設定を作らせないため)。条件はコアの CliPolicy/RestPolicy をそのまま使い、
ここには書かない。ファイルの取り込みはこの検査の対象外。

保存系(作成・更新・削除・取り込み)は、読み込んだ後に他の利用者が変更していないかを
版(If-Match)で確かめてから書き込む(app/config_files.py)。版はコマンドカタログ全体
(ディレクトリ配下の YAML 一式)で1つ。

ファイルの読み書きは ruamel.yaml の round-trip で行い、手で書いたコメント(F5・Palo Alto
の検証メモなど)や他のエントリの書式をそのまま残す(以前は PyYAML で書き直していたため、
1件編集するとコメントが全て消えていた)。null の表記と行の折り返しは、これまでの
ファイル(PyYAML の safe_dump で書いたもの)と同じになるように合わせてある。

削除は、そのコマンドをいずれかのコマンドセットが使っていれば 409 で断る(消すと、その
セットを使う機器の取得が「カタログに無いコマンド」で全て失敗するため)。
"""

from __future__ import annotations

import io
import logging
import re
from dataclasses import fields
from pathlib import Path

from fastapi import APIRouter, HTTPException, UploadFile, File, Header
from fastapi.responses import Response

from ruamel.yaml import YAML
from ruamel.yaml.comments import CommentedMap

from healthcheck.command import CliPolicy, CommandCatalog, CommandSet, CommandSpec, RestPolicy
from healthcheck.models import RestQuery

from app.config import COMMAND_CATALOG_DIR, COMMAND_SET_DIR
from app.config_files import COMMAND_CATALOG_CONFIG, atomic_write_text
from app.key_paths import first_problem
from app.schemas import CommandCatalogEntryIn, CommandCatalogEntryCreateIn
from app.yaml_archive import build_zip, save_upload

logger = logging.getLogger(__name__)

router = APIRouter()

_NAME_RE = re.compile(r"^[A-Za-z0-9_-]+$")
_PARSERS = ("genie", "textfsm", "json")
_SPEC_FIELDS = {f.name for f in fields(CommandSpec)}


def _round_trip_yaml() -> YAML:
    """コメント・書式を残して読み書きする YAML。null は "null"、長い行は折り返さない
    (PyYAML の safe_dump で書いた既存ファイルと同じ見た目にするため)。"""
    y = YAML()
    y.preserve_quotes = True
    y.width = 100000
    y.representer.add_representer(
        type(None), lambda r, _d: r.represent_scalar("tag:yaml.org,2002:null", "null"))
    return y


_YAML = _round_trip_yaml()


def _validate_name(value: str, label: str) -> None:
    if not _NAME_RE.match(value):
        raise HTTPException(
            status_code=400,
            detail=f"{label} には半角英数字・アンダースコア(_)・ハイフン(-)のみ使用できます。",
        )


def _validate_policy(command: str, body: CommandCatalogEntryIn) -> None:
    """取得の実行時と同じポリシーで検査する。REST(parser: json)は method を RestPolicy で、
    CLI はコマンドを CliPolicy で見る(どちらに当たるかは _bucket_for と同じ基準)。"""
    if body.parser == "json":
        if not RestPolicy().is_allowed(RestQuery(key=command, method=body.method, path=body.path)):
            raise HTTPException(
                status_code=400,
                detail=f"method '{body.method}' は使用できません。許可されているのは "
                       f"{', '.join(RestPolicy().allowed_methods)} のみです(RestPolicy)。",
            )
    elif not CliPolicy().is_allowed(command):
        raise HTTPException(
            status_code=400,
            detail=f"'{command}' は登録できません。CLI のコマンドは "
                   f"{', '.join(CliPolicy().allowed_prefixes)} のいずれかで始まる必要があります(CliPolicy)。",
        )


def _file_path(vendor: str, type_: str) -> Path:
    return COMMAND_CATALOG_DIR / vendor / f"{type_}.yaml"


def _read_file(path: Path) -> CommentedMap:
    """機種ファイルを読む。cli・rest が無ければ空の対応表を足して返す(他のキーやコメントは残す)。"""
    data = _YAML.load(path.read_text(encoding="utf-8")) if path.exists() else None
    if data is None:
        data = CommentedMap()
    for bucket in ("cli", "rest"):
        if data.get(bucket) is None:
            data[bucket] = CommentedMap()
    return data


def _write_file(path: Path, data: CommentedMap) -> None:
    buf = io.StringIO()
    _YAML.dump(data, buf)
    atomic_write_text(path, buf.getvalue())


def _sets_using(vendor: str, type_: str, command: str) -> list[str]:
    """このコマンドを使っているコマンドセット名(同じ vendor/type のもの)。"""
    sets = CommandSet.from_directory(COMMAND_SET_DIR).command_sets
    return sorted(
        name for name, e in sets.items()
        if e.vendor == vendor and e.type == type_ and command in (*e.cli, *e.rest)
    )


def validate_catalog_dir(root: Path) -> None:
    """取り込み前の検査。コアの読み込み(CommandCatalog.from_directory)で読めることと、
    実行時に必ず失敗する設定(未知の parser、path の無い REST)が無いことを確かめる。
    CliPolicy/RestPolicy はここでは当てない(取り込みは対象外という以前からの方針)。"""
    for f in sorted(root.glob("*/*.yaml")):
        data = _YAML.load(f.read_text(encoding="utf-8")) or {}
        rel = f.relative_to(root).as_posix()
        if not isinstance(data, dict):
            raise ValueError(f"{rel}: 先頭は cli・rest を持つ対応表にしてください。")
        for bucket in ("cli", "rest"):
            entries = data.get(bucket)
            if entries is None:
                continue
            if not isinstance(entries, dict):
                raise ValueError(f"{rel}: {bucket} はコマンドごとの対応表にしてください。")
            for command, spec in entries.items():
                if not isinstance(spec, dict):
                    raise ValueError(f"{rel} '{command}': parser などの項目を持つ対応表にしてください。")
                unknown = sorted(set(spec) - _SPEC_FIELDS)
                if unknown:
                    raise ValueError(f"{rel} '{command}': 使えない項目があります: {', '.join(unknown)}"
                                     f"(使える項目: {', '.join(sorted(_SPEC_FIELDS))})")
    catalog = CommandCatalog.from_directory(root)
    for vendor, types in catalog.by_vendor_type.items():
        for type_, commands in types.items():
            for command, spec in commands.items():
                where = f"{vendor}/{type_}.yaml '{command}'"
                if spec.parser not in _PARSERS:
                    raise ValueError(f"{where}: parser は {', '.join(_PARSERS)} のいずれかにしてください。")
                if spec.parser == "json" and not (spec.path or "").strip():
                    raise ValueError(f"{where}: parser が json(REST)の場合は path を指定してください。")
                problem = first_problem(spec.noise, "noise") or first_problem(spec.compare_keys, "compare_keys")
                if problem:
                    raise ValueError(f"{where}: {problem}")


def _spec_dict(spec: CommandSpec) -> dict:
    """description・noise・compare_keys は値が無くても常に明記する(未設定なのか
    書き忘れなのかを見た目で区別できるようにするため)。method・path は
    REST(parser: json)専用のフィールドで、CLIエントリに書いても構造的に無意味
    (command_catalog.py の不変条件。method は常に get)なので、RESTの時だけ書く。"""
    d: dict = {
        "parser": spec.parser,
        "noise": list(spec.noise),
        "compare_keys": list(spec.compare_keys) if spec.compare_keys else None,
        "description": spec.description,
    }
    if spec.parser == "json":
        d["method"] = spec.method
        d["path"] = spec.path
    return d


def _bucket_for(spec: CommandSpec) -> str:
    return "rest" if spec.parser == "json" else "cli"


def _to_spec(command: str, body: CommandCatalogEntryIn) -> CommandSpec:
    _validate_policy(command, body)
    if body.parser == "json" and not (body.path or "").strip():
        raise HTTPException(status_code=400, detail='parser が "json"(REST)の場合は path を指定してください。')
    # パスの区切りは ":"。古い書き方("." 区切り)は黙って効かなくなるので断る(app/key_paths.py)。
    problem = first_problem(body.noise, "ノイズ") or first_problem(body.compare_keys, "比較キー")
    if problem:
        raise HTTPException(status_code=400, detail=problem)
    return CommandSpec(
        parser=body.parser,
        noise=list(body.noise),
        compare_keys=list(body.compare_keys) if body.compare_keys else None,
        method=body.method,
        path=body.path or None,
        description=(body.description or "").strip() or None,
    )


@router.get("/command-catalog", response_model=dict[str, dict[str, dict[str, CommandSpec]]])
def get_command_catalog(response: Response) -> dict[str, dict[str, dict[str, CommandSpec]]]:
    with COMMAND_CATALOG_CONFIG.reading(response):
        catalog = CommandCatalog.from_directory(COMMAND_CATALOG_DIR)
        return catalog.by_vendor_type


@router.post("/command-catalog", status_code=201, response_model=CommandSpec)
def create_command_catalog_entry(
    body: CommandCatalogEntryCreateIn, response: Response, if_match: str | None = Header(default=None)
) -> CommandSpec:
    _validate_name(body.vendor, "vendor")
    _validate_name(body.type, "type")
    # 前後の空白を取り、続いた空白を1つにまとめる(コマンドセット側と文字列で一致させるため。
    # 大文字・小文字は機器のコマンドの引数で意味を持つことがあるので変えない)。
    command = " ".join(body.command.split())
    if not command:
        raise HTTPException(status_code=400, detail="コマンドを指定してください。")
    spec = _to_spec(command, body)

    path = _file_path(body.vendor, body.type)
    with COMMAND_CATALOG_CONFIG.writing(if_match, response):
        data = _read_file(path)
        if command in data["cli"] or command in data["rest"]:
            raise HTTPException(
                status_code=409,
                detail=f"'{command}' は既に存在します({body.vendor}/{body.type})。",
            )
        data[_bucket_for(spec)][command] = _spec_dict(spec)
        _write_file(path, data)
        logger.info("コマンドカタログに追加しました: %s/%s '%s' (parser=%s)",
                    body.vendor, body.type, command, spec.parser)
    return spec


@router.put("/command-catalog/{vendor}/{type}/{command}", response_model=CommandSpec)
def update_command_catalog_entry(
    vendor: str, type: str, command: str, body: CommandCatalogEntryIn,
    response: Response, if_match: str | None = Header(default=None),
) -> CommandSpec:
    _validate_name(vendor, "vendor")
    _validate_name(type, "type")
    spec = _to_spec(command, body)

    path = _file_path(vendor, type)
    with COMMAND_CATALOG_CONFIG.writing(if_match, response):
        data = _read_file(path)
        if command not in data["cli"] and command not in data["rest"]:
            raise HTTPException(status_code=404, detail=f"'{command}' が見つかりません({vendor}/{type})。")

        bucket = _bucket_for(spec)
        other = "rest" if bucket == "cli" else "cli"
        data[other].pop(command, None)      # 種別(CLI/REST)が変わった場合だけ移す
        data[bucket][command] = _spec_dict(spec)   # 同じ種別なら元の位置のまま置き換わる
        _write_file(path, data)
        logger.info("コマンドカタログを更新しました: %s/%s '%s' (parser=%s)",
                    vendor, type, command, spec.parser)
    return spec


@router.delete("/command-catalog/{vendor}/{type}/{command}", status_code=204)
def delete_command_catalog_entry(
    vendor: str, type: str, command: str, response: Response, if_match: str | None = Header(default=None)
) -> None:
    _validate_name(vendor, "vendor")
    _validate_name(type, "type")

    path = _file_path(vendor, type)
    with COMMAND_CATALOG_CONFIG.writing(if_match, response):
        data = _read_file(path)
        if command not in data["cli"] and command not in data["rest"]:
            raise HTTPException(status_code=404, detail=f"'{command}' が見つかりません({vendor}/{type})。")
        users = _sets_using(vendor, type, command)
        if users:
            raise HTTPException(
                status_code=409,
                detail=f"'{command}' はコマンドセット {', '.join(users)} で使われているため削除できません。"
                       f"先にコマンドセットから外してください。",
            )

        data["cli"].pop(command, None)
        data["rest"].pop(command, None)
        _write_file(path, data)
        logger.info("コマンドカタログから削除しました: %s/%s '%s'", vendor, type, command)


@router.get("/command-catalog/files")
def download_command_catalog() -> Response:
    """config/command/command_catalog/ 配下のYAMLを <vendor>/<type>.yaml の形のまま
    ZIPで返す。"""
    data = build_zip(COMMAND_CATALOG_DIR)
    return Response(
        content=data,
        media_type="application/zip",
        # no-store: ブラウザが前の応答を使い回して、編集前の内容を保存させないため
        headers={"Content-Disposition": 'attachment; filename="command_catalog.zip"',
                 "Cache-Control": "no-store"},
    )


@router.post("/command-catalog/files")
def upload_command_catalog(
    response: Response, file: UploadFile = File(...), if_match: str | None = Header(default=None)
) -> dict:
    """ZIP(<vendor>/<type>.yaml の形で入れたもの)を取り込む。同名は上書きし、
    アップロードに含まれない既存の機種ファイルはそのまま残す。取り込んだ後の一式が
    読み込めることを書き込む前に確かめる(yaml_archive.save_upload)。同期関数にして
    スレッドプールで動かす(ロックを待つ間にイベントループを止めないため)。"""
    content = file.file.read()
    with COMMAND_CATALOG_CONFIG.writing(if_match, response):
        try:
            saved = save_upload(COMMAND_CATALOG_DIR, file.filename, content,
                                depth=2, validate=validate_catalog_dir)
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))
    logger.info("コマンドカタログを取り込みました(%s): %s", file.filename, ", ".join(saved))
    return {"saved": saved}
