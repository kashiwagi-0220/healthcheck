"""
gui.backend.app.api.credentials — 認証情報(config/credentials.yaml)照会・変更API

コア(healthcheck/collect/file_credential_provider.py の FileCredentialProvider)は
config/credentials.yaml を読み取り専用で使う(resolve(device) で default/hosts から
1件解決するだけ)。ここではその全件を GUI から参照・編集できるようにする。ファイルの
書き込み・削除ロジックはコアに持ち込まず GUI 側に閉じる方針は他の設定(command_sets.py・
sources.py)と同じ。

default は必須(削除不可・常に1件)。hosts は host名をキーにした任意件数の上書きで、
1件は username/password が必須・secret のみ任意(FileCredentialProvider.resolve() 側の
前提と揃える。default との項目単位の合成はしない)。

パスワード・secret の値はブラウザへ返さない(2026-11-22 変更。以前は GET が平文で返し、
画面は伏せ字でも開発者ツールで読めた)。GET・PUT の応答は username と「設定済みか」だけ。
画面は今の値を知らないので、PUT では空欄を「変更しない」として扱い、既存の値と合成して
書き込む(schemas.CredentialEntryIn 参照)。

このファイルは平文の認証情報を含むため(将来 SOPS+age 等での暗号化を検討)、
書き込みは常にパーミッション 600 で行う(一時ファイルに書いてから置き換えるため、
置き換え後のファイルにも明示的に 600 を指定する)。

変更系は、読み込んだ後に他の利用者が変更していないかを版(If-Match)で確かめてから
書き込む(app/config_files.py)。
"""

from __future__ import annotations

import logging

import yaml
from fastapi import APIRouter, HTTPException, Header, Response

from app.config import CREDENTIALS_FILE
from app.config_files import CREDENTIALS_CONFIG, atomic_write_text
from app.schemas import CredentialEntryIn, CredentialEntryOut

router = APIRouter()

logger = logging.getLogger(__name__)


def _load() -> dict:
    if not CREDENTIALS_FILE.exists():
        raise HTTPException(status_code=500, detail=f"{CREDENTIALS_FILE} が見つかりません。")
    data = yaml.safe_load(CREDENTIALS_FILE.read_text(encoding="utf-8")) or {}
    if not isinstance(data.get("default"), dict):
        raise HTTPException(status_code=500, detail=f"{CREDENTIALS_FILE}: default セクションがありません。")
    return data


def _save(data: dict) -> None:
    atomic_write_text(CREDENTIALS_FILE, yaml.safe_dump(data, allow_unicode=True, sort_keys=False), mode=0o600)


def _to_entry(raw: dict) -> CredentialEntryOut:
    """表示用の1件。値は返さず、設定済みかどうかだけ。"""
    return CredentialEntryOut(
        username=raw.get("username"),
        has_password=bool(raw.get("password")),
        has_secret=bool(raw.get("secret")),
    )


def _merge(existing: dict | None, body: CredentialEntryIn) -> dict:
    """既存の1件(無ければ None)に変更内容を重ね、書き込む1件を作る。空欄は「変更しない」。"""
    existing = existing or {}
    username = body.username.strip()
    if not username:
        raise HTTPException(status_code=400, detail="ユーザ名を入力してください。")
    password = body.password or existing.get("password")
    if not password:
        raise HTTPException(status_code=400, detail="パスワードを入力してください。")
    if body.clear_secret and body.secret:
        raise HTTPException(status_code=400, detail="enableパスワードの設定と削除は同時に指定できません。")
    secret = None if body.clear_secret else (body.secret or existing.get("secret"))
    entry = {"username": username, "password": password}
    if secret:
        entry["secret"] = secret
    return entry


@router.get("/credentials")
def get_credentials(response: Response) -> dict:
    with CREDENTIALS_CONFIG.reading(response):
        data = _load()
    hosts = data.get("hosts") or {}
    return {
        "default": _to_entry(data["default"]),
        "hosts": {host: _to_entry(entry) for host, entry in hosts.items()},
    }


@router.put("/credentials/default", response_model=CredentialEntryOut)
def put_default_credential(
    body: CredentialEntryIn, response: Response, if_match: str | None = Header(default=None)
) -> CredentialEntryOut:
    with CREDENTIALS_CONFIG.writing(if_match, response):
        data = _load()
        data["default"] = _merge(data["default"], body)
        _save(data)
        logger.info("既定の認証情報を更新しました(username=%s)", data["default"]["username"])
    return _to_entry(data["default"])


@router.put("/credentials/hosts/{host}", response_model=CredentialEntryOut)
def put_host_credential(
    host: str, body: CredentialEntryIn, response: Response, if_match: str | None = Header(default=None)
) -> CredentialEntryOut:
    if not host.strip() or host != host.strip():
        raise HTTPException(status_code=400, detail="host を前後の空白なしで指定してください。")
    with CREDENTIALS_CONFIG.writing(if_match, response):
        data = _load()
        hosts = data.get("hosts") or {}
        hosts[host] = _merge(hosts.get(host), body)
        data["hosts"] = hosts
        _save(data)
        logger.info("ホスト個別の認証情報を更新しました: %s (username=%s)", host, hosts[host]["username"])
    return _to_entry(hosts[host])


@router.delete("/credentials/hosts/{host}", status_code=204)
def delete_host_credential(host: str, response: Response, if_match: str | None = Header(default=None)):
    with CREDENTIALS_CONFIG.writing(if_match, response):
        data = _load()
        hosts = data.get("hosts") or {}
        if host not in hosts:
            raise HTTPException(status_code=404, detail=f"'{host}' の上書き設定は見つかりません。")
        del hosts[host]
        data["hosts"] = hosts
        _save(data)
        logger.info("ホスト個別の認証情報を削除しました: %s", host)
