"""
gui.backend.app.api.command_sets — コマンドセット照会・作成・更新・削除API

既存の healthcheck.command.CommandSet(config/command/command_set/*.yaml から
1ファイル=1コマンドセットで読み込み)を使う。読み込みは CommandSet.from_directory()
にそのまま委ねるが、作成/更新/削除(ファイルの書き込み・削除)はコアに持ち込まず、
ここ(GUIバックエンド)に閉じる方針(healthcheck/command/command_set.py のコメント
参照。コアは読み取り専用のまま、GUI からの編集はファイル単位の単純な操作として扱う)。

コマンドセット名はそのままファイル名(<name>.yaml)になるため、パス上安全な文字
(英数字・アンダースコア・ハイフン)のみ許可する(パストラバーサル対策)。

保存系(作成・更新・削除・取り込み)は、読み込んだ後に他の利用者が変更していないかを
版(If-Match)で確かめてから書き込む(app/config_files.py)。版はコマンドセット全体
(ディレクトリ配下の YAML 一式)で1つ。

削除は、そのコマンドセットを使っている機器があれば 409 で断る(消すと、その機器を含む
取得・正常性確認が実行前の検証で全て止まるため)。

作成・更新・取り込みでは、cli・rest の各項目が同じ vendor/type のコマンドカタログに
定義されていることを確かめる(cli は CLI の定義、rest は REST(parser: json)の定義で
あること)。カタログに無い項目があると、take_snapshot が実行の直前に例外で止め、その
機器を含む取得全体が中断するため、保存の時点で断る。画面はカタログから選ぶ形なので
通常は起きないが、API を直接呼んだ場合・取り込み・画面を開いた後にカタログが変わった
場合のために、サーバ側でも確かめる。取り込みは今のカタログと照合する。
"""

from __future__ import annotations

import logging
import re
from pathlib import Path

import yaml
from fastapi import APIRouter, HTTPException, UploadFile, File, Header
from fastapi.responses import Response

from healthcheck.command import CommandCatalog, CommandSet, CommandSetEntry

from app.config import COMMAND_CATALOG_DIR, COMMAND_SET_DIR
from app.config_files import COMMAND_SETS_CONFIG, atomic_write_text
from app.sources import get_command_set_resolver, get_inventory_source
from app.schemas import CommandSetIn, CommandSetCreateIn
from app.yaml_archive import build_zip, save_upload

logger = logging.getLogger(__name__)

router = APIRouter()

_NAME_RE = re.compile(r"^[A-Za-z0-9_-]+$")


def _validate_name(name: str) -> None:
    if not _NAME_RE.match(name):
        raise HTTPException(
            status_code=400,
            detail="コマンドセット名には半角英数字・アンダースコア(_)・ハイフン(-)のみ使用できます。",
        )


def _validate_vendor_type(vendor: str, type: str) -> None:
    if not vendor.strip():
        raise HTTPException(status_code=400, detail="vendor を指定してください。")
    if not type.strip():
        raise HTTPException(status_code=400, detail="type を指定してください。")


def _file_path(name: str):
    return COMMAND_SET_DIR / f"{name}.yaml"


def _devices_using(name: str) -> list[str]:
    """このコマンドセットを割り当てている機器のホスト名(機器一覧の command_set 列)。"""
    return sorted(d.host for d in get_inventory_source().get_devices(filter={"command_set": name}))


def _uncataloged(vendor: str, type_: str, cli: list[str], rest: list[str]) -> list[str]:
    """cli・rest のうち、コマンドカタログ(vendor/type)に合う定義が無いものの説明。
    cli は CLI の定義(parser が json 以外)、rest は REST の定義(parser: json)である
    必要がある(コアのカタログは cli/rest を区別せず1つの対応表で持ち、種別は parser で
    決まる。healthcheck/command/command_catalog.py)。"""
    commands = CommandCatalog.from_directory(COMMAND_CATALOG_DIR).by_vendor_type.get(vendor, {}).get(type_, {})
    problems = []
    for c in cli:
        spec = commands.get(c)
        if spec is None:
            problems.append(f"cli '{c}'(カタログに無い)")
        elif spec.parser == "json":
            problems.append(f"cli '{c}'(カタログでは REST の定義)")
    for r in rest:
        spec = commands.get(r)
        if spec is None:
            problems.append(f"rest '{r}'(カタログに無い)")
        elif spec.parser != "json":
            problems.append(f"rest '{r}'(カタログでは CLI の定義)")
    return problems


def _describe_uncataloged(vendor: str, type_: str, problems: list[str]) -> str:
    shown = ", ".join(problems[:10]) + (f" ほか {len(problems) - 10} 件" if len(problems) > 10 else "")
    return (f"コマンドカタログ({vendor}/{type_})と合わない項目があります: {shown}。"
            f"cli には CLI の定義、rest には REST の定義を指定し、カタログに無いものは"
            f"先にコマンドカタログへ登録してください。")


def _check_catalog(body: CommandSetIn) -> None:
    problems = _uncataloged(body.vendor, body.type, list(body.cli), list(body.rest))
    if problems:
        raise HTTPException(status_code=400, detail=_describe_uncataloged(body.vendor, body.type, problems))


def validate_command_set_dir(root: Path) -> None:
    """取り込み前の検査。コアの読み込み(CommandSet.from_directory)で読めることと、
    cli・rest が文字列のリストであることを確かめる(文字列1つを書くと読み込みは通るが
    1文字ずつのコマンドになってしまうため)。さらに、各コマンドセットの項目が今の
    コマンドカタログに定義されていることを確かめる(カタログを含むバックアップを戻す
    場合は、カタログを先に取り込む)。"""
    for f in sorted(root.glob("*.yaml")):
        data = yaml.safe_load(f.read_text(encoding="utf-8")) or {}
        if not isinstance(data, dict):
            raise ValueError(f"{f.name}: 先頭は vendor・type・cli・rest を持つ対応表にしてください。")
        for key in ("cli", "rest"):
            v = data.get(key, [])
            if not isinstance(v, list) or not all(isinstance(x, str) for x in v):
                raise ValueError(f"{f.name}: {key} は文字列のリストにしてください。")
    sets = CommandSet.from_directory(root).command_sets
    for name, entry in sorted(sets.items()):
        problems = _uncataloged(entry.vendor, entry.type, list(entry.cli), list(entry.rest))
        if problems:
            raise ValueError(f"{name}.yaml: {_describe_uncataloged(entry.vendor, entry.type, problems)}"
                             f"(コマンドカタログも取り込む場合は、カタログを先に取り込んでください)")


def _to_entry(body: CommandSetIn) -> CommandSetEntry:
    return CommandSetEntry(
        vendor=body.vendor,
        type=body.type,
        cli=list(body.cli),
        rest=list(body.rest),
        description=body.description or None,
    )


def _write(name: str, body: CommandSetIn) -> None:
    data: dict = {"vendor": body.vendor, "type": body.type}
    if body.description:
        data["description"] = body.description
    data["cli"] = list(body.cli)
    data["rest"] = list(body.rest)
    atomic_write_text(_file_path(name), yaml.safe_dump(data, allow_unicode=True, sort_keys=False))


@router.get("/command-sets", response_model=dict[str, CommandSetEntry])
def list_command_sets(response: Response) -> dict[str, CommandSetEntry]:
    with COMMAND_SETS_CONFIG.reading(response):
        command_set = CommandSet.from_directory(COMMAND_SET_DIR, resolver=get_command_set_resolver())
        return command_set.command_sets


@router.post("/command-sets", status_code=201, response_model=CommandSetEntry)
def create_command_set(
    body: CommandSetCreateIn, response: Response, if_match: str | None = Header(default=None)
) -> CommandSetEntry:
    _validate_name(body.name)
    _validate_vendor_type(body.vendor, body.type)
    _check_catalog(body)
    with COMMAND_SETS_CONFIG.writing(if_match, response):
        if _file_path(body.name).exists():
            raise HTTPException(status_code=409, detail=f"コマンドセット '{body.name}' は既に存在します。")
        _write(body.name, body)
        logger.info("コマンドセットを作成しました: %s (vendor=%s type=%s cli=%d件 rest=%d件)",
                    body.name, body.vendor, body.type, len(body.cli), len(body.rest))
    return _to_entry(body)


@router.put("/command-sets/{name}", response_model=CommandSetEntry)
def update_command_set(
    name: str, body: CommandSetIn, response: Response, if_match: str | None = Header(default=None)
) -> CommandSetEntry:
    _validate_name(name)
    _validate_vendor_type(body.vendor, body.type)
    _check_catalog(body)
    with COMMAND_SETS_CONFIG.writing(if_match, response):
        if not _file_path(name).exists():
            raise HTTPException(status_code=404, detail=f"コマンドセット '{name}' が見つかりません。")
        _write(name, body)
        logger.info("コマンドセットを更新しました: %s (vendor=%s type=%s cli=%d件 rest=%d件)",
                    name, body.vendor, body.type, len(body.cli), len(body.rest))
    return _to_entry(body)


@router.delete("/command-sets/{name}", status_code=204)
def delete_command_set(name: str, response: Response, if_match: str | None = Header(default=None)) -> None:
    _validate_name(name)
    path = _file_path(name)
    with COMMAND_SETS_CONFIG.writing(if_match, response):
        if not path.exists():
            raise HTTPException(status_code=404, detail=f"コマンドセット '{name}' が見つかりません。")
        users = _devices_using(name)
        if users:
            shown = ", ".join(users[:10]) + (f" ほか {len(users) - 10} 台" if len(users) > 10 else "")
            raise HTTPException(
                status_code=409,
                detail=f"コマンドセット '{name}' は機器 {shown} で使われているため削除できません。"
                       f"先に機器一覧で別のコマンドセットに変えてください。",
            )
        path.unlink()
        logger.info("コマンドセットを削除しました: %s", name)


@router.get("/command-sets/files")
def download_command_sets() -> Response:
    """config/command/command_set/ 配下のYAMLをまとめてZIPで返す。"""
    data = build_zip(COMMAND_SET_DIR)
    return Response(
        content=data,
        media_type="application/zip",
        # no-store: ブラウザが前の応答を使い回して、編集前の内容を保存させないため
        headers={"Content-Disposition": 'attachment; filename="command_set.zip"',
                 "Cache-Control": "no-store"},
    )


@router.post("/command-sets/files")
def upload_command_sets(
    response: Response, file: UploadFile = File(...), if_match: str | None = Header(default=None)
) -> dict:
    """ZIP(複数)または単一YAML(1コマンドセット)を取り込む。同名は上書きし、
    アップロードに含まれない既存のコマンドセットはそのまま残す。取り込んだ後の一式が
    読み込めることを書き込む前に確かめる(yaml_archive.save_upload)。同期関数にして
    スレッドプールで動かす(ロックを待つ間にイベントループを止めないため)。"""
    content = file.file.read()
    with COMMAND_SETS_CONFIG.writing(if_match, response):
        try:
            saved = save_upload(COMMAND_SET_DIR, file.filename, content,
                                depth=1, validate=validate_command_set_dir)
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))
    logger.info("コマンドセットを取り込みました(%s): %s", file.filename, ", ".join(saved))
    return {"saved": saved}
