"""
gui.backend.app.sources — インベントリ/コマンドセット/SSHプロキシ/認証情報の
固定パス・アップロード・ダウンロード

インベントリ・コマンドセット解決は常に config/devices.csv(1ファイル固定)を使う。
取得方法やファイルを選ぶ設定は持たない。コア側の `InventorySource`/
`CommandSetResolver` という抽象IFはそのままなので、将来 NetBox 等へ差し替える場合は
別アダプタを実装してこのファイルの該当関数だけ差し替えればよい。

SSHプロキシ(踏み台)は常に config/proxy.conf を netmiko へ渡す。有効/無効の専用
フラグは持たない(OpenSSHのHostパターンに一致しないホストにはそもそもProxyJumpが
適用されないnetmiko/paramiko自体の挙動にそのまま委ねるため。ファイルが無ければ
プロキシ無しのCollectorを返す)。
"""

from __future__ import annotations

import csv
import io
from pathlib import Path

from fastapi import HTTPException

from healthcheck.inventory import CsvInventory, InventorySource
from healthcheck.inventory.csv_source import row_to_device
from healthcheck.command import CsvCommandSetResolver, CommandSetResolver, CommandSet, CommandCatalog
from healthcheck.collect.base import CliCollector
from healthcheck.collect.netmiko_collector import NetmikoCollector
from healthcheck.models import Device

from app.config import DEVICES_CSV, PROXY_CONF, COMMAND_SET_DIR, COMMAND_CATALOG_DIR
from app.config_files import atomic_write_text


def get_inventory_source() -> InventorySource:
    return CsvInventory(DEVICES_CSV)


def resolve_devices(hosts: list[str]) -> list[Device]:
    """host一覧から、インベントリに実在する Device のリストを解決する。1件でも
    見つからなければ404。healthchecks.py・snapshots.py が共有する。"""
    wanted = set(hosts)
    devices = [d for d in get_inventory_source().get_devices() if d.host in wanted]
    missing = wanted - {d.host for d in devices}
    if missing:
        raise HTTPException(status_code=404, detail=f"インベントリに無い host です: {sorted(missing)}")
    return devices


def get_command_set_resolver() -> CommandSetResolver:
    return CsvCommandSetResolver(DEVICES_CSV)


# コマンド出力の待ち時間。netmiko の既定(10秒)では show tech-support や大規模機の
# show running-config が終わらず、時間切れになる。netmiko は時間切れのときチャネルに
# 残った出力を掃除しないため、以降のコマンドも前の出力を読み続けて連鎖的に失敗する
# (「途中で切断された」ように見える)。そうならない余裕を取る。
# 機器が本当に応答しない場合はこの秒数だけ待つことになり、機器内のコマンドは順次
# 実行なので「秒数 × コマンド数」ブロックする点は許容している。
CLI_READ_TIMEOUT = 300.0   # 5分
# TCP接続確立の待ち時間。到達できない機器が失敗と分かるまでの時間を短くするため、
# netmiko の既定と同じ 10 秒にする(2026-11-22。以前は踏み台の分を見込んで 30 秒にしていたが、
# 再試行1回と合わせて失敗まで1分ほどかかっていた)。収集は再試行を1回行うため、届かない
# 機器は約 20 秒で失敗になる。踏み台を経由して 10 秒で接続できない環境では値を戻すこと。
# 利用ガイド(gui/frontend/src/pages/GuidePage.jsx)の待ち時間の説明も合わせる。
CLI_CONN_TIMEOUT = 10.0


def get_cli_collector() -> CliCollector:
    """config/proxy.conf があれば、それを使う NetmikoCollector を返す(無ければ
    プロキシ無し)。healthchecks.py/snapshots.py の両方から使う。"""
    ssh_config_file = str(PROXY_CONF) if PROXY_CONF.exists() else None
    return NetmikoCollector(
        ssh_config_file=ssh_config_file,
        read_timeout=CLI_READ_TIMEOUT,
        conn_timeout=CLI_CONN_TIMEOUT,
    )


def build_collection_parts() -> tuple[CommandSet, CommandCatalog, CliCollector]:
    """take_snapshot に渡す部品(コマンドセット・コマンドカタログ・CLI collector)を
    まとめて組み立てる。スナップショット取得・正常性確認のどちらも同じ3点を同じ
    固定パスから読むため、組み立て方をここに揃える。"""
    command_set = CommandSet.from_directory(COMMAND_SET_DIR, resolver=get_command_set_resolver())
    command_catalog = CommandCatalog.from_directory(COMMAND_CATALOG_DIR)
    return command_set, command_catalog, get_cli_collector()


def save_devices_csv(content: bytes) -> None:
    """アップロードされたCSVで config/devices.csv を置き換える。

    置き換えてから実行時に失敗しないよう、書き込む前に次を確かめる:
      - UTF-8 で読めること。Excel の「CSV UTF-8」が付ける先頭の BOM は取り除いて受け付ける
        (付いたままだと先頭の列名が "\ufeffhost" になり、host 列が無いと判定されていた)
      - host・vendor・type の列があること
      - 各行がコアの row_to_device(実行時と同じ読み込み)で読めること(host・vendor・type
        が空でない等)
      - host が重複しないこと(機器の関連付けキーのため)
    """
    try:
        text = content.decode("utf-8-sig")
    except UnicodeDecodeError:
        raise ValueError("UTF-8として読み込めないファイルです(Excel では「CSV UTF-8」で保存してください)。")
    reader = csv.DictReader(io.StringIO(text))
    columns = [c.strip() for c in (reader.fieldnames or [])]
    missing = [c for c in ("host", "vendor", "type") if c not in columns]
    if missing:
        raise ValueError(f"必要な列がありません: {', '.join(missing)}(1行目に host,vendor,type などの列名を書いてください)。")
    seen: dict[str, int] = {}
    for line_no, row in enumerate(reader, start=2):
        if not any((v or "").strip() for v in row.values() if isinstance(v, str)):
            continue                                    # 空行は読み込み側でも無視される
        try:
            host = row_to_device(row).host
        except ValueError as e:
            raise ValueError(f"{line_no} 行目: {e}")
        if host in seen:
            raise ValueError(f"{line_no} 行目: host '{host}' が {seen[host]} 行目と重複しています。")
        seen[host] = line_no
    atomic_write_text(DEVICES_CSV, text)


def save_proxy_conf(content: bytes) -> None:
    """アップロードされたOpenSSH形式の設定で config/proxy.conf を置き換える。
    中身の書式(Host/ProxyJump等)までは検証しない(netmikoのssh_config_fileに
    そのまま渡すだけのファイルで、書式検証はnetmiko/paramikoに委ねる)。ただし、
    取り違えた画像・ZIP など明らかにテキストでないもの(NUL を含む)は拒否する。"""
    try:
        text = content.decode("utf-8-sig")
    except UnicodeDecodeError:
        raise ValueError("UTF-8として読み込めないファイルです。")
    if "\x00" in text:
        raise ValueError("テキストファイルではありません(プロキシ設定は OpenSSH 形式のテキストです)。")
    write_proxy_conf_text(text)


def read_proxy_conf() -> str:
    """config/proxy.conf の内容(無ければ空文字列。編集フォームの初期値用)。"""
    if not PROXY_CONF.exists():
        return ""
    return PROXY_CONF.read_text(encoding="utf-8")


def write_proxy_conf_text(text: str) -> None:
    """編集フォームからの保存(アップロードと同じ書き込み先。中身は検証しない)。"""
    atomic_write_text(PROXY_CONF, text)
