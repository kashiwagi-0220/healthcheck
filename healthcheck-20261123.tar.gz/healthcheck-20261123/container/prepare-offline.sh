#!/bin/bash
# 別環境(インターネットに出られる Linux x86_64 + Podman)で、導入先がインターネットに出ずに
# イメージを作るのに必要な Python の依存(wheel)を集める。踏み台用の ssh は、導入先で
# イメージを作るときにベースイメージのリポジトリから入れるので、ここでは集めない
# (container/README.md 参照)。
#
#   ./container/prepare-offline.sh [出力先] [ubi9/python-312 のタグ]
#   例: ./container/prepare-offline.sh ~/hc-offline
#
# wheel は、導入先でイメージを作るのと同じ ubi9/python-312 のコンテナ(同じ OS・同じ Python 3.12)の
# 中で集める。この環境の OS や Python の版には依存しない。タグを省略すると、Containerfile の
# 既定と同じ 9.8-1793278874 を使う(導入先と違うタグを使う場合は、ここでも同じタグを指定する)。
# このイメージには gcc があるため、wheel の配布が無いパッケージもここで wheel に組み立てられる。
set -euo pipefail
cd "$(dirname "$0")/.."          # アプリの最上位(requirements.txt がある所)

OUT="${1:-./offline}"
TAG="${2:-9.8-1793278874}"
IMAGE="registry.access.redhat.com/ubi9/python-312:$TAG"

if [ -e "$OUT/packages" ]; then
  echo "エラー: $OUT に packages/ が既にあります。空の出力先を指定してください。" >&2
  exit 1
fi
mkdir -p "$OUT/packages"
OUT="$(cd "$OUT" && pwd)"

echo "== 1. ベースイメージ($IMAGE)"
podman pull "$IMAGE"

echo "== 2. Python の依存(wheel)"
# イメージ自身の venv(/opt/app-root)は使わず、Containerfile と同じく python3.12 で venv を作る。
podman run --rm --userns=keep-id:uid=1001,gid=0 \
  -v "$OUT/packages":/packages:Z \
  -v "$PWD/requirements.txt":/req.txt:ro,Z \
  "$IMAGE" sh -c '
    /usr/bin/python3.12 -m venv /tmp/v \
    && /tmp/v/bin/pip install -q --no-cache-dir --disable-pip-version-check -U pip \
    && /tmp/v/bin/pip wheel -q --no-cache-dir --disable-pip-version-check \
         -r /req.txt -w /packages'

echo "== 3. 確認"
nonwheel=$(find "$OUT/packages" -type f ! -name '*.whl' | wc -l)
if [ "$nonwheel" -ne 0 ]; then
  echo "  [NG] wheel 以外のファイルがあります:"; find "$OUT/packages" -type f ! -name '*.whl'
  exit 1
fi
echo "  [OK] packages/ は全て wheel です($(ls "$OUT/packages" | wc -l) 個)"
(cd "$OUT" && find packages -type f | sort | xargs sha256sum > SHA256SUMS)
echo "  チェックサム: $OUT/SHA256SUMS"
echo "完了しました: $OUT"
