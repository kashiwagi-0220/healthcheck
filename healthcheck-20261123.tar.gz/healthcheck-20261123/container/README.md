# healthcheck コンテナ構築手順書

導入先のサーバに healthcheck を新しく構築する手順です。導入先に読み込み済みの `ubi9/ubi`
イメージをベースにアプリのイメージを作り、起動します。導入先はインターネット(PyPI)に
出られない前提で、Python の依存(wheel)は別の環境(インターネットに出られる環境)で集めて
持ち込みます。踏み台用の ssh(openssh-clients)は、イメージを作るときにベースイメージの
リポジトリから `dnf` で入れます(導入先のベースイメージからリポジトリに届くことが前提です。2-1 で確かめます)。

| 項目 | 内容 |
|---|---|
| 導入先の作業ユーザー | `<podman-user>`(rootless Podman を使うユーザー。以下、実際のユーザー名に読み替える) |
| 導入先の作業場所 | `/home/<podman-user>/opt/healthcheck` |
| コンテナの実行方式 | rootless Podman + systemd(Quadlet) |
| 画面の URL | `http://127.0.0.1:8000/`(既定は導入先の中からだけ開ける) |

---

## 0. 全体の流れ

| 段階 | 場所 | 作業 |
|---|---|---|
| 1-1 | 開発サーバ | 配布アーカイブを作る |
| 1-2 | 別環境 | ubi9/ubi の中で、Python の依存(wheel)を集める |
| 1-3 | 別環境 → 導入先 | 配布アーカイブと集めたものを運ぶ |
| 2-1〜2-4 | 導入先 | 配置し、イメージを作る(ssh はベースイメージのリポジトリから入れる) |
| 2-5〜2-7 | 導入先 | 設定を用意し、起動して確かめる |

### 導入先のディレクトリの構成

イメージを作るためのもの(`build/`)と、コンテナにマウントするもの(`runtime/`)を分けます。
`build/` はイメージを作るときだけ使います。運用中に増えたり変わったりするのは `runtime/` だけです。

```
/home/<podman-user>/opt/healthcheck/
├── build/                    イメージを作るためのもの
│   ├── app/                  配布アーカイブを展開したもの
│   │   └── container/        Containerfile など(この手順書もここにある)
│   ├── packages/             Python の依存(wheel のみ)
│   └── SHA256SUMS            packages/ のチェックサム
└── runtime/                  コンテナにマウントするもの
    ├── config/               設定(画面からの編集もここに残る)
    ├── data/                 スナップショット・ログ
    └── ssh/                  踏み台の鍵と known_hosts(使う場合のみ)
```

### container/ のファイル

| ファイル | 用途 |
|---|---|
| `Containerfile` | イメージの作り方 |
| `prepare-offline.sh` | 別環境で wheel を集める |
| `healthcheck.container` | systemd(Quadlet)の設定 |

---

## 1. 別環境での準備

### 1-1. 配布アーカイブを作る(開発サーバで実行)

```bash
cd /opt/healthcheck
./make-dist.sh                 # healthcheck-<日付>.tar.gz ができる
```

認証情報(`config/credentials.yaml`)は含まれません。このアーカイブを、別環境と導入先の両方で使います。

### 1-2. wheel を集める(別環境で実行)

別環境の条件は次のとおりです。

- Linux(x86_64)で、Podman が使える
- `registry.access.redhat.com` と PyPI(`pypi.org`、`files.pythonhosted.org`)に届く

作業はすべて ubi9/ubi のコンテナの中で行うので、別環境の OS や Python の版は問いません
(ubi9 の Python 3.9 で集めるので、導入先と同じ版の ubi9/ubi でなくて構いません)。

```bash
mkdir -p ~/hc-prepare && cd ~/hc-prepare
tar xzf healthcheck-<日付>.tar.gz
cd healthcheck-<日付>
./container/prepare-offline.sh ~/hc-offline
```

最後に次のように出れば成功です(個数は目安)。

```
  [OK] packages/ は全て wheel です(125 個)
完了しました: /home/<別環境のユーザー>/hc-offline
```

`~/hc-offline/` には `packages/` と `SHA256SUMS` ができます。

### 1-3. 導入先へ運ぶ

```bash
cd ~
tar czf hc-offline.tar.gz hc-offline        # 約 170 MB(目安)
```

`healthcheck-<日付>.tar.gz` と `hc-offline.tar.gz` の2つを、導入先の `/home/<podman-user>/` に置きます。

---

## 2. 導入先での作業

以降はすべて `<podman-user>` として実行します。systemd のユーザーサービスを使うため、`su` ではなく、
SSH などで `<podman-user>` として直接ログインしてください(`su - <podman-user>` では
`systemctl --user` が使えません)。

### 2-1. 前提を確かめる

```bash
podman --version                                   # 4.4 以降
podman images registry.access.redhat.com/ubi9/ubi  # ベースイメージがあること
getenforce                                         # Enforcing でも可(マウントに :Z を付けて対処済み)
ss -ltn | grep ':8000 '                            # 何も出ないこと(8000 番が空いている)

# ベースイメージからリポジトリに届き、ssh を入れられること(2-4 のビルドで使う)
podman run --rm --pull=never registry.access.redhat.com/ubi9/ubi:latest \
  dnf -q list --available openssh-clients          # openssh-clients の行が出ること
```

- 8000 番が使われている場合は、2-6 の `PublishPort` の左側の番号を別の番号に変えます。
- ベースイメージが `<podman-user>` の一覧に出ない場合は、別のユーザー(root など)で読み込まれて
  います。rootless Podman はユーザーごとにイメージを持つので、`<podman-user>` で読み込み直して
  ください(`podman load -i <イメージのファイル>`)。
- 名前が `registry.access.redhat.com/ubi9/ubi:latest` でない場合は、上のコマンドの名前を
  `podman images` に出た名前に読み替えます(2-4 でも使います)。
- `dnf` の確認で `openssh-clients` が出ない場合(リポジトリに届かない・エラーになる)は、
  ビルドで ssh を入れられません。導入先のプロキシやリポジトリの設定を確かめてください。

### 2-2. ディレクトリを作る

```bash
mkdir -p ~/opt/healthcheck/build/app ~/opt/healthcheck/runtime/{config,data,ssh}
chmod 700 ~/opt/healthcheck/runtime/ssh
```

### 2-3. 配置して確かめる

```bash
cd ~/opt/healthcheck/build
tar xzf ~/healthcheck-<日付>.tar.gz --strip-components=1 -C app
tar xzf ~/hc-offline.tar.gz --strip-components=1 -C .

sha256sum -c --quiet SHA256SUMS && echo "チェックサム OK"
find packages -type f ! -name '*.whl' | wc -l      # 0 であること
```

### 2-4. イメージを作る

```bash
cd ~/opt/healthcheck/build
podman build --pull=never \
  -f app/container/Containerfile \
  -t localhost/healthcheck:$(date +%Y%m%d) .
```

- `--pull=never` で、ベースイメージは導入先に読み込み済みのものを使います。
- 外に取りに行くのは、ssh を入れる `dnf` だけです(ベースイメージのリポジトリから)。Python の
  依存は `packages/` だけから入れ、PyPI には取りに行きません。
- 1分前後で終わり、最後に `Successfully tagged localhost/healthcheck:<日付>` と出ます。
- ベースイメージの名前が `registry.access.redhat.com/ubi9/ubi:latest` でない場合は、
  `--build-arg BASE_IMAGE=<podman images に出た名前>` を足します。

できたイメージを確かめ、起動に使う名前(`current`)を付けます。

```bash
TAG=$(date +%Y%m%d)
podman run --rm --entrypoint .venv/bin/pip localhost/healthcheck:$TAG check
# → No broken requirements found.
podman run --rm --entrypoint .venv/bin/pip localhost/healthcheck:$TAG list 2>/dev/null \
  | grep -E '^(genie|pyats|netmiko|paramiko) '
# → genie 25.9 / netmiko 4.6.0 / paramiko 2.12.0 / pyats 25.9
podman tag localhost/healthcheck:$TAG localhost/healthcheck:current
```

### 2-5. 設定(runtime/)を用意する

#### 雛形と認証情報

雛形(コマンドカタログ・コマンドセット・機器一覧の例など)を写し、認証情報を作ります。

```bash
cp -rn ~/opt/healthcheck/build/app/config/. ~/opt/healthcheck/runtime/config/
cp ~/opt/healthcheck/runtime/config/credentials.yaml.example ~/opt/healthcheck/runtime/config/credentials.yaml
chmod 600 ~/opt/healthcheck/runtime/config/credentials.yaml
vi ~/opt/healthcheck/runtime/config/credentials.yaml
```

`config/credentials.yaml` は平文の認証情報です。権限は 600 のままにしてください。

`config/devices.csv` と `config/proxy.conf` は、開発環境の例が入っています。起動後に、導入先の
機器に合わせて画面またはファイルで書き換えてください。

#### 踏み台を使う場合

```bash
cp <鍵のファイル> ~/opt/healthcheck/runtime/ssh/
chmod 600 ~/opt/healthcheck/runtime/ssh/<鍵のファイル>
ssh-keyscan <踏み台のホスト> >> ~/opt/healthcheck/runtime/ssh/known_hosts
```

- `known_hosts` は必ず用意します。マウントは読み取り専用なので、コンテナの中からは追加できず、
  無いと踏み台への接続が `Host key verification failed` で失敗します。
  `ssh-keyscan` の結果は、踏み台の本物の鍵と一致するか確かめてください。
- `config/proxy.conf` の `IdentityFile` は、コンテナの中のパスで書きます。

  ```
  Host 192.168.100.*
      ProxyJump bastion.example.com

  Host bastion.example.com
      User <踏み台のユーザー>
      IdentityFile /home/healthcheck/.ssh/<鍵のファイル>
  ```

### 2-6. 起動する(systemd)

```bash
mkdir -p ~/.config/containers/systemd
cp ~/opt/healthcheck/build/app/container/healthcheck.container ~/.config/containers/systemd/

sudo loginctl enable-linger <podman-user>     # ログインしていなくても動かすため(初回だけ。管理者が実行)

systemctl --user daemon-reload
systemctl --user start healthcheck
systemctl --user status healthcheck      # active (running) であること
```

- `healthcheck.container` は、マウントするディレクトリを `%h/opt/healthcheck/runtime/...`
  (`%h` はホームディレクトリ)で指定しています。作業場所を変えた場合は、ここも合わせて変えます。
- `[Install]` に `WantedBy=default.target` があるので、サーバを再起動しても自動で起動します
  (Quadlet のサービスには `systemctl --user enable` は不要で、実行すると誤りになります)。
- ポートや公開する範囲を変える場合は、`~/.config/containers/systemd/healthcheck.container` を
  書き換え、`systemctl --user daemon-reload && systemctl --user restart healthcheck` を実行します。

### 2-7. 動作を確かめる

```bash
podman logs healthcheck | head -5
# → INFO:     Uvicorn running on http://0.0.0.0:8000
curl -s -o /dev/null -w '%{http_code}\n' http://127.0.0.1:8000/          # 200
curl -s http://127.0.0.1:8000/devices | head -c 300; echo               # 機器一覧の JSON
ls -l ~/opt/healthcheck/runtime/config                                       # 所有者が <podman-user> のまま
```

手元の PC のブラウザで開くには、SSH のポート転送を使います(既定では導入先の中からだけ開けるため)。

```bash
# 手元の PC で
ssh -L 8000:127.0.0.1:8000 <podman-user>@<導入先>
# → ブラウザで http://127.0.0.1:8000/ を開く
```

画面で次を確かめます。

1. 「機器一覧」で導入先の機器を登録する(または `config/devices.csv` を書き換える)
2. 機器を1台選んでスナップショットを取得し、成功する(CLI の機器と REST の機器の両方)
3. 「ログ」に接続・取得の記録が出る(`~/opt/healthcheck/runtime/data/healthcheck.log` と同じもの)

踏み台を使う場合は、コンテナの中から踏み台に届くかを確かめます。

```bash
podman exec healthcheck ssh -G -F /opt/healthcheck/config/proxy.conf <機器のIP> | grep -iE '^(proxyjump|identityfile) '
podman exec healthcheck ssh -F /opt/healthcheck/config/proxy.conf -o BatchMode=yes <踏み台のホスト> true \
  && echo "踏み台に接続できました"
```

`Pseudo-terminal will not be allocated because stdin is not a terminal.` と出ることがありますが、
問題ありません。

#### 他のマシンから開く場合(任意)

アプリには認証が無いので、公開する範囲は慎重に決めてください。公開する場合は、
`healthcheck.container` の `PublishPort=127.0.0.1:8000:8000` を `PublishPort=8000:8000` に変え、
firewalld で開けます。

```bash
sudo firewall-cmd --add-port=8000/tcp --permanent && sudo firewall-cmd --reload
```

---

## 3. 運用

### 起動・停止・状態

```bash
systemctl --user status healthcheck
systemctl --user restart healthcheck
systemctl --user stop healthcheck
journalctl --user -u healthcheck -n 50      # 起動の記録
podman logs healthcheck                     # アプリの標準出力
```

アプリのログは `~/opt/healthcheck/runtime/data/healthcheck.log` にも出ます(画面の「ログ」と同じ)。

### アプリを更新する

`runtime/` は触りません。設定とデータはそのまま残ります。

```bash
cd ~/opt/healthcheck/build
rm -rf app.prev && mv app app.prev && mkdir app
tar xzf ~/healthcheck-<新しい日付>.tar.gz --strip-components=1 -C app

# 依存が変わっていないか確かめる(差分が出たら、1-2 から集め直す)
diff app.prev/requirements.txt app/requirements.txt && echo "依存の変更なし"

TAG=$(date +%Y%m%d)
podman build --pull=never \
  -f app/container/Containerfile \
  -t localhost/healthcheck:$TAG .
podman tag localhost/healthcheck:$TAG localhost/healthcheck:current
systemctl --user restart healthcheck
```

同じ日に2回作る場合は、`TAG` を `$(date +%Y%m%d)-2` のように変えます(同じ名前だと上書きされ、
元に戻せなくなるため)。

### 元に戻す

古いイメージを残しておけば、名前を付け替えて再起動するだけで戻せます。

```bash
podman images localhost/healthcheck                 # 残っているイメージを確かめる
podman tag localhost/healthcheck:<前の日付> localhost/healthcheck:current
systemctl --user restart healthcheck
```

不要になった古いイメージは `podman rmi localhost/healthcheck:<日付>` で消します。

### ベースイメージ・ssh を更新する

- **ssh**:イメージを作るたびにリポジトリから入れます。ただし、前回と同じ内容のビルドでは
  前回の結果(層)が使い回され、ssh は更新されません。ssh を最新にしたいときは、
  `podman build` に `--no-cache` を付けて作り直します。
- **ベースイメージ**:セキュリティの修正を取り込むには、新しい ubi9/ubi を導入先に読み込み
  (`podman load` など)、2-4 からイメージを作り直します。

### バックアップ

`~/opt/healthcheck/runtime/` を丸ごと保存します。`config/credentials.yaml`(平文の認証情報)が
含まれるので、保存先の扱いに注意してください。`build/` は配布アーカイブと `hc-offline.tar.gz`
があれば作り直せます。

`data/devices/` は自動では削除されません。古いデータの削除は README の「データの保持」を参照してください。

---

## 4. うまくいかないとき

| 症状 | 原因と対処 |
|---|---|
| ビルドで `dnf` が `Cannot download repomd.xml` や `Curl error` で失敗する | ベースイメージからリポジトリに届いていません。2-1 の `dnf` の確認を行い、導入先のプロキシやリポジトリの設定を確かめます |
| ビルドで `pip` が `No matching distribution found` で失敗する | `packages/` に必要な wheel がありません。配布アーカイブと `hc-offline` が同じ版の `requirements.txt` から作られたか確かめ、1-2 からやり直します |
| ビルドで `pip` が `--only-binary` のため失敗する | `packages/` に wheel 以外が混ざっています。`prepare-offline.sh` で集め直します |
| ビルドで `registry.access.redhat.com/ubi9/ubi:latest` が見つからない | ベースイメージの名前が違うか、別のユーザーで読み込まれています。2-1 を参照し、`--build-arg BASE_IMAGE=...` を付けます |
| `systemctl --user` が `Failed to connect to bus` で失敗する | `su` で切り替えています。`<podman-user>` として SSH で直接ログインし直します |
| サーバの再起動後に起動していない | `loginctl enable-linger <podman-user>` が済んでいません(`loginctl show-user <podman-user> \| grep Linger` が `yes` であること) |
| 起動直後に止まる/`Permission denied` が出る | `runtime/` のマウントに `:Z` が無いか、`UserNS=keep-id:uid=1001,gid=0` が無いです。`healthcheck.container` を配布物のものと見比べます |
| 画面で設定やコマンドカタログが空、またはエラーになる | `runtime/config/` に雛形が写されていません。2-5 の `cp -rn` を実行してから再起動します |
| 画面の保存で失敗する | `runtime/config/` が `<podman-user>` の持ち物で、書き込めるか確かめます(`ls -ld ~/opt/healthcheck/runtime/config`) |
| `Address already in use` で起動しない | 8000 番が使われています。`PublishPort` の左側の番号を変えます |
| 踏み台で `Host key verification failed` | `runtime/ssh/known_hosts` に踏み台の鍵がありません。2-5 の「踏み台を使う場合」を参照します |
| 踏み台で `Permission denied (publickey)` | `IdentityFile` がコンテナの中のパス(`/home/healthcheck/.ssh/...`)になっているか、鍵の権限が 600 かを確かめます |
| 機器に `接続失敗(タイムアウト)` | 導入先のサーバから機器(TCP/22、REST は TCP/443)に届くかを、ホストで確かめます(`timeout 5 bash -c '</dev/tcp/<IP>/22' && echo ok`)。機器から見た接続元は導入先のサーバの IP です |
