import { useEffect, useState } from "react";
import { Check, Copy, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { copyText } from "@/lib/clipboard";

// 押すとクリップボードにコピーするボタン。押した後しばらく結果を表示する。
// getText はコピーする文字列を返す関数(大きな parsed を JSON にする処理を、押したときだけ
// 行うため)。
const RESET_MS = { done: 2000, failed: 3000 };

export default function CopyButton({ getText, label = "コピー", disabled }) {
  const [status, setStatus] = useState(null); // null | "done" | "failed"

  useEffect(() => {
    if (!status) return undefined;
    const id = setTimeout(() => setStatus(null), RESET_MS[status]);
    return () => clearTimeout(id);
  }, [status]);

  const handleClick = () => {
    copyText(getText())
      .then(() => setStatus("done"))
      .catch(() => setStatus("failed"));
  };

  return (
    <Button size="sm" variant="outline" disabled={disabled} onClick={handleClick}>
      {status === "done" ? (
        <><Check className="text-success" />コピーしました</>
      ) : status === "failed" ? (
        <><X className="text-destructive" />コピーできません</>
      ) : (
        <><Copy />{label}</>
      )}
    </Button>
  );
}
