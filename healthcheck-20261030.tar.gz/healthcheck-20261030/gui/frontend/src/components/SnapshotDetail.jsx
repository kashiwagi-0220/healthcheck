import { useState } from "react";
import { Button } from "@/components/ui/button";
import { downloadText, downloadJson, sanitizeFilename } from "@/lib/download";
import { downloadAllRaw, downloadAllParsed, downloadEverything } from "@/lib/snapshotDownload";
import JsonView from "@/components/JsonView";
import CopyButton from "@/components/CopyButton";
import { Download } from "lucide-react";

// raw / parsed のペイン。ポップアップの残りの高さに収まるよう縮み、中身だけが
// スクロールする(下の SnapshotDetail のコメント参照)。
const PANE_CLASS = "min-h-0 overflow-auto rounded-md bg-muted p-3 text-xs";

// 1コマンド分の raw/parsed 表示 + ダウンロード + コピー。表示順は raw→parsed(タブの並び・
// 既定タブとも raw を先にする)。コピーは表示中のタブの内容で、parsed はダウンロードと
// 同じ形(2字下げの JSON)にする。
function CommandBlock({ host, snapshotId, command, raw, parsed }) {
  const [tab, setTab] = useState("raw");
  const base = `${sanitizeFilename(host)}_${sanitizeFilename(snapshotId)}_${sanitizeFilename(command)}`;

  return (
    <div className="flex min-h-0 flex-col gap-2 rounded-md border p-3">
      <div className="flex shrink-0 flex-wrap items-center justify-between gap-2">
        <p className="font-mono text-sm font-medium">{command}</p>
        <div className="flex flex-wrap gap-1">
          <Button size="sm" variant="outline" onClick={() => downloadText(`${base}.raw.txt`, raw ?? "")}>
            <Download /> raw
          </Button>
          <Button
            size="sm"
            variant="outline"
            disabled={parsed == null}
            onClick={() => downloadJson(`${base}.parsed.json`, parsed)}
          >
            <Download /> parsed
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={() => {
              downloadText(`${base}.raw.txt`, raw ?? "");
              if (parsed != null) downloadJson(`${base}.parsed.json`, parsed);
            }}
          >
            <Download /> コマンド全体
          </Button>
        </div>
      </div>
      <div className="flex shrink-0 items-center gap-1">
        <Button size="sm" variant={tab === "raw" ? "default" : "outline"} onClick={() => setTab("raw")}>
          raw
        </Button>
        <Button
          size="sm"
          variant={tab === "parsed" ? "default" : "outline"}
          disabled={parsed == null}
          onClick={() => setTab("parsed")}
        >
          parsed
        </Button>
        <div className="ml-auto">
          <CopyButton
            label="表示中をコピー"
            disabled={tab === "parsed" && parsed == null}
            getText={() => (tab === "raw" ? raw ?? "" : JSON.stringify(parsed, null, 2))}
          />
        </div>
      </div>
      {tab === "raw" ? (
        <pre className={PANE_CLASS}>{raw}</pre>
      ) : parsed != null ? (
        <JsonView value={parsed} className={PANE_CLASS} />
      ) : (
        <pre className={PANE_CLASS}>(パース結果なし)</pre>
      )}
    </div>
  );
}

// snapshot 1件分の詳細表示 + ダウンロード。スナップショット一覧のポップアップ・
// スナップショット取得の結果表示の両方から共有して使う。
// commands は {command: {raw, parsed}} の形(GET .../full と POST /snapshots/take の
// レスポンスがどちらもこの形を持つ)。コマンドは初めから展開せず、ボタンで選択した
// ものだけ raw/parsed を表示する(全件を最初から開くと縦に長くなりすぎるため)。
// showDownloadAll: 全raw/全parsed/全て の一括ダウンロードボタンをここに出すか
// どうか。スナップショット一覧では表の操作列に同等のボタンがあるため false にして
// 二重表示を避ける。
//
// コマンドが多い・出力が長いときにポップアップ全体がスクロールしないよう、縦並び
// (flex)にしてコマンドのボタン・見出し・タブは大きさを保ち、raw / parsed のペイン
// だけが残りの高さに収まるよう縮んでスクロールする。ボタン群も高さに上限を設け、
// その中でスクロールさせる(コマンドが多くても下の詳細を押し出さないように)。
// 呼び出し側の Dialog の中身には DIALOG_CONTENT_FLEX を指定する。
export default function SnapshotDetail({ host, snapshotId, takenAt, success, error, commands, showDownloadAll = true }) {
  const commandNames = Object.keys(commands);
  const [activeCommand, setActiveCommand] = useState(null);
  const snapshot = { host, id: snapshotId, taken_at: takenAt, success, error, commands };

  return (
    <div className="flex min-h-0 flex-col gap-3">
      {error && <p className="shrink-0 text-sm text-destructive">{error}</p>}
      <div className="flex shrink-0 flex-wrap items-start justify-between gap-2">
        <div className="flex max-h-[30vh] flex-wrap gap-1 overflow-y-auto p-1">
          {commandNames.map((cmd) => (
            <Button
              key={cmd}
              size="sm"
              variant={activeCommand === cmd ? "default" : "outline"}
              onClick={() => setActiveCommand(activeCommand === cmd ? null : cmd)}
            >
              {cmd}
            </Button>
          ))}
          {commandNames.length === 0 && <p className="text-sm text-muted-foreground">コマンドがありません</p>}
        </div>
        {showDownloadAll && (
          <div className="flex flex-wrap gap-1">
            <Button size="sm" variant="outline" onClick={() => downloadAllRaw(snapshot)}>
              <Download /> 全raw
            </Button>
            <Button size="sm" variant="outline" onClick={() => downloadAllParsed(snapshot)}>
              <Download /> 全parsed
            </Button>
            <Button size="sm" variant="outline" onClick={() => downloadEverything(snapshot)}>
              <Download /> 全て
            </Button>
          </div>
        )}
      </div>
      {activeCommand && (
        <CommandBlock
          host={host}
          snapshotId={snapshotId}
          command={activeCommand}
          raw={commands[activeCommand].raw}
          parsed={commands[activeCommand].parsed}
        />
      )}
    </div>
  );
}
