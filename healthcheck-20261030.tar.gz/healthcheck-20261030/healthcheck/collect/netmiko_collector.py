"""
healthcheck.collect.netmiko_collector — netmiko による実収集エンジン(実機用)

CliCollector 抽象の実装。1機器に netmiko(Paramiko ベース)で接続し、CliJob.commands
を順次実行して CollectResult を返す。netmiko は重い依存のため、Genie/TextFSM と同じく
import は実行時(遅延)に行う。未導入なら pip ヒント付きの ImportError を投げる
(未導入という設定ミスを、個別機器の失敗として握りつぶさず明示するため)。

接続・コマンドの失敗は例外を投げず、CollectResult / CommandResult に success=False +
error として記録する(ファサードが完了順にまとめ、一過性の失敗だけ再試行できるように)。
踏み台(バスチョン)経由でしか到達できない機器向けに、ssh_config_file は netmiko
(Paramiko)の範囲で調整できるよう、そのまま ConnectHandler に渡す口を用意する。

接続開始・接続成功/失敗・コマンドごとの実行開始・完了/失敗・切断を標準の `logging`
(`logging.getLogger(__name__)`)で記録する(コマンド単位の実行状況を後から確認できる
ようにするため)。ログの出力先(標準出力・ファイル等)はこのモジュールでは決めず、
アプリ全体のエントリポイント(GUIの場合は gui/backend/app/logging_config.py)が
`logging` の設定で決める。

- ssh_config_file: OpenSSH 形式の設定ファイル(paramiko.SSHConfig でパースされる)。
  例えば
    Host 192.168.*.*
        ProxyJump bastion.example.com
  (Host はグロブパターンでマッチする。CIDR表記は使えない)と書いたファイルのパスを
  渡すと、そのファイルの Host 単位の設定(ProxyJump 等)が接続に反映される。
  config/proxy.conf に実例あり。

機器に送るもの(_CLI_TYPES):
  機器の設定を変えないことを保証するため、netmiko の接続時の自動処理(機種別ドライバの
  準備処理 session_preparation)は使わない。この処理は機種ごとのコマンドを自動で送り、
  その中には設定を変えるものがある(ASA の設定モードでの `terminal width 511` など)。
  そこで接続は auto_connect=False で作り、SSH の接続だけを行ってから、接続後の処理を
  このモジュールで明示的に呼ぶ。送るのは、プロンプトを読むための改行、enable(enable
  パスワードがある場合)、_CLI_TYPES に書いた準備コマンド(そのセッションの間だけ効く
  もの)、取得するコマンド、切断時の exit だけ。改行コードの揃え方などの受信側の処理は
  機種別ドライバのものをそのまま使う。
  CLI で収集する機種は _CLI_TYPES に必ず登録する。登録の無い機種は接続する前にエラーに
  する(暗黙の既定は持たない。command_catalog に既定を持たせない方針と同じ考え方)。
  機種を追加するときは、準備コマンドがセッションの間だけ効く(設定を変えない)ことを
  実機で確かめてから登録する。

出力の終わりの目印:
  コマンドは常に、接続後に一度だけ確定したプロンプトを固定の目印として指定して実行する
  (netmiko のコマンドごとのプロンプト探しを使わない)。netmiko の send_command は、目印を
  指定しないとコマンドごとにプロンプトを探し直す。この処理は応答を待たずに読み、読めた
  最後の行が記号("#" など)で終わるかを確かめずに目印にする。踏み台経由で多数の機器を
  並列に取得し、プロンプトが途中で切れて届くと、ホスト名だけが目印になり、出力の中にある
  ホスト名で始まる行で取得が打ち切られるため。目印は netmiko の base_prompt からは作らず、
  プロンプトそのものを読み直して作る(IOS / IOS-XE ドライバは base_prompt を先頭16文字に
  切り詰めるため)。取得では設定モードに入らないので、モードや状態の表示(ASA の
  フェイルオーバー表示など)は確定したプロンプトに含まれ、別に許す必要はない。取得の
  途中でプロンプトが変わった場合は、以降のコマンドがタイムアウトで失敗する。

送ったコマンドの表示し返し:
  netmiko の「送ったコマンドが表示し返されるのを確かめてから出力を読む」処理は、全機種で
  有効のまま使う(ASA ドライバがこれを切るのは準備処理の中なので、準備処理を使わなければ
  有効のまま)。この処理は、表示し返しより前に届いていた読み残し(前のプロンプトなど)を
  捨てる。これが無いと、読み残しのプロンプトを出力の終わりと取り違え、コマンドの出力が
  空になったり次のコマンドへずれたりする。
"""

from __future__ import annotations

import logging
import re
from datetime import datetime, timezone
from typing import Any

from healthcheck.models import CliJob, CommandResult, CollectResult
from healthcheck.collect.base import CliCollector, CredentialProvider

logger = logging.getLogger(__name__)

# カタログ vendor -> type -> (netmiko の device_type, 接続後に送る準備コマンド)。
# 準備コマンドは、そのセッションの間だけ効くもの(ページングの無効化など)に限る。
# CLI で収集する機種は必ず登録する(暗黙の既定は持たない)。F5(BIG-IP)・PAN-OS・APIC は
# CLI で取得していないため登録していない。
_CLI_TYPES: dict[str, dict[str, tuple[str, tuple[str, ...]]]] = {
    "cisco": {
        "ios": ("cisco_ios", ("terminal width 511", "terminal length 0")),
        # netmiko側の実在ドライバ名は "cisco_xe"(iosxeではない)
        "iosxe": ("cisco_xe", ("terminal width 511", "terminal length 0")),
        "nxos": ("cisco_nxos", ("terminal width 511", "terminal length 0")),
        # ASA の terminal width は設定モードのコマンド(設定の変更)なので送らない。
        "asa": ("cisco_asa", ("terminal pager 0",)),
    },
}


def cli_type_for(vendor: str, type: str) -> tuple[str, tuple[str, ...]]:
    """カタログの vendor + type から (netmiko の device_type, 準備コマンド) を返す。

    _CLI_TYPES に無ければ ValueError(CLI で収集する機種は、送るコマンドが設定を変えない
    ことを確かめて明示的に登録する)。
    """
    entry = _CLI_TYPES.get(vendor, {}).get(type)
    if entry is None:
        raise ValueError(
            f"vendor='{vendor}' type='{type}' が _CLI_TYPES に登録されていません"
            "(healthcheck/collect/netmiko_collector.py)。CLI で収集する機種は、"
            "送るコマンドが設定を変えないことを確かめて明示的に登録してください。"
        )
    return entry


def _read_prompt(conn: Any) -> str:
    """今のプロンプトを読む。末尾の "#" / ">" が届くまで待って読む(届き方に左右されない)。

    ログイン直後はバナーの残りが遅れて届き、その中の ">" などで読み取りが止まることがある
    ので、2回続けて同じものが読めるまで読み直す。
    """
    prompt = conn.find_prompt(pattern=r"[#>]")
    for _ in range(3):
        again = conn.find_prompt(pattern=r"[#>]")
        if again == prompt:
            return prompt
        prompt = again
    raise ValueError(f"プロンプトが定まりません(最後に読めたもの: {prompt!r})")


def _prepare(conn: Any, secret: str | None, setup: tuple[str, ...], read_timeout: float) -> str:
    """接続後、コマンドを実行できる状態にして、出力の終わりの目印を返す。

    プロンプトを読み、enable パスワードがあれば特権モードに入り、プロンプトを読み直して
    目印を作り、準備コマンドを送る。特権モードに入れなかった(プロンプトが ">" のまま)
    場合は ValueError。非特権では使えない show コマンドの出力がエラー文になり、パース不可
    (スキップ)として気づかれずに扱われるのを避けるため。
    """
    conn.ansi_escape_codes = True     # 端末の制御文字を出力から取り除く(NX-OS が出す)
    _read_prompt(conn)                # 遅れて届くバナーを読み捨ててから base_prompt を決める
    conn.set_base_prompt()
    if secret:
        try:
            conn.enable()
        except Exception as e:
            # パスワードの誤りは再試行しても直らないため、一過性の失敗(タイムアウト等)と
            # 見分けがつく文言にする。
            raise ValueError("特権モードに入れません(enable パスワードが違う可能性があります)") from e
    # base_prompt は、読み直したものが正しいかを確かめるためにだけ使う(切り詰められて
    # いても前方一致は確かめられる)。
    prompt = _read_prompt(conn)
    if not (prompt.startswith(conn.base_prompt) and prompt[-1] in "#>"):
        raise ValueError(f"プロンプトを読み直せません(読めたもの: {prompt!r})")
    if prompt.endswith(">"):
        raise ValueError(
            f"特権モードではありません(プロンプト: {prompt!r})。"
            "認証情報に enable パスワード(secret)を設定してください。"
        )
    expect = r"(?:^|\n)" + re.escape(prompt) + r"\s*$"
    for cmd in setup:
        conn.send_command(cmd, read_timeout=read_timeout, expect_string=expect)
    return expect


class NetmikoCollector(CliCollector):
    """netmiko で1機器に接続し、コマンド群を順次実行するエンジン。"""

    def __init__(
        self,
        read_timeout: float = 10.0,
        conn_timeout: float = 10.0,
        ssh_config_file: str | None = None,
    ):
        self.read_timeout = read_timeout   # コマンド出力待ち(send_command の read_timeout)
        self.conn_timeout = conn_timeout   # TCP 接続確立のタイムアウト
        self.ssh_config_file = ssh_config_file

    def collect_device(self, job: CliJob, credentials: CredentialProvider) -> CollectResult:
        try:
            from netmiko import ConnectHandler
            from netmiko.exceptions import NetmikoAuthenticationException, NetmikoTimeoutException
        except ImportError as e:
            raise ImportError(
                "netmiko が未導入です。'pip install netmiko' が必要です。"
            ) from e

        device = job.device
        creds = credentials.resolve(device)
        started_at = datetime.now(timezone.utc)
        # 登録の無い機種は、接続する前にエラーにする。
        netmiko_type, setup = cli_type_for(device.vendor, device.type)

        conn_params: dict[str, Any] = {
            "device_type": netmiko_type,
            "host": device.ip or device.host,     # ip があれば優先(DNS 非解決環境向け)
            "port": device.port,
            "username": creds.username,
            "password": creds.password,
            "conn_timeout": self.conn_timeout,
            # 接続時の自動処理(機種別ドライバの準備処理)を動かさない。SSH の接続は
            # 下で establish_connection() を呼んで行う。
            "auto_connect": False,
            # ConnectHandler の timeout は delay_factor_compat 専用(netmiko 4系以降は
            # 実質不使用)なのでここには渡さない。コマンド出力待ちは send_command 側の
            # read_timeout で制御する(下記)。
        }
        if creds.secret:
            conn_params["secret"] = creds.secret
        if self.ssh_config_file:
            conn_params["ssh_config_file"] = self.ssh_config_file

        logger.info("%s: 接続開始 (%s:%s)", device.host, conn_params["host"], device.port)
        try:
            conn = ConnectHandler(**conn_params)
            conn.establish_connection()
        except NetmikoAuthenticationException as e:
            logger.warning("%s: 接続失敗(認証) - %s", device.host, e)
            return CollectResult(
                device=device, success=False, error=f"authentication failed: {e}",
                started_at=started_at, finished_at=datetime.now(timezone.utc),
            )
        except NetmikoTimeoutException as e:
            logger.warning("%s: 接続失敗(タイムアウト) - %s", device.host, e)
            return CollectResult(
                device=device, success=False, error=f"connection timeout: {e}",
                started_at=started_at, finished_at=datetime.now(timezone.utc),
            )
        except Exception as e:
            logger.warning("%s: 接続失敗 - %r", device.host, e)
            return CollectResult(
                device=device, success=False, error=repr(e),
                started_at=started_at, finished_at=datetime.now(timezone.utc),
            )
        logger.info("%s: 接続成功", device.host)

        outputs: dict[str, CommandResult] = {}
        all_ok = True
        try:
            try:
                expect = _prepare(conn, creds.secret, setup, self.read_timeout)
            except Exception as e:
                logger.warning("%s: 接続後の準備に失敗 - %r", device.host, e)
                return CollectResult(
                    device=device, success=False, error=f"session setup failed: {e!r}",
                    started_at=started_at, finished_at=datetime.now(timezone.utc),
                )
            for cmd in job.commands:
                cmd_started = datetime.now(timezone.utc)
                logger.info("%s: コマンド実行開始 - %s", device.host, cmd)
                try:
                    raw = conn.send_command(cmd, read_timeout=self.read_timeout, expect_string=expect)
                    outputs[cmd] = CommandResult(
                        command=cmd, success=True, raw=raw,
                        started_at=cmd_started, finished_at=datetime.now(timezone.utc),
                    )
                    logger.info("%s: コマンド完了 - %s", device.host, cmd)
                except Exception as e:
                    all_ok = False
                    outputs[cmd] = CommandResult(
                        command=cmd, success=False, error=repr(e),
                        started_at=cmd_started, finished_at=datetime.now(timezone.utc),
                    )
                    logger.warning("%s: コマンド失敗 - %s: %r", device.host, cmd, e)
        finally:
            conn.disconnect()
            logger.info("%s: 切断", device.host)

        return CollectResult(
            device=device, success=all_ok, outputs=outputs,
            started_at=started_at, finished_at=datetime.now(timezone.utc),
        )
