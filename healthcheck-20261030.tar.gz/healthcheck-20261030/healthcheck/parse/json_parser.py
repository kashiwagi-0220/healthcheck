"""
healthcheck.parse.json_parser — JSONパースエンジン(REST由来の結果用)

REST 収集(RestCollector)は応答が既に構造化されているため、収集時点で
JSON 文字列化して CommandResult.raw に格納する設計にしている(CLI 側と raw の型を
str に揃えるため)。ここではその文字列を json.loads で戻すだけで、Genie/TextFSM の
ような重い依存もテンプレート選択も無い。

パース不可(JSON として不正)は None を返す(他の ParserEngine と同じ契約)。失敗の理由は
WARNING でログに残す。
"""

from __future__ import annotations

import json
import logging
from typing import Any

from healthcheck.models import Device
from healthcheck.parse.base import ParserEngine

logger = logging.getLogger(__name__)


class JsonParser(ParserEngine):
    def parse(self, device: Device, command: str, raw: str) -> Any | None:
        try:
            return json.loads(raw)
        except (TypeError, ValueError) as e:
            logger.warning("%s: パース失敗 - %s: %r", device.host, command, e)
            return None
