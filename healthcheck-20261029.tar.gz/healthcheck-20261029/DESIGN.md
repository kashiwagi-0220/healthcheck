# healthcheck — 正常性確認ツール 設計

ネットワーク機器から情報を取得し、2時点の状態を比較して差分の有無を判定する
**正常性確認ツール(healthcheck)**。汎用基盤ではなく、このツール単体として実装する。

- リポジトリ名 / Python パッケージ名: `healthcheck`(import は `from healthcheck... import ...`)

前提: 数千台規模 / Cisco中心(一部 Palo Alto・F5) / オンデマンドと定期実行の両方 /
実行環境は Linux / 無償OSSのみ。

---

## 1. 設計方針

- **単体ツールとして作る**。「複数ツールの共通基盤」は作らない。将来ツールが増えたら、
  そのとき共通化を考える(早すぎる抽象化を避ける)。
- **共通関数はできるだけシンプルに**してメンテナンス性を高める。正常性確認ツールは、
  素朴な共通関数(取得・パース・保管・比較・照会)の集合体として実装する。
- **GUI で対応できるものは共通関数(CLI)に持ち込まない**。責務分離:
  - GUI … 表示・パラメータ指定・候補の選択・意味づけの管理(下記の checkpoint/work/label)。
  - CLI … 処理実行(収集・パース・保管・比較)とデータの照会。
- **CLI は snapshot(取得結果の1時点)だけを扱う**。checkpoint(セーブ地点)・work(作業単位)・
  label といった意味づけは **GUI 側が管理**する。CLI の保管層は意味づけ属性を持たない。
- **CLI は機械可読な JSON のみ**を出力する。人間向けの整形は GUI の役割。

---

## 2. 全体構造(層)

```
インベントリ層 … 対象機器の一覧をどこから取るか(CSV→将来YAML/NetBox等)
収集層        … 機器から情報取得(netmiko+ThreadPoolExecutor 主 / REST=APIC・F5)
パース層      … 生出力を構造化。CommandCatalog でエンジン選択(Genie / TextFSM)
コマンド層    … 実行可能コマンド管理(CliPolicy) / 取得コマンド一覧+解決
                (CommandSet+CommandSetResolver) / vendor+type ごとのコマンド定義
                (CommandCatalog: パーサ・ノイズフィルタ・比較キー列を統合)
比較部品      … 正規化(list→dict)・自作再帰diff・compare本体(common/)
保管層        … 取得結果の保存・参照(show=FS / 実行履歴=FS)
ツール(healthcheck) … 上記の共通関数を組み合わせて「取得」「比較」を行う
```

正常性確認ツールは、これらの共通関数を呼び出して組み立てるオーケストレータ。
中央集権のパイプラインは持たない。

---

## 3. 各層の設計

### インベントリ層
- `InventorySource` 抽象IF、`get_devices(filter=...)` で `Device` 一覧を返す。
- 現時点は CSV アダプタ(`CsvInventory`)のみ実装。YAML は現時点で使う予定が無いため
  実装しない。将来 NetBox アダプタ等に差し替え・追加(他層は無変更)。
- `Device.meta` に属性(site, role 等)を載せ、フィルタや分岐に使う。
- **フィルタ解決(式→機器リスト)は照会に使う**。比較などの実行本体は、GUI が照会で
  解決した**確定 device_id リスト**を受け取る(実行本体はフィルタ構文・情報源に依存しない)。

### 収集層(CLI=netmiko+ThreadPoolExecutor / REST)
- CLI と REST は入力ジョブの型が本質的に違う(`CliJob.commands` は文字列列、
  `RestJob.queries` は構造化された `RestQuery` 列)ため、`CliCollector`(CLI)・
  `RestCollector`(REST)という2つの独立した抽象を持つ。どちらも同じ `CollectResult`
  型で返すので、後段(parse・保管・比較)は収集手段を意識しない。
- **CLI(CliCollector)**: 主エンジンは **netmiko + ThreadPoolExecutor**。機種別
  プロンプト認識が広く、`as_completed` で**完了した機器から順に返す**(ストリーミング)。
  実装は `NetmikoCollector`。
  - レガシーSSH: netmiko(Paramiko)の範囲で対応。届かない範囲は `paramiko` の
    バージョン指定(requirements.txt)で調整する。踏み台(バスチョン)経由が必要な
    機器は `ssh_config_file` で調整(GUIバックエンドが常に config/proxy.conf を渡す。
    2026-10-12: 以前は config/settings.yaml で有効/無効・ファイルを選べたが、
    Hostパターンに一致しないホストにはそもそもProxyJumpが適用されないnetmiko/
    paramiko自体の挙動にそのまま委ねる方針にして専用の切替を廃止した。ユーザー承認の
    上でコア変更に追従)。最も古い機器は将来 scrapli-system を `CliCollector` のフォールバック
    として追加できる(現時点では実装しない)。`disabled_algorithms`(Paramiko の
    Transport に渡すアルゴリズム除外設定)は一時期 `NetmikoCollector` に持たせて
    いたが、実際に必要になった局面が無くどこからも呼ばれない状態が続いたため撤去
    した(2026-09-22。ユーザー承認の上でコア変更。netmiko/Paramiko 自体が持つ
    機能なので、実際に必要になれば同様の形で足し戻せる)。
  - **出力の終わりの目印(プロンプト)は、接続時に決まるホスト名部分から作った固定の
    ものを全機種で使う**(2026-10-28。ユーザー承認の上でコア変更)。netmiko の
    send_command は目印(expect_string)を指定しないと、コマンドごとにプロンプトを探し
    直す。この処理は応答を待たずに読み、読めた最後の行が記号で終わるかを確かめずに目印に
    する。踏み台経由で十数台を並列に取得したとき、プロンプトが途中で切れて届いてホスト名
    だけが目印になり、ASA の show version が出力中のホスト名で始まる行で打ち切られた
    (続くコマンドも狂って失敗した)。そこで `NetmikoCollector` は、接続時に netmiko が
    プロンプト末尾の記号が届くまで待って確かめたホスト名部分(`base_prompt`)から目印を
    作り、全コマンドで `expect_string` に渡す。目印の作り方はプロンプトの形ごとの関数とし、
    `_PROMPT_PATTERN_FOR`(netmiko の device_type → 作り方)に登録する。Cisco IOS /
    IOS-XE / NX-OS / ASA は「行頭がホスト名、空白なしで # か > が続き、そこで出力が
    終わる」形。CLI で収集する機種は `_VENDOR_TYPE_TO_NETMIKO` とあわせて必ず登録し、
    未登録の機種は接続する前にエラーにする(暗黙の既定は持たない)。機種ごとに目印を
    登録する方式にしたのは、機種のプロンプトの形を知らずに接続時に実際のプロンプトを
    確定する方式よりコードが小さく、時間に頼る判断が残らず、取得中にプロンプトの一部が
    変わる機器にも目印側で対応できるため。調査の途中で一時、ASA の表示し返しの確認
    (cmd_verify)を有効に戻したが、この経路は防げなかったため取り下げた。
- **REST(RestCollector)**: APIC・F5・PAN-OS 等、CLI とは別系統。応答は収集時点で JSON
  文字列化して `CommandResult.raw` に格納する(CLI 側と raw の型を str に揃えるため)。
  パースは `parse` 層の `JsonParser`(json.loads するだけ)が行う。組み込みの実装は
  `APICRestCollector`(Cisco APIC。engine="apic")、`BigIpRestCollector`(F5
  BIG-IP。engine="bigip"。2026-09-12 追加)、`PanosRestCollector`(PAN-OS。
  engine="panos"。2026-09-21 追加)の3つ(いずれもユーザー承認の上でコア変更)。
  `RestQuery`は`key + method + path`のみ(method+pathだけで問い合わせ先が一意に
  決まる素朴なREST APIを素の requests で叩く前提。旧 module/gather_subset フィールドは
  Ansibleモジュール(aci_rest/bigip_device_info)を経由する場合にしか意味を持たず、
  そのような実装が無い現状では不要と判断し削除した。2026-09-12。ユーザー承認の
  上でコア変更)。
  - `APICRestCollector`: Cisco APIC RESTful API User Guide の手順どおり、
    POST /api/aaaLogin.json でトークンを取得し、cookie "APIC-Cookie" を載せて
    GET する(finally で /api/aaaLogout.json)。実機の APIC(Cisco DevNet の
    常時稼働サンドボックス sandboxapicdc.cisco.com)で take_snapshot→保存→比較
    まで検証済み。
  - `BigIpRestCollector`: F5 CloudDocs「Authentication with the F5 REST API」
    (https://clouddocs.f5.com/api/icontrol-soap/Authentication_with_the_F5_REST_API.html)
    の手順どおり、POST /mgmt/shared/authn/login で
    {username, password, loginProviderName: "tmos"} を送りトークン
    (応答の token.token。入れ子構造)を取得し、ヘッダー "X-F5-Auth-Token" を載せて
    GET する(finally で DELETE /mgmt/shared/authz/tokens/{token} により破棄。
    参照ページにログアウト手順の明記は無く、トークンリソースの一般的な破棄方法に
    倣った)。実機の BIG-IP がこの環境に無いため、検証はモック(HTTPレベルの
    偽装)止まり。
  - `PanosRestCollector`: PAN-OS & Panorama API リファレンス「Get Started with the
    PAN-OS REST API」(https://docs.paloaltonetworks.com/pan-os/11-1/
    pan-os-panorama-api/get-started-with-the-pan-os-rest-api)の手順どおり、
    POST /api/?type=keygen に user/password を**POSTボディ**で送り(パスワードを
    URLクエリに載せる方式もPAN-OS側は許容するがログ等に残るリスクがあるため使わない)、
    XML応答(`<response status="success"><result><key>...</key></result></response>`)
    から key を取得し、ヘッダー "X-PAN-KEY" に載せて GET する。PAN-OS の API キーには
    明示的な失効エンドポイントがドキュメント上見当たらないため、APIC/BIG-IP と異なり
    finally でのログアウト処理は無い。REST API パスにはバージョン番号を含む
    (例 "/restapi/v11.1/..."。バージョンにより対応 API が異なるため実機導入時は
    要調整)。実機の PAN-OS がこの環境に無いため、検証はモック(HTTPレベルの偽装)
    止まり(2026-09-21)。
  `collector=` でどれも直接渡すこともできる。
  証明書検証(`verify`)はいずれも既定 False(ラボ環境等で自己署名証明書を使うことが
  多いため。2026-09-12 変更。ユーザー承認の上でコア変更。正式なCA署名証明書の
  環境では呼び出し側で明示的に `verify=True` を渡す)。
- **CLI・REST の併用**: 1機器が両方から取得する構成にも対応する(コマンド層の
  `CommandSetEntry` が `cli` と `rest` を両方持てる)。`take_snapshot` が
  両方のジョブを組んで別々に実行し、同じ host の結果を1つの `CollectResult` に
  統合してから parse・保存に進む(詳細はコマンド層・6章参照)。
- **認証**: `Device` は認証情報を持たない。`CredentialProvider`(`resolve(device)->creds`)で
  解決。実装は `FileCredentialProvider`(`config/credentials.yaml`)。CLI・REST の
  両実装が共有する(どちらか一方の名前は冠さない)。
  `take_snapshot()` は `credentials` 省略時にこれを既定で使う(`collect.default_credentials()`)。
  現時点は平文保存だが、ファイルの中身を読む処理(`_read_raw()`)を分離してあり、
  将来 SOPS + age 等での暗号化に対応しやすい形にしてある
  (`config/credentials.yaml` は `.gitignore` 済み・パーミッション600)。
  将来 HashiCorp Vault を差し替え可能な設計は変わらない(`CredentialProvider` の
  別実装を追加するだけでよい)。
  `config/credentials.yaml` は `default`(全機器共通の既定アカウント。必須)と
  `hosts`(host名→アカウント。任意)の2キーを持つ。`resolve()` は
  `hosts.<host>` があればそれを、無ければ `default` を使う(2026-09-22 追加。
  ユーザー承認の上でコア変更。「defaultのクレデンシャルを利用しつつ、一部の
  ホストに対して別のクレデンシャルを利用できるようにしたい」という要望による)。
  `CommandCatalog`/`CommandSet` と同じ方針で、`hosts.<host>` を書く場合は
  `username`/`password` をその中で完結させる(`default` の一部だけを引き継ぐ
  部分マージはしない。`secret` のみ各エントリ内で独立して任意)。
  GUI(`gui/backend/app/api/credentials.py`)から `default`・`hosts` の参照/追加/
  更新/削除ができる(2026-09-22 追加。コアは `FileCredentialProvider.resolve()` で
  読み取り専用のまま、ファイルの書き込みは GUI 側に閉じる。`command_sets.py` 等と
  同じ方針。GUI 側だけの変更のためコア変更の承認対象外)。
- 収集の基本単位: `collect.collect_one(collector, job, credentials, ...) -> CollectResult`。
  1ジョブ(1機器分のCLIコマンド列、またはREST問い合わせ列)をリトライ込みで収集する。
  機器間の並列・完了順ストリーミングは `take_snapshot` 側が持つ(収集層は「1機器を
  確実に取る」ことに専念する)。retries は既定1回で、一過性の失敗(接続タイムアウト等)
  のみ指数バックオフ + ジッタで再試行する。認証失敗・コマンドエラーは決定的失敗として
  再試行しない。
- **REST engine の解決**(2026-10-12 変更。ユーザー承認の上でコア変更): CLI は netmiko
  一択だが、REST は機種ごとに認証・エンドポイントの作法が全く違う(APIC は
  aaaLogin→APIC-Cookie、BIG-IP は token 認証、PAN-OS は APIキー)ため、1つの実装を
  全機器で共有できない。`collect.rest_engine_for(device)` が機器の vendor/type から
  engine 名を引き、`take_snapshot` が機器ごとに collector を割り当てる(同じ engine の
  機器はインスタンスを共有)。対応表に無い機種が REST で取得しようとした場合は、収集を
  始める前に `ValueError` を投げる。以前は `take_snapshot(rest_engine=...)` で全機器に
  1つの engine を指定する形だったが、GUI が常に "apic" を渡していたため F5・PAN-OS の
  機器を扱えなかった。機種を増やすときは `get_rest_collector()` と
  `_REST_ENGINE_BY_DEVICE` の2箇所に足す。
- **実行ログ**(2026-10-12 追加。ユーザー承認の上でコア変更): 4つの Collector 実装
  (`NetmikoCollector`/`APICRestCollector`/`BigIpRestCollector`/`PanosRestCollector`)が
  標準の `logging`(`logging.getLogger(__name__)`)で、接続/ログイン開始・成功/失敗・
  コマンド(またはREST問い合わせ)ごとの実行開始・完了/失敗・切断を記録する。
  ログの出力先(標準出力・ファイル等)はこの層では決めず、呼び出し側(GUIの場合は
  `gui/backend/app/logging_config.py`)が `logging` の設定で決める。GUIは
  `data/healthcheck.log`(ローテーション。5MB×3世代)と標準出力の両方へ出し、
  `GET /logs`(`gui/backend/app/api/logs.py`。任意の文字列の部分一致・件数指定。
  2026-10-12: 当初はホスト名専用の絞り込みだったが、行の中身全体(コマンド名・
  エラー文言等)を対象にした汎用の部分一致に変更した)で実行後にも
  読み返せるようにしている(フロントエンドの「ログ」ページ)。実行中の進捗は
  6章のSSE(機器単位)で見せ、個々のコマンド単位の詳細はこのログで確認する、という
  役割分担。

### パース層(Genie / TextFSM、カタログで選択)
- `parse(device, command, raw, command_catalog, parse_engines)` がファサード。
  **CommandCatalog**(コマンド層。vendor + type + command ごとに定義)が選んだ
  エンジン("genie"/"textfsm")だけで parse する。フォールバックはしない。
  command_catalog に定義の無いコマンドは None(「認可されているか」の検証は
  take_snapshot 側の責務で、parse 自体は行わない)。
- エンジンは `ParserEngine` 抽象 + 実装(`GenieParser` / `TextFsmParser`)。
  parse_engines を差し替え可能な作りは保つ。実パーサは遅延 import(重い依存を
  実行時まで持ち込まない)、パース不可・未対応は None を返す。
- **パース不可のコマンドは比較対象外**(スキップして結果に記録)。比較はパース済みのみを対象とし、
  raw テキストでの比較フォールバックはしない(比較ロジックを構造化 dict のみに保つ)。

### コマンド層
機器へ投げるコマンド、およびパース・比較に関する「管理」を1箇所に集約する層。
`CliPolicy`(安全性)と `CommandSet`+`CommandCatalog`(実行対象と取り扱い方)は
互いに独立しており、`take_snapshot` が両方を満たすことを検証する。責務:

- **実行可能コマンドの管理(CliPolicy / RestPolicy)**: 設定変更を伴わない
  **確認系コマンドのみ**を通す安全性の関門。CLI(CliPolicy)は「許可プレフィックス
  (show/display 等)で始まるか」だけを見るシンプルな方式(禁止語チェックは持たない。
  安全性・柔軟性より単純さを優先)。vendor/type に依存しないグローバルな判定。
  許可プレフィックスはコード(cli_policy.py)に直接書き、YAML等の外部設定には
  しない(安全装置の変更を必ずコードレビューに乗せるため)。REST(RestPolicy)は
  RestQuery が既に構造化されている(自由文字列を組み立てない)ため、判定は
  「method が読み取り専用("get")か」だけを見る。両者は独立した別クラスで、
  CliPolicy と対称的な API(is_allowed/find_denied/filter_allowed)を持つ。
- **機器別の取得内容の管理(CommandSet)**: 「コマンドセット名 → `CommandSetEntry`
  (vendor + type: 対象機種 + cli: CLIコマンド群 + rest: REST問い合わせ群 +
  description: 任意の説明文)」のカタログ(`command_sets`)と、「host → コマンドセット名」
  を決める `CommandSetResolver`(抽象)の2段構成。1つのコマンドセットが cli・rest の
  両方を持てるため、同じ機器が CLI と REST の両方から取得する構成にも対応する
  (片方だけでもよい)。コマンドセットは必ず1つの機種(vendor + type)に属する
  (異なる機種のコマンドを1つのコマンドセットに混在させない)。コマンドセット名は
  vendor_type と同名にする運用が典型的だが、システムとしては vendor/type に縛られない
  (同じ機種で用途違いのコマンドセットを複数持てる。例:
  cisco_ios_full/cisco_ios_minimal)。この「複数持てる」を成立させるにはコマンドセット名
  から vendor/type を機械的に導出できないため、`CommandSetEntry.vendor` /
  `CommandSetEntry.type` を明示的に持たせ、`for_device()` が機器本来の vendor/type と
  一致するかをタプル比較で検証する(2026-09-12。ユーザー承認の上でコア変更。
  2026-09-21: device_type という vendor+type を結合した単一文字列ではなく、vendor/type
  の2フィールドとして持つ形に変更。ユーザー承認の上でコア変更。「device_type として
  捉えていたものを vendor と type で捉え直す」という方針のもと、結合済み文字列を
  一切経由しないようにした)。
  resolver 未設定・host が対応表に無い・コマンドセット名が未知・vendor/type が
  機器本来のものと不一致、のいずれも例外を投げる(コマンドセットは事前に
  決まっているべきという前提。空で黙って進めない)。コマンドセット名の実在・
  vendor/type一致の判定は `validate_command_set_for(command_sets, name, vendor,
  type)` という関数に切り出し、`for_device()`(実行時。host を前置きした
  ValueError)と GUI の機器保存時検証(`gui/backend/app/api/devices.py` の
  `_validate_command_set`。保存前に教えるための HTTPException)が同じ判定を共有する
  (2026-10-12 追加。以前は同じ判定ロジックを2箇所に別々に持っていた。
  ユーザー承認の上でコア変更)。
  resolver の実装は差し替え可能:
    - `CsvCommandSetResolver`(command/csv_resolver.py): host,command_set の対応表
      CSVファイルを引くだけ(現状唯一の実装。Excel で直接編集できる形。YAML実装
      (YamlCommandSetResolver)は実際に使われていなかったため2026-10-12に撤去し、
      専用の resolver/ ディレクトリも廃止して抽象(CommandSetResolver)を
      command_set.py へ統合した。ユーザー承認の上でコア変更)。
    - 将来 NetBox 等のデバイスメタデータ(Device.meta の site/role 等)を使って動的に
      決定する実装を追加できる(`CommandSetResolver.resolve(device)` は Device 全体を
      受け取るため、host だけでなく meta も参照可能)。
- **vendor + type ごとのコマンド定義カタログ(CommandCatalog)**: 「認可されたコマンド
  (＝安全でパース可能なコマンド)」を vendor + type(機種)ごとに定義する。CLI コマンドと
  REST 問い合わせ(RestQuery.key)の両方をここに同じ形で定義する(「コマンド」は
  ここでは「1つの取得単位」という意味で使っており、由来は問わない)。コマンドごとに
  `CommandSpec`(使うパーサ genie/textfsm/json・比較時に無視するノイズキーパス・
  パース結果に list が含まれる場合の比較キー列 compare_keys(パーサ種別は問わない。
  詳細は6章の比較方法を参照)・REST の場合の method/path)
  をまとめて持つ。旧 ParserPolicy / NoiseFilter / CompareKeys の3クラスが持っていた
  情報をここに統合した。`method`(既定 "get")・`path` は REST 専用で CLI エントリでは
  無視される(`parser` が CLI/REST を区別する既存の非対称構造に倣う)。以前は
  `CommandSet` 側の `RestQuery{key, method, path}` として問い合わせ内容を持っていたが、
  それでは「同じ REST 問い合わせを複数のコマンドセットで使う」場合に method/path が
  コマンドセットごとに重複し、CommandCatalog の「1つの機種ブロックだけ見れば
  全てがわかる」という原則にも反していた(実行内容の決定はコマンドカタログの責務、
  「どれを取得するか」の選択はコマンドセットの責務、という分離に合わせ、CLI の
  コマンド文字列と対称にした)。CLI コマンド文字列とまったく同じ扱いにすることで、
  GUI 側もカタログ由来の選択肢(チェックボックス)から選ぶ UX を CLI・REST の
  両方に同じ部品で適用できる(2026-09-12。ユーザー承認の上でコア変更)。
  vendor/type 間の共通化・フォールバックは持たない(かつては `"*"` キーで全機種共通の
  既定を書けたが廃止)。同じ内容でも vendor/type ごとに明示的に書く(コピペしてでも
  決定的に記載する)。編集時に「この機種+command は結局どの定義が効くのか」を
  確かめるため別の場所まで見に行く必要をなくし、1つの機種ブロックだけ見れば全てが
  わかる状態を優先する。in-memory の表現(`by_vendor_type`)も vendor → type →
  {command: spec} の3階層辞書のまま持ち、結合済み文字列をキーにすることはしない
  (2026-09-21。ユーザー承認の上でコア変更)。
  `CommandSet` が返すコマンドは、ここに定義が無ければ `take_snapshot` がエラーにする
  (実行するコマンドは全て「取り扱い方」まで決まっているべきという前提)。
- `CommandSet`(command_sets)と `CommandCatalog` はコード内蔵の既定を持たず、
  明示的な読み込みを必須とする(サンプル値が実運用の設定と誤認されるのを避けるため)。
  どちらも `config/command/<種類>/` 配下の `*.yaml` を `from_directory()` で読む。
    - `CommandCatalog` は `config/command/command_catalog/<vendor>/<type>.yaml`
      (1ファイル=1機種。ディレクトリ名=ベンダー・ファイル名=タイプ)。ベンダー別
      ディレクトリに分けているのは機種の数が増えたときに一覧しやすくするため
      (2026-09-21。ユーザー承認の上でコア変更。以前はフラットな
      `config/command/command_catalog/<device_type>.yaml` だったが、ディレクトリ構成に
      合わせて in-memory 表現も vendor/type の2階層のまま持つようにした。ディレクトリ
      直下に置き忘れた `*.yaml` は `from_directory()` が ValueError で検知する)。
      各ファイルは `{cli: {command: spec}, rest: {key: spec}}` の形(片方だけでもよい)。
      CLI・REST を同じ機種ファイルにまとめているのは、APIC のように両方使う機種でも
      「この機種は結局どう扱われるのか」を1ファイルだけ見れば分かるようにするため。
      以前は `cli_catalog.yaml`/`rest_catalog.yaml` の2ファイルに分けていたが、機種
      単位で見たいという要求とファイル分割の軸が食い違っていたため統合した
      (2026-09-12。ユーザー承認の上でコア変更)。GUI から1件(vendor+type+command)
      単位での作成/編集/削除ができる(`POST /command-catalog`・
      `PUT`/`DELETE /command-catalog/{vendor}/{type}/{command}`。
      gui/backend/app/api/command_catalog.py。コアは読み取り専用のまま、ファイルの
      書き込みは GUI 側に閉じる方針(command_sets.py と同じ考え方)。2026-09-22
      追加。以前は「GUI編集は無し、直接編集する運用」としていたが方針変更。
      vendor/type/command は作成時のみ指定でき編集時は固定(キーの変更はここでは
      扱わない)。parser が "json" かどうかで cli/rest どちらのブロックに書くかを
      機械的に決め、編集で parser を変えればブロックも移動する。method は
      RestPolicy が "get" しか許可しないため API 側でも "get" 以外を拒否する)。
    - `CommandSet` は `config/command/command_set/`(ファイル名=コマンドセット名)。
      各ファイルは `{vendor: str, type: str, description?: str, cli: [...], rest: [...]}`
      の形(vendor・type は両方必須、description は人間向けの任意の説明文。
      2026-09-12 description 追加、2026-09-21 device_type → vendor+type
      に変更。いずれもユーザー承認の上でコア変更)。`cli` は CLI コマンド文字列の
      リスト、`rest` は REST の key(文字列)のリストで、**どちらも「コマンドカタログの
      キーを並べただけ」という同じ形**(`CommandSetEntry.rest` は `list[str]`。以前は
      `list[RestQuery]` で method/path を command_set 側に直接持っていたが、上記
      CommandCatalog の変更に合わせて移動した。2026-09-12。ユーザー承認の上でコア変更)。
      実行内容(method/path)の解決は `take_snapshot` が `CommandCatalog.spec_for(vendor,
      type, command)` を引いて行う(「カタログに定義が無ければエラー」という既存の
      検証の後で `RestQuery` を組み立ててから `RestPolicy.find_denied()` にかける)。
      1コマンドセット=1ファイルにしているのは、GUI からコマンドセット
      単位で作成/削除/インポート(ファイルの
      書き込み・置き換え)できるようにするため(2026-09-12。ユーザー承認の上で
      コア変更。編集ロジック自体はコアに持ち込まず GUI 側に閉じる方針)。実際に
      GUI からの作成/編集/削除(POST/PUT/DELETE /command-sets)を実装済み
      (gui/backend/app/api/command_sets.py。コマンドセット名はそのままファイル名に
      なるため、パストラバーサル対策として半角英数字・アンダースコア・ハイフンのみ
      許可する。ファイルインポートは未実装)。
  `CommandSetResolver` が読む
  host→コマンドセット名の対応表は「設定データ」ではなく「実装の選択」なので
  YAML 化の対象に含めず、呼び出し側が resolver インスタンスとして明示的に渡す。
  `CliPolicy` だけは例外で YAML 化しない。許可プレフィックスはコードに直接書き、
  変更は必ずコードレビューを通す(安全装置を運用ファイルの気軽な編集で緩められない
  ようにするため)。

### 保管層(show=FS)
- **show**(取得結果): 毎回保存し過去を保持。`DataStore`(ファイルシステム実装
  `FilesystemStore` / メモリ実装 `InMemoryDataStore`)。
- **実行履歴は保存しない**(2026-10-12。ユーザー承認の上でコア変更。以前は
  ツール実行結果(HealthCheckResult)を保存する `RunStore`(ファイルシステム実装)を
  持っていたが、保存(save_run)しか呼ばれず get_run/list_runs を読む利用者が
  無かったため撤去した。呼び出し側がレスポンスをその場で受け取って使うだけで済む)。
- **snapshot は意味づけを持たない**。CLI にとって snapshot は「ある機器・ある時点の
  取得結果(コマンド群へのポインタ集合)」でしかない。checkpoint/work/label は保持しない
  (それらは GUI 側の管理。1章)。
- 将来ファイルシステム以外(実体=MinIO、メタ=PostgreSQL 等)に差し替えられるよう、
  `DataRef` は backend で参照先を見分ける形を保つ(filesystem / memory の2種)。
- **`InMemoryDataStore`**(`healthcheck/storage/data_memory.py`。2026-09-22 追加。
  ユーザー承認の上でコア変更): `DataStore` をメモリ上の dict だけで満たす実装。
  ディスクには一切書き込まない。GUI の「スナップショット取得」で「保存せずに
  表示」を選んだ場合に使う。`take_snapshot()` は `DataStore` という抽象IFにしか
  依存しないため、`FilesystemStore` の代わりにこれを渡すだけでよく、
  `take_snapshot()` 自体の変更は不要だった(この抽象がもともと「将来の実装差し替え」
  を想定していたおかげ)。インスタンスは1回のリクエスト限りの使い捨てで、
  他のインスタンス・プロセスから同じデータを後から引くことはできない(GUI
  バックエンドは取得直後のレスポンスに raw/parsed をそのまま埋め込んで返すため、
  それで用は足りる)。
  - この制約を踏まえ、GUI の「正常性確認」実行(`POST /healthcheck/stream`。
    2026-09-23 追加。GUI側のみの変更)は、機器ごとに「今すぐ取得・保存しない」を
    選んだ場合でも、取得(collect)と比較(compare_device)を同じ1リクエスト内で
    完結させる。以前は GUI が先に `POST /snapshots/take` で取得して得た
    snapshot_id を後続の `POST /healthcheck` へ渡す2段階の実装だったため、
    「今すぐ取得・保存しない」ホストが他ホストと混在すると、1段階目で使った
    `InMemoryDataStore` が2段階目のリクエストでは既に存在せず、比較が
    「snapshotが見つかりません」で失敗する不具合があった。

---

## 4. 保管のディスク構造

```
data/
├── devices/<device_id>/
│   ├── <command_slug>/<timestamp>/       # show 結果(毎回保存)
│   │   ├── raw.txt / parsed.json / meta.json
│   └── snapshot/<snapshot_id>/           # snapshot(コマンド群へのポインタ集合。意味づけなし)
│       └── manifest.json
└── runs/<run_id>/manifest.json           # 実行履歴(HealthCheckResult をそのまま保存)
```

- **command**(最小単位): 1機器・1コマンドの実行結果。raw.txt(生出力)+ parsed.json
  (構造化)+ meta.json(コマンド原文・取得時刻)。時系列で毎回保存。
- **snapshot**: 1機器・1時点の command 群への `DataRef`(ポインタ)集合。実データは持たず、
  比較時に必要な command の parsed だけを遅延ロードする。
- checkpoint/work という束ねの概念、および label は CLI では持たない(GUI が snapshot_id を
  管理・意味づけする)。

---

## 5. 中核の型(models.py)

```
収集: Device(host キー / vendor + type。device_type という結合済み文字列は持たない), CliJob, CommandResult, CollectResult, RestQuery, RestJob
保管: DataRef(backend区別・現状filesystem), Snapshot(ポインタ集合。意味づけ属性なし)
分析: Status, CommandComparison, DeviceComparison, HealthCheckResult
```
- **Device** は host(関連付けキー)/ vendor / type / ip / port を持つ。機器の識別は
  id ではなく host(インベントリソースで id は変わりうる)。
  - `vendor`(例 "cisco")と `type`(例 "ios")は機器の種別を2つに分けて持つフィールドで、
    **Device はこの2つ以外に機種を表す情報を一切持たない**(2026-09-21。ユーザー承認の
    上でコア変更。当初は device_type という単一のカタログキー文字列だけを持っていたが、
    GUI 側でベンダー単位の表示・絞り込みをしやすくするため vendor/type に分割し
    (この時点では device_type は vendor+type から自動導出する互換フィールドとして
    残していた)、続けて「GUI表示まで含め device_type という文字列を完全に無くしたい」
    との要望を受け、device_type フィールド自体を Device から撤去した)。`models.py` に
    型ヒント用の `Vendor`/`DeviceModel`(いずれも `Literal[...]`)を定義しているが、
    `from __future__ import annotations` により実行時evaluationされないため実行時の
    値チェックにはならない(ドキュメント目的。実際に何が有効かは
    `config/command/command_catalog/<vendor>/<type>.yaml` のディレクトリ構成が正とする
    ソース)。
  - **command_catalog/command_set/netmiko等が扱う機種の単位も vendor/type の2軸のまま
    貫通させる**。かつては vendor+type を "_" 結合した device_type という単一文字列を
    経由していたが、「device_type として捉えていたものを vendor と type で捉え直す」
    という方針のもと、結合済み文字列そのものを廃し、あらゆる箇所が vendor/type の
    2引数・2階層で受け渡しする形に揃えた(2026-09-21。ユーザー承認の上でコア変更。
    最初は「Device には結合済み文字列を持たせず、必要な箇所がその場で組み立てる」
    という中間段階を経たが、その後「内部のキー/辞書の持ち方自体も vendor/type の
    まま階層化する」まで踏み込んだ)。具体的には:
    - `CommandCatalog.by_vendor_type`(vendor → type → {command: spec} の3階層辞書。
      以前は device_type をキーにしたフラットな辞書)+
      `spec_for(vendor, type, command)`。
    - `CommandSetEntry.vendor` / `CommandSetEntry.type`(2フィールド。以前は
      `device_type: str` 1つ)。`CommandSet.for_device()` は
      `(entry.vendor, entry.type) != (device.vendor, device.type)` のタプル比較で
      検証する(以前は結合済み文字列同士の比較)。`command_set/*.yaml` も
      `vendor:`/`type:` の2キー(以前は `device_type:` 1キー)。
    - `netmiko_collector._VENDOR_TYPE_TO_NETMIKO`(vendor → type → netmiko 語彙の
      2階層辞書)+ `netmiko_type_for(vendor, type)`。
      `genie_parser._VENDOR_TYPE_TO_GENIE`・`textfsm_parser._VENDOR_TYPE_TO_TEXTFSM` も
      同様に2階層化(いずれも以前は device_type をキーにしたフラットな辞書)。
    - GUI 側(`gui/backend/app/api/devices.py`・`command_sets.py`・`command_catalog.py`、
      `gui/frontend` の `DeviceListPage.jsx`/`CommandSetsPage.jsx`/
      `CommandCatalogPage.jsx`)も同様に vendor/type の2値のまま受け渡す
      (`GET /command-catalog` のレスポンスも vendor → type → {command: spec} の
      3階層 JSON になった)。
  - 例: ACI(APIC)は vendor="cisco" + type="apic"(結合すれば "cisco_apic" になる
    組み合わせ)。一時期 netmiko の実在SSHドライバ名 "cisco_apic"(`CiscoApicSSH`)との
    混同を避けて type を "aci" にしていたが(2026-09-13)、vendor/type 分割時に
    type の一覧へ "apic" を採用することにしたため "apic" に戻した(2026-09-21。
    ユーザー承認の上でコア変更。ACI は今のところ CLI(netmiko)を使わないため実害は
    無い)。
  - vendor+type から実際に使う語彙(netmiko の device_type・Genie の os 名・
    ntc-templates の platform 名)への変換は、**その語彙を必要とする消費者側がそれぞれ
    自分専用の対応表を持つ**(上記3つの `_VENDOR_TYPE_TO_*` 辞書)。**vendor/type と
    語彙が同じ場合(例 "cisco"→"ios"→"cisco_ios")も含め、CLI で使う組み合わせは
    全て明示的に書く**(暗黙にそのまま使う既定は持たない。command_catalog に既定を
    持たせない方針と同じ考え方)。未登録時の挙動は層によって異なる:
    `netmiko_type_for()` は `ValueError`(CLI接続は語彙が無ければ進められないため。
    `_collect_with_retry` が捕捉し当該機器だけの失敗として記録する)、
    `GenieParser`/`TextFsmParser` は `None`(パース対象外としてスキップ。パース不可を
    正常に扱う既存方針と同じ)。(2026-09-13。ユーザー承認の上でコア変更。parse層が
    collect層に依存しないよう、この3つの対応表はあえて共有しない)。CliCollector は
    抽象IF(将来 netmiko 以外の実装が増える余地あり)であり、上記の変換表はいずれも
    「CLIエンジンは netmiko 一択」という前提の上に成り立っている。2つ目の CLI エンジン
    が実際に追加される際は改めて見直しが要る(機器ごとにどの CLI エンジンを使うかを
    選ぶ仕組み自体が今は無いため)。
- **Snapshot** は id / host / taken_at / refs(command→DataRef)/ success / error のみ。
  kind・label・work_id といった意味づけフィールドは持たない。
- **分析フェーズは正常性確認専用に簡素化**(汎用の封筒＋自由ペイロードはやめる):
  - `Status` = "ok" | "ng" | "skipped" | "error" の4値。
  - `CommandComparison` = 1コマンドの比較結果(status / reason / all_diffs / effective_diffs)。
  - `DeviceComparison` = 機器1台の結果(device / status / message / commands)。自由 dict の data は廃止。
  - `HealthCheckResult` = findings + summary + params(比較した2時点等)。DataSource は廃止。
  - 比較結果を型として明示的に持つので、GUI・実行履歴が中身を型から把握できる。

---

## 6. 正常性確認ツール(healthcheck)

共通関数の集合体として、2つの操作を提供する。

### 取得(snapshot を作る)
- `take_snapshot`: コマンド層から対象機器の取得コマンド群を引き、`collect`→`parse`→`storage`
  保存を行い `Snapshot`(意味づけなし)を返す共通操作。
- 取得した snapshot に対する意味づけ(これは checkpoint だ / この work に属す / label は "pre")は
  **GUI が管理**する。CLI は snapshot_id を返すだけ。
- **機器ごとに独立した並列パイプライン**(2026-09-22 変更。ユーザー承認の上でコア変更)。
  `take_snapshot` 自身が `ThreadPoolExecutor(max_concurrency)` を持ち、機器ごとに
  「収集→パース→保存」を1タスクとして投げ、`as_completed()` で完了した機器から順に
  `yield` する(返す順序は機器リストの入力順ではなく完了順)。機器単位のパイプラインに
  することで、(a) 全機器分の生データを同時にメモリへ保持しない、(b) 一番遅い機器を
  待たずにパース・保存が進む、という2点を満たす。CLI・REST は別系統
  (別ジョブ型・別Collector)のため、1機器がその両方を使う場合(APIC等)は同じ
  ワーカー内でCLI→RESTの順に逐次実行する(機器内でのさらなる並列化はしない。単体
  ツールとしてシンプルさを優先。機器間の並列性(max_concurrency)は維持)。収集の実行
  自体は `collect.collect_one(collector, job, credentials, retries)`(1ジョブをリトライ
  込みで収集する基本単位)を呼ぶ。collector・認証情報の解決には
  `get_cli_collector(engine)`/`get_rest_collector(engine)`/`rest_engine_for(device)`・
  `default_credentials()` を使う。
  検証(CliPolicy/RestPolicy・CommandCatalogとの照合)はネットワークI/Oを伴わないため
  全機器分を先にまとめて行う(1台でも設定ミスがあれば収集を始める前に全体を止める)。

### 比較(2つの snapshot を突き合わせる)
- 「確定した対象のみ」を受け取り、host ごとに次のいずれかの比較対象を指定する
  (2026-10-12。ユーザー承認の上でコア変更に伴う構成変更。以前はツール層
  `tools/healthcheck.py` の `run_healthcheck(devices, *, before, after, data_store,
  run_store, ...)` が唯一の入口だったが、CLIエントリポイント撤去で利用者がGUIのみに
  なったため、ツール層自体を撤去し、GUIバックエンド(`gui/backend/app/api/
  healthchecks.py`)が本節で説明する手順を `take_snapshot`/`compare_device` の
  公開関数を直接組み合わせて行う。コア(`healthcheck/`)はこの2つの共通関数までを
  提供し、「2時点を確定対象で比較する」というオーケストレーションそのものは
  GUIバックエンドの責務になった):
  - **snapshot指定** … 保存済み snapshot(GUIが選択・解決済み)。host→snapshot_id の
    マッピング(snapshot_id は機器ごとに個別採番されるため、複数機器の比較で単一の
    文字列を共有することはできない)。host が無い/該当 snapshot が無い機器は、
    比較結果が error になる(取得失敗・欠落=error のルールに従う)。
  - **今すぐ取得**(save で保存有無を選べる)。host ごとに独立して選べるため、
    「今すぐ取得」と「snapshot指定」を同じ比較の中で混在できる。
  - latest 等の**探索モードは持たない**。「どの snapshot を比べるか」の探索・選択は GUI が
    照会で解決し、snapshot_id を渡す。
  - 「今すぐ取得」側は、保存有無(save)ごとにグループ化して対象機器をまとめて
    `take_snapshot` 呼び出しに渡す(機器ごとにループしない。機器間の並列性は
    take_snapshot 側の ThreadPoolExecutor がそのまま活きる)。snapshot指定側は
    ローカルFS読み出しのみ(ネットワークI/Oが無いため機器ごとに逐次でよい)。
- 比較は**パース済み(構造化 dict)のみ**。パース不可の command はスキップして報告。
- **全差分(ノイズ除外前)と除外後の差分の両方**を求め、HealthCheckResult に持たせる。
  **判定は除外後**で行う: 除外後に差分なし=ok / 差分あり=ng / 取得失敗・欠落=error /
  パース不可でその command を比較できない=skipped。snapshot が見つからない・取得失敗
  (`Snapshot.success=False`)の機器は `DeviceComparison(status="error")` として記録する。
- 「一方にしかない機器・コマンド」は比較をスキップして報告する(共通部分を比較)。
- **比較方法(実装)**: 両出力を dict に正規化 → ノイズ除外 → 自作再帰 diff。
  - 正規化: dict はキーを再帰的に文字列化、list(トップレベル・dict にネストした
    ものの両方。パーサ種別は問わない)は必ず `{キー: 行}` に dict 化する(順序変化に
    強くする。2026-10-12 変更。以前はネストした list は compare_keys 未指定だと
    素の list のまま残したが、パーサ種別・ネスト位置に関わらず一貫させるため常に
    変換する方針に統一した。ユーザー承認の上でコア変更)。キーは CommandCatalog の
    compare_keys(`list[str]`)で決める。各要素は `"a.b[].c[].d"` のようなドット
    区切りパスで、`名前[]` がそのキーの値が list であることと、その要素1つずつに
    以降のパスを適用することを示す(`[]` を複数回書けば list→dict→list のような
    入り組んだ構造でも、どの list をキー化するかを区別できる)。先頭が `[]`
    単独(例 `"[].name"`)はパース結果自身(または list 要素自身)が list である
    ことを表し、`[]` の後ろに何も続かない(例 `"logs[]"`)なら要素の値そのものを
    キーにする(スカラの list 用)。`*` は「その階層にキーが1つしか無い dict」
    にのみ一致する任意の1階層(ノイズパスと同じ書き方。クラス名がコマンドごとに
    変わる APIC の imdata 要素を `"imdata[].*.attributes.dn"` の1本で拾える)。
    一致する compare_keys が無い list は index を文字列キーにした dict にフォール
    バックする(並び順の変化に弱い)。`common/diff.py` の `normalize`。
  - diff: 自作の再帰 dict diff(DeepDiff 等の外部依存は使わない)。差分は
    「キーパス + 種別(changed/added/removed)+ before/after」の自前表現。`common/diff.py` の `diff`。
    `Change.to_dict()`(`CommandComparison.all_diffs`/`effective_diffs` の中身)の
    `path` はキー配列(`list[str]`)のまま返す(2026-10-12 変更。ユーザー承認の上で
    コア変更。以前は `".".join()` した文字列だったが、BGPネイバーのIPアドレス等
    キー自体に "." を含む値があるため、GUI側で表示用にパスの階層構造を復元する際
    文字列を再分割すると境界があいまいになっていた)。
  - compare: `common/compare.py` の `compare_device(device, before, after, ...)` が
    1機器を比較して **`DeviceComparison` を直接返す**。機器横断はGUIバックエンドが
    機器ごとに回して `HealthCheckResult` に集約する(`HealthCheckResult.add()` が
    summary の件数集計も自動で行う)。
- 実行結果(HealthCheckResult)は実行履歴として保管しない(呼び出し側がレスポンスを
  その場で受け取って使うだけ。保管層の節参照)。
- **GUI バックエンド側の実装**(`gui/backend/app/api/healthchecks.py` の
  `_run_healthcheck_events`。2026-09-23 追加、2026-10-12 に旧ツール層撤去に伴い
  一本化): 機器ごとに完了順で進捗イベント(start→before取得→after取得→
  comparing→complete)を yield するジェネレータで、`POST /healthcheck`(最後の
  complete だけ使う薄い版)・`POST /healthcheck/stream`(そのままSSEに変換する版)
  の両方がこれを共有する。host ごとに「今すぐ取得」と「個別スナップショット指定」を
  混在させられる。取得(collect)と比較(compare)を同じ1リクエスト内で完結させる
  ため、「今すぐ取得・保存しない」ホストが混在していても `InMemoryDataStore` の
  制約(1リクエスト限り。3章参照)に抵触しない。

---

## 7. CLIエントリポイント(撤去済み)

`healthcheck/runner.py`(`python -m healthcheck.runner <subcommand> ...`)は撤去した
(2026-10-12。ユーザー承認の上でコア変更。利用者がGUIのみになり、settings.yaml・
run_healthcheck の両方に依存する独立した経路を維持するコストに見合わなくなった
ため)。照会・実行はいずれもGUIバックエンド(`gui/backend/app/api/`)が担う。

- 設定ファイル(config/)・データ保存先(data/)はリポジトリ直下の固定パス
  (`__file__` 基準の絶対パス。カレントディレクトリに依存しない。
  `gui/backend/app/config.py`)。`cli_policy`/`rest_policy`/`credentials`/engine 選択は
  設定で切り替える口を持たない(いずれも下位層が安全なデフォルトに解決する。
  将来必要になれば追加できる)。
- **インベントリ/コマンドセットの取得元は `config/devices.csv`(固定パス)1つだけ**
  (2026-10-12。ユーザー承認の上でコア変更。以前は `config/settings.yaml` で
  取得方法・ファイル名を選べたが、実運用では常にCSV・常に同じ1ファイルだったため
  設定ファイル自体を廃止してパスを固定した。`gui/backend/app/sources.py` の
  `get_inventory_source()`/`get_command_set_resolver()` が毎回この固定パスで
  `CsvInventory`/`CsvCommandSetResolver` を構築する。コア側の `InventorySource`/
  `CommandSetResolver` という抽象IFは変えていないため、将来 NetBox 等に差し替える
  場合は別アダプタをこの2関数の中だけ差し替えれば足りる)。
- **SSHプロキシは `config/proxy.conf`(固定パス)を常に netmiko へ渡す**(2026-10-12。
  ユーザー承認の上でコア変更。以前は `config/settings.yaml` の
  `netmiko.ssh_config_file` で有効/無効・ファイルを選べたが、専用の有効/無効フラグを
  廃止した。Host パターンに一致しないホストにはそもそも ProxyJump が適用されない
  netmiko/paramiko 自体の挙動にそのまま委ねるため、ファイルの内容(Host ブロックの
  有無)だけで機器ごとの挙動が決まる。ファイルが無ければプロキシ無しの
  `NetmikoCollector` を返す。`gui/backend/app/sources.py` の `get_cli_collector()`)。

  GUI の「機器」はサイドバー上で「機器一覧」「認証情報」「プロキシ設定」の3つの
  子項目を持つ。機器一覧は機器の
  新規作成・編集・削除ができる(`POST /devices`・`PUT`/`DELETE /devices/{host}`。
  host は作成時のみ入力でき編集時は固定。作成/編集フォームは vendor/type/ip/
  command_set をまとめて書き換える。削除は確認ダイアログを挟むのみで、
  スナップショット等の既存データへのカスケード削除はしない。いずれも
  `config/devices.csv` を対象にする)に加え、同ファイルのダウンロード・アップロード
  もできる(`GET`/`POST /devices/csv`。アップロードは host 列の有無だけを検証する)。
  「認証情報」は `config/credentials.yaml` の `default`(必須。GUI上は「デフォルト」
  という固定行として表示・編集のみ可・削除不可)と `hosts`(追加・編集・削除可)を
  1つの表として扱う。「プロキシ設定」は `config/proxy.conf` のダウンロード・
  アップロードに加え、テキストエリアでの直接編集・保存ができる
  (`GET`/`PUT /proxy`・`GET`/`POST /proxy/conf`)。

  GUI の「スナップショット」も「一覧」「取得」の2つの子項目を持つ。一覧は他の表と
  同じ見た目(sticky ヘッダー・列フィルタ)に統一し、行を展開すると `GET /snapshots/{host}/{id}/full`(全コマンド分の
  raw/parsed を一括取得。1コマンドだけ取る既存の
  `GET /snapshots/{host}/{id}/commands/{command}` とは別に追加)の結果を、コマンドは
  ボタンで選んだものだけ raw→parsed の順に表示する(全件最初から展開はしない)。
  `GET /snapshots` はページング(`limit`/`offset`。既定100件)と `until` 絞り込みを
  持つ(コアの `DataStore.list_snapshots` は host/since までで十分なため変えず、
  GUIバックエンド側で全件取得後に並び替え・絞り込み・切り出しを行う。ステータス
  (成功/失敗)の絞り込みだけはコアに条件が無いため現在のページ内のみ有効)。

  「スナップショット取得」は `healthcheck.common.snapshot` の `take_snapshot` を直接呼ぶ
  `POST /snapshots/take`(healthchecks.py と同じ部品の組み立て方)を使う。
  UIは4ステップ(機器選択→確認→進捗→結果)。機器選択は左に全機器一覧・右に選択中の
  機器を表示する形(2026-09-22 変更。以前はチェックリスト単体だった。スナップショット
  取得・正常性確認の両方が使う共有部品 `src/components/DeviceSelector.jsx` として
  切り出した)。

  コマンドカタログ・コマンドセットは複数ファイルで構成されるため、設定ファイルの
  やり取りはディレクトリ単位(ZIP)で行う(`GET`/`POST /command-catalog/files`・
  `/command-sets/files`。`gui/backend/app/yaml_archive.py`)。アップロードは単一の
  .yaml も受け付け、同名は上書き・含まれないファイルは残すマージ方式にする(取り違えた
  アーカイブで全件消える事故を避けるため)。展開時は絶対パス・`..`・YAML以外・想定より
  深い階層を拒否し、全メンバーがYAMLとして読めることを確認してから書き込む(一部だけ
  反映された状態を作らないため)。

  設定を書き換える操作(機器の作成/編集/削除、CSV・YAMLの取り込み、コマンドカタログ・
  コマンドセットの変更、認証情報・プロキシ設定の変更)は、GUIバックエンドの各APIが
  `logging` で記録する(収集層のログと同じ `data/healthcheck.log` に出る)。「いつ・誰が
  何を変えたか」を後から追えるようにするためで、正常性確認・スナップショット取得そのものの
  実行は収集層のログで足りるため追加しない。

  画面(`gui/frontend/dist`。`npm run build` の成果物)は API と同じ FastAPI プロセスが
  配信する(`gui/backend/app/main.py` で `/` に `StaticFiles` をマウント。全 API ルーターの
  登録後に行う — `/` は配下すべてを受けるため先に置くと API のパスを奪う)。別サーバへ
  展開するときに Python の環境だけで動かせるようにするためで、静的配信のためだけに
  Web サーバを別途立てない(HTTPS・認証が要る場合は前段にリバースプロキシを足す)。
  これに伴い画面側の API 呼び出し先は相対パスにしてある(`src/api/client.js` の
  `BASE_URL`。本番ビルドでは空文字=同一オリジン、Vite の開発サーバー使用時のみ
  `http://localhost:8000`)。展開先の URL をビルド時に埋め込まないため、ビルド済みの
  `dist` をそのまま配布できる。画面はどのページを開いているかを React の状態で持ち
  URL を変えないため、SPA 用のフォールバック設定は要らない。

  画面の一覧とサイドバーでの並び・階層は `src/navigation.js` の `NAV` に1箇所で持ち、
  `App.jsx` はそこから現在のページを引くだけにする。`children` を持つ項目(機器・
  スナップショット・コマンド)はまとめで、それ自体に画面は無く、サイドバー上に子項目を
  常に開いた状態で並べてそこから選ぶ(以前は右側画面上部のタブで切り替えていたが、
  どの画面があるかがサイドバーだけで分かるようにした)。見出しを押した場合は最初の子を開く。

  フロントエンドの共有部品は `src/components/` に置く: `DeviceSelector`(機器選択)/
  `TableFilters`(表の列フィルタ。全ての一覧表で共有)/ `SnapshotDetail`
  (snapshot 1件の詳細・ダウンロード)/ `DiffView`(差分のサイドバイサイド表示)/
  `HealthCheckDetail`(正常性確認の結果ポップアップの中身)。バックエンド側も、
  複数APIが使う組み立ては `app/sources.py`(`build_collection_parts()`・
  `resolve_devices()`)と `app/sse.py`(`sse_event()`)に寄せる。

  確認ステップは対象機器とその解決済みコマンドセットを表示し、
  コマンドセット未設定/vendor・type不一致(`CommandSet.for_device()` が実行時に例外を
  投げる条件と同じ)を事前に検出して警告し、取得実行を止める(take_snapshot は
  1機器でも解決に失敗すると全体を中断するため、実行前に気づけるようにする)。
  確認ステップには「取得実行」(保存する)と「保存せずに表示」の2つの実行ボタンが
  あり(2026-09-22 追加。以前は「基本的に全て保存する」方針のため save は常に true
  だったが、「保存しない」場合は本当に何もディスクへ書かない挙動が欲しいという
  要望により、選択肢を復活させた)、`POST /snapshots/take` の `save` にそのまま渡す。
  `save=True` なら `FilesystemStore`、`save=False` なら `InMemoryDataStore`(上記
  「保管層」参照。ディスク非使用)を data_store として渡す(`take_snapshot()` 自体は
  無変更)。

  `POST /snapshots/take` は Server-Sent Events(`text/event-stream`)で進捗を返す
  (2026-09-22 追加)。`take_snapshot()` が機器ごとに完了順で yield するようになった
  ことを活かし、GUIバックエンドがそれをそのままイベント化する
  (`{"type": "start", "total": N}` → 機器ごとに
  `{"type": "device_done", "done": M, "total": N, host, success, error, saved,
  commands: {...}}` → `{"type": "complete"}`。検証エラー・ImportError は
  `{"type": "error", "message": ...}`)。コアには進捗通知の仕組みを持ち込んでいない。
  フロント側は「進捗」ステップで機器ごとに「処理中」→「完了/失敗」のバッジと
  「M / N 完了」を表示し、`complete` で結果ステップへ自動的に進む。

  取得直後のイベントに raw/parsed をそのまま埋め込んで送るため(`save` の値に
  関わらず)、その場で表示・ダウンロードできる。ダウンロード(raw/parsed/
  コマンド単位/全raw/全parsed/全て)はサーバ側にAPIを増やさず、フロントの
  `src/components/SnapshotDetail.jsx` が Blob + 一時リンクでその場で組み立てる
  (一覧・取得の両画面で共有)。

  GUI には「ログ」というトップレベルのナビ項目もある。収集層の実行ログ(上記
  「収集層」の最後の項参照)を `GET /logs` で読み、任意の文字列の部分一致・件数で
  絞り込んで表示する。SSEの進捗が機器単位なのに対し、こちらはコマンド・問い合わせ
  単位の詳細を実行後にも確認するためのもの。

  サイドバーの最下部には「利用ガイド」(`src/pages/GuidePage.jsx`)を置く。各セクションの
  概要・使い方・設定方法を、画面の操作と対応する設定ファイル(`config/` 配下)の両面から
  説明する静的なページで、API は呼ばない。コマンドカタログ/コマンドセットの書式説明も
  ここに集約し、ガイドの入口を1つにしている。

  「正常性確認」画面も4ステップのウィザード形式(機器一覧→before→after→サマリ)。
  途中のステップを飛ばさずに順に進める形にして、対象や比較時点が未確定のまま実行
  されるのを防ぐ。機器一覧は
  上記の `DeviceSelector` を共有する。before/after は既存の `TargetEditor`(今すぐ
  取得/最新のスナップショット/一覧から選択)をそのまま使う。サマリステップで
  対象機器・before/after設定を確認し、実行すると同じステップ内に結果(ステータス
  サマリ・機器ごとの一覧)を表示する。バックエンド(`POST /healthcheck`)は無変更。
- 例外は `main()` の最上位で捕捉し `{"error": ...}` を stderr に JSON 出力して exit 1 と
  する(トレースバックを直接出さない。CLI は外部システムとの境界のため)。
- 定期実行は自前実装しない。CLI は「1回実行」で完結するので、外部 cron が叩けば定期実行になる。
  ただし cron 単体で「最新 checkpoint と比較」まではしない(checkpoint は GUI 管理のため)。
  cron から使うのは「今取得して snapshot を残す」等の、意味づけに依存しない実行に限る。

---

## 8. 実装の進め方

1ステップずつ実装→テスト。各ステップで「実装の概要・詳細・ポイント」を提示し、コア部分は
理由・型の流れ・他層への影響まで理解しながら進める(GUI 部分は軽い理解でよい)。

### 実装順序(共通関数の集合体を下から積む)
✓ 済 / ☐ 未。
1. ✓ 中核の型(models.py。Snapshot は意味づけなし、分析フェーズは正常性確認専用に簡素化。
   分析フェーズの型は DeviceComparison / HealthCheckResult に改称。Status は ok/ng/skipped/error)。
2. ✓ 保管層(DataStore の FS 実装。host キー。RunStore は2026-10-12に撤去。
   保存のみで読み手が無かったため)。
3. ✓ インベントリ層(CSV アダプタ + フィルタ。YAML は不要なため未実装)。
4. ✓ コマンド層(CliPolicy(許可プレフィックスをコードに直接記載。YAML化しない)/
   RestPolicy(method=get のみ許可。CliPolicy と対)/ CommandSet(command_sets:
   コマンドセット名→CommandSetEntry{vendor, type, cli, rest, description})+
   CommandSetResolver /
   CommandCatalog(旧 ParserPolicy・NoiseFilter・CompareKeys を統合。CLI・REST共通、
   parser には genie/textfsm に加え REST 用の "json" も選べる)。CommandCatalog は
   コード内蔵の既定を持たず、`config/command/command_catalog/<vendor>/<type>.yaml`
   (1ファイル=1機種。ディレクトリ名=ベンダー・ファイル名=タイプ。in-memory表現も
   `by_vendor_type`(vendor→type→{command: spec})の3階層のまま持つ)からの
   `from_directory()` 読み込みを必須とする。
   CommandSet(command_sets)も同様にコード内蔵の既定を持たず、
   `config/command/command_set/`(1ファイル=1コマンドセット)からの
   `from_directory()` 読み込みを必須とする。host→コマンドセット名の解決は
   `CommandSetResolver` 抽象(`CsvCommandSetResolver`。将来 NetBox 等に差し替え可)。
5. ✓ 収集層(CliCollector抽象+NetmikoCollector / RestCollector抽象+APICRestCollector
   (Cisco APIC。aaaLogin→APIC-Cookie→GET→aaaLogout)+BigIpRestCollector
   (F5 BIG-IP。トークン認証)+PanosRestCollector(PAN-OS。ユーザー名+パスワードから
   API キー取得)+ `collect_one()`(リトライ込みの収集単位)+ CredentialProvider。CLI は
   実機(Cisco IOSv)で KEX/認証/コマンド実行まで検証済み。レガシー機器向けに
   `paramiko>=2.9.5,<3.0` を requirements.txt に指定。REST は APICRestCollector を
   実機(Cisco DevNet サンドボックス sandboxapicdc.cisco.com)で take_snapshot→
   保存→比較まで検証済み、BigIpRestCollector/PanosRestCollector は実機がこの環境に
   無いためモックでの検証止まり(`rest_collector=` で直接渡すことも可能)。REST の
   実装は機器の vendor/type から解決する(`rest_engine_for()`)。1機器が CLI・REST の
   両方から取得する構成にも対応(take_snapshot が両方のジョブを実行し結果を統合)。
   stub 実装(StubCollector/StubParser)は実機・実パース検証が済んだため撤去)。
6. ✓ パース層(CommandCatalog で選択 + ParserEngine 抽象 + GenieParser/TextFsmParser。
   実機の `show ip route` を GenieParser で構造化できることを検証済み。TextFsmParser は
   paloalto/panos の各コマンドに対し、ntc-templates の実テンプレートへ状態遷移が
   一致する自作サンプル出力を与えてパース成功を確認済み(実機PAN-OSは無いため
   実機の生出力そのものでの確認はできていない。2026-09-21))。
7. ✓ 比較部品(common/diff.py の normalize・diff、common/compare.py の compare_device。
   実機の2時点差分(経路削除)を検出し、ノイズ(経路の updated)除外まで検証済み)。
8. ✓ take_snapshot(collect→parse→保管→Snapshot の共通操作。common/snapshot.py。
   2026-10-12にファイル名をtake_snapshot.pyから変更、関数名は不変。実機で
   take_snapshot→compare_device→結果表示の一気通貫を確認済み)。
9. ✓→撤去 healthcheck ツール本体(旧 tools/healthcheck.py の `run_healthcheck`。
   SnapshotTarget/NowTarget で比較対象を確定値として受け取り、機器ごとに
   compare_device を呼び HealthCheckResult に集約。実機RT-01で now vs now /
   snapshot vs now / 存在しない snapshot(error 判定)まで検証済みだったが、
   2026-10-12 にCLIエントリポイント撤去に伴い撤去し、同じロジックをGUIバックエンド
   (`gui/backend/app/api/healthchecks.py` の `_run_healthcheck_events`)に一本化した
   (6章参照)。実機比較で `show cdp neighbors` の hold_time(CDPのTTL相当)が
   未フィルタだったため発見し、ノイズに追加した経緯はそのまま活きている)。
10. ✓→撤去 CLIエントリポイント(旧 healthcheck/runner.py。照会系: list-devices /
    list-snapshots、実行系: healthcheck。JSON 出力のみ。実機RT-01で各種検証済み
    だったが、利用者がGUIのみになったため2026-10-12に撤去した。7章参照)。

### 段階導入
PoC(小規模で一連を検証)→ 実運用投入 → スケール(必要になったらジョブキュー等を収集層の
背後に追加。ツールは無影響)→ 将来 NetBox 移行(インベントリ層のアダプタ差し替え)。

---

## 9. スコープ外(このツールでは扱わない)

- checkpoint / work / label の管理(GUI 側の責務)。
- 探索・選択・人間向け整形(GUI 側)。
- config(running-config)のバックアップ(Oxidized 等の別システム)。
- 通知 / レポート整形 / データ鮮度判定(必要になれば別途)。
- 将来ツール(経路情報、接続位置一覧、証明書期限 等)。増えたときに共通化を再検討する。
