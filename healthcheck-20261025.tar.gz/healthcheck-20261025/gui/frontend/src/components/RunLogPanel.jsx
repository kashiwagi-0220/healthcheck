import { useEffect, useRef, useState } from "react";
import { getLogs } from "../api/client";
import LogLines from "@/components/LogLines";
import { cn } from "@/lib/utils";

// 実行中の画面(正常性確認・スナップショット取得)の右側に出すログ欄。
//
// 進捗イベントは機器が1台終わるたびにしか届かないため、遅い機器でどのコマンドを
// 実行中なのかは分からない。そこで収集層がコマンド単位で書いているログ(接続・
// コマンドの開始と完了・失敗・再試行)をそのまま見せ、人が読んで判断できるように
// する。ログの文言を解釈して件数などに変換することはしない(文言が仕様になって
// しまうため)。
//
// 開始イベントで受け取ったサーバ時刻(since)以降の、対象機器の行だけを定期的に
// 取り直す。

const POLL_INTERVAL_MS = 2000;
const MAX_LINES = 1000;

export default function RunLogPanel({ since, hosts, focusHost, onClearFocus, className }) {
  const [lines, setLines] = useState([]);
  const [total, setTotal] = useState(0);
  const [error, setError] = useState(null);
  const scrollRef = useRef(null);
  const stickToBottom = useRef(true);

  // 配列のままだと描画のたびに別物と見なされ取り直しが走るため、文字列にして比べる。
  const hostsKey = (focusHost ? [focusHost] : hosts).join("\n");

  useEffect(() => {
    if (!since || !hostsKey) return undefined;
    stickToBottom.current = true;
    let cancelled = false;
    const load = () =>
      getLogs({ since, hosts: hostsKey.split("\n"), limit: MAX_LINES })
        .then((res) => {
          if (cancelled) return;
          setLines(res.lines);
          setTotal(res.total);
          setError(null);
        })
        .catch((e) => {
          if (!cancelled) setError(e.message);
        });
    load();
    const id = setInterval(load, POLL_INTERVAL_MS);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, [since, hostsKey]);

  // 新しい行が来たら末尾まで送る。利用者が上へスクロールして読んでいる間は動かさない。
  useEffect(() => {
    const el = scrollRef.current;
    if (el && stickToBottom.current) el.scrollTop = el.scrollHeight;
  }, [lines]);

  const handleScroll = (e) => {
    const el = e.currentTarget;
    stickToBottom.current = el.scrollHeight - el.scrollTop - el.clientHeight < 16;
  };

  return (
    <div className={cn("flex min-w-0 flex-col rounded-md border bg-card", className)}>
      <div className="flex items-center justify-between gap-2 border-b px-3 py-2">
        <span className="text-sm font-semibold">ログ</span>
        {focusHost ? (
          <button type="button" className="text-xs text-primary hover:underline" onClick={onClearFocus}>
            {focusHost} のみ表示中(クリックで全機器に戻す)
          </button>
        ) : (
          <span className="text-xs text-muted-foreground">機器の行をクリックすると、その機器だけに絞り込みます</span>
        )}
      </div>
      <div ref={scrollRef} onScroll={handleScroll} className="flex-1 overflow-auto p-2 font-mono text-xs leading-5">
        {error && <p className="text-destructive">{error}</p>}
        {total > lines.length && (
          <p className="text-muted-foreground">(古い行は省略。直近 {lines.length} 行を表示)</p>
        )}
        {lines.length === 0 ? (
          <p className="text-muted-foreground">まだログはありません</p>
        ) : (
          <LogLines lines={lines} compact />
        )}
      </div>
    </div>
  );
}
