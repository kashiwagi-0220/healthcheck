import { useState } from "react";
import Sidebar from "@/components/Sidebar";
import { findPage } from "@/navigation";

function App() {
  const [active, setActive] = useState("healthcheck");
  const { page, parent } = findPage(active);
  const { Component } = page;

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar active={active} onNavigate={setActive} />
      <div className="flex flex-1 flex-col overflow-hidden">
        <header className="flex h-14 shrink-0 items-center gap-1.5 border-b px-6 text-sm">
          {parent && <span className="text-muted-foreground">{parent.label}</span>}
          {parent && <span className="text-muted-foreground">/</span>}
          <h1 className="font-semibold">{page.label}</h1>
        </header>
        <main className="flex-1 overflow-y-auto p-6">
          <Component />
        </main>
      </div>
    </div>
  );
}

export default App;
