import { useEffect, useMemo, useState } from "react";
import { useDeviceSearch } from "../hooks/useDeviceSearch";
import { getCommandSets, takeSnapshotStream } from "../api/client";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import DeviceSelector, { DEVICE_TABLE_WIDTH } from "@/components/DeviceSelector";
import { Spinner, RunningBadge, Elapsed, ProgressBar } from "@/components/Running";
import SnapshotDetail from "@/components/SnapshotDetail";
import { Dialog, RESULT_DIALOG_WIDTH, RESULT_DIALOG_HEIGHT } from "@/components/ui/dialog";
import { formatDateTime } from "@/lib/format";
import { deviceVendorColor, deviceTypeColor } from "@/lib/deviceTypeColor";
import { cn } from "@/lib/utils";
import { downloadAllRaw, downloadAllParsed, downloadEverything } from "@/lib/snapshotDownload";
import { Download } from "lucide-react";

// 確認ステップ: 対象機器とそのコマンドセットを表示する。コマンドセット未設定・
// vendor/type不一致は取得時に失敗する(CommandSet.for_device() が例外を投げる)ため、
// ここで事前に検出して警告し、取得実行ボタンを止める。
function ConfirmStep({ devices, commandSets, onBack, onConfirm, running }) {
  const rows = useMemo(
    () =>
      devices.map((d) => {
        const name = d.meta?.command_set;
        const entry = name ? commandSets[name] : undefined;
        const valid = Boolean(entry && entry.vendor === d.vendor && entry.type === d.type);
        return { device: d, commandSetName: name, valid };
      }),
    [devices, commandSets]
  );
  const hasInvalid = rows.some((r) => !r.valid);

  return (
    <div className="space-y-3">
      <h3 className="text-sm font-semibold">サマリ({rows.length} 件)</h3>
      <Table containerClassName={cn("w-full max-h-[78vh] overflow-y-auto rounded-md border bg-card", DEVICE_TABLE_WIDTH)}>
          <TableHeader className="sticky top-0 z-10 bg-muted">
            <TableRow>
              <TableHead>ホスト名</TableHead>
              <TableHead>ベンダー</TableHead>
              <TableHead>タイプ</TableHead>
              <TableHead>コマンドセット</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows.map(({ device, commandSetName, valid }) => (
              <TableRow key={device.host}>
                <TableCell className="font-medium">{device.host}</TableCell>
                <TableCell>
                  <Badge className={deviceVendorColor(device.vendor)}>{device.vendor}</Badge>
                </TableCell>
                <TableCell>
                  <Badge className={deviceTypeColor(device.type)}>{device.type}</Badge>
                </TableCell>
                <TableCell>
                  {valid ? (
                    <Badge variant="secondary">{commandSetName}</Badge>
                  ) : (
                    <Badge variant="destructive">
                      {commandSetName ? `不整合(${commandSetName})` : "未設定"}
                    </Badge>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
      </Table>
      {hasInvalid && (
        <p className="text-sm text-destructive">
          コマンドセットが未設定、または機器のベンダー/タイプと一致しない機器があります。
          「機器」画面から先に修正するか、選択を見直してください。
        </p>
      )}
      <div className="flex items-center gap-2">
        <Button variant="outline" onClick={onBack} disabled={running}>
          戻る
        </Button>
        <Button onClick={() => onConfirm(true)} disabled={running || hasInvalid}>
          {running ? <><Spinner />取得中...</> : "取得して保存"}
        </Button>
        <Button
          className="bg-accent text-accent-foreground hover:bg-accent/80"
          onClick={() => onConfirm(false)}
          disabled={running || hasInvalid}
        >
          取得して表示
        </Button>
      </div>
    </div>
  );
}

// 取得中の進捗表示。deviceStatuses は {host: {status: "pending"|"done", success}}。
// take_snapshot() が機器ごとに完了した順に結果を返すため(healthcheck/common/
// snapshot.py 参照)、ここでもその順で "処理中"→"完了/失敗" に切り替わる。
function ProgressPanel({ deviceStatuses, done, total, startedAt }) {
  const hosts = Object.keys(deviceStatuses);
  return (
    <div className={cn("space-y-3 rounded-md border bg-muted/20 p-4", DEVICE_TABLE_WIDTH)}>
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Spinner />
          <h3 className="text-sm font-semibold">取得中...</h3>
          {startedAt && <Elapsed startedAt={startedAt} />}
        </div>
        <p className="text-xs text-muted-foreground">{done} / {total} 完了</p>
      </div>
      <ProgressBar done={done} total={total} />
      <div className="max-h-[78vh] overflow-y-auto rounded-md border bg-card">
        {hosts.map((host) => {
          const st = deviceStatuses[host];
          return (
            <div key={host} className="flex items-center gap-2 border-b px-3 py-1.5 text-sm last:border-0">
              <span className="font-medium">{host}</span>
              {st.status === "pending" ? (
                <span className="ml-auto"><RunningBadge /></span>
              ) : (
                <Badge variant={st.success ? "success" : "destructive"} className="ml-auto">
                  {st.success ? "完了" : "失敗"}
                </Badge>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default function SnapshotTakePage() {
  const { devices, loading, error: devicesError } = useDeviceSearch();
  const [commandSets, setCommandSets] = useState({});
  const [selectedHosts, setSelectedHosts] = useState([]);
  const [step, setStep] = useState("select"); // select -> confirm -> running -> result
  const [running, setRunning] = useState(false);
  const [deviceStatuses, setDeviceStatuses] = useState({});
  const [progress, setProgress] = useState({ done: 0, total: 0 });
  const [startedAt, setStartedAt] = useState(null);  // 取得開始時刻(経過時間の表示用)
  const [results, setResults] = useState(null);
  const [error, setError] = useState(null);
  const [selected, setSelected] = useState(null); // 選択中の結果(snapshot形)。選択中はポップアップ表示する。

  // コマンドセットは確認ステップでの検証(機器に割り当てられたセットが実在し、
  // vendor/type が一致するか)に使う。取得に失敗したまま進むと、設定は正しいのに
  // 「未設定」と表示して実行を止めてしまうため、理由を出す。
  useEffect(() => {
    getCommandSets().then(setCommandSets)
      .catch((e) => setError(`コマンドセットの取得に失敗しました: ${e.message}`));
  }, []);

  const toggleHost = (host) =>
    setSelectedHosts((prev) => (prev.includes(host) ? prev.filter((h) => h !== host) : [...prev, host]));

  // 列フィルタで絞り込んだ分をまとめて選択/解除する(1回の更新で反映する)。
  const selectManyHosts = (hosts, selected) =>
    setSelectedHosts((prev) => {
      const next = new Set(prev);
      for (const h of hosts) {
        if (selected) next.add(h);
        else next.delete(h);
      }
      return [...next];
    });

  const selectedDevices = useMemo(
    () => selectedHosts.map((h) => devices.find((d) => d.host === h)).filter(Boolean),
    [selectedHosts, devices]
  );

  const handleNext = () => {
    if (selectedHosts.length === 0) {
      setError("機器を選択してください。");
      return;
    }
    setError(null);
    setStep("confirm");
  };

  const handleRun = (save) => {
    setRunning(true);
    setStartedAt(Date.now());
    setError(null);
    const initialStatuses = Object.fromEntries(selectedHosts.map((h) => [h, { status: "pending" }]));
    setDeviceStatuses(initialStatuses);
    setProgress({ done: 0, total: selectedHosts.length });
    setResults([]);
    setStep("running");

    takeSnapshotStream({ hosts: selectedHosts, save }, (event) => {
      if (event.type === "start") {
        setProgress({ done: 0, total: event.total });
      } else if (event.type === "device_done") {
        setDeviceStatuses((prev) => ({ ...prev, [event.host]: { status: "done", success: event.success } }));
        setProgress({ done: event.done, total: event.total });
        setResults((prev) => [...prev, event]);
      } else if (event.type === "error") {
        setError(event.message);
      }
    })
      .then(() => setStep("result"))
      .catch((e) => {
        setError(e.message);
        setStep("confirm");
      })
      .finally(() => setRunning(false));
  };

  const handleReset = () => {
    setSelectedHosts([]);
    setResults(null);
    setDeviceStatuses({});
    setProgress({ done: 0, total: 0 });
    setError(null);
    setStep("select");
  };

  // 選択中の機器(selectedHosts)は残したまま機器選択画面に戻る(ConfirmStep の
  // 「戻る」と同じ考え方)。handleReset は選択自体もクリアする点が異なる。
  const handleBackToSelect = () => {
    setResults(null);
    setDeviceStatuses({});
    setProgress({ done: 0, total: 0 });
    setError(null);
    setStep("select");
  };

  return (
    <div className="space-y-4">
      {error && <p className="text-sm text-destructive">{error}</p>}

      {step === "select" && (
        <>
          <DeviceSelector
            devices={devices}
            loading={loading}
            error={devicesError}
            selectedHosts={selectedHosts}
            onToggle={toggleHost}
            onSelectMany={selectManyHosts}
          />
          <Button onClick={handleNext}>次へ(確認)</Button>
        </>
      )}

      {step === "confirm" && (
        <ConfirmStep
          devices={selectedDevices}
          commandSets={commandSets}
          onBack={() => setStep("select")}
          onConfirm={handleRun}
          running={running}
        />
      )}

      {step === "running" && (
        <ProgressPanel
          deviceStatuses={deviceStatuses}
          done={progress.done}
          total={progress.total}
          startedAt={startedAt}
        />
      )}

      {step === "result" && results && (
        <div className="space-y-3">
          <p className="text-sm text-muted-foreground">{results.length} 件取得しました</p>

          <Table className="table-fixed" containerClassName="max-h-[78vh] overflow-y-auto rounded-md border bg-card">
            <TableHeader className="sticky top-0 z-10 bg-muted">
              <TableRow>
                <TableHead className="w-[22%]">ホスト名</TableHead>
                <TableHead className="w-[26%]">取得時刻</TableHead>
                <TableHead className="w-[12%]">ステータス</TableHead>
                <TableHead className="w-[12%]">保存</TableHead>
                <TableHead className="w-[28%]">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {results.map((r) => {
                const snapshot = { host: r.host, id: r.id, taken_at: r.taken_at, success: r.success, error: r.error, commands: r.commands };
                return (
                  <TableRow
                    key={`${r.host}:${r.id}`}
                    className="cursor-pointer hover:bg-accent"
                    onClick={() => setSelected(snapshot)}
                  >
                    <TableCell className="font-medium">{r.host}</TableCell>
                    <TableCell>{formatDateTime(r.taken_at)}</TableCell>
                    <TableCell>
                      <Badge variant={r.success ? "success" : "destructive"}>{r.success ? "成功" : "失敗"}</Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant={r.saved ? "success" : "secondary"}>{r.saved ? "保存済み" : "表示のみ"}</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        <Button size="sm" variant="outline" onClick={(e) => { e.stopPropagation(); downloadAllRaw(snapshot); }}>
                          <Download /> raw
                        </Button>
                        <Button size="sm" variant="outline" onClick={(e) => { e.stopPropagation(); downloadAllParsed(snapshot); }}>
                          <Download /> parsed
                        </Button>
                        <Button size="sm" variant="outline" onClick={(e) => { e.stopPropagation(); downloadEverything(snapshot); }}>
                          <Download /> 全て
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>

          <Dialog
            open={Boolean(selected)}
            onClose={() => setSelected(null)}
            title={selected ? `${selected.host} / ${selected.id}` : ""}
            className={RESULT_DIALOG_WIDTH}
            contentClassName={RESULT_DIALOG_HEIGHT}
          >
            {selected && (
              <SnapshotDetail
                host={selected.host}
                snapshotId={selected.id}
                takenAt={selected.taken_at}
                success={selected.success}
                error={selected.error}
                commands={selected.commands}
                showDownloadAll={false}
              />
            )}
          </Dialog>

          <div className="flex items-center gap-2">
            <Button size="sm" variant="outline" onClick={handleBackToSelect}>
              戻る
            </Button>
            <Button size="sm" variant="outline" onClick={handleReset}>
              最初からやり直す
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
