import { useEffect, useState } from "react";
import { getLogs } from "../api/client";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { RefreshCw } from "lucide-react";

const LIMIT_OPTIONS = [100, 500, 1000, 5000];

// 実行ログ(data/healthcheck.log)の照会ページ。収集層(healthcheck/collect/*)が
// コマンド・問い合わせ単位で記録したログを、正常性確認・スナップショット取得を
// 実行した後からでも確認できるようにする。
export default function LogsPage() {
  const [query, setQuery] = useState("");
  const [limit, setLimit] = useState(500);
  const [lines, setLines] = useState([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const reload = () => {
    setLoading(true);
    setError(null);
    getLogs({ q: query || undefined, limit })
      .then((res) => {
        setLines(res.lines);
        setTotal(res.total);
      })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    reload();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [limit]);

  return (
    <div className="space-y-3">
      <div className="flex items-end justify-between gap-3">
        <div className="flex items-end gap-3">
          <div className="space-y-1">
            <Label className="text-sm font-semibold">文字列(部分一致)</Label>
            <Input
              className="h-8 w-56"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && reload()}
              placeholder="例: RT-01 / show ip route / 失敗"
            />
          </div>
          <div className="space-y-1">
            <Label className="text-sm font-semibold">表示件数(末尾から)</Label>
            <Select className="h-8 w-28" value={limit} onChange={(e) => setLimit(Number(e.target.value))}>
              {LIMIT_OPTIONS.map((n) => (
                <option key={n} value={n}>
                  {n}
                </option>
              ))}
            </Select>
          </div>
          <Button size="sm" variant="outline" onClick={reload} disabled={loading}>
            <RefreshCw /> 更新
          </Button>
        </div>
        <p className="text-sm text-muted-foreground">
          {loading ? "読み込み中..." : `${lines.length} / ${total} 行`}
        </p>
      </div>

      {error && <p className="text-sm text-destructive">{error}</p>}

      <pre className="max-h-[75vh] overflow-auto rounded-md border bg-white p-3 font-mono text-xs leading-5 whitespace-pre-wrap text-black">
        {lines.length > 0 ? lines.join("\n") : loading ? "" : "ログがありません"}
      </pre>
    </div>
  );
}
