import { useMemo } from "react";
import { cn } from "@/lib/utils";
import { RESULT_DIALOG_PANE_HEIGHT } from "@/components/ui/dialog";

// Genie Diff のツリー表示を参考にした、左before・右after のサイドバイサイド表示。
// 同じ親を持つ diff 群を1本の木にマージし、共通のキー階層は左右とも同じテキストの
// 1行だけ描画する(同じキーが何度も繰り返されるのを避けるため)。葉(1件の diff が
// 確定する深さ)は種別に応じて: changed は同じ行の左にbefore値・右にafter値(黄色)、
// added は右だけに値(緑、左は空欄)、removed は左だけに値(赤、右は空欄)。
// dict 同士は値が変わった葉まで再帰的に分解される仕様(healthcheck.common.diff.diff)
// なので、通常 changed の before/after はスカラ。added/removed はキーがまるごと
// 増減した場合で、値がネストした構造を持ちうるため同じ側に再帰的に全て表示する。
//
// diff の path はキー配列(IPアドレス等キーに "." を含む値があるため、コア側で
// 文字列結合していない)なので、そのままツリーのキーとして使える。

function formatScalar(value) {
  if (typeof value === "string") return value;
  return JSON.stringify(value);
}

// value がオブジェクトならキーごとに再帰して全行を同じ種別・同じ側(before/after
// どちらか一方)にする(added/removed でキーがまるごとネストした構造を持つ場合用)。
function pushValueLines(keyLabel, value, depth, kind, side, out) {
  if (value !== null && typeof value === "object" && !Array.isArray(value)) {
    out.push({ depth, kind, [side]: `${keyLabel}:` });
    for (const [k, v] of Object.entries(value)) {
      pushValueLines(k, v, depth + 1, kind, side, out);
    }
  } else {
    out.push({ depth, kind, [side]: `${keyLabel}: ${formatScalar(value)}` });
  }
}

// diff 群をキー配列(path)でマージしてツリー化し、表示行(左右のテキストを持つ)の
// フラットなリストに変換する。中間ノード(まだ差分が確定しない共通キー)は
// 左右とも同じテキストの1行、葉ノードは種別に応じた行を生成する。
function buildDiffLines(diffs) {
  const root = { children: new Map(), leaf: null };
  for (const d of diffs) {
    let node = root;
    for (const key of d.path) {
      if (!node.children.has(key)) node.children.set(key, { children: new Map(), leaf: null });
      node = node.children.get(key);
    }
    node.leaf = d;
  }

  const out = [];
  const walk = (node, depth, keyLabel) => {
    if (node.leaf) {
      const d = node.leaf;
      if (d.type === "changed") {
        out.push({
          depth,
          kind: "changed",
          beforeText: `${keyLabel}: ${formatScalar(d.before)}`,
          afterText: `${keyLabel}: ${formatScalar(d.after)}`,
        });
      } else if (d.type === "added") {
        pushValueLines(keyLabel, d.after, depth, "added", "afterText", out);
      } else if (d.type === "removed") {
        pushValueLines(keyLabel, d.before, depth, "removed", "beforeText", out);
      }
      return;
    }
    let nextDepth = depth;
    if (keyLabel !== null) {
      out.push({ depth, kind: "context", beforeText: `${keyLabel}:`, afterText: `${keyLabel}:` });
      nextDepth = depth + 1;
    }
    for (const [key, child] of node.children) walk(child, nextDepth, key);
  };
  for (const [key, child] of root.children) walk(child, 0, key);
  return out;
}

// 変更=黄色・削除=赤色・追加=緑色(ユーザー指定)。削除/追加は空欄側も含めて
// 行全体をその色にする(どちらの変化か一目で分かるようにするため)。
const DIFF_ROW_BG = {
  changed: "bg-yellow-100",
  added: "bg-green-100",
  removed: "bg-red-100",
};

// スクロールはポップアップ全体ではなく、このウィンドウ単位で完結させる(長い場合に
// 目的の行を探しやすくするため)。高さの上限は raw/parsed/正規化後のタブ
// (HealthCheckDetail の DataPanel)と同じにして、タブを切り替えても表示領域の
// 大きさが変わらないようにする。sticky ヘッダーの基準になる「直近のスクロール祖先」は
// 縦横1つの div に統一する(table.jsx の Table コンポーネントと同じ理由による設計)。
function DiffTree({ diffs }) {
  const lines = useMemo(() => buildDiffLines(diffs), [diffs]);
  return (
    <div className={cn(RESULT_DIALOG_PANE_HEIGHT, "overflow-auto rounded-md border")}>
      <div className="grid min-w-max grid-cols-2 font-mono text-xs">
        <div className="sticky top-0 z-10 border-r border-b bg-muted px-2 py-1 text-[10px] font-medium text-muted-foreground">
          before
        </div>
        <div className="sticky top-0 z-10 border-b bg-muted px-2 py-1 text-[10px] font-medium text-muted-foreground">
          after
        </div>
        {lines.map((line, i) => (
          <div className="contents" key={i}>
            <div className={cn("border-r px-2 py-0.5 whitespace-pre", DIFF_ROW_BG[line.kind])}>
              {line.beforeText != null ? `${"  ".repeat(line.depth)}${line.beforeText}` : ""}
            </div>
            <div className={cn("px-2 py-0.5 whitespace-pre", DIFF_ROW_BG[line.kind])}>
              {line.afterText != null ? `${"  ".repeat(line.depth)}${line.afterText}` : ""}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function DiffSection({ title, diffs, empty }) {
  return (
    <div className="space-y-2 rounded-md border p-3">
      <p className="text-base font-bold">
        {title} <span className="text-sm font-normal text-muted-foreground">({diffs.length} 件)</span>
      </p>
      {diffs.length === 0 ? <p className="text-sm text-muted-foreground">{empty}</p> : <DiffTree diffs={diffs} />}
    </div>
  );
}
