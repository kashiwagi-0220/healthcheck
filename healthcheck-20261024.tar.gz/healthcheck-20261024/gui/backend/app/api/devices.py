"""
gui.backend.app.api.devices — 機器一覧API・機器の作成/編集/削除API・CSVの
アップロード/ダウンロード

照会(GET /devices)はインベントリソース(app.sources.get_inventory_source())を
そのまま呼ぶだけの薄いエンドポイント。

作成(POST /devices)・編集(PUT /devices/{host})・削除(DELETE /devices/{host})は、
host→機器情報を持つ config/devices.csv(固定パス)の該当行を書き換える。コアには
書き込みロジックを持ち込まず GUI 側に閉じる方針(command_sets.py と同じ考え方)。
command_set 列を書く場合は、指定されたコマンドセットが実在し、かつその
vendor/type が対象機器本来の vendor/type と一致するかを検証する
(CommandSet.for_device() が実行時に行う検証と同じ内容を、保存前に GUI 側でも
行うことで事前に気づけるようにする)。コマンドセットの変更は他のフィールドと
同様この編集フォーム経由のみで行う。

インベントリとコマンドセット解決は常に同じ config/devices.csv を指す(app/sources.py
参照)。

GET/POST /devices/csv は config/devices.csv そのもののダウンロード/アップロード。
"""

from __future__ import annotations

import logging
import csv
import json
from pathlib import Path

from fastapi import APIRouter, HTTPException, Query, UploadFile, File
from fastapi.responses import FileResponse

from healthcheck.command import CommandSet, validate_command_set_for
from healthcheck.models import Device

from app.config import DEVICES_CSV, COMMAND_SET_DIR
from app.sources import get_inventory_source, save_devices_csv
from app.schemas import DeviceIn, DeviceCreateIn

router = APIRouter()

logger = logging.getLogger(__name__)

_FIELD_ORDER = ["host", "vendor", "type", "ip", "command_set"]


def _inventory_csv_path() -> Path:
    return DEVICES_CSV


def _read_csv(csv_path: Path) -> tuple[list[str], list[dict]]:
    with csv_path.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        fieldnames = list(reader.fieldnames or [])
        rows = list(reader)
    return fieldnames, rows


def _write_csv(csv_path: Path, fieldnames: list[str], rows: list[dict]) -> None:
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({name: row.get(name, "") for name in fieldnames})


def _validate_command_set(command_set: str | None, vendor: str, type_: str) -> None:
    """コマンドセットの実在・vendor/type一致を検証する。判定ロジック自体は
    healthcheck.command.validate_command_set_for にあり、CommandSet.for_device()
    (実行時の検証)と共有する。"""
    if not command_set:
        return
    command_sets = CommandSet.from_directory(COMMAND_SET_DIR).command_sets
    try:
        validate_command_set_for(command_sets, command_set, vendor, type_)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


def _device_row(host: str, body: DeviceIn) -> dict:
    return {
        "host": host,
        "vendor": body.vendor,
        "type": body.type,
        "ip": body.ip or "",
        "command_set": body.command_set or "",
    }


@router.get("/devices", response_model=list[Device])
def list_devices(
    filter: str | None = Query(
        default=None,
        description='属性名→値(または値のリスト)のJSON。例 {"vendor": "cisco", "type": "ios"}',
    ),
) -> list[Device]:
    filter_dict = None
    if filter:
        try:
            filter_dict = json.loads(filter)
        except json.JSONDecodeError as e:
            raise HTTPException(status_code=400, detail=f"filter が不正なJSONです: {e}")
    return get_inventory_source().get_devices(filter=filter_dict)


@router.post("/devices", status_code=201, response_model=Device)
def create_device(body: DeviceCreateIn) -> Device:
    host = body.host.strip()
    if not host:
        raise HTTPException(status_code=400, detail="host を指定してください。")
    if not body.vendor.strip() or not body.type.strip():
        raise HTTPException(status_code=400, detail="vendor / type を指定してください。")
    _validate_command_set(body.command_set, body.vendor, body.type)

    csv_path = _inventory_csv_path()
    fieldnames, rows = _read_csv(csv_path)
    if any((r.get("host") or "").strip() == host for r in rows):
        raise HTTPException(status_code=409, detail=f"host '{host}' は既に存在します。")

    for name in _FIELD_ORDER:
        if name not in fieldnames:
            fieldnames.append(name)
    rows.append(_device_row(host, body))
    _write_csv(csv_path, fieldnames, rows)
    logger.info("機器を追加しました: %s (vendor=%s type=%s ip=%s command_set=%s)",
                host, body.vendor, body.type, body.ip or "-", body.command_set or "-")

    return get_inventory_source().get_devices(filter={"host": host})[0]


@router.put("/devices/{host}", response_model=Device)
def update_device(host: str, body: DeviceIn) -> Device:
    if not body.vendor.strip() or not body.type.strip():
        raise HTTPException(status_code=400, detail="vendor / type を指定してください。")
    _validate_command_set(body.command_set, body.vendor, body.type)

    csv_path = _inventory_csv_path()
    fieldnames, rows = _read_csv(csv_path)
    target = next((r for r in rows if (r.get("host") or "").strip() == host), None)
    if target is None:
        raise HTTPException(status_code=404, detail=f"host が見つかりません: {host}")

    for name in _FIELD_ORDER:
        if name not in fieldnames:
            fieldnames.append(name)
    target.update(_device_row(host, body))
    _write_csv(csv_path, fieldnames, rows)
    logger.info("機器を更新しました: %s (vendor=%s type=%s ip=%s command_set=%s)",
                host, body.vendor, body.type, body.ip or "-", body.command_set or "-")

    return get_inventory_source().get_devices(filter={"host": host})[0]


@router.delete("/devices/{host}", status_code=204)
def delete_device(host: str) -> None:
    csv_path = _inventory_csv_path()
    fieldnames, rows = _read_csv(csv_path)
    if not any((r.get("host") or "").strip() == host for r in rows):
        raise HTTPException(status_code=404, detail=f"host が見つかりません: {host}")

    rows = [r for r in rows if (r.get("host") or "").strip() != host]
    _write_csv(csv_path, fieldnames, rows)
    logger.info("機器を削除しました: %s", host)


@router.get("/devices/csv")
def download_devices_csv() -> FileResponse:
    if not DEVICES_CSV.exists():
        raise HTTPException(status_code=404, detail=f"{DEVICES_CSV} が見つかりません。")
    return FileResponse(DEVICES_CSV, filename=DEVICES_CSV.name, media_type="text/csv")


@router.post("/devices/csv")
async def upload_devices_csv(file: UploadFile = File(...)) -> dict:
    content = await file.read()
    try:
        save_devices_csv(content)
    except ValueError as e:
        logger.warning("機器一覧CSVの取り込みに失敗しました(%s): %s", file.filename, e)
        raise HTTPException(status_code=400, detail=str(e))
    logger.info("機器一覧CSVを取り込みました: %s", file.filename)
    return {"saved": DEVICES_CSV.name}
