"""
gui.backend.app.api.credentials — 認証情報(config/credentials.yaml)照会・変更API

コア(healthcheck/collect/file_credential_provider.py の FileCredentialProvider)は
config/credentials.yaml を読み取り専用で使う(resolve(device) で default/hosts から
1件解決するだけ)。ここではその全件を GUI から参照・編集できるようにする。ファイルの
書き込み・削除ロジックはコアに持ち込まず GUI 側に閉じる方針は他の設定(command_sets.py・
sources.py)と同じ。

default は必須(削除不可・常に1件)。hosts は host名をキーにした任意件数の上書きで、
1件は username/password が必須・secret のみ任意(部分マージはしない。
FileCredentialProvider.resolve() 側の前提と揃える)。

このファイルは平文の認証情報を含むため(将来 SOPS+age 等での暗号化を検討)、
書き込み後は毎回 chmod 600 を掛け直す
(YAML書き込みでパーミッションがリセットされる可能性があるため)。
"""

from __future__ import annotations

import logging

import yaml
from fastapi import APIRouter, HTTPException

from app.config import CREDENTIALS_FILE
from app.schemas import CredentialEntryIn

router = APIRouter()

logger = logging.getLogger(__name__)


def _load() -> dict:
    if not CREDENTIALS_FILE.exists():
        raise HTTPException(status_code=500, detail=f"{CREDENTIALS_FILE} が見つかりません。")
    data = yaml.safe_load(CREDENTIALS_FILE.read_text(encoding="utf-8")) or {}
    if not isinstance(data.get("default"), dict):
        raise HTTPException(status_code=500, detail=f"{CREDENTIALS_FILE}: default セクションがありません。")
    return data


def _save(data: dict) -> None:
    CREDENTIALS_FILE.write_text(
        yaml.safe_dump(data, allow_unicode=True, sort_keys=False), encoding="utf-8"
    )
    CREDENTIALS_FILE.chmod(0o600)


def _to_entry(raw: dict) -> dict:
    return {
        "username": raw.get("username"),
        "password": raw.get("password"),
        "secret": raw.get("secret") or None,
    }


@router.get("/credentials")
def get_credentials():
    data = _load()
    hosts = data.get("hosts") or {}
    return {
        "default": _to_entry(data["default"]),
        "hosts": {host: _to_entry(entry) for host, entry in hosts.items()},
    }


@router.put("/credentials/default")
def put_default_credential(body: CredentialEntryIn):
    data = _load()
    data["default"] = body.model_dump(exclude_none=True)
    _save(data)
    logger.info("既定の認証情報を更新しました(username=%s)", body.username)
    return _to_entry(data["default"])


@router.put("/credentials/hosts/{host}")
def put_host_credential(host: str, body: CredentialEntryIn):
    if not host.strip():
        raise HTTPException(status_code=400, detail="host を指定してください。")
    data = _load()
    hosts = data.setdefault("hosts", {})
    hosts[host] = body.model_dump(exclude_none=True)
    _save(data)
    logger.info("ホスト個別の認証情報を更新しました: %s (username=%s)", host, body.username)
    return _to_entry(hosts[host])


@router.delete("/credentials/hosts/{host}", status_code=204)
def delete_host_credential(host: str):
    data = _load()
    hosts = data.get("hosts") or {}
    if host not in hosts:
        raise HTTPException(status_code=404, detail=f"'{host}' の上書き設定は見つかりません。")
    del hosts[host]
    data["hosts"] = hosts
    _save(data)
    logger.info("ホスト個別の認証情報を削除しました: %s", host)
