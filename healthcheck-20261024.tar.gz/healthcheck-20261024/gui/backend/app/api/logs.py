"""
gui.backend.app.api.logs — 実行ログ照会API

app.logging_config が data/healthcheck.log へ書いている、収集層(healthcheck/collect/*)の
コマンド・問い合わせ単位の実行ログを読み返す。ローテーション後の
過去分(.1/.2/...)は対象にしない(「直近の実行を後から確認する」という用途には
現在のファイルで十分なため)。
"""

from __future__ import annotations

from fastapi import APIRouter, Query

from app.logging_config import LOG_FILE

router = APIRouter()


@router.get("/logs")
def get_logs(
    q: str | None = Query(default=None, description="任意の文字列の部分一致(大小文字区別なし)で絞り込む(ホスト名・コマンド名・エラー文言等、行の中身全体が対象)"),
    limit: int = Query(default=500, ge=1, le=5000, description="末尾から何行返すか"),
) -> dict:
    if not LOG_FILE.exists():
        return {"lines": [], "total": 0}

    with LOG_FILE.open(encoding="utf-8", errors="replace") as f:
        lines = [line.rstrip("\n") for line in f]

    if q:
        needle = q.strip().lower()
        lines = [line for line in lines if needle in line.lower()]

    return {"lines": lines[-limit:], "total": len(lines)}
