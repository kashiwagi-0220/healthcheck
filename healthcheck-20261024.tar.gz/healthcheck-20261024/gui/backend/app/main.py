"""
gui.backend.app.main — FastAPI アプリケーション起動点

API と画面(ビルド済みのフロントエンド)の両方をこの1プロセスで配信する。
別サーバへ展開するときに Python の環境だけで動くようにするため、静的ファイル配信の
ためだけに nginx 等を別途立てる構成にはしない(HTTPS や認証を前段に置きたい場合は、
このプロセスの前にリバースプロキシを足せばよい)。

起動:
  PYTHONPATH=<リポジトリ直下> python -m uvicorn app.main:app \\
      --host 127.0.0.1 --port 8000 --app-dir <リポジトリ直下>/gui/backend

画面は gui/frontend/dist(`npm run build` の成果物)を配信する。dist が無い場合は
API だけを提供する(開発中に Vite の開発サーバー(既定 5173)を使う場合がこれに当たる)。
"""

from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.logging_config import setup_logging
from app.api import devices, snapshots, healthchecks, proxy, command_sets, command_catalog, credentials, logs

setup_logging()

app = FastAPI(title="healthcheck GUI API")

# Vite の開発サーバー(既定 http://localhost:5173)から API を叩く場合だけ別オリジンに
# なるため許可する。ビルド済みの画面を下でマウントして使う場合は同一オリジンになり、
# この設定は使われない。
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(devices.router)
app.include_router(snapshots.router)
app.include_router(healthchecks.router)
app.include_router(proxy.router)
app.include_router(command_sets.router)
app.include_router(command_catalog.router)
app.include_router(credentials.router)
app.include_router(logs.router)

# 画面のマウントは必ず全 API ルーターの後に行う。"/" へのマウントは配下すべてを
# 受けるため、先に置くと API のパスまで奪ってしまう。
# 画面はタブの切り替えを React の状態で持ち URL を変えないため、SPA 用の
# 「存在しないパスは index.html へ」というフォールバックは不要(html=True だけで足りる)。
_DIST = Path(__file__).resolve().parent.parent.parent / "frontend" / "dist"
if _DIST.is_dir():
    app.mount("/", StaticFiles(directory=_DIST, html=True), name="ui")
