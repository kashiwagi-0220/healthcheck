"""
gui.backend.app.sources — インベントリ/コマンドセット/SSHプロキシ/認証情報の
固定パス・アップロード・ダウンロード

インベントリ・コマンドセット解決は常に config/devices.csv(1ファイル固定)を使う。
取得方法やファイルを選ぶ設定は持たない。コア側の `InventorySource`/
`CommandSetResolver` という抽象IFはそのままなので、将来 NetBox 等へ差し替える場合は
別アダプタを実装してこのファイルの該当関数だけ差し替えればよい。

SSHプロキシ(踏み台)は常に config/proxy.conf を netmiko へ渡す。有効/無効の専用
フラグは持たない(OpenSSHのHostパターンに一致しないホストにはそもそもProxyJumpが
適用されないnetmiko/paramiko自体の挙動にそのまま委ねるため。ファイルが無ければ
プロキシ無しのCollectorを返す)。
"""

from __future__ import annotations

import csv
import io
from pathlib import Path

from fastapi import HTTPException

from healthcheck.inventory import CsvInventory, InventorySource
from healthcheck.command import CsvCommandSetResolver, CommandSetResolver, CommandSet, CommandCatalog
from healthcheck.collect.base import CliCollector
from healthcheck.collect.netmiko_collector import NetmikoCollector
from healthcheck.models import Device

from app.config import DEVICES_CSV, PROXY_CONF, COMMAND_SET_DIR, COMMAND_CATALOG_DIR


def get_inventory_source() -> InventorySource:
    return CsvInventory(DEVICES_CSV)


def resolve_devices(hosts: list[str]) -> list[Device]:
    """host一覧から、インベントリに実在する Device のリストを解決する。1件でも
    見つからなければ404。healthchecks.py・snapshots.py が共有する。"""
    wanted = set(hosts)
    devices = [d for d in get_inventory_source().get_devices() if d.host in wanted]
    missing = wanted - {d.host for d in devices}
    if missing:
        raise HTTPException(status_code=404, detail=f"インベントリに無い host です: {sorted(missing)}")
    return devices


def get_command_set_resolver() -> CommandSetResolver:
    return CsvCommandSetResolver(DEVICES_CSV)


def get_cli_collector() -> CliCollector:
    """config/proxy.conf があれば、それを使う NetmikoCollector を返す(無ければ
    プロキシ無し)。healthchecks.py/snapshots.py の両方から使う。"""
    ssh_config_file = str(PROXY_CONF) if PROXY_CONF.exists() else None
    return NetmikoCollector(ssh_config_file=ssh_config_file)


def build_collection_parts() -> tuple[CommandSet, CommandCatalog, CliCollector]:
    """take_snapshot に渡す部品(コマンドセット・コマンドカタログ・CLI collector)を
    まとめて組み立てる。スナップショット取得・正常性確認のどちらも同じ3点を同じ
    固定パスから読むため、組み立て方をここに揃える。"""
    command_set = CommandSet.from_directory(COMMAND_SET_DIR, resolver=get_command_set_resolver())
    command_catalog = CommandCatalog.from_directory(COMMAND_CATALOG_DIR)
    return command_set, command_catalog, get_cli_collector()


def save_devices_csv(content: bytes) -> None:
    """アップロードされたCSVで config/devices.csv を置き換える。host 列を含む
    UTF-8 の CSV であることだけ確認する(CsvInventory/CsvCommandSetResolver の
    どちらも host 列に依存するため)。"""
    try:
        text = content.decode("utf-8")
    except UnicodeDecodeError:
        raise ValueError("UTF-8として読み込めないファイルです。")
    reader = csv.DictReader(io.StringIO(text))
    if not reader.fieldnames or "host" not in reader.fieldnames:
        raise ValueError("host 列を含むCSVファイルではありません。")
    DEVICES_CSV.write_text(text, encoding="utf-8")


def save_proxy_conf(content: bytes) -> None:
    """アップロードされたOpenSSH形式の設定で config/proxy.conf を置き換える。
    中身の書式(Host/ProxyJump等)までは検証しない(netmikoのssh_config_fileに
    そのまま渡すだけのファイルで、書式検証はnetmiko/paramikoに委ねる)。"""
    try:
        text = content.decode("utf-8")
    except UnicodeDecodeError:
        raise ValueError("UTF-8として読み込めないファイルです。")
    write_proxy_conf_text(text)


def read_proxy_conf() -> str:
    """config/proxy.conf の内容(無ければ空文字列。編集フォームの初期値用)。"""
    if not PROXY_CONF.exists():
        return ""
    return PROXY_CONF.read_text(encoding="utf-8")


def write_proxy_conf_text(text: str) -> None:
    """編集フォームからの保存(アップロードと同じ書き込み先。中身は検証しない)。"""
    PROXY_CONF.write_text(text, encoding="utf-8")
