import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import JsonView from "@/components/JsonView";
import { DiffSection } from "@/components/DiffView";
import { STATUS_VARIANT } from "@/lib/statusVariant";
import { cn } from "@/lib/utils";

// 結果ポップアップの中身。機器1台分のコマンド一覧(DeviceDetail)と、選んだ
// コマンド1件の詳細(CommandDetail。差分・ノイズ・raw・parsed・正規化後のタブ)。

function reasonText(c) {
  if (c.status === "ok") return `${c.all_diffs?.length ?? 0} 件のノイズを除外`;
  if (c.status === "ng") return `${c.effective_diffs?.length ?? 0} 件の差分`;
  return c.reason ?? "-";
}

// 1コマンド・片側(before/after)分の raw・parsed・normalized 表示(タブは
// 呼び出し側(CommandDetail)で持つので、ここは表示専用)。mode="normalized" は
// healthcheck.common.diff.normalize(parsed, compare_keys) の結果(compare_device が
// 実際に比較へ使う形)。
function DataPanel({ label, data, mode }) {
  const value = mode === "parsed" ? data?.parsed : mode === "normalized" ? data?.normalized : null;
  return (
    <div className="space-y-1">
      <p className="text-xs font-medium text-muted-foreground">{label}</p>
      {!data ? (
        <p className="text-sm text-muted-foreground">データがありません</p>
      ) : mode === "raw" ? (
        <pre className="max-h-[60vh] overflow-auto rounded-md bg-muted p-2 text-xs">{data.raw}</pre>
      ) : value != null ? (
        <JsonView value={value} className="max-h-[60vh] overflow-auto rounded-md bg-muted p-2 text-xs" />
      ) : (
        <pre className="max-h-[60vh] overflow-auto rounded-md bg-muted p-2 text-xs">(パース結果なし)</pre>
      )}
    </div>
  );
}

// parsed(正規化前)と normalized(正規化後)を同じ経路で辿り、本来 list だった
// 箇所が compare_keys で一致するキーを見つけられず index にフォールバックした
// 箇所のパスを集める(「compare_keysがどう効いたか確認できない」という要望への
// 対応)。index フォールバックかどうかは「parsed 側がそこで
// 配列だったか」で判定するため、Genie由来の整数キーdict(例 next_hop_list の
// "1"/"2". JSON化しても元から dict であり配列ではない)を誤検知しない。
function findFallbackPaths(parsed, normalized, path = [], out = []) {
  if (Array.isArray(parsed) && normalized && typeof normalized === "object") {
    const keys = Object.keys(normalized);
    const isFallback = keys.length > 0 && keys.every((k) => /^\d+(#\d+)?$/.test(k));
    if (isFallback) {
      out.push(path.length ? path.join(".") : "(ルート)");
    }
    for (const k of keys) {
      const idx = Number(k.split("#")[0]);
      findFallbackPaths(parsed[idx], normalized[k], [...path, k], out);
    }
    return out;
  }
  if (normalized && typeof normalized === "object" && !Array.isArray(normalized)
      && parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
    for (const k of Object.keys(normalized)) {
      if (k in parsed) {
        findFallbackPaths(parsed[k], normalized[k], [...path, k], out);
      }
    }
  }
  return out;
}

// コマンド1件分の詳細。「差分」「ノイズ」「raw」「parsed」「正規化後」をタブで
// 切り替える(ポップアップ内のコマンド選択(DeviceDetail)と同じボタンの形に
// 揃えている)。差分は判定に使われた effective_diffs、ノイズは all_diffs のうち
// effective_diffs に無いもの(=noise 設定で除外された分)で、件数が多くなりやすい
// ため別々のタブにする。commandDetails は
// {before: {raw,parsed,normalized}, after: {raw,parsed,normalized}}(POST
// /healthcheck/stream の complete イベントの details から。core の
// CommandComparison 自体は差分しか持たないための補足データ)。
function CommandDetail({ c, commandDetails }) {
  const [tab, setTab] = useState("diff");
  // path は配列(キーに "." を含む値があるためコア側で文字列結合していない)なので、
  // Set に入れて同一性を比較するには JSON.stringify でキー化する。
  const effectivePaths = new Set((c.effective_diffs ?? []).map((d) => JSON.stringify(d.path)));
  const diffDiffs = c.effective_diffs ?? [];
  const noiseDiffs = (c.all_diffs ?? []).filter((d) => !effectivePaths.has(JSON.stringify(d.path)));

  const fallbackPaths = useMemo(() => {
    if (tab !== "normalized") return [];
    const before = commandDetails?.before;
    const after = commandDetails?.after;
    const paths = new Set();
    if (before) findFallbackPaths(before.parsed, before.normalized).forEach((p) => paths.add(p));
    if (after) findFallbackPaths(after.parsed, after.normalized).forEach((p) => paths.add(p));
    return [...paths];
  }, [tab, commandDetails]);

  return (
    <div className="space-y-3 rounded-md border p-3">
      <div className="flex items-center gap-2">
        <Badge variant={STATUS_VARIANT[c.status] ?? "secondary"}>{c.status}</Badge>
        <span className="text-xs text-muted-foreground">{reasonText(c)}</span>
      </div>
      <div className="flex gap-1">
        <Button size="sm" variant={tab === "diff" ? "default" : "outline"} onClick={() => setTab("diff")}>
          差分({diffDiffs.length})
        </Button>
        <Button size="sm" variant={tab === "noise" ? "default" : "outline"} onClick={() => setTab("noise")}>
          ノイズ({noiseDiffs.length})
        </Button>
        <Button size="sm" variant={tab === "raw" ? "default" : "outline"} onClick={() => setTab("raw")}>
          raw
        </Button>
        <Button size="sm" variant={tab === "parsed" ? "default" : "outline"} onClick={() => setTab("parsed")}>
          parsed
        </Button>
        <Button size="sm" variant={tab === "normalized" ? "default" : "outline"} onClick={() => setTab("normalized")}>
          正規化後
        </Button>
      </div>
      {tab === "diff" && <DiffSection title="差分" diffs={diffDiffs} empty="差分はありません" />}
      {tab === "noise" && <DiffSection title="ノイズ" diffs={noiseDiffs} empty="ノイズはありません" />}
      {(tab === "raw" || tab === "parsed" || tab === "normalized") && (
        <>
          {tab === "normalized" && fallbackPaths.length > 0 && (
            <p className="text-xs text-destructive">
              compare_keys が一致せず index にフォールバックした箇所: {fallbackPaths.join(", ")}
            </p>
          )}
          <div className="grid grid-cols-2 gap-3">
            <DataPanel label="before" data={commandDetails?.before} mode={tab} />
            <DataPanel label="after" data={commandDetails?.after} mode={tab} />
          </div>
        </>
      )}
    </div>
  );
}

// DeviceRow のポップアップの中身。スナップショット一覧の詳細ポップアップ
// (SnapshotDetail)と同じ、コマンド名のボタンを並べてクリックしたものだけ
// 詳細(差分・ノイズ)を表示する形にする。ボタンの色は差分の有無(effective_diffs。判定に
// 使われた差分で、ノイズは含まない)で薄い赤/緑に分け、一覧を見ただけで
// どのコマンドに差分があったか分かるようにする。選択中はリングで示す
// (色そのものは維持し、outline/default の切り替えでは表さない)。
export function DeviceDetail({ f, details }) {
  const commands = f.commands ?? [];
  const [activeCommand, setActiveCommand] = useState(null);
  const active = commands.find((c) => c.command === activeCommand);
  const activeDetails = active && {
    before: details?.before?.[active.command],
    after: details?.after?.[active.command],
  };

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-1">
        {commands.map((c) => {
          const hasDiff = (c.effective_diffs?.length ?? 0) > 0;
          const isActive = activeCommand === c.command;
          return (
            <Button
              key={c.command}
              size="sm"
              variant="outline"
              className={cn(
                hasDiff
                  ? "border-red-200 bg-red-100 text-red-900 hover:bg-red-200"
                  : "border-green-200 bg-green-100 text-green-900 hover:bg-green-200",
                isActive && "ring-2 ring-primary ring-offset-1"
              )}
              onClick={() => setActiveCommand(isActive ? null : c.command)}
            >
              {c.command}
            </Button>
          );
        })}
        {commands.length === 0 && <p className="text-sm text-muted-foreground">コマンドがありません</p>}
      </div>
      {active && <CommandDetail c={active} commandDetails={activeDetails} />}
    </div>
  );
}
