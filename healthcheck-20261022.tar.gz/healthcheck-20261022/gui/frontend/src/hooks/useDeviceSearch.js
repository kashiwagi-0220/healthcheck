import { useCallback, useEffect, useMemo, useState } from "react";
import { listDevices } from "../api/client";

// 数百台規模を想定: 機器一覧は1回だけ取得し、以降の絞り込みはクライアント側で
// 即座に行う(検索のたびにAPIへ往復しない)。host / vendor / type の部分一致で絞る。
export function useDeviceSearch() {
  const [devices, setDevices] = useState([]);
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const refetch = useCallback(() => {
    setLoading(true);
    return listDevices()
      .then(setDevices)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    refetch();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return devices;
    return devices.filter(
      (d) =>
        d.host.toLowerCase().includes(q) ||
        d.vendor.toLowerCase().includes(q) ||
        d.type.toLowerCase().includes(q)
    );
  }, [devices, query]);

  return { devices, filtered, query, setQuery, loading, error, refetch };
}
