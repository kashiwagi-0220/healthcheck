import { useEffect, useMemo, useState } from "react";
import { listSnapshots, getSnapshotFull } from "../api/client";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import SnapshotDetail from "@/components/SnapshotDetail";
import { downloadAllRaw, downloadAllParsed, downloadEverything } from "@/lib/snapshotDownload";
import { formatDateTime } from "@/lib/format";
import Pagination from "@/components/Pagination";
import { PAGE_SIZE, usePageRange } from "@/hooks/usePagination";
import { Download } from "lucide-react";
import { TextFilter, SelectFilter } from "@/components/TableFilters";

// "YYYY-MM-DDTHH:mm" 形式(datetime-local の value と同じ形)のローカル時刻文字列を、
// バックエンドへ渡す ISO8601 文字列に変換する。この環境の Python は 3.9 のため
// datetime.fromisoformat() が "Z" 終端を受け付けない(3.11 以降のみ対応)。
// toISOString() の "Z" を "+00:00" に置き換えて渡す。
function toBackendIso(localValue) {
  if (!localValue) return null;
  const d = new Date(localValue);
  if (Number.isNaN(d.getTime())) return null;
  return d.toISOString().replace("Z", "+00:00");
}

// 日付は <input type="date">、時刻は <input type="time"> の2つにする。
// <input type="time"> の value は表示ロケールに関わらず常に "HH:mm"(24時間表記)の
// 文字列になる(DOM仕様。表示だけが地域設定でAM/PM風になることはあるが、値は
// 変わらない)ため、時・分を別の<Select>に分けず1つの入力にまとめている。value は
// datetime-local と同じ "YYYY-MM-DDTHH:mm" 形式を保つので、呼び出し側
// (toBackendIso 等)は変更不要。
function DateTime24Input({ value, onChange }) {
  const [datePart, timePart] = value ? value.split("T") : ["", ""];

  const emitDate = (nextDate) => {
    if (!nextDate) {
      onChange("");
      return;
    }
    onChange(`${nextDate}T${timePart || "00:00"}`);
  };
  const emitTime = (nextTime) => {
    if (!datePart) return;
    onChange(`${datePart}T${nextTime || "00:00"}`);
  };

  return (
    <div className="flex items-center gap-1">
      <Input className="h-7 w-32 text-xs" type="date" value={datePart} onChange={(e) => emitDate(e.target.value)} />
      <Input
        className="h-7 w-24 text-xs"
        type="time"
        value={timePart}
        disabled={!datePart}
        onChange={(e) => emitTime(e.target.value)}
      />
    </div>
  );
}

// 展開時に GET .../full を1回だけ呼び、コマンドごとの raw/parsed をまとめて取得する。
function SnapshotDetailLoader({ host, snapshotId }) {
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    getSnapshotFull(host, snapshotId).then(setData).catch((e) => setError(e.message));
  }, [host, snapshotId]);

  if (error) return <p className="text-sm text-destructive">{error}</p>;
  if (!data) return <p className="text-sm text-muted-foreground">読み込み中...</p>;

  return (
    <SnapshotDetail
      host={host}
      snapshotId={data.id}
      takenAt={data.taken_at}
      success={data.success}
      error={data.error}
      commands={data.commands}
      showDownloadAll={false}
    />
  );
}

// 一括ダウンロードは表側に raw/parsed を持たないため、押された時点で
// GET .../full を取ってから組み立てる(ポップアップを開く場合と同じ取得元)。
const DOWNLOAD_KINDS = {
  raw: { label: "raw", run: downloadAllRaw },
  parsed: { label: "parsed", run: downloadAllParsed },
  all: { label: "全て", run: downloadEverything },
};

function RowDownloadButtons({ host, id, pendingKey, onPendingChange, onError }) {
  const handleClick = (kind) => {
    const key = `${host}:${id}:${kind}`;
    onPendingChange(key);
    getSnapshotFull(host, id)
      .then((data) => DOWNLOAD_KINDS[kind].run(data))
      .catch((e) => onError(e.message))
      .finally(() => onPendingChange(null));
  };

  return (
    <>
      {Object.entries(DOWNLOAD_KINDS).map(([kind, { label }]) => (
        <Button
          key={kind}
          size="sm"
          variant="outline"
          disabled={pendingKey === `${host}:${id}:${kind}`}
          onClick={(e) => {
            e.stopPropagation();
            handleClick(kind);
          }}
        >
          <Download /> {label}
        </Button>
      ))}
    </>
  );
}

const EMPTY_FILTERS = { host: "", status: "", since: "", until: "" };

export default function SnapshotListPage() {
  const [snapshots, setSnapshots] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filters, setFilters] = useState(EMPTY_FILTERS);
  const [selected, setSelected] = useState(null); // {host, id} | null。選択中は詳細をポップアップ表示する。
  const [pendingDownload, setPendingDownload] = useState(null); // "host:id:kind" | null
  const setFilter = (key) => (value) => {
    setPage(0);
    setFilters((prev) => ({ ...prev, [key]: value }));
  };

  useEffect(() => {
    setLoading(true);
    setError(null);
    listSnapshots({
      hostContains: filters.host || undefined,
      since: toBackendIso(filters.since) || undefined,
      until: toBackendIso(filters.until) || undefined,
      limit: PAGE_SIZE,
      offset: page * PAGE_SIZE,
    })
      .then((res) => {
        setSnapshots(res.items);
        setTotal(res.total);
      })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, [filters.host, filters.since, filters.until, page]);

  // ステータス(成功/失敗)はコア(healthcheck.storage)に絞り込み条件が無いため、
  // 現在のページの範囲内でのみクライアント側で絞り込む(host・取得時刻範囲とは
  // 違い、ページをまたいだ絞り込みにはならない)。
  const filtered = useMemo(() => {
    if (!filters.status) return snapshots;
    return snapshots.filter((s) => (s.success ? "成功" : "失敗") === filters.status);
  }, [snapshots, filters.status]);

  const { pageCount, rangeStart, rangeEnd } = usePageRange(total, page);

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          {loading ? "読み込み中..." : `${rangeStart}-${rangeEnd} / ${total} 件`}
        </p>
        <div className="flex items-center gap-2">
          <Pagination page={page} pageCount={pageCount} onPageChange={setPage} />
        </div>
      </div>
      {error && <p className="text-sm text-destructive">{error}</p>}

      {/* table-fixed: 展開行の raw/JSON はスペースも改行も無い1行の生データ
          (例: REST応答の生JSON)になることがあり、その場合 <pre> に
          overflow-auto を付けても、table-layout:auto の列幅計算は
          「折り返し不可能な内容の最小幅」を無視できない(overflow による
          最小幅0扱いは flex/grid 専用の仕様で、table には適用されない)ため、
          表全体が中身の幅まで伸びてしまう。table-fixed は列幅を中身から
          完全に切り離す(1行目の指定幅のみで決まる)ため、これを防げる。 */}
      <Table
        className="table-fixed"
        containerClassName="max-h-[78vh] overflow-y-auto rounded-md border bg-card"
      >
          <TableHeader className="sticky top-0 z-10 bg-muted">
            <TableRow>
              <TableHead className="w-[26%]">ホスト名</TableHead>
              <TableHead className="w-[42%]">取得時刻</TableHead>
              <TableHead className="w-[8%]">ステータス</TableHead>
              <TableHead className="w-[24%]">操作</TableHead>
            </TableRow>
            <TableRow className="hover:bg-transparent">
              <TableHead className="py-1.5">
                <TextFilter value={filters.host} onChange={setFilter("host")} placeholder="絞り込み" />
              </TableHead>
              <TableHead className="py-1.5">
                {/* 時刻が <input type="time"> 1つにまとまったことで since/until を
                    横並びにしても幅は収まるため、1行で表示する。 */}
                <div className="flex items-center gap-1">
                  <DateTime24Input value={filters.since} onChange={setFilter("since")} />
                  <span className="text-xs text-muted-foreground">〜</span>
                  <DateTime24Input value={filters.until} onChange={setFilter("until")} />
                </div>
              </TableHead>
              <TableHead className="py-1.5">
                <SelectFilter value={filters.status} onChange={setFilter("status")} options={["成功", "失敗"]} />
              </TableHead>
              <TableHead className="py-1.5" />
            </TableRow>
          </TableHeader>
          <TableBody>
            {filtered.map((s) => {
              const key = `${s.host}:${s.id}`;
              return (
                <TableRow key={key} className="cursor-pointer hover:bg-accent" onClick={() => setSelected({ host: s.host, id: s.id })}>
                  <TableCell className="font-medium">{s.host}</TableCell>
                  <TableCell>{formatDateTime(s.taken_at)}</TableCell>
                  <TableCell>
                    <Badge variant={s.success ? "success" : "destructive"}>{s.success ? "成功" : "失敗"}</Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-wrap gap-1">
                      <RowDownloadButtons
                        host={s.host}
                        id={s.id}
                        pendingKey={pendingDownload}
                        onPendingChange={setPendingDownload}
                        onError={setError}
                      />
                    </div>
                  </TableCell>
                </TableRow>
              );
            })}
            {!loading && filtered.length === 0 && (
              <TableRow>
                <TableCell colSpan={4} className="text-center text-sm text-muted-foreground">
                  該当する snapshot がありません
                </TableCell>
              </TableRow>
            )}
          </TableBody>
      </Table>

      <Dialog
        open={Boolean(selected)}
        onClose={() => setSelected(null)}
        title={selected ? `${selected.host} / ${selected.id}` : ""}
        className="max-w-8xl"
        contentClassName="max-h-[90vh]"
      >
        {selected && <SnapshotDetailLoader host={selected.host} snapshotId={selected.id} />}
      </Dialog>
    </div>
  );
}
